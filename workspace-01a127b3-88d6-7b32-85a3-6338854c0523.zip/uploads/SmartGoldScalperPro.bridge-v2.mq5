//+------------------------------------------------------------------+
//|                                         SmartGoldScalperPro.mq5  |
//|              Smart Gold Scalper Pro (SGS Professional MT5 EA)    |
//|                                                                  |
//| Single-file Expert Advisor for MetaTrader 5.                     |
//| Primary target: XAUUSD, M5. Hedging and Netting accounts.        |
//|                                                                  |
//| This EA is an independent engineering work based on a written    |
//| specification. It does NOT reproduce, reverse engineer or clone  |
//| any proprietary commercial product, and it makes NO claim of     |
//| profit, win-rate or drawdown guarantees.                         |
//|                                                                  |
//| Design goals:                                                    |
//|   - Deterministic, fail-safe lifecycle (init/trade/shutdown)     |
//|   - Explicit state machine with validated transitions            |
//|   - Versioned binary journal with CRC32, SHA-256 hash chain,     |
//|     commit records, conservative recovery and generation-based   |
//|     rotation (manifest + previous-generation terminal hash)      |
//|   - Instance lock to prevent incompatible concurrent instances   |
//|   - Reconciliation of terminal state before any trading          |
//|   - Layered risk management connected to every order path        |
//|                                                                  |
//| Build target: MetaTrader 5 / MetaEditor (build >= 3300), MQL5.   |
//| Compile expectation: 0 errors, 0 warnings (strict review done).  |
//+------------------------------------------------------------------+
#property copyright "SGS Project"
#property link      "https://local.projects/sgs"
#property version   "1.00"
#property description "Smart Gold Scalper Pro - XAUUSD M5 professional EA"
#property description "Binary hash-chained journal, generation rotation,"
#property description "instance lock, reconciliation, layered risk guards."
#property strict
//--- BRIDGE-INJECTED: اتصالِ خودکار به «برنامهٔ تحلیل» (توسطِ bridge_injector) ---
#include <RobotBridge.mqh>
input string InpBridgeURL = "http://127.0.0.1:8000"; // آدرسِ برنامه
input string InpSecret    = ""; // توکنِ مشترک
input int    InpTimeoutMs = 10000;   // مهلتِ درخواست (ms)
CRobotBridge bridge;   // شیءِ پُل
//--- پایانِ BRIDGE-INJECTED ---


//+------------------------------------------------------------------+
//| Version constants                                                |
//+------------------------------------------------------------------+
#define SGS_VERSION_TEXT   "1.00"
#define SGS_BUILD_TARGET   "MetaEditor build >= 3300 (single file, no includes)"

//+------------------------------------------------------------------+
//| Enumerations                                                     |
//+------------------------------------------------------------------+
enum ENUM_SGS_STATE            // lifecycle state machine
  {
   SGS_CREATED = 0,            // object constructed, nothing initialised
   SGS_INITIALIZING,           // OnInit in progress
   SGS_READY,                  // all subsystems healthy, idle allowed
   SGS_TRADING_ENABLED,        // may open new positions
   SGS_PAUSED,                 // healthy but deliberately not trading
   SGS_RECOVERY_REQUIRED,      // financial/data ambiguity -> no trading
   SGS_RECONCILING,            // reconciliation pass in progress
   SGS_FAULTED,                // unrecoverable fault -> no trading
   SGS_SHUTTING_DOWN,          // OnDeinit in progress
   SGS_STOPPED                 // deinitialised
  };

enum ENUM_SGS_DIR              // trade direction switch
  {
   DIR_BOTH = 0,               // allow long and short
   DIR_BUY_ONLY,               // allow long only
   DIR_SELL_ONLY               // allow short only
  };

enum ENUM_SGS_SIGNAL           // evaluated signal direction
  {
   SIGNAL_NONE = 0,
   SIGNAL_BUY  = 1,
   SIGNAL_SELL = 2,
   SIGNAL_CONFLICT = 3
  };

enum ENUM_SGS_RISK_MODE
  {
   RISK_FIXED_LOT = 0,         // fixed volume
   RISK_PERCENT    = 1         // percent of equity at risk per trade
  };

enum ENUM_SGS_SL_MODE
  {
   SL_ATR    = 0,              // stop distance = ATR * multiplier
   SL_POINTS = 1,              // stop distance = fixed points
   SL_STRUCT = 2               // stop distance = beyond latest confirmed swing pivot + ATR buffer
  };

enum ENUM_SGS_TP_MODE
  {
   TP_RR     = 0,              // take profit = R:R * stop distance
   TP_POINTS = 1,              // take profit = fixed points
   TP_NONE   = 2               // no take profit (exits by BE/trailing/time)
  };

enum ENUM_SGS_TRAIL_MODE
  {
   TRAIL_OFF    = 0,
   TRAIL_POINTS = 1,
   TRAIL_ATR    = 2,
   TRAIL_STRUCT = 3            // trail to latest confirmed swing pivot +/- ATR buffer
  };

enum ENUM_SGS_NEWS_IMPORTANCE  // MQL5 calendar importance levels
  {
   NEWS_HIGH_ONLY = 0,
   NEWS_MEDIUM_AND_HIGH = 1,
   NEWS_ALL = 2
  };

enum ENUM_SGS_DASH_THEME
  {
   THEME_DARK = 0,
   THEME_LIGHT = 1
  };

enum ENUM_SGS_DURABILITY       // journal durability classes
  {
   DUR_AUDIT     = 0,          // informational (signals, diagnostics)
   DUR_STATE     = 1,          // operational state
   DUR_FINANCIAL = 2           // money-moving facts
  };

enum ENUM_SGS_JR               // journal record types (uint16 domain)
  {
   JR_META_OPEN        = 1,    // journal opened/created (file meta)
   JR_SESSION_START    = 2,    // EA session started
   JR_SESSION_END      = 3,    // EA session ended cleanly
   JR_CONFIG           = 4,    // configuration snapshot
   JR_STATE            = 5,    // state machine transition
   JR_SIGNAL           = 6,    // signal evaluation summary
   JR_RISK_EVENT       = 7,    // risk guard decisions
   JR_GUARD            = 8,    // runtime guard (spread, DD, ...)
   JR_ORDER_REQUEST    = 9,    // order request snapshot (pre-send)
   JR_ORDER_RESULT     = 10,   // order send result
   JR_ORDER_ERROR      = 11,   // order failure / retcode
   JR_POSITION_OPEN    = 12,   // position opened (attributed)
   JR_POSITION_UPDATE  = 13,   // SL/TP / volume changes we performed
   JR_POSITION_CLOSE   = 14,   // position closed (attributed)
   JR_DEAL             = 15,   // deal accepted via OnTradeTransaction
   JR_RECONCILE        = 16,   // reconciliation report line
   JR_RECOVERY         = 17,   // journal/state recovery action
   JR_ROTATION_INTENT  = 18,   // rotation intent (pre-rotation)
   JR_ROTATION_DONE    = 19,   // rotation completed (post-rotation)
   JR_LOCK             = 20,   // instance lock events
   JR_MANUAL           = 21,   // manual / external modification detected
   JR_NEWS             = 22,   // news filter event
   JR_ERROR            = 23    // internal error record
  };

enum ENUM_SGS_SCAN             // binary journal scan result codes
  {
   SCAN_OK = 0,                // whole file valid
   SCAN_HEADER_TOO_SHORT,      // file smaller than header (physical partial header)
   SCAN_HEADER_BAD_MAGIC,
   SCAN_HEADER_BAD_VERSION,
   SCAN_HEADER_BAD_SIZE,
   SCAN_HEADER_BAD_CRC,
   SCAN_HEADER_INSTANCE_MISMATCH,
   SCAN_REC_SHORT_HEADER,      // EOF inside record header (physical partial tail)
   SCAN_REC_BAD_MAGIC,
   SCAN_REC_BAD_FORMAT,
   SCAN_REC_BAD_HEADER_SIZE,
   SCAN_REC_BAD_HEADER_CRC,
   SCAN_REC_PAYLOAD_TOO_BIG,
   SCAN_REC_SHORT_PAYLOAD,     // EOF inside payload (physical partial tail)
   SCAN_REC_BAD_PAYLOAD_CRC,
   SCAN_REC_BAD_HASH,
   SCAN_REC_PREVHASH_MISMATCH,
   SCAN_REC_SEQUENCE_MISMATCH,
   SCAN_REC_INSTANCE_MISMATCH,
   SCAN_REC_SESSION_ZERO,
   SCAN_REC_GENERATION_MISMATCH,
   SCAN_REC_SHORT_COMMIT,      // EOF inside commit trailer (physical partial tail)
   SCAN_REC_BAD_COMMIT,        // commit bytes present but wrong (full physical length, uncommitted)
   SCAN_IO_ERROR
  };

enum ENUM_SGS_REASON           // signal reason / decision codes (bitmask u32)
  {
   RSN_TREND_UP        = 0x00000001,
   RSN_TREND_DOWN      = 0x00000002,
   RSN_RSI_BULL_ZONE   = 0x00000004,
   RSN_RSI_BEAR_ZONE   = 0x00000008,
   RSN_RSI_CROSS_UP    = 0x00000010,
   RSN_RSI_CROSS_DOWN  = 0x00000020,
   RSN_CANDLE_BULL     = 0x00000040,
   RSN_CANDLE_BEAR     = 0x00000080,
   RSN_PULLBACK_BUY    = 0x00000100,
   RSN_PULLBACK_SELL   = 0x00000200,
   RSN_VOLATILITY_OK   = 0x00000400,
   RSN_SPREAD_OK       = 0x00000800,
   RSN_SESSION_OK      = 0x00001000,
   RSN_NEWS_CLEAR      = 0x00002000,
   RSN_ROLLOVER_CLEAR  = 0x00004000,
   RSN_HISTORY_OK      = 0x00008000,
   RSN_TREND_GATE_OK   = 0x00010000,
   RSN_HTF_OK          = 0x00020000,
   RSN_CLOSEPOS_OK     = 0x00040000,
   RSN_RSI_MOM_OK      = 0x00080000,
   RSN_NO_EXT_OK       = 0x00100000,
   RSN_SR_OK           = 0x00200000,
   RSN_FVG_OK          = 0x00400000,
   RSN_MSS_OK          = 0x00800000,
   RSN_EMASLOPE_OK     = 0x01000000,
   RSN_ADX_OK          = 0x02000000,
   RSN_MACD_OK         = 0x04000000,
   RSN_CANDLE_OK       = 0x08000000,
   RSN_SD_OK           = 0x10000000,
   RSN_LIQ_OK          = 0x20000000,
   RSN_GAP_OK          = 0x40000000,
   RSN_DAYHILO_OK      = (int)0x80000000
  };

//+------------------------------------------------------------------+
//| Journal binary format constants                                  |
//| Layout summary (little endian):                                  |
//|   FILE HEADER (128 bytes):                                       |
//|     0   char[8]  "SGSJOURN"                                      |
//|     8   u16 major=1   10 u16 minor=0   12 u32 header_size=128    |
//|     16  u64 instance_id   24 u64 created_ts   32 u64 generation  |
//|     40  u8[32] prev_generation_terminal_hash (zeros if gen 0)    |
//|     72  u8[52] reserved (zeros)   124 u32 header_crc32 (0..123)  |
//|   RECORD HEADER (136 bytes):                                     |
//|     0   u32 magic = 0x43524753 ('SGRC')                          |
//|     4   u16 rec_format=1   6 u16 header_size=136                 |
//|     8   u16 record_type    10 u16 flags                          |
//|     12  u8  durability     13 u8[3] pad                          |
//|     16  u64 sequence       24 u64 timestamp_sec                  |
//|     32  u32 timestamp_msc  36 u32 payload_size                   |
//|     40  u64 instance_id    48 u64 session_id   56 u64 generation |
//|     64  u32 payload_crc32                                        |
//|     68  u8[32] prev_record_hash (zeros for first record)         |
//|     100 u8[32] record_hash = SHA256(header[0..99] || payload)    |
//|     132 u32 header_crc32 = CRC32(header[0..131])                 |
//|   PAYLOAD (payload_size <= limit, utf-8 "k=v;..." or binary)     |
//|   COMMIT (8 bytes) "SGSCOMT1" - written+flushed last.            |
//+------------------------------------------------------------------+
#define SGS_JOURNAL_MAGIC_TEXT   "SGSJOURN"
#define SGS_MANIFEST_MAGIC_TEXT  "SGSJMAN1"
#define SGS_COMMIT_MAGIC_TEXT    "SGSCOMT1"
#define SGS_REC_MAGIC            0x43524753
#define SGS_FORMAT_MAJOR         1
#define SGS_FORMAT_MINOR         0
#define SGS_FILE_HEADER_SIZE     128
#define SGS_REC_HEADER_SIZE      136
#define SGS_COMMIT_SIZE          8
#define SGS_MANIFEST_SIZE        180
#define SGS_MAX_PAYLOAD_HARD     65536
#define SGS_COPY_CHUNK           4096
#define SGS_MAX_LOCK_AGE_SEC     10
#define SGS_ENTRY_GAP_POINTS     0.0   // market orders: no gap

//+------------------------------------------------------------------+
//| Inputs                                                           |
//+------------------------------------------------------------------+
input group "===== General ====="
input ENUM_SGS_DIR   InpTradeDirection        = DIR_BOTH;            // Allowed trade direction
input long           InpMagicNumber           = 550011;              // Magic number (1..2000000000)
input string         InpTradeComment          = "SGSPro";            // Order comment (<=24 chars)
input bool           InpDryRun                = false;               // Dry-run: full logic, no real orders

input group "===== Symbol and Timeframe ====="
input string         InpSymbol                = "";                  // Symbol (empty = chart symbol)
input ENUM_TIMEFRAMES InpTimeframe            = PERIOD_M5;           // Working timeframe
input bool           InpAllowOtherSymbols     = true;                // Allow symbols other than XAU/GOLD
input int            InpBarsRequired          = 300;                 // Minimum bars required on timeframe

input group "===== Strategy ====="
input int            InpEmaFastPeriod         = 20;                  // EMA fast period (2..500)
input int            InpEmaSlowPeriod         = 50;                  // EMA slow period (3..1000, > fast)
input int            InpRsiPeriod             = 14;                  // RSI period (2..100)
input int            InpAtrPeriod             = 14;                  // ATR period (2..200)
input double         InpBodyConfirmRatio      = 0.55;                // Min body/range of signal candle (0..1)
input double         InpPullbackAtrMult       = 0.50;                // Pullback: |close-EMAfast| <= mult*ATR (0.05..5)
input double         InpRsiBullMin            = 52.0;                // RSI buy zone lower bound (30..70)
input double         InpRsiBullMax            = 75.0;                // RSI buy zone upper bound (50..90)
input double         InpRsiBearMin            = 25.0;                // RSI sell zone lower bound (10..50)
input double         InpRsiBearMax            = 48.0;                // RSI sell zone upper bound (30..70)

input group "===== Signal Scoring ====="
input int            InpMinScoreToTrade       = 60;                  // Min score to trade (1..100)
input double         InpMinConfidence         = 0.60;                // Min confidence score/max (0..max achievable)
input int            InpSignalCooldownSec     = 120;                 // Cooldown between signals, seconds (0..86400)
input bool           InpOneTradePerBar        = true;                // Only one entry per closed bar
input bool           InpUseHtfTrendConfirm    = false;               // Precision: require HTF trend alignment with entry side
input ENUM_TIMEFRAMES InpHtfTimeframe         = PERIOD_H1;           // HTF for trend confirm (must exceed working TF)
input bool           InpUseClosePosFilter     = false;               // Precision: require strong close location in the signal candle
input double         InpMinClosePosRatio      = 0.60;                // Close position in range: buy >= x, sell <= 1-x (0.50..0.95)
input bool           InpUseRsiMomentumFilter  = false;               // Precision: require RSI slope toward the signal direction
input bool           InpUseExtensionFilter    = false;               // Precision: block entries overextended from EMA fast
input double         InpMaxExtensionAtrMult   = 1.50;                // Max |close1-EMAfast1| / ATR1 for entry (0.10..20.00)

input group "===== Structure Filters ====="   // round-12: swing S/R space + FVG (all default OFF, strictly additive)
input bool           InpUseSwingSRFilter      = false;               // Structure: require clear space to nearest swing S/R level
input int            InpSrLookbackBars        = 200;                 // Swing S/R scan depth, closed bars (20..5000, <= InpBarsRequired-radius-4)
input int            InpSrPivotRadius         = 2;                   // Pivot radius (bars each side, 1..10)
input double         InpMinSpaceToLevelAtrMult= 0.75;                // Min distance to nearest S/R level, ATR multiples (0.00..10.00)
input bool           InpUseFvgFilter          = false;               // Structure: require fresh unmitigated FVG aligned with entry side
input int            InpFvgLookbackBars       = 30;                  // FVG max age, closed bars (3..1000; <= InpBarsRequired-4)
input double         InpMinFvgSizeAtrMult     = 0.10;                // Min FVG height, ATR multiples (0.00..5.00; 0=any)
input bool           InpUseMssFilter          = false;               // Structure: require BOS/CHoCH market-structure bias aligned with entry
input int            InpMssLookbackBars       = 100;                 // MSS pivot scan depth, closed bars (20..5000; uses InpSrPivotRadius)

input group "===== Advanced Signal Models ====="   // round-14 confirmations (all default OFF, strictly additive)
input bool           InpUseEmaSlopeFilter       = false;               // Models: require EMA-fast slope toward the signal direction
input bool           InpUseAdxFilter            = false;               // Models: ADX trend strength + DI direction confirm
input int            InpAdxPeriod               = 14;                  // ADX period (2..200)
input double         InpAdxMin                  = 20.0;                // Min ADX for a tradable trend (5.0..60.0)
input bool           InpUseMacdFilter           = false;               // Models: MACD main/signal alignment confirm
input int            InpMacdFast                = 12;                  // MACD fast EMA (2..200, < slow)
input int            InpMacdSlow                = 26;                  // MACD slow EMA (3..400)
input int            InpMacdSignal              = 9;                   // MACD signal SMA (1..100)
input bool           InpUseCandlePatternFilter  = false;               // Models: engulfing / pin-bar pattern confirm on the signal candle
input bool           InpUseSupplyDemandFilter   = false;               // Models: unmitigated supply/demand zone confirm (impulse out of base)
input double         InpSdImpulseAtrMult        = 1.50;                // SD impulse body >= x*ATR (0.30..10.00)
input int            InpSdZoneMaxAgeBars        = 60;                  // SD zone max age, closed bars (3..2000)
input bool           InpUseLiquidityFilter      = false;               // Models: equal highs/lows (liquidity pool) proximity block
input double         InpLiqToleranceAtrMult     = 0.10;                // Equal-level tolerance, ATR multiples (0.01..1.00)
input double         InpLiqProximityAtrMult     = 0.50;                // Block entries closer than x*ATR to the pool (0.05..10.00)
input int            InpLiqLookbackBars         = 60;                  // Liquidity scan depth, closed bars (10..2000)

input group "===== Filters ====="
input bool           InpUseSpreadFilter       = true;                // Enable spread filter
input int            InpPipSizePoints        = 10;                  // Points per pip (XAUUSD convention: 10)
input int            InpMaxSpreadPips         = 25;                  // Max spread in pips (1..10000)
input bool           InpUseVolatilityFilter   = true;                // Enable ATR volatility gate
input double         InpAtrFilterMinPips      = 3.0;                 // Min ATR in pips (0=off)
input double         InpAtrFilterMaxPips      = 200.0;               // Max ATR in pips (0=off)
input bool           InpUseTrendGate          = false;               // Hard trend gate (else trend is scored)
input bool           InpUseNewsFilter         = false;               // Enable news filter (MQL5 calendar)
input int            InpNewsBlockBeforeMin    = 30;                  // Block minutes before event (0..720)
input int            InpNewsBlockAfterMin     = 30;                  // Block minutes after event (0..720)
input ENUM_SGS_NEWS_IMPORTANCE InpNewsMinImportance = NEWS_HIGH_ONLY;// Minimum event importance
input string         InpNewsCurrency          = "USD";               // Event currency (XAU quoted in USD)
input string         InpNewsExtraCurrencies   = "";                  // Extra currencies, comma-separated (e.g. "EUR,GBP"; empty = InpNewsCurrency only)
input bool           InpNewsBlockWhenUnavailable = true;             // Fail-closed if calendar unavailable (live only)

input bool           InpUseGapJumpFilter        = false;               // Filter: block entries after an oversized bar gap/jump
input double         InpMaxBarGapAtrMult        = 0.50;                // Max |open1-close2| in ATR multiples (0.05..10.00)
input bool           InpUseDayHiLoFilter        = false;               // Filter: require distance from day high/low before entry
input double         InpDayHiLoMinDistAtrMult   = 0.30;                // Min distance to day extreme, ATR multiples (0.05..10.00)

input group "===== Sessions ====="
input bool           InpUseSessionFilter      = true;                // Enable session filter (server time)
input string         InpSessionStart          = "08:00";             // Session start "HH:MM" (server)
input string         InpSessionEnd            = "21:00";             // Session end "HH:MM" (server, overnight ok)
input bool           InpTradeMonday           = true;                // Trade on Monday
input bool           InpTradeTuesday          = true;                // Trade on Tuesday
input bool           InpTradeWednesday        = true;                // Trade on Wednesday
input bool           InpTradeThursday         = true;                // Trade on Thursday
input bool           InpTradeFriday           = true;                // Trade on Friday
input bool           InpUseRolloverFilter     = true;                // Enable rollover exclusion window
input string         InpRolloverStart         = "23:55";             // Rollover block start "HH:MM"
input string         InpRolloverEnd           = "00:10";             // Rollover block end "HH:MM" (next day ok)

input group "===== Risk ====="
input ENUM_SGS_RISK_MODE InpRiskMode          = RISK_PERCENT;        // Position sizing mode
input double         InpFixedLot              = 0.01;                // Fixed lot (RISK_FIXED_LOT mode)
input double         InpRiskPercentPerTrade   = 0.50;                // Risk % of equity per trade (0.01..10)
input double         InpMaxRiskPercentPerTrade= 2.00;                // Hard cap for single-trade risk %
input double         InpMaxTotalRiskPercentOpen = 3.00;              // Max summed open risk % (0=off)
input int            InpMaxOpenPositions      = 3;                   // Max concurrent positions (1..100; only used when InpOnePositionPerSymbol=false)
input bool           InpOnePositionPerSymbol  = true;                // Only one managed position open at a time
input double         InpMaxExposureLotsPerDir = 5.0;                 // Max summed lots per direction (0=off)
input int            InpConsecLossLimit       = 3;                   // Consecutive losses pause limit (0=off)
input int            InpLossCooldownMinutes   = 60;                  // Cooldown after loss-limit hit (1..10080)
input double         InpMinFreeMarginAfterPct = 30.0;                // Min free margin left after trade (% of equity)

input group "===== Orders ====="
input int            InpDeviationPips         = 3;                   // Max deviation/slippage on send (pips; converted to points internally)
input int            InpOrderRetryMax         = 2;                   // Max retries for retryable retcodes (0..5)
input int            InpRetryBackoffMs        = 400;                 // Backoff between retries (ms, 50..10000)
input bool           InpUseOrderCalcProfitSizing= false;               // Sizing: refine lot via exact OrderCalcProfit loss per lot at live prices

input group "===== Stops and Targets ====="
input ENUM_SGS_SL_MODE InpSlMode              = SL_ATR;              // Stop-loss mode
input double         InpAtrSlMult             = 2.00;                // SL distance = ATR * mult (0.10..20)
input int            InpSlPips                = 35;                  // SL distance in pips (SL_POINTS mode)
input ENUM_SGS_TP_MODE InpTpMode              = TP_RR;               // Take-profit mode
input double         InpRewardRiskRatio       = 1.80;                // R:R for TP_RR mode (0.10..50)
input double         InpMinRewardRiskRatio    = 1.20;                // Min accepted R:R (validation, 0.10..50)
input int            InpTpPips                = 70;                  // TP distance in pips (TP_POINTS mode)
input double         InpStructSlBufferAtrMult   = 0.25;                // SL_STRUCT: buffer beyond the swing pivot (0.00..5.00 ATR)
input double         InpStructSlMaxAtrMult      = 3.00;                // SL_STRUCT: max accepted distance, else ATR fallback (0.50..20.00)

input group "===== Break-even ====="
input bool           InpUseBreakEven          = true;                // Enable break-even move
input int            InpBeTriggerPips         = 20;                  // BE trigger profit (pips, 1..10000)
input double         InpBeOffsetPips          = 3.0;                 // BE offset beyond entry (pips, 0..1000)
input int            InpBe2TriggerPips          = 0;                   // BE stage-2 trigger profit (pips, 0=off, else 1..100000)
input double         InpBe2LockPips             = 15.0;                // BE stage-2 locked profit beyond entry (0.0..10000)

input group "===== Trailing ====="
input ENUM_SGS_TRAIL_MODE InpTrailMode        = TRAIL_ATR;           // Trailing mode
input int            InpTrailStartPips        = 30;                  // Trailing activation profit (pips)
input double         InpTrailStepPips         = 6.0;                 // Min trailing improvement step (pips)
input double         InpTrailAtrMult          = 1.50;                // Trailing distance = ATR * mult (TRAIL_ATR)
input int            InpTrailDistancePips     = 20;                  // Trailing distance behind price, pips (TRAIL_POINTS; 1..100000)
input double         InpStructTrailBufferAtrMult= 0.25;                // TRAIL_STRUCT: buffer beyond the swing pivot (0.00..5.00 ATR)

input group "===== Adaptive Exits ====="
input bool           InpUseMomentumDecayExit    = false;               // Exit: close when RSI moves against the position N consecutive closed bars
input int            InpMomentumDecayBars       = 2;                   // Consecutive decaying bars to exit (1..20)

input group "===== Partial Close ====="
input bool           InpUsePartialClose       = true;                // Enable partial close
input int            InpPartialTriggerPips    = 30;                  // Partial close trigger profit (pips)
input double         InpPartialClosePercent   = 50.0;                // Partial close percent (1..99)

input group "===== Daily Limits ====="
input int            InpMaxTradesPerDay       = 20;                  // Max entries per day (0=off, else 1..500)
input double         InpMaxDailyLossPercent   = 3.0;                 // Max daily loss % of day-start equity (0=off)
input int            InpMaxTradeDurationMin   = 240;                 // Time-based exit, minutes (0=off)
input double         InpMaxWeeklyLossPercent    = 0.0;                 // Max weekly realised loss % of week-start equity (0=off; else 0.10..100)
input double         InpDailyProfitTargetPercent= 0.0;                 // Daily realised profit target % of day-start equity, then stop new entries (0=off)
input bool           InpUseDayProfitLock        = false;               // Lock a winning day: pause new entries when realised P/L retraces from its day peak
input double         InpDayProfitLockActivatePct= 0.50;                // Arm the lock when day peak realised profit >= this % of day-start equity (0.01..100)
input double         InpDayProfitLockRetracePct = 50.0;                // Lock trigger: realised P/L falls to <= (100-x)% of its day-peak profit (1..99)
input bool           InpUseOppositeSignalExit = false;               // Exit on opposite qualifying signal

input group "===== Drawdown Protection ====="
input bool           InpEquityProtectEnabled  = true;                // Enable equity/DD protection
input double         InpMaxDailyDDPercent     = 4.0;                 // Max daily drawdown % (0=off)
input double         InpMaxTotalDDPercent     = 10.0;                // Max total drawdown % from peak (hard guard)
input bool           InpCloseOnHardGuard      = true;                // Emergency-close positions on total-DD breach
input double         InpPeakEquityFloor       = 0.0;                 // Manual peak equity seed (0=auto)

input group "===== Journal ====="
input bool           InpJournalEnabled        = true;                // Enable binary journal
input string         InpJournalFileName       = "SGSProJournal.dat"; // Journal file name (relative to MQL5/Files)
input int            InpJournalMaxPayloadBytes= 4096;                // Max payload bytes per record (64..65536)
input int            InpJournalMaxFileMB      = 16;                  // Rotate when journal exceeds this size (MB, 1..512)
input bool           InpJournalSelfTestOnOpen = true;                // Full journal verification on open

input bool           InpCsvReportEnabled        = false;               // Also append closed-deal rows to a CSV report file (MQL5/Files)
input string         InpCsvReportFile           = "SGS_Trades.csv";    // CSV report file name (1..60 chars, must end .csv)

input group "===== Recovery ====="
input bool           InpRecoveryAllowTailTruncate = true;            // Auto-truncate ONLY physical partial tail
input bool           InpRecoveryAdoptOrphans  = true;                // Adopt orphaned positions (else RECOVERY_REQUIRED)
input bool           InpRespectManualChanges  = true;                // Stop auto-managing manually modified positions

input group "===== Rotation ====="
input bool           InpRotationEnabled       = true;                // Enable generation-based rotation
input int            InpJournalBackups        = 3;                   // Archived generations to keep (1..20)

input group "===== Dashboard ====="
input bool           InpDashboardEnabled      = true;                // Show chart dashboard
input int            InpDashboardX            = 16;                  // Panel X (px, 0..4000)
input int            InpDashboardY            = 28;                  // Panel Y (px, 0..4000)
input int            InpDashboardRefreshSec   = 1;                   // Refresh interval (sec, 1..60)
input ENUM_SGS_DASH_THEME InpDashboardTheme   = THEME_DARK;          // Colour theme
input int            InpDashboardScalePercent = 100;                 // Font scale (50..200)
input bool           InpShowFilterScoreboard  = false;               // Show ACTIVE filters + their assigned score weights in one dashboard row (round-26)

input group "===== Diagnostics ====="
input bool           InpSelfTestOnInit        = true;                // Known-answer tests (CRC32/SHA-256) on init
input int            InpMaxConsecutiveErrors  = 5;                   // Fault after N consecutive op errors (1..50)
input bool           InpVerboseJournal        = false;               // Also journal non-trading signal evaluations

input group "===== Testing ====="
input int            InpSelfTestDummyRecords  = 0;                   // Append N dummy audit records at init (QA, 0..100)
input bool           InpDisableNewsFilterInTester = true;            // Auto-disable news filter inside Strategy Tester

//+------------------------------------------------------------------+
//| Small shared structs (must precede all classes)                  |
//+------------------------------------------------------------------+
struct SGsDerived                      // validated+parsed configuration
  {
   string   symbol;                    // resolved trading symbol (after broker-name tolerance)
   string   symbolRaw;                 // user input as typed (pre-resolution), for audit
   string   comment;                   // clamped order comment
   int      sessionStartMin;           // minutes of day, server time
   int      sessionEndMin;
   int      rollStartMin;
   int      rollEndMin;
   bool     dayAllowed[7];             // index per MqlDateTime.day_of_week
  };

struct SGsRuntime                      // mutable runtime state (single instance)
  {
   ENUM_SGS_STATE state;
   ulong    instanceId;                // deterministic per (account,symbol,magic,file)
   ulong    sessionId;                 // unique per launch, never zero
   bool     initOk;
   bool     reconciled;                // reconciliation fully passed
   bool     journalHealthy;
   bool     lockOwned;
   string   lastError;
   int      consecutiveErrors;
   // signal bookkeeping
   datetime lastSignalBarTime;
   int      lastSignalDir;             // ENUM_SGS_SIGNAL
   datetime lastSignalTime;            // cooldown anchor
   double   lastSignalConf;
   // risk bookkeeping
   int      dayKey;                    // yyyymmdd of current accounting day
   double   dayStartEquity;
   double   dayClosedPnl;              // closed P/L of current day (our magic)
   double   dayPeakClosedPnl;          // round-23: running peak of today's realised closed P/L (rebuilt from history)
   int      dayTradeCount;
   int      weekKey;                   // yyyymmdd of the Monday of the current accounting week
   double   weekStartEquity;
   double   weekClosedPnl;             // closed P/L of current week (our magic)
   int      dayWins, dayLosses;        // round-15: realised win/loss counts of the current day (deal-based)
   int      consecLosses;
   datetime lossCooldownUntil;
   datetime streakEpoch;             // R9-2: losses closed at/before this time are excluded from the running streak
   double   peakEquity;
   bool     hardGuardHit;
  };

SGsDerived g_cfg;
SGsRuntime g_rt;

//+------------------------------------------------------------------+
//| Utility functions                                                |
//+------------------------------------------------------------------+
uint SgsCrcTable(const int idx)        // lazy-built CRC32 (IEEE, poly 0xEDB88320)
  {
   static uint  t[256];
   static bool  t_init = false;
   if(!t_init)
     {
      for(uint n2 = 0; n2 < 256; n2++)
        {
         uint c = n2;
         for(int k = 0; k < 8; k++)
           {
            if((c & 1) != 0) c = 0xEDB88320 ^ (c >> 1);
            else             c = c >> 1;
           }
         t[n2] = c;
        }
      t_init = true;
     }
   return(t[idx]);
  }
//---
uint SgsCrc32Begin() { return(0xFFFFFFFF); }
//---
uint SgsCrc32Add(uint crc, const uchar &data[], const int start, const int len)
  {
   int lim = start + len;
   for(int i = start; i < lim; i++)
      crc = SgsCrcTable((crc ^ data[i]) & 0xFF) ^ (crc >> 8);
   return(crc);
  }
//---
uint SgsCrc32End(uint crc) { return(~crc); }
//---
uint SgsCrc32Of(const uchar &data[])   // convenience: CRC32 over whole array
  {
   return(SgsCrc32End(SgsCrc32Add(SgsCrc32Begin(), data, 0, ArraySize(data))));
  }
//---
uint SgsCrc32OfString(const string s)  // known-answer testing helper
  {
   uchar b[];
   int n = StringToCharArray(s, b, 0, WHOLE_ARRAY, CP_UTF8);
   if(n > 0) n--;                      // drop trailing zero
   return(SgsCrc32End(SgsCrc32Add(SgsCrc32Begin(), b, 0, n)));
  }
//+------------------------------------------------------------------+
//| SHA-256 via MQL5 built-in CryptEncode (no external dependency).  |
//| Output array must already hold at least 32 bytes.                |
//+------------------------------------------------------------------+
bool SgsSha256(const uchar &data[], uchar &out32[])
  {
   if(ArraySize(out32) < 32) return(false);
   uchar key[];
   ArrayResize(key, 1); key[0] = 0;    // ignored for HASH methods
   uchar tmp[];
   ArrayResize(tmp, 64);
   int n = CryptEncode(CRYPT_HASH_SHA256, data, key, tmp);
   if(n != 32) return(false);
   for(int i = 0; i < 32; i++) out32[i] = tmp[i];
   return(true);
  }
//---
bool SgsSha256Pair(const uchar &a[], const uchar &b[], uchar &out32[])
  {
   uchar joined[];
   int na = ArraySize(a), nb = ArraySize(b);
   ArrayResize(joined, na + nb);
   for(int i = 0; i < na; i++) joined[i] = a[i];
   for(int j = 0; j < nb; j++) joined[na + j] = b[j];
   return(SgsSha256(joined, out32));
  }
//---
string SgsHex(const uchar &data[], const int count)
  {
   string s = "";
   int lim = (int)MathMin((long)count, (long)ArraySize(data));
   for(int i = 0; i < lim; i++)
      s += StringFormat("%02x", data[i]);
   return(s);
  }
//---
bool SgsBytesEqual(const uchar &a[], const uchar &b[], const int count)
  {
   if(ArraySize(a) < count || ArraySize(b) < count) return(false);
   for(int i = 0; i < count; i++) if(a[i] != b[i]) return(false);
   return(true);
  }
//---
void SgsBytesZero(uchar &a[], const int count)
  {
   int lim = (int)MathMin((long)count, (long)ArraySize(a));
   for(int i = 0; i < lim; i++) a[i] = 0;
  }
//---
void SgsBytesCopy(uchar &dst[], const int dstOff, const uchar &src[], const int count)
  {
   for(int i = 0; i < count; i++) dst[dstOff + i] = src[i];
  }
//---
bool SgsBytesAreZero(const uchar &a[], const int count)
  {
   for(int i = 0; i < count; i++) if(a[i] != 0) return(false);
   return(true);
  }
//---
long SgsNowSec()          { return((long)TimeCurrent()); }
uint SgsNowMsc()          { return((uint)((GetMicrosecondCount() / 1000) % 1000)); }
//---
string SgsSafeFilePart(const string s) // strips path separators from a file name
  {
   string r = s;
   StringReplace(r, "/", "_");
   StringReplace(r, "\\", "_");
   StringReplace(r, ":", "_");
   return(r);
  }
//---
bool SgsParseHHMM(const string s, int &minutesOfDay)
  {
   minutesOfDay = -1;
   if(StringLen(s) != 5) return(false);
   if(StringGetCharacter(s, 2) != ':') return(false);
   int hh = (int)StringToInteger(StringSubstr(s, 0, 2));
   int mm = (int)StringToInteger(StringSubstr(s, 3, 2));
   if(hh < 0 || hh > 23 || mm < 0 || mm > 59) return(false);
   string digits = "0123456789:";
   for(int i = 0; i < 5; i++)
     {
      if(StringFind(digits, StringSubstr(s, i, 1)) < 0) return(false);
     }
   minutesOfDay = hh * 60 + mm;
   return(true);
  }
//---
int SgsMinutesOfDay(const datetime t)  // server-time minutes since midnight
  {
   MqlDateTime dt;
   TimeToStruct(t, dt);
   return(dt.hour * 60 + dt.min);
  }
//---
bool SgsInWindow(const int nowMin, const int startMin, const int endMin) // overnight aware
  {
   if(startMin < 0 || endMin < 0) return(true);
   if(startMin == endMin) return(false);
   if(startMin < endMin)  return(nowMin >= startMin && nowMin < endMin);
   return(nowMin >= startMin || nowMin < endMin);
  }
//---
int SgsDayKey(const datetime t)
  {
   MqlDateTime dt;
   TimeToStruct(t, dt);
   return(dt.year * 10000 + dt.mon * 100 + dt.day);
  }
//---
datetime SgsDayStart(const datetime t)
  {
   MqlDateTime dt;
   TimeToStruct(t, dt);
   dt.hour = 0; dt.min = 0; dt.sec = 0;
   return(StructToTime(dt));
  }
//---
datetime SgsWeekStart(const datetime t)      // Monday 00:00 (server time axis) of the week containing t
  {
   MqlDateTime dt;
   TimeToStruct(t, dt);
   int back = (dt.day_of_week == 0 ? 6 : dt.day_of_week - 1);   // MQL5: 0=Sunday..6=Saturday
   return(SgsDayStart(t - (datetime)back * 86400));
  }
//---
int SgsWeekKey(const datetime t) { return(SgsDayKey(SgsWeekStart(t))); }
//---
// CSV trade report (round-14, opt-in): one row per CLOSED deal of our magic+symbol.
// File lives in MQL5/Files like the rest of the EA artifacts; header written once.
void SgsCsvAppendClosedDeal(const ulong deal, const ulong pid, const long dtype,
                            const double vol, const double prc, const double pnlNet,
                            const string reason,
                            const double entryPrice = 0.0, const double sl = 0.0,
                            const double tp = 0.0, const datetime openTime = 0)
  {
   if(!InpCsvReportEnabled) return;
   if(InpCsvReportFile == "") return;
   bool created = !FileIsExist(InpCsvReportFile);
   // (round-27 fix 5): FILE_WRITE without FILE_READ truncates the existing file on
   // open in MQL5 — every row used to wipe the report. FILE_READ|FILE_WRITE keeps
   // contents so the SEEK_END append actually appends.
   int h = FileOpen(InpCsvReportFile, FILE_READ | FILE_WRITE | FILE_CSV | FILE_ANSI, ',');
   if(h == INVALID_HANDLE) return;
   FileSeek(h, 0, SEEK_END);
   if(created || FileSize(h) == 0)
      FileWrite(h, "time", "deal", "position_id", "type", "volume", "price", "pnl_net", "reason",
                    "entry_price", "sl", "tp", "open_time");
   FileWrite(h, TimeToString(TimeCurrent(), TIME_DATE | TIME_SECONDS),
             (long)deal, (long)pid, (int)dtype,
             DoubleToString(vol, 2), DoubleToString(prc, g_sym.Digits()),
             DoubleToString(pnlNet, 2), reason,
             (entryPrice > 0.0 ? DoubleToString(entryPrice, g_sym.Digits()) : ""),
             (sl > 0.0 ? DoubleToString(sl, g_sym.Digits()) : ""),
             (tp > 0.0 ? DoubleToString(tp, g_sym.Digits()) : ""),
             (openTime > 0 ? TimeToString(openTime, TIME_DATE | TIME_SECONDS) : ""));
   FileClose(h);
  }
//---
string SgsStateName(const ENUM_SGS_STATE s)
  {
   switch(s)
     {
      case SGS_CREATED:           return("CREATED");
      case SGS_INITIALIZING:      return("INITIALIZING");
      case SGS_READY:             return("READY");
      case SGS_TRADING_ENABLED:   return("TRADING_ENABLED");
      case SGS_PAUSED:            return("PAUSED");
      case SGS_RECOVERY_REQUIRED: return("RECOVERY_REQUIRED");
      case SGS_RECONCILING:       return("RECONCILING");
      case SGS_FAULTED:           return("FAULTED");
      case SGS_SHUTTING_DOWN:     return("SHUTTING_DOWN");
      case SGS_STOPPED:           return("STOPPED");
     }
   return("UNKNOWN");
  }
//---
string SgsDirText(const int d)
  {
   if(d == (int)SIGNAL_BUY)  return("BUY");
   if(d == (int)SIGNAL_SELL) return("SELL");
   if(d == (int)SIGNAL_CONFLICT) return("CONFLICT");
   return("NONE");
  }
//---
string SgsScanCodeName(const int c)
  {
   switch((ENUM_SGS_SCAN)c)
     {
      case SCAN_OK:                      return("OK");
      case SCAN_HEADER_TOO_SHORT:        return("HEADER_TOO_SHORT");
      case SCAN_HEADER_BAD_MAGIC:        return("HEADER_BAD_MAGIC");
      case SCAN_HEADER_BAD_VERSION:      return("HEADER_BAD_VERSION");
      case SCAN_HEADER_BAD_SIZE:         return("HEADER_BAD_SIZE");
      case SCAN_HEADER_BAD_CRC:          return("HEADER_BAD_CRC");
      case SCAN_HEADER_INSTANCE_MISMATCH:return("HEADER_INSTANCE_MISMATCH");
      case SCAN_REC_SHORT_HEADER:        return("REC_SHORT_HEADER");
      case SCAN_REC_BAD_MAGIC:           return("REC_BAD_MAGIC");
      case SCAN_REC_BAD_FORMAT:          return("REC_BAD_FORMAT");
      case SCAN_REC_BAD_HEADER_SIZE:     return("REC_BAD_HEADER_SIZE");
      case SCAN_REC_BAD_HEADER_CRC:      return("REC_BAD_HEADER_CRC");
      case SCAN_REC_PAYLOAD_TOO_BIG:     return("REC_PAYLOAD_TOO_BIG");
      case SCAN_REC_SHORT_PAYLOAD:       return("REC_SHORT_PAYLOAD");
      case SCAN_REC_BAD_PAYLOAD_CRC:     return("REC_BAD_PAYLOAD_CRC");
      case SCAN_REC_BAD_HASH:            return("REC_BAD_HASH");
      case SCAN_REC_PREVHASH_MISMATCH:   return("REC_PREVHASH_MISMATCH");
      case SCAN_REC_SEQUENCE_MISMATCH:   return("REC_SEQUENCE_MISMATCH");
      case SCAN_REC_INSTANCE_MISMATCH:   return("REC_INSTANCE_MISMATCH");
      case SCAN_REC_SESSION_ZERO:        return("REC_SESSION_ZERO");
      case SCAN_REC_GENERATION_MISMATCH: return("REC_GENERATION_MISMATCH");
      case SCAN_REC_SHORT_COMMIT:        return("REC_SHORT_COMMIT");
      case SCAN_REC_BAD_COMMIT:          return("REC_BAD_COMMIT");
      case SCAN_IO_ERROR:                return("IO_ERROR");
     }
   return("SCAN_UNKNOWN");
  }
//---
bool SgsScanIsPhysicalTail(const int c) // ONLY these may auto-truncate
  {
   return(c == (int)SCAN_REC_SHORT_HEADER ||
          c == (int)SCAN_REC_SHORT_PAYLOAD ||
          c == (int)SCAN_REC_SHORT_COMMIT);
  }
//---
string SgsReasonBitsToText(const uint bits)
  {
   string s = "";
   if((bits & (uint)RSN_TREND_UP)       != 0) s += "TREND_UP|";
   if((bits & (uint)RSN_TREND_DOWN)     != 0) s += "TREND_DOWN|";
   if((bits & (uint)RSN_RSI_BULL_ZONE)  != 0) s += "RSI_BULL|";
   if((bits & (uint)RSN_RSI_BEAR_ZONE)  != 0) s += "RSI_BEAR|";
   if((bits & (uint)RSN_RSI_CROSS_UP)   != 0) s += "RSI_XUP|";
   if((bits & (uint)RSN_RSI_CROSS_DOWN) != 0) s += "RSI_XDOWN|";
   if((bits & (uint)RSN_CANDLE_BULL)    != 0) s += "CANDLE_BULL|";
   if((bits & (uint)RSN_CANDLE_BEAR)    != 0) s += "CANDLE_BEAR|";
   if((bits & (uint)RSN_PULLBACK_BUY)   != 0) s += "PULLBACK_BUY|";
   if((bits & (uint)RSN_PULLBACK_SELL)  != 0) s += "PULLBACK_SELL|";
   if((bits & (uint)RSN_VOLATILITY_OK)  != 0) s += "VOL_OK|";
   if((bits & (uint)RSN_SPREAD_OK)      != 0) s += "SPREAD_OK|";
   if((bits & (uint)RSN_SESSION_OK)     != 0) s += "SESSION_OK|";
   if((bits & (uint)RSN_NEWS_CLEAR)     != 0) s += "NEWS_CLEAR|";
   if((bits & (uint)RSN_ROLLOVER_CLEAR) != 0) s += "ROLLOVER_CLEAR|";
   if((bits & (uint)RSN_HISTORY_OK)     != 0) s += "HISTORY_OK|";
   if((bits & (uint)RSN_TREND_GATE_OK)  != 0) s += "TREND_GATE|";
   if((bits & (uint)RSN_HTF_OK)         != 0) s += "HTF_OK|";
   if((bits & (uint)RSN_CLOSEPOS_OK)    != 0) s += "CLOSEPOS_OK|";
   if((bits & (uint)RSN_RSI_MOM_OK)     != 0) s += "RSI_MOM_OK|";
   if((bits & (uint)RSN_NO_EXT_OK)      != 0) s += "NO_EXT_OK|";
   if((bits & (uint)RSN_SR_OK)          != 0) s += "SR_OK|";
   if((bits & (uint)RSN_FVG_OK)         != 0) s += "FVG_OK|";
   if((bits & (uint)RSN_MSS_OK)         != 0) s += "MSS_OK|";
   if((bits & (uint)RSN_EMASLOPE_OK)    != 0) s += "EMASLOPE|";
   if((bits & (uint)RSN_ADX_OK)         != 0) s += "ADX|";
   if((bits & (uint)RSN_MACD_OK)        != 0) s += "MACD|";
   if((bits & (uint)RSN_CANDLE_OK)      != 0) s += "CANDLE|";
   if((bits & (uint)RSN_SD_OK)          != 0) s += "SD|";
   if((bits & (uint)RSN_LIQ_OK)         != 0) s += "LIQ|";
   if((bits & (uint)RSN_GAP_OK)         != 0) s += "GAP|";
   if((bits & (uint)RSN_DAYHILO_OK)     != 0) s += "DAYHILO|";
   if(StringLen(s) > 0) s = StringSubstr(s, 0, StringLen(s) - 1);
   return(s);
  }
//---
ulong SgsMakeInstanceId(const string symbolName) // deterministic, stable across restarts
  {
   string raw = StringFormat("%I64d|%s|%d|%s",
                             AccountInfoInteger(ACCOUNT_LOGIN),
                             symbolName,
                             (int)InpMagicNumber,
                             InpJournalFileName);
   uchar b[];
   int n = StringToCharArray(raw, b, 0, WHOLE_ARRAY, CP_UTF8);
   if(n > 0) n--;
   uint h1 = SgsCrc32End(SgsCrc32Add(0xFFFFFFFF, b, 0, n));
   uint h2 = SgsCrc32End(SgsCrc32Add(0x8F3A5C7D, b, 0, n));
   ulong id = (((ulong)h1) << 32) | (ulong)h2;
   if(id == 0) id = 1;
   return(id);
  }
//---
ulong SgsMakeSessionId()               // unique per launch, never zero
  {
   ulong a = (ulong)TimeCurrent();
   ulong b = (ulong)GetMicrosecondCount();
   ulong c = (ulong)GetTickCount();
   ulong id = (a << 32) ^ (b << 8) ^ c ^ ((ulong)TerminalInfoInteger(TERMINAL_BUILD) << 16);
   if(id == 0) id = 1;
   return(id);
  }
//---
string SgsClampedComment(const string s)
  {
   string r = s;
   StringReplace(r, ";", " ");         // ';' reserved inside payloads
   StringReplace(r, "\n", " ");
   if(StringLen(r) > 24) r = StringSubstr(r, 0, 24);
   return(r);
  }
//---
string SgsKvEscape(const string s)     // minimal payload escaping for ';' and '='
  {
   string r = s;
   StringReplace(r, ";", ".");
   StringReplace(r, "=", ":");
   StringReplace(r, "\n", " ");
   StringReplace(r, "\r", " ");
   return(r);
  }

//+------------------------------------------------------------------+
//| Configuration validation (pure inputs + symbol-dependent pass)   |
//+------------------------------------------------------------------+
class CSgsConfig
  {
public:
   // pure input validation; fills g_cfg; returns false with reason on reject
   static bool      Validate(string &err)
     {
      err = "";
      // --- symbol
      string sym = InpSymbol;
      StringTrimLeft(sym); StringTrimRight(sym);
      if(sym == "") sym = _Symbol;
      if(StringLen(sym) < 2 || StringLen(sym) > 32)
        { err = "Symbol name invalid: '" + sym + "'"; return(false); }
      // --- broker naming tolerance (R10-1): XAUUSD vs XAUUSD.a / GOLD / GOLD.fs ...
      g_cfg.symbolRaw = sym;
      {
       bool isCustom = false;
       if(!SymbolExist(sym, isCustom))
         {
          string want = sym; StringToUpper(want);
          bool  xauFamily = (StringFind(want, "XAU") == 0 || StringFind(want, "GOLD") == 0);
          string bestSame = "", bestAlias = ""; int lenSame = 9999, lenAlias = 9999;
          int total = SymbolsTotal(true);           // scan ALL known symbols, not only Market Watch
          for(int i = 0; i < total; i++)
            {
             string cand = SymbolName(i, true);
             string cup  = cand; StringToUpper(cup);
             bool mSame = (StringFind(cup, want) == 0);          // base + suffix only; prefix variants rejected conservatively
             bool mAlias = false;
             if(!mSame && xauFamily)
                mAlias = ((StringFind(want, "XAU") == 0  && StringFind(cup, "GOLD") == 0) ||
                          (StringFind(want, "GOLD") == 0 && StringFind(cup, "XAU")  == 0));
             if(!mSame && !mAlias) continue;
             int L = StringLen(cand);
             if(mSame  && (L < lenSame  || (L == lenSame  && StringCompare(cand, bestSame)  < 0))) { bestSame  = cand; lenSame  = L; }
             if(mAlias && (L < lenAlias || (L == lenAlias && StringCompare(cand, bestAlias) < 0))) { bestAlias = cand; lenAlias = L; }
            }
          string best = (bestSame != "" ? bestSame : bestAlias);   // same-base always beats family alias
          if(best != "") sym = best;   // resolved; e.g. XAUUSD -> XAUUSD.a
          // no match: keep raw name so CSgsEnvironment::Init fails with the precise SymbolSelect error
         }
      }
      if(!InpAllowOtherSymbols)
        {
         string up = sym; StringToUpper(up);
         if(StringFind(up, "XAU") < 0 && StringFind(up, "GOLD") < 0)
           { err = "InpAllowOtherSymbols=false but symbol '" + sym + "' is not XAU/GOLD"; return(false); }
        }
      g_cfg.symbol = sym;
      // --- magic
      if(InpMagicNumber < 1 || InpMagicNumber > 2000000000)
        { err = "InpMagicNumber must be in 1..2000000000"; return(false); }
      g_cfg.comment = SgsClampedComment(InpTradeComment);
      // --- timeframe
      if(InpTimeframe == PERIOD_CURRENT)
        { err = "InpTimeframe must be an explicit timeframe (not PERIOD_CURRENT)"; return(false); }
      // --- bars
      if(InpBarsRequired < 100 || InpBarsRequired > 100000)
        { err = "InpBarsRequired must be in 100..100000"; return(false); }
      // --- strategy periods
      if(InpEmaFastPeriod < 2 || InpEmaFastPeriod > 500)
        { err = "InpEmaFastPeriod must be in 2..500"; return(false); }
      if(InpEmaSlowPeriod < 3 || InpEmaSlowPeriod > 1000)
        { err = "InpEmaSlowPeriod must be in 3..1000"; return(false); }
      if(InpEmaSlowPeriod <= InpEmaFastPeriod)
        { err = "InpEmaSlowPeriod must be greater than InpEmaFastPeriod"; return(false); }
      if(InpRsiPeriod < 2 || InpRsiPeriod > 100)
        { err = "InpRsiPeriod must be in 2..100"; return(false); }
      if(InpAtrPeriod < 2 || InpAtrPeriod > 200)
        { err = "InpAtrPeriod must be in 2..200"; return(false); }
      if(InpBodyConfirmRatio < 0.0 || InpBodyConfirmRatio > 1.0)
        { err = "InpBodyConfirmRatio must be in 0..1"; return(false); }
      if(InpPullbackAtrMult < 0.05 || InpPullbackAtrMult > 5.0)
        { err = "InpPullbackAtrMult must be in 0.05..5.0"; return(false); }
      if(!(InpRsiBullMin >= 30.0 && InpRsiBullMin <= 70.0 &&
           InpRsiBullMax >= 50.0 && InpRsiBullMax <= 90.0 &&
           InpRsiBullMin < InpRsiBullMax))
        { err = "RSI bull zone invalid (need 30<=min<max<=90, min in 30..70, max in 50..90)"; return(false); }
      if(!(InpRsiBearMin >= 10.0 && InpRsiBearMin <= 50.0 &&
           InpRsiBearMax >= 30.0 && InpRsiBearMax <= 70.0 &&
           InpRsiBearMin < InpRsiBearMax))
        { err = "RSI bear zone invalid (need 10<=min<max<=70, min in 10..50, max in 30..70)"; return(false); }
      if(InpMinScoreToTrade < 1 || InpMinScoreToTrade > 100)
        { err = "InpMinScoreToTrade must be in 1..100"; return(false); }
      if(InpMinConfidence < 0.10 || InpMinConfidence > 1.0)
        { err = "InpMinConfidence must be in 0.10..1.00"; return(false); }
      if(InpMinClosePosRatio < 0.50 || InpMinClosePosRatio > 0.95)
        { err = "InpMinClosePosRatio must be in 0.50..0.95"; return(false); }
      if(InpMaxExtensionAtrMult < 0.10 || InpMaxExtensionAtrMult > 20.0)
        { err = "InpMaxExtensionAtrMult must be in 0.10..20.00"; return(false); }
      if(InpUseHtfTrendConfirm && PeriodSeconds(InpHtfTimeframe) <= PeriodSeconds(InpTimeframe))
        { err = "InpHtfTimeframe must be a higher timeframe than InpTimeframe"; return(false); }
      if(InpSrLookbackBars < 20 || InpSrLookbackBars > 5000)
        { err = "InpSrLookbackBars must be in 20..5000"; return(false); }
      if(InpSrPivotRadius < 1 || InpSrPivotRadius > 10)
        { err = "InpSrPivotRadius must be in 1..10"; return(false); }
      if(InpMinSpaceToLevelAtrMult < 0.0 || InpMinSpaceToLevelAtrMult > 10.0)
        { err = "InpMinSpaceToLevelAtrMult must be in 0.00..10.00"; return(false); }
      if(InpFvgLookbackBars < 3 || InpFvgLookbackBars > 1000)
        { err = "InpFvgLookbackBars must be in 3..1000"; return(false); }
      if(InpMinFvgSizeAtrMult < 0.0 || InpMinFvgSizeAtrMult > 5.0)
        { err = "InpMinFvgSizeAtrMult must be in 0.00..5.00"; return(false); }
      if(InpUseSwingSRFilter && InpSrLookbackBars + InpSrPivotRadius + 4 > InpBarsRequired)
        { err = "InpSrLookbackBars + InpSrPivotRadius + 4 must be <= InpBarsRequired"; return(false); }
      if(InpUseFvgFilter && InpFvgLookbackBars + 4 > InpBarsRequired)
        { err = "InpFvgLookbackBars + 4 must be <= InpBarsRequired"; return(false); }
      if(InpMssLookbackBars < 20 || InpMssLookbackBars > 5000)
        { err = "InpMssLookbackBars must be in 20..5000"; return(false); }
      if(InpUseMssFilter && InpMssLookbackBars + InpSrPivotRadius + 4 > InpBarsRequired)
        { err = "InpMssLookbackBars + InpSrPivotRadius + 4 must be <= InpBarsRequired"; return(false); }
      if(InpAdxPeriod < 2 || InpAdxPeriod > 200)
        { err = "InpAdxPeriod must be in 2..200"; return(false); }
      if(InpAdxMin < 5.0 || InpAdxMin > 60.0)
        { err = "InpAdxMin must be in 5.0..60.0"; return(false); }
      if(InpMacdFast < 2 || InpMacdFast > 200 || InpMacdSlow < 3 || InpMacdSlow > 400 || InpMacdFast >= InpMacdSlow)
        { err = "InpMacdFast/Slow invalid (need 2<=fast<slow<=400)"; return(false); }
      if(InpMacdSignal < 1 || InpMacdSignal > 100)
        { err = "InpMacdSignal must be in 1..100"; return(false); }
      if(InpSdImpulseAtrMult < 0.30 || InpSdImpulseAtrMult > 10.0)
        { err = "InpSdImpulseAtrMult must be in 0.30..10.00"; return(false); }
      if(InpSdZoneMaxAgeBars < 3 || InpSdZoneMaxAgeBars > 2000)
        { err = "InpSdZoneMaxAgeBars must be in 3..2000"; return(false); }
      if(InpUseSupplyDemandFilter && InpSdZoneMaxAgeBars + 4 > InpBarsRequired)
        { err = "InpSdZoneMaxAgeBars + 4 must be <= InpBarsRequired"; return(false); }
      if(InpLiqToleranceAtrMult < 0.01 || InpLiqToleranceAtrMult > 1.0)
        { err = "InpLiqToleranceAtrMult must be in 0.01..1.00"; return(false); }
      if(InpLiqProximityAtrMult < 0.05 || InpLiqProximityAtrMult > 10.0)
        { err = "InpLiqProximityAtrMult must be in 0.05..10.00"; return(false); }
      if(InpLiqLookbackBars < 10 || InpLiqLookbackBars > 2000)
        { err = "InpLiqLookbackBars must be in 10..2000"; return(false); }
      if(InpUseLiquidityFilter && InpLiqLookbackBars + InpSrPivotRadius + 4 > InpBarsRequired)
        { err = "InpLiqLookbackBars + InpSrPivotRadius + 4 must be <= InpBarsRequired"; return(false); }
      if(InpMaxBarGapAtrMult < 0.05 || InpMaxBarGapAtrMult > 10.0)
        { err = "InpMaxBarGapAtrMult must be in 0.05..10.00"; return(false); }
      if(InpDayHiLoMinDistAtrMult < 0.05 || InpDayHiLoMinDistAtrMult > 10.0)
        { err = "InpDayHiLoMinDistAtrMult must be in 0.05..10.00"; return(false); }
      if(InpStructSlBufferAtrMult < 0.0 || InpStructSlBufferAtrMult > 5.0)
        { err = "InpStructSlBufferAtrMult must be in 0.00..5.00"; return(false); }
      if(InpStructSlMaxAtrMult < 0.5 || InpStructSlMaxAtrMult > 20.0)
        { err = "InpStructSlMaxAtrMult must be in 0.50..20.00"; return(false); }
      if(InpBe2TriggerPips != 0 && (InpBe2TriggerPips < 1 || InpBe2TriggerPips > 100000))
        { err = "InpBe2TriggerPips must be 0 (off) or 1..100000"; return(false); }
      if(InpBe2LockPips < 0.0 || InpBe2LockPips > 10000.0)
        { err = "InpBe2LockPips must be in 0.0..10000.0"; return(false); }
      if(InpBe2TriggerPips > 0 && InpBe2LockPips >= InpBe2TriggerPips)
        { err = "InpBe2LockPips must be below InpBe2TriggerPips (lock before target)"; return(false); }
      if(InpUseBreakEven && InpBe2TriggerPips > 0 && InpBe2TriggerPips <= InpBeTriggerPips)
        { err = "InpBe2TriggerPips must be greater than InpBeTriggerPips (stage-2 after stage-1)"; return(false); }
      if(InpStructTrailBufferAtrMult < 0.0 || InpStructTrailBufferAtrMult > 5.0)
        { err = "InpStructTrailBufferAtrMult must be in 0.00..5.00"; return(false); }
      if(InpMomentumDecayBars < 1 || InpMomentumDecayBars > 20)
        { err = "InpMomentumDecayBars must be in 1..20"; return(false); }
      if(InpMaxWeeklyLossPercent != 0.0 && (InpMaxWeeklyLossPercent < 0.1 || InpMaxWeeklyLossPercent > 100.0))
        { err = "InpMaxWeeklyLossPercent must be 0 (off) or 0.10..100"; return(false); }
      if(InpDailyProfitTargetPercent < 0.0 || InpDailyProfitTargetPercent > 100.0)
        { err = "InpDailyProfitTargetPercent must be in 0..100 (0=off)"; return(false); }
      if(InpUseDayProfitLock)
        {
         if(InpDayProfitLockActivatePct < 0.01 || InpDayProfitLockActivatePct > 100.0)
           { err = "InpDayProfitLockActivatePct must be in 0.01..100"; return(false); }
         if(InpDayProfitLockRetracePct < 1.0 || InpDayProfitLockRetracePct > 99.0)
           { err = "InpDayProfitLockRetracePct must be in 1..99"; return(false); }
        }
      if(InpCsvReportFile == "" || StringLen(InpCsvReportFile) > 60 ||
         StringFind(InpCsvReportFile, ".csv") < 0)
        { err = "InpCsvReportFile must be non-empty, <=60 chars and end with .csv"; return(false); }
      if(InpSignalCooldownSec < 0 || InpSignalCooldownSec > 86400)
        { err = "InpSignalCooldownSec must be in 0..86400"; return(false); }
      // --- filters
      if(InpPipSizePoints < 1 || InpPipSizePoints > 100)
        { err = "InpPipSizePoints must be in 1..100"; return(false); }
      if(InpMaxSpreadPips < 1 || InpMaxSpreadPips > 10000)
        { err = "InpMaxSpreadPips must be in 1..10000"; return(false); }
      if(InpAtrFilterMinPips < 0.0 || InpAtrFilterMaxPips < 0.0)
        { err = "ATR filter bounds must be >= 0 (0 disables that bound)"; return(false); }
      if(InpAtrFilterMinPips > 0.0 && InpAtrFilterMaxPips > 0.0 &&
         InpAtrFilterMinPips >= InpAtrFilterMaxPips)
        { err = "InpAtrFilterMinPips must be < InpAtrFilterMaxPips when both are set"; return(false); }
      if(InpNewsBlockBeforeMin < 0 || InpNewsBlockBeforeMin > 720 ||
         InpNewsBlockAfterMin < 0 || InpNewsBlockAfterMin > 720)
        { err = "News block minutes must be in 0..720"; return(false); }
      if((int)InpNewsMinImportance < (int)NEWS_HIGH_ONLY || (int)InpNewsMinImportance > (int)NEWS_ALL)
        { err = "InpNewsMinImportance out of range"; return(false); }
      string nc = InpNewsCurrency; StringTrimLeft(nc); StringTrimRight(nc);
      if(StringLen(nc) != 3)
        { err = "InpNewsCurrency must be a 3-letter currency code"; return(false); }
      for(int ci = 0; ci < 3; ci++)
        {
         ushort ch = StringGetCharacter(nc, ci);
         if(!((ch >= 'A' && ch <= 'Z') || (ch >= 'a' && ch <= 'z')))
           { err = "InpNewsCurrency must contain letters only"; return(false); }
        }
      // --- optional extra currencies (union with InpNewsCurrency; empty = off)
      {
       if(StringLen(InpNewsExtraCurrencies) > 80)
         { err = "InpNewsExtraCurrencies must be <= 80 chars"; return(false); }
       string xtoks[];
       int nx = StringSplit(InpNewsExtraCurrencies, ',', xtoks);
       if(nx > 8)
         { err = "InpNewsExtraCurrencies: at most 8 codes"; return(false); }
       for(int xi = 0; xi < nx; xi++)
         {
          string xt = xtoks[xi]; StringTrimLeft(xt); StringTrimRight(xt);
          if(xt == "") continue;                       // empty segments tolerated ("USD,,EUR")
          if(StringLen(xt) != 3)
            { err = "InpNewsExtraCurrencies: each code must be exactly 3 letters"; return(false); }
          for(int xci = 0; xci < 3; xci++)
            {
             ushort xch = StringGetCharacter(xt, xci);
             if(!((xch >= 'A' && xch <= 'Z') || (xch >= 'a' && xch <= 'z')))
               { err = "InpNewsExtraCurrencies must contain letters only"; return(false); }
            }
         }
      }
      // --- sessions
      if(!SgsParseHHMM(InpSessionStart, g_cfg.sessionStartMin))
        { err = "InpSessionStart must be 'HH:MM' (00:00..23:59)"; return(false); }
      if(!SgsParseHHMM(InpSessionEnd, g_cfg.sessionEndMin))
        { err = "InpSessionEnd must be 'HH:MM' (00:00..23:59)"; return(false); }
      if(!SgsParseHHMM(InpRolloverStart, g_cfg.rollStartMin))
        { err = "InpRolloverStart must be 'HH:MM'"; return(false); }
      if(!SgsParseHHMM(InpRolloverEnd, g_cfg.rollEndMin))
        { err = "InpRolloverEnd must be 'HH:MM'"; return(false); }
      if(InpUseSessionFilter && g_cfg.sessionStartMin == g_cfg.sessionEndMin)
        { err = "Session window has zero length (start == end)"; return(false); }
      if(InpUseRolloverFilter && g_cfg.rollStartMin == g_cfg.rollEndMin)
        { err = "Rollover window has zero length (start == end); disable the filter or set a real window"; return(false); }
      g_cfg.dayAllowed[0] = false;                       // Sunday: market closed
      g_cfg.dayAllowed[1] = InpTradeMonday;
      g_cfg.dayAllowed[2] = InpTradeTuesday;
      g_cfg.dayAllowed[3] = InpTradeWednesday;
      g_cfg.dayAllowed[4] = InpTradeThursday;
      g_cfg.dayAllowed[5] = InpTradeFriday;
      g_cfg.dayAllowed[6] = false;                       // Saturday: market closed
      bool anyDay = false;
      for(int i = 0; i < 7; i++) anyDay = anyDay || g_cfg.dayAllowed[i];
      if(InpUseSessionFilter && !anyDay)
        { err = "All weekdays disabled while session filter enabled: EA could never trade"; return(false); }
      // --- risk
      if(InpFixedLot <= 0.0 || InpFixedLot > 100000.0)
        { err = "InpFixedLot must be > 0 and <= 100000"; return(false); }
      if(InpRiskPercentPerTrade < 0.01 || InpRiskPercentPerTrade > 10.0)
        { err = "InpRiskPercentPerTrade must be in 0.01..10.0"; return(false); }
      if(InpMaxRiskPercentPerTrade < 0.01 || InpMaxRiskPercentPerTrade > 100.0)
        { err = "InpMaxRiskPercentPerTrade must be in 0.01..100"; return(false); }
      if(InpRiskPercentPerTrade > InpMaxRiskPercentPerTrade)
        { err = "InpRiskPercentPerTrade exceeds InpMaxRiskPercentPerTrade (hard cap)"; return(false); }
      if(InpMaxTotalRiskPercentOpen < 0.0 || InpMaxTotalRiskPercentOpen > 100.0)
        { err = "InpMaxTotalRiskPercentOpen must be in 0..100 (0=off)"; return(false); }
      if(InpMaxOpenPositions < 1 || InpMaxOpenPositions > 100)
        { err = "InpMaxOpenPositions must be in 1..100"; return(false); }
      if(InpMaxExposureLotsPerDir < 0.0 || InpMaxExposureLotsPerDir > 100000.0)
        { err = "InpMaxExposureLotsPerDir must be >= 0 (0=off)"; return(false); }
      if(InpConsecLossLimit < 0 || InpConsecLossLimit > 100)
        { err = "InpConsecLossLimit must be in 0..100 (0=off)"; return(false); }
      if(InpConsecLossLimit > 0 && (InpLossCooldownMinutes < 1 || InpLossCooldownMinutes > 10080))
        { err = "InpLossCooldownMinutes must be in 1..10080 when loss limit is active"; return(false); }
      if(InpDeviationPips < 0 || InpDeviationPips > 10000)
        { err = "InpDeviationPips must be in 0..10000"; return(false); }
      if(InpMinFreeMarginAfterPct < 0.0 || InpMinFreeMarginAfterPct >= 100.0)
        { err = "InpMinFreeMarginAfterPct must be in 0..99.99"; return(false); }
      if(InpOrderRetryMax < 0 || InpOrderRetryMax > 5)
        { err = "InpOrderRetryMax must be in 0..5"; return(false); }
      if(InpRetryBackoffMs < 50 || InpRetryBackoffMs > 10000)
        { err = "InpRetryBackoffMs must be in 50..10000"; return(false); }
      // --- stops / targets
      if(InpSlMode == SL_ATR && (InpAtrSlMult < 0.10 || InpAtrSlMult > 20.0))
        { err = "InpAtrSlMult must be in 0.10..20.0"; return(false); }
      if(InpSlMode == SL_POINTS && (InpSlPips < 1 || InpSlPips > 100000))
        { err = "InpSlPips must be in 1..100000"; return(false); }
      if(InpRewardRiskRatio <= 0.0 || InpRewardRiskRatio > 50.0)
        { err = "InpRewardRiskRatio must be in (0..50]"; return(false); }
      if(InpMinRewardRiskRatio <= 0.0 || InpMinRewardRiskRatio > 50.0)
        { err = "InpMinRewardRiskRatio must be in (0..50]"; return(false); }
      if(InpTpMode == TP_RR && InpRewardRiskRatio < InpMinRewardRiskRatio)
        { err = "InpRewardRiskRatio below InpMinRewardRiskRatio"; return(false); }
      if(InpTpMode == TP_POINTS && (InpTpPips < 1 || InpTpPips > 100000))
        { err = "InpTpPips must be in 1..100000 for TP_POINTS"; return(false); }
      // --- break-even
      if(InpUseBreakEven)
        {
         if(InpBeTriggerPips < 1 || InpBeTriggerPips > 10000)
           { err = "InpBeTriggerPips must be in 1..10000"; return(false); }
         if(InpBeOffsetPips < 0.0 || InpBeOffsetPips > 1000.0)
           { err = "InpBeOffsetPips must be in 0..1000"; return(false); }
        }
      // --- trailing
      if(InpTrailMode != TRAIL_OFF)
        {
         if(InpTrailStartPips < 1 || InpTrailStartPips > 100000)
           { err = "InpTrailStartPips must be in 1..100000"; return(false); }
         if(InpTrailStepPips < 1.0 || InpTrailStepPips > 10000.0)
           { err = "InpTrailStepPips must be in 1..10000"; return(false); }
         if(InpTrailMode == TRAIL_ATR && (InpTrailAtrMult < 0.05 || InpTrailAtrMult > 20.0))
           { err = "InpTrailAtrMult must be in 0.05..20.0"; return(false); }
         if(InpTrailMode == TRAIL_POINTS && (InpTrailDistancePips < 1 || InpTrailDistancePips > 100000))
           { err = "InpTrailDistancePips must be in 1..100000"; return(false); }
        }
      // --- partial close
      if(InpUsePartialClose)
        {
         if(InpPartialTriggerPips < 1 || InpPartialTriggerPips > 100000)
           { err = "InpPartialTriggerPips must be in 1..100000"; return(false); }
         if(InpPartialClosePercent < 1.0 || InpPartialClosePercent > 99.0)
           { err = "InpPartialClosePercent must be in 1..99"; return(false); }
        }
      // --- daily limits
      if(InpMaxTradesPerDay != 0 && (InpMaxTradesPerDay < 1 || InpMaxTradesPerDay > 500))
        { err = "InpMaxTradesPerDay must be 0 (off) or 1..500"; return(false); }
      if(InpMaxDailyLossPercent < 0.0 || InpMaxDailyLossPercent > 100.0)
        { err = "InpMaxDailyLossPercent must be in 0..100 (0=off)"; return(false); }
      if(InpMaxTradeDurationMin < 0 || InpMaxTradeDurationMin > 10080)
        { err = "InpMaxTradeDurationMin must be in 0..10080 (0=off)"; return(false); }
      // --- drawdown protection
      if(InpMaxDailyDDPercent < 0.0 || InpMaxDailyDDPercent > 100.0)
        { err = "InpMaxDailyDDPercent must be in 0..100 (0=off)"; return(false); }
      if(InpMaxTotalDDPercent < 0.1 || InpMaxTotalDDPercent > 100.0)
        { err = "InpMaxTotalDDPercent must be in 0.1..100 (hard guard, mandatory)"; return(false); }
      if(InpPeakEquityFloor < 0.0)
        { err = "InpPeakEquityFloor must be >= 0 (0=auto)"; return(false); }
      // --- journal
      if(InpJournalMaxPayloadBytes < 64 || InpJournalMaxPayloadBytes > SGS_MAX_PAYLOAD_HARD)
        { err = "InpJournalMaxPayloadBytes must be in 64..65536"; return(false); }
      if(InpJournalMaxFileMB < 1 || InpJournalMaxFileMB > 512)
        { err = "InpJournalMaxFileMB must be in 1..512"; return(false); }
      string jf = InpJournalFileName; StringTrimLeft(jf); StringTrimRight(jf);
      if(StringLen(jf) < 3 || StringLen(jf) > 96)
        { err = "InpJournalFileName length must be 3..96"; return(false); }
      if(jf != SgsSafeFilePart(jf))
        { err = "InpJournalFileName must not contain path separators"; return(false); }
      // --- rotation
      if(InpJournalBackups < 1 || InpJournalBackups > 20)
        { err = "InpJournalBackups must be in 1..20"; return(false); }
      // --- dashboard
      if(InpDashboardX < 0 || InpDashboardX > 4000 || InpDashboardY < 0 || InpDashboardY > 4000)
        { err = "Dashboard X/Y must be in 0..4000"; return(false); }
      if(InpDashboardRefreshSec < 1 || InpDashboardRefreshSec > 60)
        { err = "InpDashboardRefreshSec must be in 1..60"; return(false); }
      if(InpDashboardScalePercent < 50 || InpDashboardScalePercent > 200)
        { err = "InpDashboardScalePercent must be in 50..200"; return(false); }
      // --- diagnostics / testing
      if(InpMaxConsecutiveErrors < 1 || InpMaxConsecutiveErrors > 50)
        { err = "InpMaxConsecutiveErrors must be in 1..50"; return(false); }
      if(InpSelfTestDummyRecords < 0 || InpSelfTestDummyRecords > 100)
        { err = "InpSelfTestDummyRecords must be in 0..100"; return(false); }
      return(true);
     }
  };

//+------------------------------------------------------------------+
//| Symbol descriptor: contract spec, normalization, dynamic quotes  |
//+------------------------------------------------------------------+
class CSgsSymbol
  {
private:
   string  m_name;
   bool    m_ready;
   int     m_digits;
   double  m_point;
   double  m_tickSize;
   double  m_tickValue;        // profit tick value (deposit ccy, 1 lot)
   double  m_tickValueLoss;    // loss tick value if provided by broker
   double  m_contractSize;
   double  m_volMin, m_volMax, m_volStep;
   long    m_stopsLevel;       // points
   long    m_freezeLevel;      // points
   int     m_filling;          // SYMBOL_FILLING_MODE bitmask
   long    m_tradeMode;        // ENUM_SYMBOL_TRADE_MODE
   double  m_bid, m_ask;
   datetime m_tickTime;

public:
   CSgsSymbol()
     {
      m_ready = false; m_name = ""; m_digits = 0; m_point = 0.0;
      m_tickSize = 0.0; m_tickValue = 0.0; m_tickValueLoss = 0.0;
      m_contractSize = 0.0; m_volMin = 0.0; m_volMax = 0.0; m_volStep = 0.0;
      m_stopsLevel = 0; m_freezeLevel = 0; m_filling = 0; m_tradeMode = 0;
      m_bid = 0.0; m_ask = 0.0; m_tickTime = 0;
     }
   bool    Ready()  const { return(m_ready); }
   string  Name()   const { return(m_name); }
   int     Digits() const { return(m_digits); }
   double  Point()  const { return(m_point); }
   double  TickSize() const { return(m_tickSize); }
   double  TickValue() const { return(m_tickValue); }
   double  ContractSize() const { return(m_contractSize); }
   double  VolMin() const { return(m_volMin); }
   double  VolMax() const { return(m_volMax); }
   double  VolStep() const { return(m_volStep); }
   long    StopsLevel() const { return(m_stopsLevel); }
   long    FreezeLevel() const { return(m_freezeLevel); }
   double  Bid() const { return(m_bid); }
   double  Ask() const { return(m_ask); }
   long    TradeMode() const { return(m_tradeMode); }
   //---
   bool    Init(const string sym, string &err)
     {
      err = "";
      m_ready = false;
      m_name = sym;
      if(!SymbolSelect(m_name, true))
        { err = "SymbolSelect failed for " + m_name; return(false); }
      m_digits   = (int)SymbolInfoInteger(m_name, SYMBOL_DIGITS);
      m_point    = SymbolInfoDouble(m_name, SYMBOL_POINT);
      m_tickSize = SymbolInfoDouble(m_name, SYMBOL_TRADE_TICK_SIZE);
      m_tickValue     = SymbolInfoDouble(m_name, SYMBOL_TRADE_TICK_VALUE);
      m_tickValueLoss = SymbolInfoDouble(m_name, SYMBOL_TRADE_TICK_VALUE_LOSS);
      m_contractSize  = SymbolInfoDouble(m_name, SYMBOL_TRADE_CONTRACT_SIZE);
      m_volMin   = SymbolInfoDouble(m_name, SYMBOL_VOLUME_MIN);
      m_volMax   = SymbolInfoDouble(m_name, SYMBOL_VOLUME_MAX);
      m_volStep  = SymbolInfoDouble(m_name, SYMBOL_VOLUME_STEP);
      m_stopsLevel  = SymbolInfoInteger(m_name, SYMBOL_TRADE_STOPS_LEVEL);
      m_freezeLevel = SymbolInfoInteger(m_name, SYMBOL_TRADE_FREEZE_LEVEL);
      m_filling     = (int)SymbolInfoInteger(m_name, SYMBOL_FILLING_MODE);
      m_tradeMode   = SymbolInfoInteger(m_name, SYMBOL_TRADE_MODE);
      if(m_digits < 0 || m_digits > 8 || m_point <= 0.0)
        { err = "Invalid digits/point for " + m_name; return(false); }
      if(m_tickSize <= 0.0)
        { err = "Invalid tick size for " + m_name + " (contract spec unavailable)"; return(false); }
      // (round-31 fix 8): accept the symbol when EITHER tick-value variant is provided.
      // Some brokers/feeds report only one of PROFIT/LOSS tick values at init; the sizing
      // layer (MoneyPerPointOneLot) already prefers LOSS and falls back to PROFIT, so
      // requiring the PROFIT variant here wrongly rejected those symbols (INIT_FAILED).
      if(m_tickValue <= 0.0 && m_tickValueLoss <= 0.0)
        { err = "Invalid tick value(s) for " + m_name + " (contract spec unavailable)"; return(false); }
      if(m_contractSize <= 0.0)
        { err = "Invalid contract size for " + m_name; return(false); }
      if(m_volMin <= 0.0 || m_volStep <= 0.0 || m_volMax < m_volMin)
        { err = "Invalid volume spec for " + m_name; return(false); }
      // (round-31 fix 9): no quotes at attach must NOT eject the EA (weekend / market-closed
      // attach or a feed still connecting). Every trading path is already quote-gated per
      // tick (OnTick and ManagePositions return on !RefreshDynamic), so the EA now stays
      // loaded with its dashboard and simply idles until quotes arrive.
      if(!RefreshDynamic())
         Print("SGS WARNING: no quotes for ", m_name,
               " at attach (market closed / feed connecting) - EA stays loaded, waiting for quotes");
      m_ready = true;
      return(true);
     }
   //---
   bool    RefreshDynamic()
     {
      MqlTick t;
      if(!SymbolInfoTick(m_name, t)) return(false);
      if(t.bid <= 0.0 || t.ask <= 0.0 || t.ask < t.bid) return(false);
      m_bid = t.bid; m_ask = t.ask; m_tickTime = t.time;
      return(true);
     }
   //---
   long    SpreadPoints() const
     {
      if(m_point <= 0.0) return(999999999);
      return((long)MathRound((m_ask - m_bid) / m_point));
     }
   //---
   double  NormalizePrice(const double p) const
     {
      // Quantize to the SYMBOL_TRADE_TICK_SIZE grid first (some XAU/GOLD feeds
      // have tick size != point, e.g. 0.05 with 2 digits). Sending a price off
      // that grid yields retcode 10015 INVALID_PRICE.
      if(m_tickSize > 0.0)
        {
         double q = MathRound(p / m_tickSize) * m_tickSize;
         return(NormalizeDouble(q, m_digits));
        }
      return(NormalizeDouble(p, m_digits));
     }
   //---
   double  MinStopDistancePrice() const // conservative broker floor
     {
      long lvl = m_stopsLevel;
      double d = (double)lvl * m_point;
      if(d < m_point) d = m_point;      // never allow tighter than 1 point
      return(d);
     }
   //---
   bool    NormalizeVolume(const double inV, double &outV) const
     {
      outV = 0.0;
      if(m_volStep <= 0.0) return(false);
      double steps = MathFloor((inV + 1e-12) / m_volStep);
      double v = steps * m_volStep;
      v = MathMin(v, m_volMax);
      v = NormalizeDouble(v, 8);
      if(v < m_volMin - 1e-12) return(false);
      if(v <= 0.0) return(false);
      outV = v;
      return(true);
     }
   //---
   double  MoneyPerPointOneLot() const  // deposit ccy per 1 point move per 1 lot
     {
      if(m_point <= 0.0 || m_tickSize <= 0.0) return(0.0);
      double tv = (m_tickValueLoss > 0.0 ? m_tickValueLoss : m_tickValue);
      return(tv * (m_point / m_tickSize));
     }
   //---
   double  LossAtDistance(const double vol, const double distPrice) const
     {
      if(vol <= 0.0 || distPrice <= 0.0) return(0.0);
      double mpp = MoneyPerPointOneLot();
      if(mpp <= 0.0) return(0.0);
      return(vol * mpp * (distPrice / m_point));
     }
   //---
   bool    DirectionAllowed(const int dir) const
     {
      if(dir == (int)SIGNAL_BUY)
         return(m_tradeMode == SYMBOL_TRADE_MODE_FULL || m_tradeMode == SYMBOL_TRADE_MODE_LONGONLY);
      if(dir == (int)SIGNAL_SELL)
         return(m_tradeMode == SYMBOL_TRADE_MODE_FULL || m_tradeMode == SYMBOL_TRADE_MODE_SHORTONLY);
      return(false);
     }
   //---
   ENUM_ORDER_TYPE_FILLING PreferredFilling() const
     {
      if((m_filling & SYMBOL_FILLING_IOC) == SYMBOL_FILLING_IOC) return(ORDER_FILLING_IOC);
      if((m_filling & SYMBOL_FILLING_FOK) == SYMBOL_FILLING_FOK) return(ORDER_FILLING_FOK);
      return(ORDER_FILLING_RETURN);
     }
   //---
   bool    IsNettingAccount() const
     {
      return((ENUM_ACCOUNT_MARGIN_MODE)AccountInfoInteger(ACCOUNT_MARGIN_MODE) ==
             ACCOUNT_MARGIN_MODE_RETAIL_NETTING);
     }
  };

CSgsSymbol g_sym;

//+------------------------------------------------------------------+
//| Little-endian helpers for the binary journal codec               |
//+------------------------------------------------------------------+
ushort SgsGetU16(const uchar &b[], const int off) { return((ushort)(b[off] | (b[off+1] << 8))); }
uint   SgsGetU32(const uchar &b[], const int off)
  {
   return((uint)b[off] | ((uint)b[off+1] << 8) | ((uint)b[off+2] << 16) | ((uint)b[off+3] << 24));
  }
ulong  SgsGetU64(const uchar &b[], const int off)
  {
   ulong lo = SgsGetU32(b, off), hi = SgsGetU32(b, off + 4);
   return((hi << 32) | lo);
  }
void SgsPutU16(uchar &b[], const int off, const ushort v)
  { b[off] = (uchar)(v & 0xFF); b[off+1] = (uchar)((v >> 8) & 0xFF); }
void SgsPutU32(uchar &b[], const int off, const uint v)
  {
   b[off]   = (uchar)(v & 0xFF);        b[off+1] = (uchar)((v >> 8) & 0xFF);
   b[off+2] = (uchar)((v >> 16) & 0xFF); b[off+3] = (uchar)((v >> 24) & 0xFF);
  }
void SgsPutU64(uchar &b[], const int off, const ulong v)
  { SgsPutU32(b, off, (uint)(v & 0xFFFFFFFF)); SgsPutU32(b, off + 4, (uint)(v >> 32)); }
//---
void SgsAscii8(const string s, uchar &dst[]) // exactly 8 ASCII bytes, padded zero
  {
   int lim = (int)MathMin((long)8, (long)ArraySize(dst));
   for(int i = 0; i < lim; i++)
      dst[i] = (uchar)(i < StringLen(s) ? StringGetCharacter(s, i) : 0);
  }

//+------------------------------------------------------------------+
//| Journal scan report                                              |
//+------------------------------------------------------------------+
struct SGsScanReport
  {
   int      code;                     // ENUM_SGS_SCAN
   long     fileSize;
   long     errorOffset;              // offset where the failing record starts
   long     validDataEnd;             // end of last fully valid+committed record
   int      recordCount;              // fully valid+committed records
   ulong    firstSeq, lastSeq;
   ulong    instanceId;
   ulong    generation;
   ulong    sessionSeen;              // last non-zero session id seen
   uchar    lastHash[32];             // chain head (zeros if no records)
   long     firstTs, lastTs;
   bool     headerValid;
   void     Reset()
     {
      code = (int)SCAN_OK; fileSize = 0; errorOffset = 0; validDataEnd = 0;
      recordCount = 0; firstSeq = 0; lastSeq = 0; instanceId = 0; generation = 0;
      sessionSeen = 0; firstTs = 0; lastTs = 0; headerValid = false;
      SgsBytesZero(lastHash, 32);
     }
  };

//+------------------------------------------------------------------+
//| Binary journal: codec, append, scan, recovery, rotation, manifest|
//+------------------------------------------------------------------+
class CSgsJournal
  {
private:
   string    m_baseName;               // user-supplied logical name
   string    m_file;                   // resolved per-instance file name
   string    m_manifest;               // resolved manifest name
   int       m_handle;
   bool      m_open;
   bool      m_healthy;
   bool      m_needRotate;
   ulong     m_instanceId;
   ulong     m_sessionId;
   ulong     m_generation;
   ulong     m_seq;                    // next sequence number
   long      m_validEnd;               // writer position (end of valid data)
   uchar     m_lastHash[32];           // chain head
   //---
   bool      ReadBytes(const int h, const long off, uchar &dst[], const int count)
     {
      if(h == INVALID_HANDLE || count <= 0) return(count==0);
      if(!FileSeek(h, off, SEEK_SET)) return(false);
      ArrayResize(dst, count);
      uint got = FileReadArray(h, dst, 0, count);
      return(got == (uint)count);
     }
   //---
   bool      WriteHeader(const int h)  // writes fixed 128-byte file header at 0
     {
      uchar hdr[];
      ArrayResize(hdr, SGS_FILE_HEADER_SIZE);
      for(int i = 0; i < SGS_FILE_HEADER_SIZE; i++) hdr[i] = 0;
      uchar mg[8]; SgsAscii8(SGS_JOURNAL_MAGIC_TEXT, mg);
      SgsBytesCopy(hdr, 0, mg, 8);
      SgsPutU16(hdr, 8, (ushort)SGS_FORMAT_MAJOR);
      SgsPutU16(hdr, 10, (ushort)SGS_FORMAT_MINOR);
      SgsPutU32(hdr, 12, (uint)SGS_FILE_HEADER_SIZE);
      SgsPutU64(hdr, 16, m_instanceId);
      SgsPutU64(hdr, 24, (ulong)SgsNowSec());
      SgsPutU64(hdr, 32, m_generation);
      SgsPutU32(hdr, 124, SgsCrc32End(SgsCrc32Add(SgsCrc32Begin(), hdr, 0, 124)));
      if(!FileSeek(h, 0, SEEK_SET)) return(false);
      if(FileWriteArray(h, hdr, 0, SGS_FILE_HEADER_SIZE) != (uint)SGS_FILE_HEADER_SIZE) return(false);
      FileFlush(h);
      return(true);
     }
   //---
   // (round-27 fix 4): stamp a freshly created generation-N header with the previous
   // generation's terminal hash — required by VerifyCrossGeneration / chain anchoring.
   // Used by Rotate() and by both interrupted-rotation resume paths in OpenOrCreate.
   void      CarryPrevGenHash(const uchar &termHash[])
     {
      uchar hdr[];
      if(!ReadBytes(m_handle, 0, hdr, SGS_FILE_HEADER_SIZE)) return;
      for(int i = 0; i < 32; i++) hdr[40 + i] = termHash[i];
      SgsPutU32(hdr, 124, SgsCrc32End(SgsCrc32Add(SgsCrc32Begin(), hdr, 0, 124)));
      if(FileSeek(m_handle, 0, SEEK_SET))
        {
         if(FileWriteArray(m_handle, hdr, 0, SGS_FILE_HEADER_SIZE) == SGS_FILE_HEADER_SIZE)
            FileFlush(m_handle);
         FileSeek(m_handle, m_validEnd, SEEK_SET);
        }
     }
   //---
   bool      ParseFileHeader(const uchar &hdr[], SGsScanReport &rep,
                             const ulong expectedInstance, const bool checkInstance)
     {
      rep.headerValid = false;
      uchar mg[8]; SgsAscii8(SGS_JOURNAL_MAGIC_TEXT, mg);
      for(int i = 0; i < 8; i++)
         if(hdr[i] != mg[i]) { rep.code = (int)SCAN_HEADER_BAD_MAGIC; rep.errorOffset = 0; return(false); }
      if(SgsGetU16(hdr, 8) != (ushort)SGS_FORMAT_MAJOR)
        { rep.code = (int)SCAN_HEADER_BAD_VERSION; rep.errorOffset = 0; return(false); }
      if(SgsGetU32(hdr, 12) != (uint)SGS_FILE_HEADER_SIZE)
        { rep.code = (int)SCAN_HEADER_BAD_SIZE; rep.errorOffset = 0; return(false); }
      uint crcStored = SgsGetU32(hdr, 124);
      uint crcCalc = SgsCrc32End(SgsCrc32Add(SgsCrc32Begin(), hdr, 0, 124));
      if(crcStored != crcCalc)
        { rep.code = (int)SCAN_HEADER_BAD_CRC; rep.errorOffset = 0; return(false); }
      rep.instanceId = SgsGetU64(hdr, 16);
      rep.generation = SgsGetU64(hdr, 32);
      if(checkInstance && rep.instanceId != expectedInstance)
        { rep.code = (int)SCAN_HEADER_INSTANCE_MISMATCH; rep.errorOffset = 0; return(false); }
      rep.headerValid = true;
      rep.validDataEnd = SGS_FILE_HEADER_SIZE;
      return(true);
     }
   //---
   bool      CreateNewFile(string &err) // assumes manifest/state already decided
     {
      err = "";
      int h = FileOpen(m_file, FILE_WRITE | FILE_BIN);
      if(h == INVALID_HANDLE) { err = "cannot create journal file"; return(false); }
      FileClose(h);
      h = FileOpen(m_file, FILE_READ | FILE_WRITE | FILE_BIN);
      if(h == INVALID_HANDLE) { err = "cannot open new journal"; return(false); }
      m_handle = h; m_open = true;
      if(!WriteHeader(h))
        { err = "failed writing journal header"; FileClose(h); m_handle = INVALID_HANDLE; m_open = false; return(false); }
      m_seq = 1;
      m_validEnd = SGS_FILE_HEADER_SIZE;
      SgsBytesZero(m_lastHash, 32);
      m_healthy = true;
      Append((int)JR_META_OPEN, (int)DUR_STATE, 0,
             StringFormat("action=create;file=%s;gen=%I64u;instance=%I64u", m_file, m_generation, m_instanceId));
      return(true);
     }
   //---
   bool      WriteManifest(const ulong liveGen, const uchar &termHash[],
                           const string prevArc) // atomic-ish: tmp + FileMove
     {
      uchar buf[];
      ArrayResize(buf, SGS_MANIFEST_SIZE);
      for(int i = 0; i < SGS_MANIFEST_SIZE; i++) buf[i] = 0;
      uchar mg[8]; SgsAscii8(SGS_MANIFEST_MAGIC_TEXT, mg);
      SgsBytesCopy(buf, 0, mg, 8);
      SgsPutU64(buf, 8, liveGen);
      SgsBytesCopy(buf, 16, termHash, 32);
      uchar nm[64]; SgsBytesZero(nm, 64);
      int nl = (int)MathMin((long)63, (long)StringLen(m_file));
      for(int i = 0; i < nl; i++) nm[i] = (uchar)StringGetCharacter(m_file, i);
      SgsBytesCopy(buf, 48, nm, 64);
      uchar pm[64]; SgsBytesZero(pm, 64);
      int pl = (int)MathMin((long)63, (long)StringLen(prevArc));
      for(int j = 0; j < pl; j++) pm[j] = (uchar)StringGetCharacter(prevArc, j);
      SgsBytesCopy(buf, 112, pm, 64);
      SgsPutU32(buf, 176, SgsCrc32End(SgsCrc32Add(SgsCrc32Begin(), buf, 0, 176)));
      string tmp = m_manifest + ".tmp";
      int h = FileOpen(tmp, FILE_WRITE | FILE_BIN);
      if(h == INVALID_HANDLE) return(false);
      FileWriteArray(h, buf, 0, SGS_MANIFEST_SIZE);
      FileFlush(h); FileClose(h);
      if(!FileMove(tmp, 0, m_manifest, FILE_REWRITE))
        { FileDelete(tmp); return(false); }
      return(true);
     }
   //---
   bool      ReadManifest(ulong &liveGen, uchar &termHash[], string &prevArc)
     {
      liveGen = 0; SgsBytesZero(termHash, 32); prevArc = "";
      if(!FileIsExist(m_manifest)) return(false);
      int h = FileOpen(m_manifest, FILE_READ | FILE_BIN);
      if(h == INVALID_HANDLE) return(false);
      uchar buf[];
      bool ok = ReadBytes(h, 0, buf, SGS_MANIFEST_SIZE);
      FileClose(h);
      if(!ok) return(false);
      uchar mg[8]; SgsAscii8(SGS_MANIFEST_MAGIC_TEXT, mg);
      for(int i = 0; i < 8; i++) if(buf[i] != mg[i]) return(false);
      uint crcStored = SgsGetU32(buf, 176);
      uint crcCalc = SgsCrc32End(SgsCrc32Add(SgsCrc32Begin(), buf, 0, 176));
      if(crcStored != crcCalc) return(false);
      liveGen = SgsGetU64(buf, 8);
      SgsBytesZero(termHash, 32);
      for(int k = 0; k < 32; k++) termHash[k] = buf[16 + k];
      string pa = "";
      for(int j = 0; j < 64; j++)
        { if(buf[112 + j] == 0) break; pa += CharToString((uchar)buf[112 + j]); }
      prevArc = pa;
      return(true);
     }
   //---
   string    ArcName(const ulong gen) const
     { return(StringFormat("%s.gen%04I64u.arc", m_file, gen)); }
   //---
   void      PruneArchives()
     {
      string mask = m_file + ".gen*.arc";
      string found[];
      ArrayResize(found, 0);
      string firstName = "";
      long fh = FileFindFirst(mask, firstName, 0);
      if(fh != INVALID_HANDLE)
        {
         if(StringLen(firstName) > 0) { ArrayResize(found, ArraySize(found) + 1); found[ArraySize(found)-1] = firstName; }
         string nextName = "";
         while(FileFindNext(fh, nextName))
           {
            if(StringLen(nextName) > 0) { ArrayResize(found, ArraySize(found) + 1); found[ArraySize(found)-1] = nextName; }
           }
         FileFindClose(fh);
        }
      int total = ArraySize(found);
      if(total <= InpJournalBackups) return;
      // simple selection: delete lexicographically smallest names (gen numbers zero-padded => lexical == numeric)
      // bubble-sort ascending
      for(int i = 0; i < total; i++)
         for(int j = i + 1; j < total; j++)
           {
            if(StringCompare(found[j], found[i]) < 0)
              { string t = found[i]; found[i] = found[j]; found[j] = t; }
           }
      int toDelete = total - InpJournalBackups;
      for(int k = 0; k < toDelete; k++) FileDelete(found[k]);
     }
   //---
   bool      ResumeInterruptedRotation(const ulong manifestGen, string &detail)
     {
      // Manifest says live generation should be manifestGen, but live file is
      // still at an older generation (rotation interrupted). Deterministic
      // resume: archive the stale live file, then create the fresh one.
      detail = "";
      SGsScanReport rep; rep.Reset();
      if(FileIsExist(m_file))
        {
         if(!FullScan(m_file, m_instanceId, true, rep)) return(false);
         if(rep.code != (int)SCAN_OK) { detail = "stale live journal invalid: " + SgsScanCodeName(rep.code); return(false); }
         if(rep.generation >= manifestGen) { detail = "stale live journal generation not stale"; return(false); }
         string arc = ArcName(rep.generation);
         if(!FileCopy(m_file, 0, arc, FILE_REWRITE)) { detail = "cannot copy stale journal to archive"; return(false); }
         if(!FileDelete(m_file)) { detail = "cannot delete stale journal"; return(false); }
        }
      m_generation = manifestGen;
      return(true);
     }
   //---
public:
   CSgsJournal()
     {
      m_handle = INVALID_HANDLE; m_open = false; m_healthy = false; m_needRotate = false;
      m_instanceId = 0; m_sessionId = 0; m_generation = 0; m_seq = 1; m_validEnd = 0;
      SgsBytesZero(m_lastHash, 32);
     }
   //---
   void      Setup(const string baseName, const ulong instanceId)
     {
      m_baseName = baseName;
      m_instanceId = instanceId;
      string stem = baseName;
      uint hi32 = (uint)(instanceId >> 32), lo32 = (uint)(instanceId & 0xFFFFFFFF);
      string hex = StringFormat("%08x%08x", hi32, lo32);
      // resolved per-instance file: <name>.<instancehex><.ext>
      int dot = StringFind(stem, ".");
      if(dot > 0) m_file = StringSubstr(stem, 0, dot) + "." + hex + StringSubstr(stem, dot);
      else        m_file = stem + "." + hex + ".dat";
      m_manifest = m_file + ".manifest";
      m_generation = 0; m_seq = 1; m_validEnd = 0;
      SgsBytesZero(m_lastHash, 32);
     }
   //---
   string    ResolvedName() const { return(m_file); }
   bool      IsOpen()    const { return(m_open); }
   bool      IsHealthy() const { return(m_open && m_healthy); }
   bool      NeedsRotation() const { return(m_needRotate); }
   ulong     Generation() const { return(m_generation); }
   ulong     NextSequence() const { return(m_seq); }
   string    LastHashHex() const { return(SgsHex(m_lastHash, 32)); }
   long      CurrentSize() const
     {
      if(!m_open) return(0);
      return((long)FileSize(m_handle));
     }
   //---
   void      Close()
     {
      if(m_open && m_handle != INVALID_HANDLE)
        { FileFlush(m_handle); FileClose(m_handle); }
      m_handle = INVALID_HANDLE; m_open = false;
     }
   //---
   void      MarkUnhealthy() { m_healthy = false; }
   //---
   // Full scan + verification. Static-capable: works on any path.
   bool      FullScan(const string path, const ulong expectedInstance,
                      const bool checkInstance, SGsScanReport &rep)
     {
      rep.Reset();
      if(!FileIsExist(path)) { rep.code = (int)SCAN_IO_ERROR; rep.errorOffset = 0; return(false); }
      int h = FileOpen(path, FILE_READ | FILE_BIN);
      if(h == INVALID_HANDLE) { rep.code = (int)SCAN_IO_ERROR; return(false); }
      rep.fileSize = (long)FileSize(h);
      if(rep.fileSize < SGS_FILE_HEADER_SIZE)
        { rep.code = (int)SCAN_HEADER_TOO_SHORT; rep.errorOffset = 0; FileClose(h); return(false); }
      uchar hdr[];
      if(!ReadBytes(h, 0, hdr, SGS_FILE_HEADER_SIZE))
        { rep.code = (int)SCAN_IO_ERROR; FileClose(h); return(false); }
      if(!ParseFileHeader(hdr, rep, expectedInstance, checkInstance))
        { FileClose(h); return(false); }
      uchar prevHash[]; ArrayResize(prevHash, 32); SgsBytesZero(prevHash, 32);
      ulong expectSeq = 1;
      long off = SGS_FILE_HEADER_SIZE;
      rep.validDataEnd = off;
      uchar rhdr[]; uchar pld[]; uchar cmt[];
      while(off < rep.fileSize)
        {
         long recStart = off;
         long remain = rep.fileSize - off;
         if(remain < SGS_REC_HEADER_SIZE)
           { rep.code = (int)SCAN_REC_SHORT_HEADER; rep.errorOffset = recStart; break; }
         if(!ReadBytes(h, off, rhdr, SGS_REC_HEADER_SIZE))
           { rep.code = (int)SCAN_IO_ERROR; rep.errorOffset = recStart; break; }
         if(SgsGetU32(rhdr, 0) != (uint)SGS_REC_MAGIC)
           { rep.code = (int)SCAN_REC_BAD_MAGIC; rep.errorOffset = recStart; break; }
         if(SgsGetU16(rhdr, 4) != (ushort)1)
           { rep.code = (int)SCAN_REC_BAD_FORMAT; rep.errorOffset = recStart; break; }
         if(SgsGetU16(rhdr, 6) != (ushort)SGS_REC_HEADER_SIZE)
           { rep.code = (int)SCAN_REC_BAD_HEADER_SIZE; rep.errorOffset = recStart; break; }
         uint hdrCrcStored = SgsGetU32(rhdr, 132);
         uint hdrCrcCalc = SgsCrc32End(SgsCrc32Add(SgsCrc32Begin(), rhdr, 0, 132));
         if(hdrCrcStored != hdrCrcCalc)
           { rep.code = (int)SCAN_REC_BAD_HEADER_CRC; rep.errorOffset = recStart; break; }
         uint payloadSize = SgsGetU32(rhdr, 36);
         // (round-27 fix 3): format-level scans check only the HARD cap. The configured
         // InpJournalMaxPayloadBytes is runtime write-side policy — journals written under
         // a larger configured cap must still verify (SGS Doctor has always done hard-only).
         if(payloadSize > (uint)SGS_MAX_PAYLOAD_HARD)
           { rep.code = (int)SCAN_REC_PAYLOAD_TOO_BIG; rep.errorOffset = recStart; break; }
         ulong seq   = SgsGetU64(rhdr, 16);
         ulong inst  = SgsGetU64(rhdr, 40);
         ulong sess  = SgsGetU64(rhdr, 48);
         ulong gen   = SgsGetU64(rhdr, 56);
         if(inst != rep.instanceId)
           { rep.code = (int)SCAN_REC_INSTANCE_MISMATCH; rep.errorOffset = recStart; break; }
         if(sess == 0)
           { rep.code = (int)SCAN_REC_SESSION_ZERO; rep.errorOffset = recStart; break; }
         if(gen != rep.generation)
           { rep.code = (int)SCAN_REC_GENERATION_MISMATCH; rep.errorOffset = recStart; break; }
         if(seq != expectSeq)
           { rep.code = (int)SCAN_REC_SEQUENCE_MISMATCH; rep.errorOffset = recStart; break; }
         uchar ph[32];
         for(int i = 0; i < 32; i++) ph[i] = rhdr[68 + i];
         if(!SgsBytesEqual(ph, prevHash, 32))
           { rep.code = (int)SCAN_REC_PREVHASH_MISMATCH; rep.errorOffset = recStart; break; }
         off += SGS_REC_HEADER_SIZE;
         remain = rep.fileSize - off;
         if(remain < (long)payloadSize)
           { rep.code = (int)SCAN_REC_SHORT_PAYLOAD; rep.errorOffset = recStart; break; }
         if(payloadSize > 0)
           {
            if(!ReadBytes(h, off, pld, (int)payloadSize))
              { rep.code = (int)SCAN_IO_ERROR; rep.errorOffset = recStart; break; }
            uint pldCrcStored = SgsGetU32(rhdr, 64);
            uint pldCrcCalc = SgsCrc32Of(pld);
            if(pldCrcStored != pldCrcCalc)
              { rep.code = (int)SCAN_REC_BAD_PAYLOAD_CRC; rep.errorOffset = recStart; break; }
           }
         else ArrayResize(pld, 0);
         off += (long)payloadSize;
         // record hash = SHA256(header[0..100) || payload)
         uchar headPart[100];
         for(int i = 0; i < 100; i++) headPart[i] = rhdr[i];
         uchar calcHash[32];
         if(!SgsSha256Pair(headPart, pld, calcHash))
           { rep.code = (int)SCAN_IO_ERROR; rep.errorOffset = recStart; break; }
         uchar storedHash[32];
         for(int i = 0; i < 32; i++) storedHash[i] = rhdr[100 + i];
         if(!SgsBytesEqual(storedHash, calcHash, 32))
           { rep.code = (int)SCAN_REC_BAD_HASH; rep.errorOffset = recStart; break; }
         remain = rep.fileSize - off;
         if(remain < SGS_COMMIT_SIZE)
           { rep.code = (int)SCAN_REC_SHORT_COMMIT; rep.errorOffset = recStart; break; }
         if(!ReadBytes(h, off, cmt, SGS_COMMIT_SIZE))
           { rep.code = (int)SCAN_IO_ERROR; rep.errorOffset = recStart; break; }
         uchar cmOk[8]; SgsAscii8(SGS_COMMIT_MAGIC_TEXT, cmOk);
         bool commitOk = true;
         for(int i = 0; i < 8; i++) if(cmt[i] != cmOk[i]) { commitOk = false; break; }
         if(!commitOk)
           { rep.code = (int)SCAN_REC_BAD_COMMIT; rep.errorOffset = recStart; break; }
         off += SGS_COMMIT_SIZE;
         // commit checks passed -> record fully valid
         rep.recordCount++;
         if(rep.recordCount == 1) rep.firstSeq = seq;
         rep.lastSeq = seq; expectSeq = seq + 1;
         for(int i = 0; i < 32; i++) { prevHash[i] = calcHash[i]; rep.lastHash[i] = calcHash[i]; }
         rep.sessionSeen = sess;
         rep.lastTs = (long)SgsGetU64(rhdr, 24);
         if(rep.firstTs == 0) rep.firstTs = rep.lastTs;
         rep.validDataEnd = off;
        }
      FileClose(h);
      if(rep.code == (int)SCAN_OK) rep.validDataEnd = rep.fileSize;
      if(rep.errorOffset == 0 && rep.code != (int)SCAN_OK) rep.errorOffset = rep.validDataEnd;
      if(!SgsScanIsPhysicalTail(rep.code) && rep.code != (int)SCAN_OK) rep.validDataEnd = rep.errorOffset;
      return(rep.code == (int)SCAN_OK);
     }
   //---
   // Conservative recovery, spec steps 1-9 (physical partial tail ONLY):
   //  1 lock held          2 full scan/locate damage   3 classify damage
   //  4 refuse semantic corruption   5 prefix rewrite + atomic-ish move
   //  6 mandatory post-recovery full scan   7 adopt recovered chain state
   //  8 AUDIT the recovery outcome (caller appends JR_RECOVERY)
   //  9 rotation-threshold re-evaluation (caller, at open)
   // (rewrite via temp+FileMove because MQL5 has no FileResize)
   bool      RecoverTailIfPhysical(SGsScanReport &rep, string &outcome)
     {
      outcome = "";
      if(rep.code == (int)SCAN_OK) { outcome = "scan_ok_no_recovery"; return(true); }
      if(!SgsScanIsPhysicalTail(rep.code))
        { outcome = "refused_non_physical_tail:" + SgsScanCodeName(rep.code); return(false); }
      if(!InpRecoveryAllowTailTruncate)
        { outcome = "refused_disabled_by_input:" + SgsScanCodeName(rep.code); return(false); }
      if(!g_rt.lockOwned)
        { outcome = "refused_lock_not_held"; return(false); }
      // rewrite prefix [0, validDataEnd) into a temp file, then atomic-ish move
      string tmp = m_file + ".tmpfix";
      int hs = FileOpen(m_file, FILE_READ | FILE_BIN);
      if(hs == INVALID_HANDLE) { outcome = "open_source_failed"; return(false); }
      int hd = FileOpen(tmp, FILE_WRITE | FILE_BIN);
      if(hd == INVALID_HANDLE) { FileClose(hs); outcome = "open_temp_failed"; return(false); }
      long left = rep.validDataEnd;
      long off = 0; bool ok = true;
      uchar chunk[];
      while(left > 0)
        {
         int take = (int)MathMin(left, (long)SGS_COPY_CHUNK);
         ArrayResize(chunk, take);
         if(!FileSeek(hs, off, SEEK_SET)) { ok = false; break; }
         if((int)FileReadArray(hs, chunk, 0, take) != take) { ok = false; break; }
         if((int)FileWriteArray(hd, chunk, 0, take) != take) { ok = false; break; }
         off += take; left -= take;
        }
      FileFlush(hd); FileClose(hd); FileClose(hs);
      if(!ok) { FileDelete(tmp); outcome = "copy_failed"; return(false); }
      if(!FileMove(tmp, 0, m_file, FILE_REWRITE))
        { FileDelete(tmp); outcome = "move_failed"; return(false); }
      // mandatory full rescan after recovery
      SGsScanReport rep2; rep2.Reset();
      if(!FullScan(m_file, m_instanceId, true, rep2) || rep2.code != (int)SCAN_OK)
        { outcome = "post_recovery_rescan_failed:" + SgsScanCodeName(rep2.code); return(false); }
      // adopt recovered chain state
      rep.code = rep2.code; rep.recordCount = rep2.recordCount; rep.lastSeq = rep2.lastSeq;
      rep.validDataEnd = rep2.validDataEnd; rep.fileSize = rep2.fileSize;
      for(int i = 0; i < 32; i++) rep.lastHash[i] = rep2.lastHash[i];
      outcome = "truncated_physical_tail_to_" + IntegerToString(rep.validDataEnd);
      return(true);
     }
   //---
   // High-level open used during OnInit (scan -> recover -> adopt state)
   bool      OpenOrCreate(const ulong sessionId, string &err)
     {
      err = "";
      if(m_open) { err = "journal already open"; return(false); }
      m_sessionId = sessionId;
      m_needRotate = false;
      // 1) consult manifest for expected live generation
      ulong manifestGen = 0; uchar termHash[32]; string prevArc = "";
      SgsBytesZero(termHash, 32);
      bool haveManifest = ReadManifest(manifestGen, termHash, prevArc);
      // 2) resolve rotation leftovers
      if(haveManifest)
        {
         bool liveExists = FileIsExist(m_file);
         if(!liveExists)
           {
            // interrupted rotation after delete: recreate fresh live generation
            m_generation = manifestGen;
            for(int i = 0; i < 32; i++) m_lastHash[i] = 0;
            if(!CreateNewFile(err)) return(false);
            CarryPrevGenHash(termHash);   // round-27: chain anchor must survive the resume
            Append((int)JR_RECOVERY, (int)DUR_STATE, 0,
                   "action=resume_after_interrupted_rotation;gen=" + IntegerToString((int)manifestGen));
            return(true);
           }
        }
      if(!FileIsExist(m_file))
        {
         m_generation = 0;
         if(!CreateNewFile(err)) return(false);
         if(haveManifest && manifestGen > 0)
           {
            // manifest without journal: suspicious -> rebuild manifest to gen 0 truth
            uchar z[32]; SgsBytesZero(z, 32);
            WriteManifest(0, z, "");
            Append((int)JR_RECOVERY, (int)DUR_STATE, 0, "action=manifest_rebuilt_to_gen0");
           }
         return(true);
        }
      // 3) scan live file
      bool   hadRecovery = false;
      string recoveryOutcome = "";
      SGsScanReport rep; rep.Reset();
      FullScan(m_file, m_instanceId, true, rep);
      if(rep.code != (int)SCAN_OK)
        {
         string outcome = "";
         if(!RecoverTailIfPhysical(rep, outcome))
           {
            err = "journal recovery refused/failed: " + outcome;
            m_healthy = false;
            m_open = false;
            return(false);
           }
         hadRecovery = true; recoveryOutcome = outcome;
        }
      if(!rep.headerValid)
        { err = "journal header invalid"; m_healthy = false; return(false); }
      // 4) rotation-in-progress resolution: manifest generation ahead of file
      if(haveManifest && rep.generation < manifestGen)
        {
         string det = "";
         // close nothing: we still operate by path; open happens below
         if(!ResumeInterruptedRotation(manifestGen, det))
           { err = "cannot resume interrupted rotation: " + det; m_healthy = false; return(false); }
         // fresh live file now
         if(!CreateNewFile(err)) return(false);
         CarryPrevGenHash(termHash);      // round-27: chain anchor must survive the resume
         Append((int)JR_RECOVERY, (int)DUR_STATE, 0,
                "action=rotation_resumed;new_gen=" + IntegerToString((int)m_generation));
         return(true);
        }
      // 5) adopt state and open for writing
      int h = FileOpen(m_file, FILE_READ | FILE_WRITE | FILE_BIN);
      if(h == INVALID_HANDLE) { err = "cannot open journal for writing"; return(false); }
      m_handle = h; m_open = true;
      m_generation = rep.generation;
      m_seq = rep.lastSeq + 1; if(m_seq == 0) m_seq = 1;
      m_validEnd = rep.validDataEnd;
      for(int i = 0; i < 32; i++) m_lastHash[i] = rep.lastHash[i];
      m_healthy = true;
      FileSeek(m_handle, m_validEnd, SEEK_SET);
      // 6) AUDIT the recovery outcome first (step 8 of recovery contract)
      if(hadRecovery)
         Append((int)JR_RECOVERY, (int)DUR_STATE, 0,
                StringFormat("action=tail_truncated;outcome=%s;post_scan=ok;seq_next=%I64u;gen=%I64u",
                             recoveryOutcome, m_seq, m_generation));
      //    then log the open event
      Append((int)JR_META_OPEN, (int)DUR_STATE, 0,
             StringFormat("action=open;file=%s;gen=%I64u;records=%d;size=%I64d",
                          m_file, m_generation, rep.recordCount, rep.fileSize));
      // 7) rotation threshold check at open
      if(InpRotationEnabled && rep.fileSize >= (long)InpJournalMaxFileMB * 1048576L)
         m_needRotate = true;
      return(true);
     }
   //---
   bool      AppendBinary(const int type, const int durability, const int flags,
                          const uchar &payload[])
     {
      if(!m_open || !m_healthy) return(false);
      int payloadSize = ArraySize(payload);
      if(payloadSize > InpJournalMaxPayloadBytes || payloadSize > SGS_MAX_PAYLOAD_HARD)
        {
         // payload must never be silently truncated for FINANCIAL records; refuse
         if(durability == (int)DUR_FINANCIAL) { MarkUnhealthy(); return(false); }
         payloadSize = InpJournalMaxPayloadBytes; // audit/state may be clipped explicitly
        }
      // (round-27 fix 2): CRC32, SHA-256 and the bytes on disk must ALL describe the
      // SAME window. Previously the clipped audit/state record was written with
      // payload[0..payloadSize) but hashed/CRCed over the FULL array — the first scan
      // then flagged SCAN_REC_BAD_PAYLOAD_CRC and broke the chain. Build the clipped
      // body once and use it for crc, hash and write.
      uchar body[];
      ArrayResize(body, payloadSize);
      for(int bi = 0; bi < payloadSize; bi++) body[bi] = payload[bi];
      uchar hdr[]; ArrayResize(hdr, SGS_REC_HEADER_SIZE);
      for(int i = 0; i < SGS_REC_HEADER_SIZE; i++) hdr[i] = 0;
      SgsPutU32(hdr, 0, (uint)SGS_REC_MAGIC);
      SgsPutU16(hdr, 4, (ushort)1);
      SgsPutU16(hdr, 6, (ushort)SGS_REC_HEADER_SIZE);
      SgsPutU16(hdr, 8, (ushort)type);
      SgsPutU16(hdr, 10, (ushort)flags);
      hdr[12] = (uchar)durability;
      SgsPutU64(hdr, 16, m_seq);
      SgsPutU64(hdr, 24, (ulong)SgsNowSec());
      SgsPutU32(hdr, 32, (uint)SgsNowMsc());
      SgsPutU32(hdr, 36, (uint)payloadSize);
      SgsPutU64(hdr, 40, m_instanceId);
      SgsPutU64(hdr, 48, m_sessionId);
      SgsPutU64(hdr, 56, m_generation);
      if(payloadSize > 0)
         SgsPutU32(hdr, 64, SgsCrc32Of(body));
      for(int i = 0; i < 32; i++) hdr[68 + i] = m_lastHash[i];
      uchar headPart[100];
      for(int i = 0; i < 100; i++) headPart[i] = hdr[i];
      uchar recHash[32];
      if(!SgsSha256Pair(headPart, body, recHash))
        { MarkUnhealthy(); return(false); }
      for(int i = 0; i < 32; i++) hdr[100 + i] = recHash[i];
      SgsPutU32(hdr, 132, SgsCrc32End(SgsCrc32Add(SgsCrc32Begin(), hdr, 0, 132)));
      uchar cmt[8]; SgsAscii8(SGS_COMMIT_MAGIC_TEXT, cmt);
      if(!FileSeek(m_handle, m_validEnd, SEEK_SET)) { MarkUnhealthy(); return(false); }
      if(FileWriteArray(m_handle, hdr, 0, SGS_REC_HEADER_SIZE) != (uint)SGS_REC_HEADER_SIZE)
        { MarkUnhealthy(); return(false); }
      if(payloadSize > 0)
        {
         if((int)FileWriteArray(m_handle, body, 0, payloadSize) != payloadSize)
           { MarkUnhealthy(); return(false); }
        }
      if(FileWriteArray(m_handle, cmt, 0, SGS_COMMIT_SIZE) != (uint)SGS_COMMIT_SIZE)
        { MarkUnhealthy(); return(false); }
      FileFlush(m_handle);   // durability: flush policy is immediate for every record
      for(int i = 0; i < 32; i++) m_lastHash[i] = recHash[i];
      m_validEnd += SGS_REC_HEADER_SIZE + payloadSize + SGS_COMMIT_SIZE;
      m_seq++;
      if(InpRotationEnabled && m_validEnd >= (long)InpJournalMaxFileMB * 1048576L)
         m_needRotate = true;
      return(true);
     }
   //---
   bool      Append(const int type, const int durability, const int flags, const string kv)
     {
      if(!m_open || !m_healthy) return(false);
      uchar p[];
      int n = StringToCharArray(kv, p, 0, WHOLE_ARRAY, CP_UTF8);
      int real = (n > 0 ? n - 1 : 0);
      ArrayResize(p, real);
      return(AppendBinary(type, durability, flags, p));
     }
   //---
   // Generation-based rotation with resumable, manifest-driven protocol.
   bool      Rotate(string &err)
     {
      err = "";
      if(!m_open || !m_healthy) { err = "journal not healthy"; return(false); }
      if(!InpRotationEnabled)   { err = "rotation disabled"; return(false); }
      ulong oldGen = m_generation;
      string termHex = LastHashHex();
      Append((int)JR_ROTATION_INTENT, (int)DUR_STATE, 0,
             StringFormat("to_gen=%I64u;term_hash=%s;size=%I64d",
                          oldGen + 1, termHex, CurrentSize()));
      uchar termHash[32];
      for(int i = 0; i < 32; i++) termHash[i] = m_lastHash[i];
      Close();
      string arc = ArcName(oldGen);
      // 1) persist intent in manifest first (single source of truth)
      if(!WriteManifest(oldGen + 1, termHash, arc))
        { err = "manifest write failed"; return(false); }
      // 2) archive copy of the old generation (backup retention)
      if(!FileCopy(m_file, 0, arc, FILE_REWRITE))
        { err = "archive copy failed"; return(false); }
      // 3) delete old live file (resume point if crash happens here)
      if(!FileDelete(m_file))
        { err = "cannot delete old journal"; return(false); }
      // 4) create fresh live file at new generation
      m_generation = oldGen + 1;
      m_sessionId = g_rt.sessionId;
      if(!CreateNewFile(err)) return(false);
      // 5) header of new file: carry previous-generation terminal hash
      //    (rewrite header with prev_gen_terminal_hash != zeros)
      CarryPrevGenHash(termHash);                 // round-27: shared helper (identical logic)
      Append((int)JR_ROTATION_DONE, (int)DUR_STATE, 0,
             StringFormat("gen=%I64u;prev_gen=%I64u;prev_term_hash=%s;arc=%s",
                          m_generation, oldGen, termHex, arc));
      PruneArchives();
      m_needRotate = false;
      return(true);
     }
   //---
   // Cross-generation chain validation: if the previous generation archive
   // still exists, its terminal hash MUST equal this file's prev_gen hash.
   bool      VerifyCrossGeneration(string &why)
     {
      why = "";
      if(m_generation == 0) return(true);
      uchar hdr[];
      if(!ReadBytes(m_handle, 0, hdr, SGS_FILE_HEADER_SIZE))
        { why = "cannot read header"; return(false); }
      uchar expect[32];
      for(int i = 0; i < 32; i++) expect[i] = hdr[40 + i];
      if(SgsBytesAreZero(expect, 32))
        { why = "gen>0_without_prev_terminal_hash"; return(false); } // chain anchor missing
      string arc = ArcName(m_generation - 1);
      if(!FileIsExist(arc))
        { why = "archive_pruned_ok"; return(true); } // retention policy: documented non-fatal
      SGsScanReport rep; rep.Reset();
      if(!FullScan(arc, m_instanceId, true, rep) || rep.code != (int)SCAN_OK)
        { why = "previous generation archive invalid"; return(false); }
      if(!SgsBytesEqual(rep.lastHash, expect, 32))
        { why = "generation terminal hash mismatch (chain broken)"; return(false); }
      return(true);
     }
  };

CSgsJournal g_journal;

//+------------------------------------------------------------------+
//| Instance lock: prevents incompatible concurrent EA instances.    |
//| Scope: per-terminal Files sandbox (documented limitation for     |
//| multi-terminal deployments: use distinct magic per terminal).    |
//+------------------------------------------------------------------+
class CSgsLock
  {
private:
   string  m_name;
   bool    m_owned;
   ulong   m_token;     // instance id
   ulong   m_session;   // session id
   // layout: u32 magic | u64 token | u64 session | u64 chart | u64 heartbeat | u64 timeout | u32 crc
   bool    WriteContent(const int h)
     {
      uchar b[];
      ArrayResize(b, 48);
      for(int i = 0; i < 48; i++) b[i] = 0;
      SgsPutU32(b, 0,  0x4B4C4753);         // 'SGLK'
      SgsPutU64(b, 4,  m_token);
      SgsPutU64(b, 12, m_session);
      SgsPutU64(b, 20, (ulong)ChartID());
      SgsPutU64(b, 28, (ulong)SgsNowSec());
      SgsPutU64(b, 36, (ulong)SGS_MAX_LOCK_AGE_SEC);
      SgsPutU32(b, 44, SgsCrc32End(SgsCrc32Add(SgsCrc32Begin(), b, 0, 44)));
      if(!FileSeek(h, 0, SEEK_SET)) return(false);
      bool ok = (FileWriteArray(h, b, 0, 48) == (uint)48);
      FileFlush(h);
      return(ok);
     }
   bool    ReadContent(ulong &token, ulong &session, ulong &heartbeat, ulong &timeoutSec, ulong &ch)
     {
      token = 0; session = 0; heartbeat = 0; timeoutSec = SGS_MAX_LOCK_AGE_SEC; ch = 0;
      int h = FileOpen(m_name, FILE_READ | FILE_BIN);
      if(h == INVALID_HANDLE) return(false);
      if((long)FileSize(h) < 48) { FileClose(h); return(false); }
      uchar b[]; ArrayResize(b, 48);
      uint got = FileReadArray(h, b, 0, 48);
      FileClose(h);
      if(got != 48) return(false);
      if(SgsGetU32(b, 0) != 0x4B4C4753) return(false);
      uint crc = SgsGetU32(b, 44);
      if(crc != SgsCrc32End(SgsCrc32Add(SgsCrc32Begin(), b, 0, 44))) return(false);
      token = SgsGetU64(b, 4); session = SgsGetU64(b, 12); ch = SgsGetU64(b, 20);
      heartbeat = SgsGetU64(b, 28); timeoutSec = SgsGetU64(b, 36);
      if(timeoutSec == 0 || timeoutSec > 3600) timeoutSec = SGS_MAX_LOCK_AGE_SEC;
      return(true);
     }
public:
   CSgsLock() { m_owned = false; m_token = 0; m_session = 0; m_name = ""; }
   void    Setup(const ulong token, const ulong session)
     {
      m_token = token; m_session = session;
      m_name = StringFormat("SGSP_%I64d_%s_%d.lock",
                            AccountInfoInteger(ACCOUNT_LOGIN),
                            SgsSafeFilePart(g_cfg.symbol), (int)InpMagicNumber);
     }
   string  Name() const { return(m_name); }
   bool    Owned() const { return(m_owned); }
   // returns: 0 acquired, 1 busy(live other owner), 2 io error
   int     Acquire(string &detail)
     {
      detail = "";
      m_owned = false;
      if(FileIsExist(m_name))
        {
         ulong tok = 0, ses = 0, hb = 0, to = 0, ch = 0;
         bool valid = ReadContent(tok, ses, hb, to, ch);
         long age = (long)SgsNowSec() - (long)hb;
         if(valid)
           {
            bool otherOwner = !(tok == m_token && ses == m_session);
            if(otherOwner && age <= (long)to)
              {
               // round-32: tell the user EXACTLY which live chart holds this lock (heartbeat
               // is still inside its 10s TTL => a really-running instance), and the 3 remedies.
               detail = StringFormat("live_lock_held_by_other;chart=%I64d;session=%I64u;stale_in=%ds",
                                     (long)ch, ses, (long)to - age);
               return(1);
              }
            // own lock (same launch re-entry is impossible) or stale
            if(otherOwner)
               detail = "stale_lock_takeover:age=" + IntegerToString(age);
           }
         else detail = "corrupt_lock_overwritten";
        }
      int h = FileOpen(m_name, FILE_READ | FILE_WRITE | FILE_BIN);
      if(h == INVALID_HANDLE)
        {
         h = FileOpen(m_name, FILE_WRITE | FILE_BIN);
         if(h == INVALID_HANDLE) { detail = "lock_create_failed"; return(2); }
        }
      bool ok = WriteContent(h);
      FileClose(h);
      if(!ok) { detail = "lock_write_failed"; return(2); }
      // verify ownership (best-effort race check on this terminal)
      ulong tok = 0, ses = 0, hb = 0, to = 0, ch = 0;
      if(!ReadContent(tok, ses, hb, to, ch) || tok != m_token || ses != m_session)
        { detail = "lock_verify_failed"; return(2); }
      m_owned = true;
      return(0);
     }
   bool    Heartbeat()
     {
      if(!m_owned) return(false);
      int h = FileOpen(m_name, FILE_READ | FILE_WRITE | FILE_BIN);
      if(h == INVALID_HANDLE) return(false);
      // guard: overwrite only if we still appear to be the owner
      ulong tok = 0, ses = 0, hb = 0, to = 0;
      uchar b[]; ArrayResize(b, 48);
      uint got = FileReadArray(h, b, 0, 48);
      if(got == 48 && SgsGetU32(b, 0) == 0x4B4C4753)
        {
         tok = SgsGetU64(b, 4); ses = SgsGetU64(b, 12);
         if(tok != m_token || ses != m_session)
           { FileClose(h); m_owned = false; return(false); } // ownership lost
        }
      bool ok = WriteContent(h);
      FileClose(h);
      return(ok);
     }
   void    Release()               // only the verified owner deletes the lock
     {
      if(!m_owned) return;
      ulong tok = 0, ses = 0, hb = 0, to = 0, ch = 0;
      if(ReadContent(tok, ses, hb, to, ch) && tok == m_token && ses == m_session)
         FileDelete(m_name);
      m_owned = false;
     }
  };

CSgsLock g_lock;

//+------------------------------------------------------------------+
//| State machine with validated transitions                         |
//+------------------------------------------------------------------+
class CSgsState
  {
public:
   static bool Allowed(const ENUM_SGS_STATE from, const ENUM_SGS_STATE to)
     {
      if(from == to) return(false);
      switch(from)
        {
         case SGS_CREATED:
            return(to == SGS_INITIALIZING);
         case SGS_INITIALIZING:
            return(to == SGS_READY || to == SGS_FAULTED || to == SGS_RECOVERY_REQUIRED || to == SGS_RECONCILING);
         case SGS_READY:
            return(to == SGS_TRADING_ENABLED || to == SGS_PAUSED || to == SGS_RECONCILING ||
                   to == SGS_SHUTTING_DOWN || to == SGS_FAULTED || to == SGS_RECOVERY_REQUIRED);
         case SGS_TRADING_ENABLED:
            return(to == SGS_PAUSED || to == SGS_RECOVERY_REQUIRED || to == SGS_FAULTED ||
                   to == SGS_RECONCILING || to == SGS_SHUTTING_DOWN || to == SGS_READY);
         case SGS_PAUSED:
            return(to == SGS_TRADING_ENABLED || to == SGS_RECOVERY_REQUIRED ||
                   to == SGS_FAULTED || to == SGS_SHUTTING_DOWN || to == SGS_READY);
         case SGS_RECOVERY_REQUIRED:
            return(to == SGS_RECONCILING || to == SGS_FAULTED || to == SGS_SHUTTING_DOWN);
         case SGS_RECONCILING:
            return(to == SGS_READY || to == SGS_TRADING_ENABLED || to == SGS_RECOVERY_REQUIRED ||
                   to == SGS_FAULTED || to == SGS_SHUTTING_DOWN);
         case SGS_FAULTED:
            return(to == SGS_SHUTTING_DOWN);
         case SGS_SHUTTING_DOWN:
            return(to == SGS_STOPPED);
         case SGS_STOPPED:
            return(false);
        }
      return(false);
     }
   //---
   static bool Transition(const ENUM_SGS_STATE to, const string reason)
     {
      ENUM_SGS_STATE from = g_rt.state;
      if(!Allowed(from, to))
        {
         string msg = "illegal_state_transition:" + SgsStateName(from) + "->" +
                      SgsStateName(to) + ";reason=" + SgsKvEscape(reason);
         Print("SGS STATE ERROR: ", msg);
         if(g_journal.IsHealthy())
            g_journal.Append((int)JR_ERROR, (int)DUR_STATE, 0, msg);
         g_rt.consecutiveErrors++;
         return(false);
        }
      g_rt.state = to;
      if(g_journal.IsHealthy())
         g_journal.Append((int)JR_STATE, (int)DUR_STATE, 0,
                          "from=" + SgsStateName(from) + ";to=" + SgsStateName(to) +
                          ";reason=" + SgsKvEscape(reason));
      return(true);
     }
  };

//+------------------------------------------------------------------+
//| News filter (MQL5 economic calendar); multi-currency union via   |
//| InpNewsExtraCurrencies (round-18; empty => single-currency mode).|
//| In Strategy Tester the calendar is NOT available: the filter is  |
//| auto-disabled there when InpDisableNewsFilterInTester=true.      |
//| On live, if the calendar is unavailable and                      |
//| InpNewsBlockWhenUnavailable=true, trading is blocked (fail-safe) |
//+------------------------------------------------------------------+
class CSgsNews
  {
private:
   bool     m_effectiveEnabled;
   bool     m_tester;
   datetime m_lastCheck;
   bool     m_blocked;
   string   m_reason;
   string   m_codes[];             // normalised (trim + UPPERCASE, deduped): base + extras (round-18)
public:
   CSgsNews()
     {
      m_effectiveEnabled = false; m_tester = false;
      m_lastCheck = 0; m_blocked = false; m_reason = ""; ArrayResize(m_codes, 0);
     }
   void     Init()
     {
      m_tester = ((bool)MQLInfoInteger(MQL_TESTER)) || ((bool)MQLInfoInteger(MQL_OPTIMIZATION));
      m_effectiveEnabled = InpUseNewsFilter && !(m_tester && InpDisableNewsFilterInTester);
      m_blocked = false; m_reason = ""; m_lastCheck = 0;
      // build the currency set: base code first, then parsed extras (deduped);
      // with default inputs this is exactly { InpNewsCurrency } — single-query behaviour.
      ArrayResize(m_codes, 0);
      {
       string all = InpNewsCurrency + "," + InpNewsExtraCurrencies;
       string toks[];
       int nt0 = StringSplit(all, ',', toks);
       for(int ti = 0; ti < nt0; ti++)
         {
          string tk = toks[ti];
          StringTrimLeft(tk); StringTrimRight(tk); StringToUpper(tk);
          if(StringLen(tk) != 3) continue;             // Validate() already enforces; defensive
          bool dup = false;
          for(int d = 0; d < ArraySize(m_codes); d++)
             if(m_codes[d] == tk) { dup = true; break; }
          if(!dup)
            {
             int cn = ArraySize(m_codes);
             ArrayResize(m_codes, cn + 1); m_codes[cn] = tk;
            }
         }
      }
      if(ArraySize(m_codes) == 0) { ArrayResize(m_codes, 1); m_codes[0] = "USD"; }   // never empty
      if(InpUseNewsFilter && !m_effectiveEnabled)
         m_reason = "disabled_in_tester";   // surfaced on the dashboard News row
     }
   bool     EffectiveEnabled() const { return(m_effectiveEnabled); }
   bool     IsBlocked() const { return(m_effectiveEnabled && m_blocked); }
   string   Reason() const { return(m_reason); }
   //---
   void     Refresh()              // called from OnTimer (<= once / 60s)
     {
      if(!m_effectiveEnabled) { m_blocked = false; return; }   // keep Init-time reason (e.g. disabled_in_tester) for the dashboard (R7-5)
      datetime now = TimeTradeServer();   // calendar times live on the trade-server time axis (MQL5 reference)
      if(now <= 0) now = TimeCurrent();   // fallback when server time is momentarily unknown
      if(m_lastCheck != 0 && now - m_lastCheck < 60) return;
      m_lastCheck = now;
      datetime from = now - InpNewsBlockAfterMin * 60;
      datetime to   = now + InpNewsBlockBeforeMin * 60 + 3600;
      datetime horizonPast   = now - InpNewsBlockAfterMin * 60;
      datetime horizonFuture = now + InpNewsBlockBeforeMin * 60;
      bool blk = false; string why = "";
      bool anyFail = false;
      for(int ci = 0; ci < ArraySize(m_codes); ci++)           // union over currencies (round-18)
        {
         MqlCalendarValue vals[];
         int n = CalendarValueHistory(vals, from, to, NULL, m_codes[ci]);
         if(n < 0) { anyFail = true; continue; }               // one source down must not mask others
         for(int i = 0; i < n && !blk; i++)
           {
            MqlCalendarEvent ev;
            if(!CalendarEventById(vals[i].event_id, ev)) continue;
            bool impOk = false;
            if(InpNewsMinImportance == NEWS_ALL) impOk = true;
            else if(InpNewsMinImportance == NEWS_MEDIUM_AND_HIGH)
               impOk = (ev.importance == CALENDAR_IMPORTANCE_MODERATE || ev.importance == CALENDAR_IMPORTANCE_HIGH);
            else impOk = (ev.importance == CALENDAR_IMPORTANCE_HIGH);
            if(!impOk) continue;
            datetime t = vals[i].time;
            if(t >= horizonPast && t <= horizonFuture)
              {
               blk = true;
               why = m_codes[ci] + " event=" + ev.name + ";t=" + TimeToString(t);   // raw - escaped at journal Append (R7-2)
               break;
              }
           }
         if(blk) break;
        }
      if(anyFail)
        {
         // fail-closed (option): a found block is preserved even when another currency feed failed
         bool prev = m_blocked;
         m_reason = "calendar_unavailable";
         m_blocked = (InpNewsBlockWhenUnavailable || blk);
         if(prev != m_blocked && g_journal.IsHealthy())
            g_journal.Append((int)JR_NEWS, (int)DUR_STATE, 0,
                             "event=calendar_unavailable;blocked=" + IntegerToString((int)m_blocked));
         return;
        }
      bool prev2 = m_blocked;
      m_blocked = blk; m_reason = why;
      if(prev2 != blk && g_journal.IsHealthy())
         g_journal.Append((int)JR_NEWS, (int)DUR_STATE, 0,
                          "event=window_change;blocked=" + IntegerToString((int)blk) +
                          ";why=" + SgsKvEscape(why));
     }
  };

CSgsNews g_news;

//+------------------------------------------------------------------+
//| Technical context + indicator handle cache                       |
//| IMPORTANT: scoring uses ONLY closed bars (shift 1 and 2).        |
//| Shift 0 is never scored (no lookahead / no repainting).          |
//+------------------------------------------------------------------+
struct SGsTech
  {
   bool     ok;
   datetime barTime;        // open time of the scoring (closed) bar = shift 1
   double   emaFast1, emaSlow1;
   double   rsi1, rsi2;
   double   atr1;
   double   open1, high1, low1, close1;
   double   atrPoints;
   bool     htfOk;                  // HTF data ready (only meaningful when InpUseHtfTrendConfirm)
   double   closeHtf1, emaFastHtf1, emaSlowHtf1;
   double   emaFast2, emaSlow2;     // shift-2 values (EMA slope filter, round-14)
   double   open2, high2, low2, close2;  // shift-2 candle (candle patterns / gap filter, round-14)
   bool     adxOk;                  // ADX/+DI/-DI ready (only meaningful when InpUseAdxFilter)
   double   adx1, diPlus1, diMinus1;
   bool     macdOk;                 // MACD main/signal ready (only meaningful when InpUseMacdFilter)
   double   macdMain1, macdSig1;
   void     Reset()
     {
      ok = false; barTime = 0;
      emaFast1 = 0; emaSlow1 = 0; rsi1 = 0; rsi2 = 0; atr1 = 0;
      open1 = 0; high1 = 0; low1 = 0; close1 = 0; atrPoints = 0;
      htfOk = false; closeHtf1 = 0; emaFastHtf1 = 0; emaSlowHtf1 = 0;
      emaFast2 = 0; emaSlow2 = 0;
      open2 = 0; high2 = 0; low2 = 0; close2 = 0;
      adxOk = false; adx1 = 0; diPlus1 = 0; diMinus1 = 0;
      macdOk = false; macdMain1 = 0; macdSig1 = 0;
     }
  };

class CSgsIndicators
  {
private:
   int    m_hEmaF, m_hEmaS, m_hRsi, m_hAtr;
   int    m_hEmaFHtf, m_hEmaSHtf;        // created only when InpUseHtfTrendConfirm
   int    m_hAdx, m_hMacd;               // created only when their filters are enabled (round-14)
   string m_sym;
   ENUM_TIMEFRAMES m_tf;
public:
   CSgsIndicators()
     {
      m_hEmaF = INVALID_HANDLE; m_hEmaS = INVALID_HANDLE;
      m_hRsi  = INVALID_HANDLE; m_hAtr  = INVALID_HANDLE;
      m_hEmaFHtf = INVALID_HANDLE; m_hEmaSHtf = INVALID_HANDLE;
      m_hAdx = INVALID_HANDLE; m_hMacd = INVALID_HANDLE;
      m_tf = PERIOD_M5;
     }
   bool   Init(const string sym, const ENUM_TIMEFRAMES tf, string &err)
     {
      err = ""; m_sym = sym; m_tf = tf;
      m_hEmaF = iMA(sym, tf, InpEmaFastPeriod, 0, MODE_EMA, PRICE_CLOSE);
      if(m_hEmaF == INVALID_HANDLE) { err = "iMA(fast) handle failed"; return(false); }
      m_hEmaS = iMA(sym, tf, InpEmaSlowPeriod, 0, MODE_EMA, PRICE_CLOSE);
      if(m_hEmaS == INVALID_HANDLE) { err = "iMA(slow) handle failed"; Release(); return(false); }
      m_hRsi = iRSI(sym, tf, InpRsiPeriod, PRICE_CLOSE);
      if(m_hRsi == INVALID_HANDLE) { err = "iRSI handle failed"; Release(); return(false); }
      m_hAtr = iATR(sym, tf, InpAtrPeriod);
      if(m_hAtr == INVALID_HANDLE) { err = "iATR handle failed"; Release(); return(false); }
      if(InpUseHtfTrendConfirm)
        {
         m_hEmaFHtf = iMA(sym, InpHtfTimeframe, InpEmaFastPeriod, 0, MODE_EMA, PRICE_CLOSE);
         if(m_hEmaFHtf == INVALID_HANDLE) { err = "iMA(htf fast) handle failed"; Release(); return(false); }
         m_hEmaSHtf = iMA(sym, InpHtfTimeframe, InpEmaSlowPeriod, 0, MODE_EMA, PRICE_CLOSE);
         if(m_hEmaSHtf == INVALID_HANDLE) { err = "iMA(htf slow) handle failed"; Release(); return(false); }
        }
      if(InpUseAdxFilter)
        {
         m_hAdx = iADX(sym, tf, InpAdxPeriod);
         if(m_hAdx == INVALID_HANDLE) { err = "iADX handle failed"; Release(); return(false); }
        }
      if(InpUseMacdFilter)
        {
         m_hMacd = iMACD(sym, tf, InpMacdFast, InpMacdSlow, InpMacdSignal, PRICE_CLOSE);
         if(m_hMacd == INVALID_HANDLE) { err = "iMACD handle failed"; Release(); return(false); }
        }
      return(true);
     }
   void   Release()
     {
      if(m_hEmaF != INVALID_HANDLE) { IndicatorRelease(m_hEmaF); m_hEmaF = INVALID_HANDLE; }
      if(m_hEmaS != INVALID_HANDLE) { IndicatorRelease(m_hEmaS); m_hEmaS = INVALID_HANDLE; }
      if(m_hRsi  != INVALID_HANDLE) { IndicatorRelease(m_hRsi);  m_hRsi  = INVALID_HANDLE; }
      if(m_hAtr  != INVALID_HANDLE) { IndicatorRelease(m_hAtr);  m_hAtr  = INVALID_HANDLE; }
      if(m_hEmaFHtf != INVALID_HANDLE) { IndicatorRelease(m_hEmaFHtf); m_hEmaFHtf = INVALID_HANDLE; }
      if(m_hEmaSHtf != INVALID_HANDLE) { IndicatorRelease(m_hEmaSHtf); m_hEmaSHtf = INVALID_HANDLE; }
      if(m_hAdx  != INVALID_HANDLE) { IndicatorRelease(m_hAdx);  m_hAdx  = INVALID_HANDLE; }
      if(m_hMacd != INVALID_HANDLE) { IndicatorRelease(m_hMacd); m_hMacd = INVALID_HANDLE; }
     }
   int    RequiredBars() const
     {
      int m1 = (int)MathMax((long)InpEmaFastPeriod, (long)InpEmaSlowPeriod);
      int m2 = (int)MathMax((long)InpRsiPeriod, (long)InpAtrPeriod);
      return((int)MathMax((long)m1, (long)m2) + 8);
     }
   bool   Warm() const
     {
      if(m_hEmaF == INVALID_HANDLE || m_hEmaS == INVALID_HANDLE) return(false);
      if(m_hRsi == INVALID_HANDLE || m_hAtr == INVALID_HANDLE) return(false);
      int need = RequiredBars();
      if(BarsCalculated(m_hEmaF) < need || BarsCalculated(m_hEmaS) < need) return(false);
      if(BarsCalculated(m_hRsi) < need || BarsCalculated(m_hAtr) < need) return(false);
      if(Bars(m_sym, m_tf) < need) return(false);
      return(true);
     }
   bool   Refresh(SGsTech &t)
     {
      t.Reset();
      if(!Warm()) return(false);
      double ef[], es[], r[], a[];
      ArraySetAsSeries(ef, true); ArraySetAsSeries(es, true);
      ArraySetAsSeries(r, true);  ArraySetAsSeries(a, true);
      if(CopyBuffer(m_hEmaF, 0, 0, 3, ef) < 3) return(false);
      if(CopyBuffer(m_hEmaS, 0, 0, 3, es) < 3) return(false);
      if(CopyBuffer(m_hRsi,  0, 0, 3, r)  < 3) return(false);
      if(CopyBuffer(m_hAtr,  0, 0, 3, a)  < 3) return(false);
      double o[], h[], l[], c[];
      ArraySetAsSeries(o, true); ArraySetAsSeries(h, true);
      ArraySetAsSeries(l, true); ArraySetAsSeries(c, true);
      if(CopyOpen(m_sym, m_tf, 0, 3, o)  < 3) return(false);
      if(CopyHigh(m_sym, m_tf, 0, 3, h)  < 3) return(false);
      if(CopyLow(m_sym, m_tf, 0, 3, l)   < 3) return(false);
      if(CopyClose(m_sym, m_tf, 0, 3, c) < 3) return(false);
      // sanity: no EMPTY_VALUE, no non-positive ATR
      if(ef[1] == EMPTY_VALUE || es[1] == EMPTY_VALUE ||
         r[1] == EMPTY_VALUE || a[1] == EMPTY_VALUE) return(false);
      if(a[1] <= 0.0) return(false);
      t.emaFast1 = ef[1]; t.emaSlow1 = es[1];
      t.emaFast2 = ef[2]; t.emaSlow2 = es[2];
      t.rsi1 = r[1]; t.rsi2 = r[2];
      t.atr1 = a[1];
      t.open1 = o[1]; t.high1 = h[1]; t.low1 = l[1]; t.close1 = c[1];
      t.open2 = o[2]; t.high2 = h[2]; t.low2 = l[2]; t.close2 = c[2];
      t.barTime = iTime(m_sym, m_tf, 1);       // closed bar open time
      t.atrPoints = t.atr1 / g_sym.Point();
      // round-14 model data (optional): ADX(+DI/-DI) and MACD(main/signal), closed bar only.
      // Failure never blocks the M5 tech state; it only forces the related gate false (fail-safe).
      t.adxOk = false; t.macdOk = false;
      if(InpUseAdxFilter && m_hAdx != INVALID_HANDLE)
        {
         double av[], dp[], dm[];
         ArraySetAsSeries(av, true); ArraySetAsSeries(dp, true); ArraySetAsSeries(dm, true);
         if(BarsCalculated(m_hAdx) >= InpAdxPeriod + 8 &&
            CopyBuffer(m_hAdx, 0, 0, 2, av) >= 2 && CopyBuffer(m_hAdx, 1, 0, 2, dp) >= 2 &&
            CopyBuffer(m_hAdx, 2, 0, 2, dm) >= 2 &&
            av[1] != EMPTY_VALUE && dp[1] != EMPTY_VALUE && dm[1] != EMPTY_VALUE)
           {
            t.adx1 = av[1]; t.diPlus1 = dp[1]; t.diMinus1 = dm[1];
            t.adxOk = true;
           }
        }
      if(InpUseMacdFilter && m_hMacd != INVALID_HANDLE)
        {
         double mm[], ms[];
         ArraySetAsSeries(mm, true); ArraySetAsSeries(ms, true);
         if(BarsCalculated(m_hMacd) >= InpMacdSlow + InpMacdSignal + 8 &&
            CopyBuffer(m_hMacd, 0, 0, 2, mm) >= 2 && CopyBuffer(m_hMacd, 1, 0, 2, ms) >= 2 &&
            mm[1] != EMPTY_VALUE && ms[1] != EMPTY_VALUE)
           {
            t.macdMain1 = mm[1]; t.macdSig1 = ms[1];
            t.macdOk = true;
           }
        }
      // HTF confirmation data (optional): failure here never blocks the M5 tech state,
      // it only forces gateHtf=false when the filter is enabled (fail-safe, no entries).
      t.htfOk = false;
      if(InpUseHtfTrendConfirm)
        {
         int needH = (int)InpEmaSlowPeriod + 8;
         double hf[], hs[];
         ArraySetAsSeries(hf, true); ArraySetAsSeries(hs, true);
         if(m_hEmaFHtf != INVALID_HANDLE && m_hEmaSHtf != INVALID_HANDLE &&
            BarsCalculated(m_hEmaFHtf) >= needH && BarsCalculated(m_hEmaSHtf) >= needH &&
            CopyBuffer(m_hEmaFHtf, 0, 0, 2, hf) >= 2 && CopyBuffer(m_hEmaSHtf, 0, 0, 2, hs) >= 2)
           {
            double hc = iClose(m_sym, InpHtfTimeframe, 1);   // closed HTF bar only
            if(hc > 0.0 && hf[1] != EMPTY_VALUE && hs[1] != EMPTY_VALUE)
              {
               t.closeHtf1 = hc; t.emaFastHtf1 = hf[1]; t.emaSlowHtf1 = hs[1];
               t.htfOk = true;
              }
           }
        }
      t.ok = true;
      return(true);
     }
  };

CSgsIndicators g_ind;

//+------------------------------------------------------------------+
//| Signal result                                                    |
//+------------------------------------------------------------------+
struct SGsSignalOut
  {
   int      dir;                 // ENUM_SGS_SIGNAL
   int      buyScore,  buyMax;   // 0..100
   int      sellScore, sellMax;
   double   confidence;          // winner score / 100
   uint     reasons;             // RSN_* bitmask of positive conditions
   string   gates;               // gate layer pass/fail summary
   datetime barTime;             // scoring bar
   bool     gateSpread, gateVolatility, gateSession, gateRollover,
            gateNews, gateHistory, gateTrend;
   bool     gateHtf, gateClosePos, gateRsiMom, gateNoExtension;   // precision pack (round-11)
   bool     gateSrSpace, gateFvg;                                 // structure pack (round-12)
   bool     gateMss;                                              // BOS/CHoCH structure bias (round-13)
   // round-14: advanced models + extra trading filters
   bool     gateEmaSlope, gateAdx, gateMacd, gateCandlePattern;
   bool     gateSupplyDemand, gateLiquidity, gateGapJump, gateDayHiLo;
   void     Reset()
     {
      dir = (int)SIGNAL_NONE; buyScore = 0; sellScore = 0;
      buyMax = 100; sellMax = 100; confidence = 0.0; reasons = 0;
      gates = ""; barTime = 0;
      gateSpread = false; gateVolatility = false; gateSession = false;
      gateRollover = false; gateNews = false; gateHistory = false; gateTrend = false;
      gateHtf = false; gateClosePos = false; gateRsiMom = false; gateNoExtension = false;
      gateSrSpace = false; gateFvg = false;
      gateMss = false;
      gateEmaSlope = false; gateAdx = false; gateMacd = false; gateCandlePattern = false;
      gateSupplyDemand = false; gateLiquidity = false; gateGapJump = false; gateDayHiLo = false;
     }
   bool     GatesAllPass() const
     {
      return(gateSpread && gateVolatility && gateSession && gateRollover &&
             gateNews && gateHistory && gateTrend &&
             gateHtf && gateClosePos && gateRsiMom && gateNoExtension &&
             gateSrSpace && gateFvg && gateMss &&
             gateEmaSlope && gateAdx && gateMacd && gateCandlePattern &&
             gateSupplyDemand && gateLiquidity && gateGapJump && gateDayHiLo);
     }
  };

//+------------------------------------------------------------------+
//| Signal engine (documented original logic):                       |
//|  Score layer (max 100 per side; 85 when candle-confirm is off):                                  |
//|    Trend       30  close1>Sema & fema>sema (mirror for sell)     |
//|    RSI zone    25  RSI inside configured bull/bear zone          |
//|    RSI cross   15  RSI crosses 50 on closed bars                 |
//|    Candle      15  body/range >= InpBodyConfirmRatio (if >0)     |
//|    Pullback    15  |close1-EMAfast| <= InpPullbackAtrMult*ATR    |
//|  Gate layer (must ALL pass to trade): spread, ATR volatility,    |
//|  session+DoW, rollover window, news window, history depth,       |
//|  optional hard trend gate.                                       |
//+------------------------------------------------------------------+
class CSgsSignalEngine
  {
private:
   datetime m_structBar;           // bar-time of the cached structural snapshot (0 = stale)
   bool     m_structOk;            // data sufficiency on last ComputeStructure
   bool     m_hasResist, m_hasSupport;
   double   m_resistAbove, m_supportBelow;   // nearest pivot levels vs close of bar1
   bool     m_bullFvg, m_bearFvg;            // fresh unmitigated FVG exists (each side)
   bool     m_hasPHigh, m_hasPLow;           // most recent CONFIRMED pivot high/low (levels)
   double   m_lastPHigh, m_lastPLow;
   bool     m_mssOk;                         // data + at least one confirmed pivot available for MSS
   int      m_mssBias;                       // LATCHED market-structure bias: +1 bull / -1 bear / 0 unknown
   // round-14: supply/demand zones + liquidity pools
   bool     m_sdDemand, m_sdSupply;          // fresh unmitigated zone exists per side
   bool     m_hasLiqHigh, m_hasLiqLow;       // equal-highs pool above / equal-lows pool below
   double   m_liqHigh, m_liqLow;              // pool boundary levels (nearest sweep zone)
   double   m_pivH[], m_pivL[];               // per-bar pivot pool for liquidity detection (cleared in ResetStruct)

public:
   CSgsSignalEngine() { ResetStruct(); m_mssBias = 0; }
   void   ResetStruct()
     {
      m_structBar = 0; m_structOk = false;
      m_hasResist = false; m_hasSupport = false;
      m_resistAbove = 0.0; m_supportBelow = 0.0;
      m_bullFvg = false; m_bearFvg = false;
      m_hasPHigh = false; m_hasPLow = false;
      m_lastPHigh = 0.0; m_lastPLow = 0.0; m_mssOk = false;
      m_sdDemand = false; m_sdSupply = false;
      m_hasLiqHigh = false; m_hasLiqLow = false;
      m_liqHigh = 0.0; m_liqLow = 0.0;
      ArrayResize(m_pivH, 0); ArrayResize(m_pivL, 0);
      // NOTE: m_mssBias is intentionally NOT reset here - the structure bias is a per-bar
      // latch that must survive ResetStruct(), which runs at the start of every recomputation.
     }

   // round-30: read-only pivot accessors for the SL_STRUCT/TRAIL_STRUCT consumers
   // (CSgsRisk::ComputeStopDistancePrice, CSgsTrade trailing) — guarded by the snapshot
   // validity flag so a stale/insufficient structure snapshot can never move a stop.
   bool   HasPivotLow()  const { return(m_structOk && m_hasPLow); }
   bool   HasPivotHigh() const { return(m_structOk && m_hasPHigh); }
   double LastPLow()     const { return(m_lastPLow); }
   double LastPHigh()    const { return(m_lastPHigh); }

   // Structural snapshot, recomputed at most once per closed bar (bar-close data only,
   // no lookahead): pivot S/R uses bars fully older than the newest closed bar;
   // pivots need `radius` newer closed bars before they confirm.
   void   ComputeStructure(const SGsTech &t)
     {
      const bool useStructSl = (InpSlMode == SL_STRUCT || InpTrailMode == TRAIL_STRUCT);
      if(!InpUseSwingSRFilter && !InpUseFvgFilter && !InpUseMssFilter &&
         !InpUseSupplyDemandFilter && !InpUseLiquidityFilter && !useStructSl) return;
      if(t.barTime == m_structBar) return;     // memoized per closed bar (perf)
      ResetStruct(); m_structBar = t.barTime;

      const bool usePiv = (InpUseSwingSRFilter || InpUseMssFilter || InpUseLiquidityFilter || useStructSl);
      int needSr  = (InpUseSwingSRFilter ? InpSrLookbackBars + InpSrPivotRadius + 2 : 0);
      int needFvg = (InpUseFvgFilter     ? InpFvgLookbackBars + 3 : 0);
      int needMss = (InpUseMssFilter     ? InpMssLookbackBars + InpSrPivotRadius + 2 : 0);
      int needSd  = (InpUseSupplyDemandFilter ? InpSdZoneMaxAgeBars + 3 : 0);
      int needLiq = (InpUseLiquidityFilter ? InpLiqLookbackBars + InpSrPivotRadius + 2 : 0);
      int needPiv = (useStructSl ? InpSrLookbackBars + InpSrPivotRadius + 2 : 0);
      int need    = (int)MathMax(needSr, (int)MathMax(needFvg,
                     (int)MathMax(needMss, (int)MathMax(needSd, (int)MathMax(needLiq, needPiv)))));
      double h[], l[], c[], o[];
      ArraySetAsSeries(h, true); ArraySetAsSeries(l, true);
      ArraySetAsSeries(c, true); ArraySetAsSeries(o, true);
      int gh = CopyHigh(g_cfg.symbol, InpTimeframe, 1, need, h);   // h[0] = bar shift 1 (closed)
      int gl = CopyLow (g_cfg.symbol, InpTimeframe, 1, need, l);
      if(gh <= 0 || gl <= 0) return;           // data not ready -> gate fail (fail-safe)
      int gc = 0, go = 0;
      if(InpUseSupplyDemandFilter)
        {
         gc = CopyClose(g_cfg.symbol, InpTimeframe, 1, need, c);
         go = CopyOpen (g_cfg.symbol, InpTimeframe, 1, need, o);
         if(gc <= 0 || go <= 0) return;
        }
      int got = (int)MathMin(gh, gl);
      if(InpUseSupplyDemandFilter) got = (int)MathMin(got, (int)MathMin(gc, go));
      m_structOk = true;
      const double refC = t.close1;

      if(usePiv)
        {
         int r = InpSrPivotRadius;
         int maxSr  = ((InpUseSwingSRFilter || useStructSl) ? (int)MathMin(got - 1 - r, InpSrLookbackBars) : r - 1);
         int maxMss = (InpUseMssFilter     ? (int)MathMin(got - 1 - r, InpMssLookbackBars) : r - 1);
         int maxLiq = (InpUseLiquidityFilter ? (int)MathMin(got - 1 - r, InpLiqLookbackBars) : r - 1);
         int maxAll = (int)MathMax(maxSr, (int)MathMax(maxMss, maxLiq));
         for(int i = r; i <= maxAll; i++)
           {
            bool isPH = true, isPL = true;
            for(int k = 1; k <= r; k++)
              {
               if(!(h[i] > h[i-k]) || !(h[i] > h[i+k])) isPH = false;   // strict: plateaus skipped
               if(!(l[i] < l[i-k]) || !(l[i] < l[i+k])) isPL = false;
              }
            if(i <= maxSr)
              {
               if(isPH && h[i] > refC && (!m_hasResist  || h[i] < m_resistAbove))  { m_resistAbove  = h[i]; m_hasResist  = true; }
               if(isPL && l[i] < refC && (!m_hasSupport || l[i] > m_supportBelow)) { m_supportBelow = l[i]; m_hasSupport = true; }
              }
            if(i <= maxMss || (useStructSl && i <= maxSr))   // round-30: struct SL/trail also need the most-recent confirmed pivot
              {   // ascending i: the FIRST confirmed pivot is the MOST RECENT one
               if(isPH && !m_hasPHigh) { m_lastPHigh = h[i]; m_hasPHigh = true; }
               if(isPL && !m_hasPLow)  { m_lastPLow  = l[i]; m_hasPLow  = true; }
              }
            if(i <= maxLiq)
              {
               if(isPH) { int q = ArraySize(m_pivH); ArrayResize(m_pivH, q + 1); m_pivH[q] = h[i]; }
               if(isPL) { int q = ArraySize(m_pivL); ArrayResize(m_pivL, q + 1); m_pivL[q] = l[i]; }
              }
           }
        }
      // Liquidity pools: equal pivot highs ABOVE price / equal lows BELOW (round-14)
      if(InpUseLiquidityFilter)
        {
         double tol = InpLiqToleranceAtrMult * t.atr1;
         int nh = ArraySize(m_pivH), nl = ArraySize(m_pivL);
         for(int i = 0; i < nh && !m_hasLiqHigh; i++)
            for(int j = i + 1; j < nh; j++)
              {
               if(m_pivH[i] <= refC || m_pivH[j] <= refC) continue;
               if(MathAbs(m_pivH[i] - m_pivH[j]) <= tol)
                 { m_liqHigh = (m_pivH[i] < m_pivH[j] ? m_pivH[i] : m_pivH[j]); m_hasLiqHigh = true; break; }
              }
         for(int i = 0; i < nl && !m_hasLiqLow; i++)
            for(int j = i + 1; j < nl; j++)
              {
               if(m_pivL[i] >= refC || m_pivL[j] >= refC) continue;
               if(MathAbs(m_pivL[i] - m_pivL[j]) <= tol)
                 { m_liqLow = (m_pivL[i] > m_pivL[j] ? m_pivL[i] : m_pivL[j]); m_hasLiqLow = true; break; }
              }
        }
      // Supply/demand zones: strong impulse out of a small base candle, zone still unmitigated
      if(InpUseSupplyDemandFilter)
        {
         double impMin = InpSdImpulseAtrMult * t.atr1;
         double baseMax = 0.35 * t.atr1;
         int maxJ = (int)MathMin(got - 2, InpSdZoneMaxAgeBars);
         for(int j = 1; j <= maxJ && (!m_sdDemand || !m_sdSupply); j++)
           {
            double imp = c[j] - o[j];
            double rng = h[j] - l[j];
            if(rng <= 0.0) continue;
            double baseBody = MathAbs(c[j+1] - o[j+1]);
            if(baseBody > baseMax) continue;
            if(!m_sdDemand && imp >= impMin && imp / rng >= 0.6)
              {                                  // bullish impulse out of base -> DEMAND at base range
               double zoneLow = l[j+1];
               bool filled = false;
               for(int k = 0; k < j; k++) { if(l[k] <= zoneLow) { filled = true; break; } }
               if(!filled) m_sdDemand = true;
              }
            if(!m_sdSupply && -imp >= impMin && -imp / rng >= 0.6)
              {                                  // bearish impulse out of base -> SUPPLY at base range
               double zoneHigh = h[j+1];
               bool filled = false;
               for(int k = 0; k < j; k++) { if(h[k] >= zoneHigh) { filled = true; break; } }
               if(!filled) m_sdSupply = true;
              }
           }
        }
      if(InpUseMssFilter)
        {
         m_mssOk = (m_hasPHigh || m_hasPLow);
         if(m_mssOk)
           {   // BOS up: close breaks the most recent confirmed swing high; down: swing low.
               // Between breaks the bias LATCHES; the first break against the latch is the CHoCH.
            if(m_hasPHigh && t.close1 > m_lastPHigh)      m_mssBias =  1;
            else if(m_hasPLow && t.close1 < m_lastPLow)   m_mssBias = -1;
           }
        }
      if(InpUseFvgFilter)
        {
         double minGap = InpMinFvgSizeAtrMult * t.atr1;
         int maxF = (int)MathMin(got - 3, InpFvgLookbackBars - 1);    // series index of newest FVG candle (C)
         for(int f = 0; f <= maxF; f++)
           {
            if(!m_bullFvg && l[f] > h[f+2] && (l[f] - h[f+2]) >= minGap)
              {                       // bullish FVG (h[f+2] .. l[f]); full-fill mitigation check
               bool filled = false;
               for(int j = 0; j < f; j++) { if(l[j] <= h[f+2]) { filled = true; break; } }
               if(!filled) m_bullFvg = true;
              }
            if(!m_bearFvg && h[f] < l[f+2] && (l[f+2] - h[f]) >= minGap)
              {                       // bearish FVG (h[f] .. l[f+2])
               bool filled = false;
               for(int j = 0; j < f; j++) { if(h[j] >= l[f+2]) { filled = true; break; } }
               if(!filled) m_bearFvg = true;
              }
            if(m_bullFvg && m_bearFvg) break;
           }
        }
     }

   void   Evaluate(const SGsTech &t, const long spreadPts, SGsSignalOut &o)
     {
      o.Reset();
      if(!t.ok) { o.gates = "tech_not_ready"; return; }
      o.barTime = t.barTime;
      // ---- score layer
      int bs = 0, ss = 0;
      uint rsn = 0;
      bool trendUp   = (t.close1 > t.emaSlow1 && t.emaFast1 > t.emaSlow1);
      bool trendDown = (t.close1 < t.emaSlow1 && t.emaFast1 < t.emaSlow1);
      if(trendUp)   { bs += 30; rsn |= (uint)RSN_TREND_UP; }
      if(trendDown) { ss += 30; rsn |= (uint)RSN_TREND_DOWN; }
      if(t.rsi1 >= InpRsiBullMin && t.rsi1 <= InpRsiBullMax)
        { bs += 25; rsn |= (uint)RSN_RSI_BULL_ZONE; }
      if(t.rsi1 >= InpRsiBearMin && t.rsi1 <= InpRsiBearMax)
        { ss += 25; rsn |= (uint)RSN_RSI_BEAR_ZONE; }
      if(t.rsi2 < 50.0 && t.rsi1 >= 50.0) { bs += 15; rsn |= (uint)RSN_RSI_CROSS_UP; }
      if(t.rsi2 > 50.0 && t.rsi1 <= 50.0) { ss += 15; rsn |= (uint)RSN_RSI_CROSS_DOWN; }
      if(InpBodyConfirmRatio > 0.0)
        {
         double range = t.high1 - t.low1;
         if(range > 0.0)
           {
            double body = t.close1 - t.open1;
            if(body > 0.0 && body / range >= InpBodyConfirmRatio)
              { bs += 15; rsn |= (uint)RSN_CANDLE_BULL; }
            if(body < 0.0 && (-body) / range >= InpBodyConfirmRatio)
              { ss += 15; rsn |= (uint)RSN_CANDLE_BEAR; }
           }
        }
      double pullLim = InpPullbackAtrMult * t.atr1;
      double distF = MathAbs(t.close1 - t.emaFast1);
      if(trendUp   && distF <= pullLim) { bs += 15; rsn |= (uint)RSN_PULLBACK_BUY; }
      if(trendDown && distF <= pullLim) { ss += 15; rsn |= (uint)RSN_PULLBACK_SELL; }
      o.buyScore = bs; o.sellScore = ss; o.reasons = rsn;
      // ---- gate layer
      o.gateSpread = !InpUseSpreadFilter || spreadPts <= (long)InpMaxSpreadPips * (long)InpPipSizePoints;
      if(o.gateSpread) o.reasons |= (uint)RSN_SPREAD_OK;
      bool volOk = true;
      if(InpUseVolatilityFilter)
        {
         if(InpAtrFilterMinPips > 0.0 && t.atrPoints < InpAtrFilterMinPips * (double)InpPipSizePoints) volOk = false;
         if(InpAtrFilterMaxPips > 0.0 && t.atrPoints > InpAtrFilterMaxPips * (double)InpPipSizePoints) volOk = false;
        }
      o.gateVolatility = volOk;
      if(volOk) o.reasons |= (uint)RSN_VOLATILITY_OK;
      // session + weekday
      bool sessOk = true;
      if(InpUseSessionFilter)
        {
         datetime now = TimeCurrent();
         MqlDateTime dt; TimeToStruct(now, dt);
         if(dt.day_of_week < 0 || dt.day_of_week > 6 || !g_cfg.dayAllowed[dt.day_of_week])
            sessOk = false;
         else if(!SgsInWindow(SgsMinutesOfDay(now), g_cfg.sessionStartMin, g_cfg.sessionEndMin))
            sessOk = false;
        }
      o.gateSession = sessOk;
      if(sessOk) o.reasons |= (uint)RSN_SESSION_OK;
      bool rollOk = true;
      if(InpUseRolloverFilter)
        {
         if(SgsInWindow(SgsMinutesOfDay(TimeCurrent()), g_cfg.rollStartMin, g_cfg.rollEndMin))
            rollOk = false;
        }
      o.gateRollover = rollOk;
      if(rollOk) o.reasons |= (uint)RSN_ROLLOVER_CLEAR;
      o.gateNews = !g_news.IsBlocked();
      if(o.gateNews) o.reasons |= (uint)RSN_NEWS_CLEAR;
      o.gateHistory = (Bars(g_cfg.symbol, InpTimeframe) >= InpBarsRequired);
      if(o.gateHistory) o.reasons |= (uint)RSN_HISTORY_OK;
      o.gateTrend = true;
      if(InpUseTrendGate)
        {
         o.gateTrend = (trendUp || trendDown);   // market must have a trend state
         if(o.gateTrend) o.reasons |= (uint)RSN_TREND_GATE_OK;
        }
      // ---- decision
      // R9-3: confidence normalizes against the achievable maximum; with the
      // candle component switched off the ceiling is 85, not 100 (otherwise a
      // high InpMinConfidence could silently block every entry).
      double maxScore = (InpBodyConfirmRatio > 0.0 ? 100.0 : 85.0);
      bool buyQ  = (bs >= InpMinScoreToTrade && ((double)bs / maxScore) >= InpMinConfidence);
      bool sellQ = (ss >= InpMinScoreToTrade && ((double)ss / maxScore) >= InpMinConfidence);
      if(InpUseTrendGate)
        {
         if(buyQ  && !trendUp)   buyQ  = false;
         if(sellQ && !trendDown) sellQ = false;
        }
      // ---- precision confirmation layer (round-11; all default OFF; strictly additive) ----
      bool htfUp = false, htfDown = false;
      o.gateHtf = true;
      if(InpUseHtfTrendConfirm)
        {
         if(!t.htfOk) o.gateHtf = false;          // fail-safe: no HTF data -> no entries
         else
           {
            htfUp   = (t.closeHtf1 > t.emaSlowHtf1 && t.emaFastHtf1 > t.emaSlowHtf1);
            htfDown = (t.closeHtf1 < t.emaSlowHtf1 && t.emaFastHtf1 < t.emaSlowHtf1);
            o.gateHtf = (htfUp || htfDown);
            if(o.gateHtf) o.reasons |= (uint)RSN_HTF_OK;
            if(buyQ  && !htfUp)   buyQ  = false;  // entry side must match the HTF trend
            if(sellQ && !htfDown) sellQ = false;
           }
        }
      o.gateClosePos = true;
      if(InpUseClosePosFilter)
        {
         double posInRange = (t.high1 > t.low1 ? (t.close1 - t.low1) / (t.high1 - t.low1) : 0.5);
         bool posB = (posInRange >= InpMinClosePosRatio);
         bool posS = (posInRange <= 1.0 - InpMinClosePosRatio);
         o.gateClosePos = (posB || posS);
         if(o.gateClosePos) o.reasons |= (uint)RSN_CLOSEPOS_OK;
         if(buyQ  && !posB) buyQ  = false;
         if(sellQ && !posS) sellQ = false;
        }
      o.gateRsiMom = true;
      if(InpUseRsiMomentumFilter)
        {
         bool momB = (t.rsi1 > t.rsi2);
         bool momS = (t.rsi1 < t.rsi2);
         o.gateRsiMom = (momB || momS);
         if(o.gateRsiMom) o.reasons |= (uint)RSN_RSI_MOM_OK;
         if(buyQ  && !momB) buyQ  = false;
         if(sellQ && !momS) sellQ = false;
        }
      o.gateNoExtension = true;
      if(InpUseExtensionFilter)
        {
         double ext = t.close1 - t.emaFast1;
         double lim = InpMaxExtensionAtrMult * t.atr1;
         o.gateNoExtension = (MathAbs(ext) <= lim);   // chasing entries beyond lim are denied
         if(o.gateNoExtension) o.reasons |= (uint)RSN_NO_EXT_OK;
         if(buyQ  && ext >  lim) buyQ  = false;
         if(sellQ && ext < -lim) sellQ = false;
        }
      // ---- structure layer (round-12/14; default OFF; strictly additive) ----
      // OnTick already computed this bar (memoized no-op here); the disjunction lists
      // every consumer so a future call-site reorder cannot strand the gates.
      // (round-27 fix 1): Evaluate must own this local — the identically named flag
      // inside ComputeStructure is out of scope here (undeclared identifier).
      const bool useStructSl = (InpSlMode == SL_STRUCT || InpTrailMode == TRAIL_STRUCT);
      if(InpUseSwingSRFilter || InpUseFvgFilter || InpUseMssFilter ||
         InpUseSupplyDemandFilter || InpUseLiquidityFilter || useStructSl)
         ComputeStructure(t);
      o.gateSrSpace = true;
      if(InpUseSwingSRFilter)
        {
         if(!m_structOk) o.gateSrSpace = false;      // fail-safe like HTF: no data -> no entries
         else
           {
            double limS = InpMinSpaceToLevelAtrMult * t.atr1;
            bool spB = (!m_hasResist  || (m_resistAbove  - t.close1) >= limS);  // absent level = open space (breakout allowed)
            bool spS = (!m_hasSupport || (t.close1 - m_supportBelow) >= limS);
            o.gateSrSpace = (spB || spS);
            if(o.gateSrSpace) o.reasons |= (uint)RSN_SR_OK;
            if(buyQ  && !spB) buyQ  = false;
            if(sellQ && !spS) sellQ = false;
           }
        }
      o.gateFvg = true;
      if(InpUseFvgFilter)
        {
         o.gateFvg = (m_bullFvg || m_bearFvg);       // fresh unmitigated FVG must exist somewhere
         if(o.gateFvg) o.reasons |= (uint)RSN_FVG_OK;
         if(buyQ  && !m_bullFvg) buyQ  = false;      // demand imbalance required for longs
         if(sellQ && !m_bearFvg) sellQ = false;
        }
      o.gateMss = true;
      if(InpUseMssFilter)
        {
         int eff = (m_structOk && m_mssOk ? m_mssBias : 0);  // fail-safe: no pivot/data -> entries blocked, latch preserved
         o.gateMss = (eff != 0);
         if(o.gateMss) o.reasons |= (uint)RSN_MSS_OK;
         if(buyQ  && eff <= 0) buyQ  = false;
         if(sellQ && eff >= 0) sellQ = false;
        }
      // ---- advanced models & extra filters (round-14; all default OFF; strictly additive) ----
      o.gateEmaSlope = true;
      if(InpUseEmaSlopeFilter)
        {
         if(t.emaFast2 <= 0.0) o.gateEmaSlope = false;        // fail-safe: slope data required
         else
           {
            bool slopeB = (t.emaFast1 > t.emaFast2);
            bool slopeS = (t.emaFast1 < t.emaFast2);
            o.gateEmaSlope = (slopeB || slopeS);
            if(o.gateEmaSlope) o.reasons |= (uint)RSN_EMASLOPE_OK;
            if(buyQ  && !slopeB) buyQ  = false;
            if(sellQ && !slopeS) sellQ = false;
           }
        }
      o.gateAdx = true;
      if(InpUseAdxFilter)
        {
         if(!t.adxOk || t.adx1 < InpAdxMin) o.gateAdx = false;
         else
           {
            bool diB = (t.diPlus1 > t.diMinus1);
            bool diS = (t.diMinus1 > t.diPlus1);
            o.gateAdx = (diB || diS);
            if(o.gateAdx) o.reasons |= (uint)RSN_ADX_OK;
            if(buyQ  && !diB) buyQ  = false;
            if(sellQ && !diS) sellQ = false;
           }
        }
      o.gateMacd = true;
      if(InpUseMacdFilter)
        {
         if(!t.macdOk) o.gateMacd = false;
         else
           {
            bool mB = (t.macdMain1 > t.macdSig1);
            bool mS = (t.macdMain1 < t.macdSig1);
            o.gateMacd = (mB || mS);
            if(o.gateMacd) o.reasons |= (uint)RSN_MACD_OK;
            if(buyQ  && !mB) buyQ  = false;
            if(sellQ && !mS) sellQ = false;
           }
        }
      o.gateCandlePattern = true;
      if(InpUseCandlePatternFilter)
        {
         if(t.open2 <= 0.0 || t.close2 <= 0.0) o.gateCandlePattern = false;   // fail-safe: bar-2 required
         else
           {
            double b1 = t.close1 - t.open1;                 // signed body of signal bar
            double ab1 = MathAbs(b1);
            double rng1 = t.high1 - t.low1;
            bool engulfB = (b1 > 0.0 && t.close2 < t.open2 && t.close1 >= t.open2 && t.open1 <= t.close2);
            bool hammerB = (b1 > 0.0 && (MathMin(t.open1, t.close1) - t.low1) >= 2.0 * b1 &&
                            (t.high1 - MathMax(t.open1, t.close1)) <= b1);
            bool engulfS = (b1 < 0.0 && t.close2 > t.open2 && t.close1 <= t.open2 && t.open1 >= t.close2);
            bool starS   = (b1 < 0.0 && (t.high1 - MathMax(t.open1, t.close1)) >= 2.0 * ab1 &&
                            (MathMin(t.open1, t.close1) - t.low1) <= ab1);
            o.gateCandlePattern = (engulfB || hammerB || engulfS || starS);
            if(o.gateCandlePattern) o.reasons |= (uint)RSN_CANDLE_OK;
            if(buyQ  && !(engulfB || hammerB)) buyQ  = false;
            if(sellQ && !(engulfS || starS))   sellQ = false;
           }
        }
      o.gateSupplyDemand = true;
      if(InpUseSupplyDemandFilter)
        {
         if(!m_structOk) o.gateSupplyDemand = false;
         else
           {
            o.gateSupplyDemand = (m_sdDemand || m_sdSupply);
            if(o.gateSupplyDemand) o.reasons |= (uint)RSN_SD_OK;
            if(buyQ  && !m_sdDemand) buyQ  = false;
            if(sellQ && !m_sdSupply) sellQ = false;
           }
        }
      o.gateLiquidity = true;
      if(InpUseLiquidityFilter)
        {
         if(!m_structOk) o.gateLiquidity = false;
         else
           {
            double prox = InpLiqProximityAtrMult * t.atr1;
            bool okB = (!m_hasLiqHigh || (m_liqHigh - t.close1) > prox);   // too close under pool = sweep risk
            bool okS = (!m_hasLiqLow  || (t.close1 - m_liqLow)  > prox);
            o.gateLiquidity = (okB || okS);
            if(o.gateLiquidity) o.reasons |= (uint)RSN_LIQ_OK;
            if(buyQ  && !okB) buyQ  = false;
            if(sellQ && !okS) sellQ = false;
           }
        }
      o.gateGapJump = true;
      if(InpUseGapJumpFilter)
        {
         if(t.close2 <= 0.0) o.gateGapJump = false;
         else
           {
            double gap = MathAbs(t.open1 - t.close2);
            o.gateGapJump = (gap <= InpMaxBarGapAtrMult * t.atr1);   // oversized jump: entries blocked
            if(o.gateGapJump) o.reasons |= (uint)RSN_GAP_OK;
            if(!o.gateGapJump) { buyQ = false; sellQ = false; }
           }
        }
      o.gateDayHiLo = true;
      if(InpUseDayHiLoFilter)
        {
         double dh = iHigh(g_cfg.symbol, PERIOD_D1, 0);   // forming day = intraday extreme so far
         double dl = iLow (g_cfg.symbol, PERIOD_D1, 0);
         if(dh <= 0.0 || dl <= 0.0) o.gateDayHiLo = false;
         else
           {
            double minD = InpDayHiLoMinDistAtrMult * t.atr1;
            bool dB = ((dh - t.close1) >= minD);          // too close to day high -> longs blocked
            bool dS = ((t.close1 - dl) >= minD);
            o.gateDayHiLo = (dB || dS);
            if(o.gateDayHiLo) o.reasons |= (uint)RSN_DAYHILO_OK;
            if(buyQ  && !dB) buyQ  = false;
            if(sellQ && !dS) sellQ = false;
           }
        }
      if(buyQ && sellQ) o.dir = (int)SIGNAL_CONFLICT;
      else if(buyQ)     { o.dir = (int)SIGNAL_BUY;  o.confidence = (double)bs / maxScore; }
      else if(sellQ)    { o.dir = (int)SIGNAL_SELL; o.confidence = (double)ss / maxScore; }
      else                o.dir = (int)SIGNAL_NONE;
      o.gates = StringFormat("spread=%d vol=%d sess=%d roll=%d news=%d hist=%d trend=%d htf=%d clpos=%d rsimom=%d noext=%d srsp=%d fvg=%d mss=%d slope=%d adx=%d macd=%d cndl=%d sd=%d liq=%d gap=%d dhilo=%d",
                             (int)o.gateSpread, (int)o.gateVolatility, (int)o.gateSession,
                             (int)o.gateRollover, (int)o.gateNews, (int)o.gateHistory,
                             (int)o.gateTrend, (int)o.gateHtf, (int)o.gateClosePos,
                             (int)o.gateRsiMom, (int)o.gateNoExtension,
                             (int)o.gateSrSpace, (int)o.gateFvg, (int)o.gateMss,
                             (int)o.gateEmaSlope, (int)o.gateAdx, (int)o.gateMacd, (int)o.gateCandlePattern,
                             (int)o.gateSupplyDemand, (int)o.gateLiquidity, (int)o.gateGapJump, (int)o.gateDayHiLo);
     }
  };

CSgsSignalEngine g_engine;

//+------------------------------------------------------------------+
//| Explicit resets for MQL trade structs. ZeroMemory() is avoided   |
//| on these types because they contain string members.              |
//+------------------------------------------------------------------+
void SgsResetRequest(MqlTradeRequest &r)
  {
   r.action = (ENUM_TRADE_REQUEST_ACTIONS)0; r.magic = 0; r.order = 0; r.symbol = "";
   r.volume = 0.0; r.price = 0.0; r.stoplimit = 0.0;
   r.sl = 0.0; r.tp = 0.0; r.deviation = 0;
   r.type = (ENUM_ORDER_TYPE)0; r.type_filling = (ENUM_ORDER_TYPE_FILLING)0;
   r.type_time = (ENUM_ORDER_TYPE_TIME)0; r.expiration = 0;
   r.comment = ""; r.position = 0; r.position_by = 0;
  }
//---
void SgsResetCheckResult(MqlTradeCheckResult &r)
  {
   r.retcode = 0; r.balance = 0.0; r.equity = 0.0; r.profit = 0.0;
   r.margin = 0.0; r.margin_free = 0.0; r.margin_level = 0.0; r.comment = "";
  }
//---
void SgsResetResult(MqlTradeResult &r)
  {
   r.retcode = 0; r.deal = 0; r.order = 0; r.volume = 0.0;
   r.price = 0.0; r.bid = 0.0; r.ask = 0.0; r.comment = "";
   r.request_id = 0; r.retcode_external = 0;
  }
//+------------------------------------------------------------------+
//| Trade-server return code helpers                                 |
//+------------------------------------------------------------------+
string SgsRetcodeName(const uint r)
  {
   switch(r)
     {
      case 10004: return("REQUOTE");           case 10006: return("REJECT");
      case 10007: return("CANCEL");            case 10008: return("PLACED");
      case 10009: return("DONE");              case 10010: return("DONE_PARTIAL");
      case 10011: return("ERROR");             case 10012: return("TIMEOUT");
      case 10013: return("INVALID_REQUEST");   case 10014: return("INVALID_VOLUME");
      case 10015: return("INVALID_PRICE");     case 10016: return("INVALID_STOPS");
      case 10017: return("TRADE_DISABLED");    case 10018: return("MARKET_CLOSED");
      case 10019: return("NO_MONEY");          case 10020: return("PRICE_CHANGED");
      case 10021: return("PRICE_OFF");         case 10022: return("INVALID_EXPIRATION");
      case 10023: return("ORDER_CHANGED");     case 10024: return("TOO_MANY_REQUESTS");
      case 10025: return("NO_CHANGES");        case 10026: return("SERVER_DISABLES_AT");
      case 10027: return("CLIENT_DISABLES_AT");case 10028: return("LOCKED");
      case 10029: return("FROZEN");            case 10030: return("INVALID_FILL");
      case 10031: return("NO_CONNECTION");     case 10032: return("ONLY_REAL");
      case 10033: return("LIMIT_ORDERS");      case 10034: return("LIMIT_VOLUME");
      case 10036: return("INVALID_ORDER");     case 10038: return("POSITION_CLOSED");
      case 10039: return("INVALID_CLOSE_VOLUME");
     }
   return("RETCODE_" + IntegerToString((int)r));
  }
//---
bool SgsRetcodeSuccess(const uint r) { return(r == 10008 || r == 10009 || r == 10010); }
//---
bool SgsRetcodeRetryable(const uint r)
  {
   return(r == 10004 || r == 10012 || r == 10020 || r == 10021 ||
          r == 10024 || r == 10028 || r == 10031);
  }

//+------------------------------------------------------------------+
//| Permission / environment prechecks (used by risk + main loop)    |
//+------------------------------------------------------------------+
bool SgsEnvTradeAllowed(string &why)
  {
   why = "";
   // Strategy Tester emulates trading: terminal-side environment flags
   // (connection, terminal/algo toggles) are bypassed there entirely.
   if((bool)MQLInfoInteger(MQL_TESTER)) return(true);
   if(!TerminalInfoInteger(TERMINAL_CONNECTED))      { why = "terminal_not_connected"; return(false); }
   if(!MQLInfoInteger(MQL_TRADE_ALLOWED))            { why = "algo_not_allowed_for_ea"; return(false); }
   if(!TerminalInfoInteger(TERMINAL_TRADE_ALLOWED))  { why = "terminal_trade_disabled"; return(false); }
   if(!AccountInfoInteger(ACCOUNT_TRADE_ALLOWED))    { why = "account_trade_disabled"; return(false); }
   if(!AccountInfoInteger(ACCOUNT_TRADE_EXPERT))     { why = "account_expert_disabled"; return(false); }
   if(g_sym.TradeMode() == SYMBOL_TRADE_MODE_DISABLED) { why = "symbol_trade_disabled"; return(false); }
   if(g_sym.TradeMode() == SYMBOL_TRADE_MODE_CLOSEONLY){ why = "symbol_close_only"; return(false); }
   return(true);
  }

//+------------------------------------------------------------------+
//| Risk manager: sizing + all guards. Every order path must pass    |
//| PreTradeCheck() first (enforced by CTradeManager callers).       |
//+------------------------------------------------------------------+
class CSgsRisk
  {
private:
   string PeakKey() const
     { return(StringFormat("SGSP_PEAK_%I64d_%d", AccountInfoInteger(ACCOUNT_LOGIN), (int)InpMagicNumber)); }
public:
   // ---- day accounting (rebuilt from deal history; restart-safe)
   void   RecountDaily()
     {
      datetime now = TimeCurrent();
      int key = SgsDayKey(now);
      if(g_rt.dayKey != key)
        {
         g_rt.dayKey = key;
         g_rt.dayStartEquity = AccountInfoDouble(ACCOUNT_EQUITY);
         g_rt.dayClosedPnl = 0.0;
         g_rt.dayPeakClosedPnl = 0.0;   // round-23
         g_rt.dayTradeCount = 0;
         g_rt.dayWins = 0; g_rt.dayLosses = 0;
         g_rt.consecLosses = 0;
        }
      datetime dayStart = SgsDayStart(now);
      if(!HistorySelect(dayStart, now)) return;
      double pnl = 0.0; int entries = 0;
      double runPeak = 0.0;              // round-23: intraday prefix-max of realised P/L
      ulong inPids[]; ArrayResize(inPids, 0);  // dedupe partially-filled entries
      int total = HistoryDealsTotal();
      for(int i = 0; i < total; i++)
        {
         ulong dt = HistoryDealGetTicket(i);
         if(dt == 0) continue;
         if((long)HistoryDealGetInteger(dt, DEAL_MAGIC) != InpMagicNumber) continue;
         string dsym = HistoryDealGetString(dt, DEAL_SYMBOL);
         if(dsym != g_cfg.symbol) continue;
         long entry = HistoryDealGetInteger(dt, DEAL_ENTRY);
         double prof = HistoryDealGetDouble(dt, DEAL_PROFIT) +
                       HistoryDealGetDouble(dt, DEAL_SWAP) +
                       HistoryDealGetDouble(dt, DEAL_COMMISSION);
         if(entry == DEAL_ENTRY_IN)
           {
            ulong pid = (ulong)HistoryDealGetInteger(dt, DEAL_POSITION_ID);
            bool seen = false;
            for(int k = 0; k < ArraySize(inPids); k++)
               if(inPids[k] == pid) { seen = true; break; }
            if(!seen)
              {
               int nn = ArraySize(inPids);
               ArrayResize(inPids, nn + 1); inPids[nn] = pid;
               entries++;
              }
           }
         if(entry == DEAL_ENTRY_OUT || entry == DEAL_ENTRY_INOUT || entry == DEAL_ENTRY_OUT_BY)
           {
            pnl += prof;
            if(pnl > runPeak) runPeak = pnl;   // round-23: chronological prefix peak (history is ticket-ordered)
           }
        }
      g_rt.dayClosedPnl = pnl;
      g_rt.dayPeakClosedPnl = MathMax(0.0, runPeak);   // round-23: restart-safe lock anchor
      g_rt.dayTradeCount = entries;   // trades != fills: partial fills count once
      {                                   // round-15: win/loss tally (by outer-deal pnl sign; break-even counts for neither)
       int w = 0, ls = 0;
       for(int i = 0; i < total; i++)
         {
          ulong dt = HistoryDealGetTicket(i);
          if(dt == 0) continue;
          if((long)HistoryDealGetInteger(dt, DEAL_MAGIC) != InpMagicNumber) continue;
          if(HistoryDealGetString(dt, DEAL_SYMBOL) != g_cfg.symbol) continue;
          long entry = HistoryDealGetInteger(dt, DEAL_ENTRY);
          if(entry != DEAL_ENTRY_OUT && entry != DEAL_ENTRY_INOUT && entry != DEAL_ENTRY_OUT_BY) continue;
          double prof = HistoryDealGetDouble(dt, DEAL_PROFIT) +
                        HistoryDealGetDouble(dt, DEAL_SWAP) +
                        HistoryDealGetDouble(dt, DEAL_COMMISSION);
          if(prof > 0.0) w++; else if(prof < 0.0) ls++;
         }
       g_rt.dayWins = w; g_rt.dayLosses = ls;
      }
      // ---- weekly accounting (same rules; Monday 00:00 server anchor)
      int wk = SgsWeekKey(now);
      if(g_rt.weekKey != wk)
        {
         g_rt.weekKey = wk;
         g_rt.weekStartEquity = AccountInfoDouble(ACCOUNT_EQUITY);
         g_rt.weekClosedPnl = 0.0;
        }
      datetime wStart = SgsWeekStart(now);
      if(HistorySelect(wStart, now))
        {
         double wpnl = 0.0;
         int wtot = HistoryDealsTotal();
         for(int i = 0; i < wtot; i++)
           {
            ulong wdt = HistoryDealGetTicket(i);
            if(wdt == 0) continue;
            if((long)HistoryDealGetInteger(wdt, DEAL_MAGIC) != InpMagicNumber) continue;
            if(HistoryDealGetString(wdt, DEAL_SYMBOL) != g_cfg.symbol) continue;
            long went = HistoryDealGetInteger(wdt, DEAL_ENTRY);
            if(went == DEAL_ENTRY_OUT || went == DEAL_ENTRY_INOUT || went == DEAL_ENTRY_OUT_BY)
               wpnl += HistoryDealGetDouble(wdt, DEAL_PROFIT) +
                       HistoryDealGetDouble(wdt, DEAL_SWAP) +
                       HistoryDealGetDouble(wdt, DEAL_COMMISSION);
           }
         g_rt.weekClosedPnl = wpnl;
        }
     }
   //----
   void   RecountConsecutiveLosses()   // lookback 60 days, newest first
     {
      datetime now = TimeCurrent();
      if(!HistorySelect(now - 60 * 86400, now)) return;
      int total = HistoryDealsTotal();
      int consec = 0; datetime lastLoss = 0;
      for(int i = total - 1; i >= 0; i--)
        {
         ulong dt = HistoryDealGetTicket(i);
         if(dt == 0) continue;
         if((long)HistoryDealGetInteger(dt, DEAL_MAGIC) != InpMagicNumber) continue;
         if(HistoryDealGetString(dt, DEAL_SYMBOL) != g_cfg.symbol) continue;
         long entry = HistoryDealGetInteger(dt, DEAL_ENTRY);
         if(entry != DEAL_ENTRY_OUT && entry != DEAL_ENTRY_INOUT && entry != DEAL_ENTRY_OUT_BY) continue;
         datetime dtime = (datetime)HistoryDealGetInteger(dt, DEAL_TIME);
         // R9-2 epoch barrier: after a resumed cooldown the streak RESTARTS; deals
         // closed at/before the epoch do not belong to the running streak. Without
         // this barrier the old losses keep the counter at/over the limit, so one
         // single fresh loss would re-arm the full cooldown forever (rolling lock).
         if(dtime <= g_rt.streakEpoch) break;
         double prof = HistoryDealGetDouble(dt, DEAL_PROFIT) +
                       HistoryDealGetDouble(dt, DEAL_SWAP) +
                       HistoryDealGetDouble(dt, DEAL_COMMISSION);
         if(prof < 0.0) { consec++; if(lastLoss == 0) lastLoss = dtime; }
         else if(prof > 0.0) break;
        }
      g_rt.consecLosses = consec;
      if(InpConsecLossLimit > 0 && consec >= InpConsecLossLimit && lastLoss > 0)
        {
         datetime until = lastLoss + InpLossCooldownMinutes * 60;
         if(until > now) g_rt.lossCooldownUntil = until;
        }
     }
   //----
   void   LoadPeakEquity()
     {
      double eq = AccountInfoDouble(ACCOUNT_EQUITY);
      string k = PeakKey();
      double peak = 0.0;
      if(GlobalVariableCheck(k)) peak = GlobalVariableGet(k);
      if(InpPeakEquityFloor > 0.0) peak = MathMax(peak, InpPeakEquityFloor);
      if(peak < eq) peak = eq;
      g_rt.peakEquity = peak;
      GlobalVariableSet(k, peak);
     }
   //----
   int    CountOursOpen() const
     {
      int c = 0;
      for(int i = PositionsTotal() - 1; i >= 0; i--)
        {
         ulong tk = PositionGetTicket(i);
         if(tk == 0) continue;
         if((long)PositionGetInteger(POSITION_MAGIC) != InpMagicNumber) continue;
         if(PositionGetString(POSITION_SYMBOL) != g_cfg.symbol) continue;
         c++;
        }
      return(c);
     }
   //----
   double ExposedLots(const int dir) const
     {
      double lots = 0.0;
      for(int i = PositionsTotal() - 1; i >= 0; i--)
        {
         ulong tk = PositionGetTicket(i);
         if(tk == 0) continue;
         if((long)PositionGetInteger(POSITION_MAGIC) != InpMagicNumber) continue;
         if(PositionGetString(POSITION_SYMBOL) != g_cfg.symbol) continue;
         long pt = PositionGetInteger(POSITION_TYPE);
         double vol = PositionGetDouble(POSITION_VOLUME);
         if(dir > 0 && pt == POSITION_TYPE_BUY)  lots += vol;
         if(dir < 0 && pt == POSITION_TYPE_SELL) lots += vol;
        }
      return(lots);
     }
   //----
   double FloatingPnl() const
     {
      double p = 0.0;
      for(int i = PositionsTotal() - 1; i >= 0; i--)
        {
         ulong tk = PositionGetTicket(i);
         if(tk == 0) continue;
         if((long)PositionGetInteger(POSITION_MAGIC) != InpMagicNumber) continue;
         if(PositionGetString(POSITION_SYMBOL) != g_cfg.symbol) continue;
         p += PositionGetDouble(POSITION_PROFIT) + PositionGetDouble(POSITION_SWAP);
        }
      return(p);
     }
   //----
   double OpenRiskPercent() const  // conservative: missing SL => planning number per trade
     {
      double total = 0.0;
      double eq = AccountInfoDouble(ACCOUNT_EQUITY);
      if(eq <= 0.0) return(100.0);
      for(int i = PositionsTotal() - 1; i >= 0; i--)
        {
         ulong tk = PositionGetTicket(i);
         if(tk == 0) continue;
         if((long)PositionGetInteger(POSITION_MAGIC) != InpMagicNumber) continue;
         if(PositionGetString(POSITION_SYMBOL) != g_cfg.symbol) continue;
         double vol = PositionGetDouble(POSITION_VOLUME);
         double price = PositionGetDouble(POSITION_PRICE_OPEN);
         double sl = PositionGetDouble(POSITION_SL);
         double loss;
         if(sl > 0.0 && sl != price)
            loss = g_sym.LossAtDistance(vol, MathAbs(price - sl));
         else
            loss = eq * InpMaxRiskPercentPerTrade / 100.0; // conservative planning number
         total += loss;
        }
      return(total / eq * 100.0);
     }
   //----
   double ComputeStopDistancePrice(const SGsTech &t, int dir) const
     {
      double dist = 0.0;
      if(InpSlMode == SL_ATR)
        { if(t.ok && t.atr1 > 0.0) dist = t.atr1 * InpAtrSlMult; }
      else if(InpSlMode == SL_STRUCT)
        {
         // stop beyond the latest confirmed swing pivot +/- ATR buffer (round-14)
         bool okS = false;
         if(t.ok && t.atr1 > 0.0)
           {
            double buf = InpStructSlBufferAtrMult * t.atr1;
            double maxD = InpStructSlMaxAtrMult * t.atr1;
            if(dir > 0 && g_engine.HasPivotLow())
              { double d2 = t.close1 - (g_engine.LastPLow() - buf); if(d2 > 0.0 && d2 <= maxD) { dist = d2; okS = true; } }
            if(dir < 0 && g_engine.HasPivotHigh())
              { double d2 = (g_engine.LastPHigh() + buf) - t.close1; if(d2 > 0.0 && d2 <= maxD) { dist = d2; okS = true; } }
           }
         if(!okS && t.ok && t.atr1 > 0.0) dist = t.atr1 * InpAtrSlMult;   // documented fallback: no usable pivot/too wide
        }
      else dist = (double)InpSlPips * (double)InpPipSizePoints * g_sym.Point();
      double floorD = g_sym.MinStopDistancePrice();
      if(dist < floorD) dist = floorD;
      return(dist);
     }
   //----
   // Runtime equity/DD guards; returns true when trading may continue.
   bool   TickGuards(string &why)
     {
      why = "";
      if(!InpEquityProtectEnabled) return(true);
      double eq = AccountInfoDouble(ACCOUNT_EQUITY);
      if(eq <= 0.0) { why = "equity_invalid"; return(false); }
      // peak tracking
      if(eq > g_rt.peakEquity)
        {
         g_rt.peakEquity = eq;
         GlobalVariableSet(PeakKey(), eq);
        }
      // total drawdown (hard guard)
      double ddTotal = (g_rt.peakEquity > 0.0 ? (g_rt.peakEquity - eq) / g_rt.peakEquity * 100.0 : 0.0);
      if(ddTotal >= InpMaxTotalDDPercent && !g_rt.hardGuardHit)
        {
         g_rt.hardGuardHit = true;
         if(g_journal.IsHealthy())
            g_journal.Append((int)JR_GUARD, (int)DUR_FINANCIAL, 0,
                             StringFormat("guard=total_dd;dd=%.2f;limit=%.2f;equity=%.2f;peak=%.2f",
                                          ddTotal, InpMaxTotalDDPercent, eq, g_rt.peakEquity));
         CSgsState::Transition(SGS_FAULTED, "total_drawdown_breach");
         why = "total_dd_breach";
         return(false);
        }
      if(g_rt.hardGuardHit) { why = "hard_guard_latched"; return(false); }
      // daily drawdown
      if(g_rt.dayKey == SgsDayKey(TimeCurrent()) && g_rt.dayStartEquity > 0.0)
        {
         double ddDay = (g_rt.dayStartEquity - eq) / g_rt.dayStartEquity * 100.0;
         if(InpMaxDailyDDPercent > 0.0 && ddDay >= InpMaxDailyDDPercent)
           {
            if(g_journal.IsHealthy())
               g_journal.Append((int)JR_GUARD, (int)DUR_STATE, 0,
                                StringFormat("guard=daily_dd;dd=%.2f;limit=%.2f", ddDay, InpMaxDailyDDPercent));
            if(g_rt.state == SGS_TRADING_ENABLED)
               CSgsState::Transition(SGS_PAUSED, "daily_dd_limit");
            why = "daily_dd_breach";
            return(false);
           }
         // daily realised loss limit (closed + floating as equity-based above; closed leg below)
         if(InpMaxDailyLossPercent > 0.0)
           {
            double lossPct = -g_rt.dayClosedPnl / g_rt.dayStartEquity * 100.0;
            if(g_rt.dayClosedPnl < 0.0 && lossPct >= InpMaxDailyLossPercent)
              {
               if(g_rt.state == SGS_TRADING_ENABLED)
                  CSgsState::Transition(SGS_PAUSED, "daily_loss_limit");
               why = "daily_loss_breach";
               return(false);
              }
           }
         // daily realised profit target: stop opening new trades after the target is banked
         if(InpDailyProfitTargetPercent > 0.0 && g_rt.dayClosedPnl > 0.0 && g_rt.dayStartEquity > 0.0)
           {
            double gainPct = g_rt.dayClosedPnl / g_rt.dayStartEquity * 100.0;
            if(gainPct >= InpDailyProfitTargetPercent)
              {
               if(g_rt.state == SGS_TRADING_ENABLED)
                  CSgsState::Transition(SGS_PAUSED, "daily_profit_target");
               why = "daily_profit_target_reached";
               return(false);
              }
           }
         // round-23: winning-day profit lock (giveback guard) — once armed, bank the day
         if(g_rt.dayClosedPnl > g_rt.dayPeakClosedPnl)
            g_rt.dayPeakClosedPnl = g_rt.dayClosedPnl;
         if(InpUseDayProfitLock && g_rt.dayPeakClosedPnl > 0.0)
           {
            double plPeakPct = g_rt.dayPeakClosedPnl / g_rt.dayStartEquity * 100.0;
            if(plPeakPct >= InpDayProfitLockActivatePct)
              {
               double lockFloor = g_rt.dayPeakClosedPnl * (1.0 - InpDayProfitLockRetracePct / 100.0);
               if(g_rt.dayClosedPnl <= lockFloor + 1e-9)
                 {
                  if(g_journal.IsHealthy())
                     g_journal.Append((int)JR_GUARD, (int)DUR_STATE, 0,
                                      StringFormat("guard=day_profit_lock;peak=%.2f;pnl=%.2f;floor=%.2f;retr=%.2f",
                                                   g_rt.dayPeakClosedPnl, g_rt.dayClosedPnl, lockFloor, InpDayProfitLockRetracePct));
                  if(g_rt.state == SGS_TRADING_ENABLED)
                     CSgsState::Transition(SGS_PAUSED, "day_profit_lock");
                  why = "day_profit_lock";
                  return(false);
                 }
              }
           }
         // weekly realised loss limit (Monday 00:00 server anchor)
         if(InpMaxWeeklyLossPercent > 0.0 && g_rt.weekStartEquity > 0.0)
           {
            double wLossPct = -g_rt.weekClosedPnl / g_rt.weekStartEquity * 100.0;
            if(g_rt.weekClosedPnl < 0.0 && wLossPct >= InpMaxWeeklyLossPercent)
              {
               if(g_rt.state == SGS_TRADING_ENABLED)
                  CSgsState::Transition(SGS_PAUSED, "weekly_loss_limit");
               why = "weekly_loss_breach";
               return(false);
              }
           }
        }
      return(true);
     }
   //----
   // Full pre-trade risk gate. On success returns target volume.
   bool   PreTradeCheck(const int dir, const double entry, const double slPrice,
                        const double tpPrice, const SGsTech &t,
                        double &outLots, string &deny)
     {
      deny = ""; outLots = 0.0;
      if(g_rt.state != SGS_TRADING_ENABLED) { deny = "state_not_trading"; return(false); }
      if(!g_rt.reconciled)                  { deny = "not_reconciled"; return(false); }
      string envWhy; if(!SgsEnvTradeAllowed(envWhy)) { deny = envWhy; return(false); }
      if(!g_sym.DirectionAllowed(dir))      { deny = "symbol_direction_forbidden"; return(false); }
      if(InpTradeDirection == DIR_BUY_ONLY  && dir != (int)SIGNAL_BUY)  { deny = "direction_input_block"; return(false); }
      if(InpTradeDirection == DIR_SELL_ONLY && dir != (int)SIGNAL_SELL) { deny = "direction_input_block"; return(false); }
      if(g_sym.TradeMode() == SYMBOL_TRADE_MODE_CLOSEONLY ||
         g_sym.TradeMode() == SYMBOL_TRADE_MODE_DISABLED) { deny = "symbol_mode_block"; return(false); }
      if(InpUseSpreadFilter && g_sym.SpreadPoints() > (long)InpMaxSpreadPips * (long)InpPipSizePoints)
        { deny = "spread_guard"; return(false); }
      if(g_rt.hardGuardHit) { deny = "hard_guard"; return(false); }
      // consecutive-loss guard = finite cooldown (spec): once the cooldown has
      // fully elapsed, trading resumes and the streak restarts; fresh losses
      // re-arm a new cooldown from history (see RecountConsecutiveLosses).
      if(InpConsecLossLimit > 0 && g_rt.lossCooldownUntil > 0 &&
         TimeCurrent() >= g_rt.lossCooldownUntil)
        {
         g_rt.consecLosses = 0; g_rt.lossCooldownUntil = 0;
         g_rt.streakEpoch = TimeCurrent();       // R9-2: the streak restarts from here
         if(g_journal.IsHealthy())
            g_journal.Append((int)JR_RISK_EVENT, (int)DUR_STATE, 0,
                             "event=loss_cooldown_expired;action=resume_trading");
        }
      if(g_rt.lossCooldownUntil > TimeCurrent()) { deny = "loss_cooldown"; return(false); }
      RecountDaily();
      if(InpMaxTradesPerDay > 0 && g_rt.dayTradeCount >= InpMaxTradesPerDay)
        { deny = "max_trades_per_day"; return(false); }
      string gwhy; if(!TickGuards(gwhy)) { deny = "guard:" + gwhy; return(false); }
      // position/exposure accounting
      bool netting = g_sym.IsNettingAccount();
      int openNow = CountOursOpen();
      // R9-1: at most one managed position per (symbol,magic). Prevents stacking
      // same-direction adds AND simultaneous opposite-direction hedges. Setting
      // InpOnePositionPerSymbol=false restores the legacy multi-position mode
      // guarded by the netting rule / InpMaxOpenPositions below.
      if(InpOnePositionPerSymbol && openNow > 0)
        { deny = "position_already_open"; return(false); }
      if(netting)
        {
         if(openNow > 0) { deny = "netting_merge_blocked"; return(false); } // conservative: entries would net
        }
      else
        {
         if(openNow >= InpMaxOpenPositions) { deny = "max_open_positions"; return(false); }
        }
      double slDist = MathAbs(entry - slPrice);
      if(slDist <= 0.0) { deny = "zero_stop_distance"; return(false); }
      if(slDist < g_sym.MinStopDistancePrice()) { deny = "stop_below_broker_min"; return(false); }
      if(InpTpMode != TP_NONE && tpPrice > 0.0)
        {
         double tpDist = MathAbs(tpPrice - entry);
         double rr = tpDist / slDist;
         if(rr < InpMinRewardRiskRatio) { deny = "rr_below_min"; return(false); }
        }
      if(InpMaxExposureLotsPerDir > 0.0)
        {
         double exp = ExposedLots(dir == (int)SIGNAL_BUY ? 1 : -1);
         if(exp >= InpMaxExposureLotsPerDir) { deny = "direction_exposure_cap"; return(false); }
        }
      // ---- sizing
      double lots = 0.0;
      if(InpRiskMode == RISK_FIXED_LOT)
        {
         lots = InpFixedLot;
        }
      else
        {
         double eq = AccountInfoDouble(ACCOUNT_EQUITY);
         if(eq <= 0.0) { deny = "equity_invalid"; return(false); }
         double pct = MathMin(InpRiskPercentPerTrade, InpMaxRiskPercentPerTrade);
         double riskMoney = eq * pct / 100.0;
         double lossPerLot = g_sym.LossAtDistance(1.0, slDist);
         if(lossPerLot <= 0.0) { deny = "tick_value_invalid"; return(false); }
         lots = riskMoney / lossPerLot;
         if(InpUseOrderCalcProfitSizing)
           {
            // exact per-lot loss at live prices via the trade subsystem (round-14 option);
            // on failure the tick-value estimate above is kept (documented in BuildReport).
            double refPx = (dir == (int)SIGNAL_BUY ? g_sym.Ask() : g_sym.Bid());
            double tgtPx = (dir == (int)SIGNAL_BUY ? refPx - slDist : refPx + slDist);
            double loss1 = 0.0;
            if(OrderCalcProfit((dir == (int)SIGNAL_BUY ? ORDER_TYPE_BUY : ORDER_TYPE_SELL),
                               g_cfg.symbol, 1.0, refPx, tgtPx, loss1) && loss1 < 0.0)
               lots = riskMoney / (-loss1);
           }
        }
      if(InpMaxExposureLotsPerDir > 0.0)
        {
         double exp2 = ExposedLots(dir == (int)SIGNAL_BUY ? 1 : -1);
         double room = InpMaxExposureLotsPerDir - exp2;
         if(room <= 0.0) { deny = "direction_exposure_cap"; return(false); }
         if(lots > room) lots = room;
        }
      double normLots = 0.0;
      if(!g_sym.NormalizeVolume(lots, normLots))
        { deny = "volume_below_min_or_invalid"; return(false); } // never bump UP beyond risk
      if(InpMaxTotalRiskPercentOpen > 0.0)
        {
         double eq2 = AccountInfoDouble(ACCOUNT_EQUITY);
         double addLoss = g_sym.LossAtDistance(normLots, slDist);
         double addPct = (eq2 > 0.0 ? addLoss / eq2 * 100.0 : 100.0);
         if(OpenRiskPercent() + addPct > InpMaxTotalRiskPercentOpen)
           { deny = "total_open_risk_cap"; return(false); }
        }
      // ---- margin
      ENUM_ORDER_TYPE ot = (dir == (int)SIGNAL_BUY ? ORDER_TYPE_BUY : ORDER_TYPE_SELL);
      double needMargin = 0.0;
      if(!OrderCalcMargin(ot, g_cfg.symbol, normLots, entry, needMargin))
        { deny = "margin_calc_failed"; return(false); }
      double freeM = AccountInfoDouble(ACCOUNT_MARGIN_FREE);
      double eqF = AccountInfoDouble(ACCOUNT_EQUITY);
      if(freeM < needMargin) { deny = "no_money"; return(false); }
      if(eqF > 0.0 && (freeM - needMargin) < eqF * InpMinFreeMarginAfterPct / 100.0)
        { deny = "free_margin_reserve"; return(false); }
      outLots = normLots;
      return(true);
     }
  };

CSgsRisk g_risk;

//+------------------------------------------------------------------+
//| Position tracking registry                                       |
//+------------------------------------------------------------------+
struct SGsPosTrack
  {
   ulong    ticket;
   ulong    posId;
   int      dir;            // +1 long, -1 short
   double   volume;
   double   entry;
   double   sl, tp;         // latest known (terminal is source of truth)
   datetime openTime;
   bool     beDone;
   bool     be2Done;         // multi-stage break-even stage 2 applied
   bool     partialDone;
   bool     manualTouched;
   bool     journaledOpen;
   int      momDecay;        // consecutive closed bars with RSI moving against the position
   datetime lastDecayBar;    // bar-time of last decay evaluation (per-position, once per bar)
  };

//+------------------------------------------------------------------+
//| Trade manager: requests, retries, modify, close, transactions    |
//+------------------------------------------------------------------+
class CSgsTrade
  {
private:
   SGsPosTrack m_pos[];
   ulong    m_seenDeals[];
   bool     m_inFlight;
   datetime m_inFlightSince;
   ulong    m_selfOpTicket;
   datetime m_selfOpAt;
   // round-17: managed-close reason keyed by position id, so the CSV row and the
   // audit trail show the TRUE close cause (partial/time_exit/momentum_decay/...),
   // not the generic "close". Capped tombstone map; entries consumed on use.
   ulong    m_closePid[];
   string   m_closeReason[];
   //---
   int      FindByTicket(const ulong ticket) const
     {
      for(int i = 0; i < ArraySize(m_pos); i++)
         if(m_pos[i].ticket == ticket) return(i);
      return(-1);
     }
   int      FindByPosId(const ulong pid) const
     {
      for(int i = 0; i < ArraySize(m_pos); i++)
         if(m_pos[i].posId == pid) return(i);
      return(-1);
     }
   void     RemoveAt(const int idx)
     {
      int n = ArraySize(m_pos);
      if(idx < 0 || idx >= n) return;
      for(int i = idx; i < n - 1; i++) m_pos[i] = m_pos[i + 1];
      ArrayResize(m_pos, n - 1);
     }
   bool     DealKnown(const ulong deal)
     {
      for(int i = 0; i < ArraySize(m_seenDeals); i++)
         if(m_seenDeals[i] == deal) return(true);
      return(false);
     }
   void     MarkDeal(const ulong deal)
     {
      int n = ArraySize(m_seenDeals);
      ArrayResize(m_seenDeals, n + 1);
      m_seenDeals[n] = deal;
      if(n + 1 > 256) // ring cap
        {
         for(int i = 0; i < 256; i++) m_seenDeals[i] = m_seenDeals[i + (n + 1 - 256)];
         ArrayResize(m_seenDeals, 256);
        }
     }
   void     MarkCloseReason(const ulong pid, const string reason)
     {
      if(pid == 0) return;
      for(int i = 0; i < ArraySize(m_closePid); i++)
         if(m_closePid[i] == pid) { m_closeReason[i] = reason; return; }
      int n = ArraySize(m_closePid);
      if(n >= 64)                                     // tombstone cap: evict oldest
        {
         for(int i = 0; i < n - 1; i++)
           { m_closePid[i] = m_closePid[i + 1]; m_closeReason[i] = m_closeReason[i + 1]; }
         n = 63;
        }
      ArrayResize(m_closePid, n + 1); ArrayResize(m_closeReason, n + 1);
      m_closePid[n] = pid; m_closeReason[n] = reason;
     }
   string   TakeCloseReason(const ulong pid)          // consumed on use
     {
      string rsn = "";
      for(int i = 0; i < ArraySize(m_closePid); i++)
         if(m_closePid[i] == pid)
           {
            rsn = m_closeReason[i];
            for(int k = i; k < ArraySize(m_closePid) - 1; k++)
              { m_closePid[k] = m_closePid[k + 1]; m_closeReason[k] = m_closeReason[k + 1]; }
            ArrayResize(m_closePid, ArraySize(m_closePid) - 1);
            ArrayResize(m_closeReason, ArraySize(m_closeReason) - 1);
            break;
           }
      return(rsn);
     }
   //---
   ulong    ResolvePositionTicket(const ulong orderTicket, const ulong dealTicket)
     {
      if(dealTicket > 0 && HistoryDealSelect(dealTicket))
        {
         ulong pid = (ulong)HistoryDealGetInteger(dealTicket, DEAL_POSITION_ID);
         if(pid > 0 && PositionSelectByTicket(pid)) return(pid);
        }
      if(orderTicket > 0 && PositionSelectByTicket(orderTicket)) return(orderTicket);
      for(int i = PositionsTotal() - 1; i >= 0; i--)
        {
         ulong tk = PositionGetTicket(i);
         if(tk == 0) continue;
         if((long)PositionGetInteger(POSITION_MAGIC) != InpMagicNumber) continue;
         if(PositionGetString(POSITION_SYMBOL) != g_cfg.symbol) continue;
         if((ulong)PositionGetInteger(POSITION_IDENTIFIER) == orderTicket) return(tk);
        }
      return(0);
     }
   //---
   // shared sender: OrderCheck + bounded retry with backoff; full journaling
   bool     SendWithRetry(MqlTradeRequest &req, MqlTradeResult &res,
                          const string opName, string &err)
     {
      err = "";
      string reqDump = StringFormat(
         "op=%s;action=%d;type=%d;vol=%.2f;price=%s;sl=%s;tp=%s;dev=%I64u;idem=%I64u",
         opName, (int)req.action, (int)req.type, req.volume,
         DoubleToString(req.price, g_sym.Digits()),
         DoubleToString(req.sl, g_sym.Digits()),
         DoubleToString(req.tp, g_sym.Digits()),
         req.deviation, g_journal.NextSequence());
      if(g_journal.IsHealthy())
         g_journal.Append((int)JR_ORDER_REQUEST, (int)DUR_FINANCIAL, 0, reqDump);
      MqlTradeCheckResult chk; SgsResetCheckResult(chk);
      MqlTradeRequest reqCopy = req;
      if(!OrderCheck(reqCopy, chk))
        {
         err = "ordercheck_" + SgsRetcodeName(chk.retcode);
         if(g_journal.IsHealthy())
            g_journal.Append((int)JR_ORDER_ERROR, (int)DUR_FINANCIAL, 0,
                             reqDump + ";stage=check;retcode=" + SgsRetcodeName(chk.retcode));
         return(false);
        }
      int attempts = 1 + InpOrderRetryMax;
      for(int a = 1; a <= attempts; a++)
        {
         if(!g_sym.RefreshDynamic()) { err = "quotes_lost"; return(false); }
         if(req.action == TRADE_ACTION_DEAL)
            req.price = (req.type == ORDER_TYPE_BUY ? g_sym.Ask() : g_sym.Bid());
         SgsResetResult(res);
         bool sent = bridge.OrderSendBridge(req, res);
         uint rc = (sent ? res.retcode : (uint)10011);
         if(SgsRetcodeSuccess(rc) || (req.action == TRADE_ACTION_SLTP && rc == 10025))
           {
            double slipPts = 0.0;
            if(req.action == TRADE_ACTION_DEAL && res.price > 0.0 && g_sym.Point() > 0.0)
               slipPts = (res.price - req.price) / g_sym.Point() * (req.type == ORDER_TYPE_BUY ? 1.0 : -1.0);
            if(g_journal.IsHealthy())
               g_journal.Append((int)JR_ORDER_RESULT, (int)DUR_FINANCIAL, 0,
                  reqDump + StringFormat(";retcode=%s;order=%I64u;deal=%I64u;fill_price=%s;fill_vol=%.2f;slip_pips=%.2f;partial=%d",
                  SgsRetcodeName(rc), res.order, res.deal,
                  DoubleToString(res.price, g_sym.Digits()), res.volume,
                  slipPts / (double)InpPipSizePoints,
                  (int)(req.action == TRADE_ACTION_DEAL && res.volume > 0.0 && res.volume < req.volume)));
            g_rt.consecutiveErrors = 0;
            return(true);
           }
         bool retryable = SgsRetcodeRetryable(rc);
         if(g_journal.IsHealthy())
            g_journal.Append((int)JR_ORDER_ERROR, (int)(retryable ? DUR_STATE : DUR_FINANCIAL), 0,
               reqDump + ";retcode=" + SgsRetcodeName(rc) + ";attempt=" + IntegerToString(a) +
               ";retryable=" + IntegerToString((int)retryable));
         if(!retryable || a == attempts)
           {
            err = "send_" + SgsRetcodeName(rc);
            g_rt.consecutiveErrors++;
            if(g_rt.consecutiveErrors >= InpMaxConsecutiveErrors && g_rt.state == SGS_TRADING_ENABLED)
               CSgsState::Transition(SGS_FAULTED, "consecutive_errors");
            return(false);
           }
         Sleep(InpRetryBackoffMs); // no-op inside Strategy Tester (documented)
        }
      err = "send_exhausted";
      return(false);
     }
   //---
   bool     ModifySLTP(SGsPosTrack &tr, const double newSl, const double newTp, const string why)
     {
      if(newSl == tr.sl && newTp == tr.tp) return(true);
      MqlTradeRequest req; MqlTradeResult res; SgsResetRequest(req);
      req.action = TRADE_ACTION_SLTP;
      req.symbol = g_cfg.symbol;
      req.magic = InpMagicNumber;
      req.position = tr.ticket;
      req.sl = newSl; req.tp = newTp;
      req.comment = g_cfg.comment;
      m_selfOpTicket = tr.ticket; m_selfOpAt = TimeCurrent();
      string err;
      bool ok = SendWithRetry(req, res, "modify_sltp", err);
      if(ok)
        {
         double oldSl = tr.sl, oldTp = tr.tp;
         tr.sl = newSl; tr.tp = newTp;
         if(g_journal.IsHealthy())
            g_journal.Append((int)JR_POSITION_UPDATE, (int)DUR_FINANCIAL, 0,
               StringFormat("ticket=%I64u;old_sl=%s;new_sl=%s;old_tp=%s;new_tp=%s;why=%s",
                  tr.ticket, DoubleToString(oldSl, g_sym.Digits()), DoubleToString(newSl, g_sym.Digits()),
                  DoubleToString(oldTp, g_sym.Digits()), DoubleToString(newTp, g_sym.Digits()), why));
        }
      return(ok);
     }
   //---
   bool     CloseVolume(SGsPosTrack &tr, const double vol, const string reason)
     {
      if(vol <= 0.0) return(false);
      MqlTradeRequest req; MqlTradeResult res; SgsResetRequest(req);
      req.action = TRADE_ACTION_DEAL;
      req.symbol = g_cfg.symbol;
      req.magic = InpMagicNumber;
      req.position = tr.ticket;
      req.type = (tr.dir > 0 ? ORDER_TYPE_SELL : ORDER_TYPE_BUY);
      req.volume = vol;
      req.deviation = (ulong)((long)InpDeviationPips * (long)InpPipSizePoints); // broker API takes points
      req.type_filling = g_sym.PreferredFilling();
      req.type_time = ORDER_TIME_GTC;
      req.comment = g_cfg.comment;
      string err;
      bool ok = SendWithRetry(req, res, "close:" + reason, err);
      if(ok) MarkCloseReason(tr.posId, reason);
      if(ok && g_journal.IsHealthy())
         g_journal.Append((int)JR_POSITION_CLOSE, (int)DUR_FINANCIAL, 0,
            StringFormat("ticket=%I64u;vol=%.2f;reason=%s;full=%d",
                         tr.ticket, vol, reason, (int)(vol >= tr.volume - 1e-9)));
      return(ok);
     }
public:
   CSgsTrade()
     {
      ArrayResize(m_pos, 0); ArrayResize(m_seenDeals, 0);
      ArrayResize(m_closePid, 0); ArrayResize(m_closeReason, 0);
      m_inFlight = false; m_inFlightSince = 0;
      m_selfOpTicket = 0; m_selfOpAt = 0;
     }
   void     Init()
     {
      ArrayResize(m_pos, 0); ArrayResize(m_seenDeals, 0);
      ArrayResize(m_closePid, 0); ArrayResize(m_closeReason, 0);
      m_inFlight = false; m_inFlightSince = 0; m_selfOpTicket = 0; m_selfOpAt = 0;
     }
   int      ManagedCount() const { return(ArraySize(m_pos)); }
   bool     GetTrack(const int idx, SGsPosTrack &tr) const
     {
      if(idx < 0 || idx >= ArraySize(m_pos)) return(false);
      tr = m_pos[idx]; return(true);
     }
   bool     RegisterFromTerminal(const ulong ticket, const bool adopted)
     {
      if(FindByTicket(ticket) >= 0) return(true);
      if(!PositionSelectByTicket(ticket)) return(false);
      SGsPosTrack tr; ZeroMemory(tr);
      tr.ticket = ticket;
      tr.posId = (ulong)PositionGetInteger(POSITION_IDENTIFIER);
      tr.dir = (PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_BUY ? 1 : -1);
      tr.volume = PositionGetDouble(POSITION_VOLUME);
      tr.entry = PositionGetDouble(POSITION_PRICE_OPEN);
      tr.sl = PositionGetDouble(POSITION_SL);
      tr.tp = PositionGetDouble(POSITION_TP);
      tr.openTime = (datetime)PositionGetInteger(POSITION_TIME);
      tr.beDone = (tr.sl > 0.0 && ((tr.dir > 0 && tr.sl >= tr.entry) || (tr.dir < 0 && tr.sl <= tr.entry)));
      tr.be2Done = false;
      tr.momDecay = 0; tr.lastDecayBar = 0;
      tr.partialDone = false;
      tr.manualTouched = false;
      tr.journaledOpen = adopted;
      int n = ArraySize(m_pos);
      ArrayResize(m_pos, n + 1);
      m_pos[n] = tr;
      return(true);
     }
   //---
   bool     OpenBySignal(const int dir, const SGsTech &t, string &why)
     {
      why = "";
      if(m_inFlight)
        {
         // idempotency guard: one request in flight; stale flag auto-clears after 30s
         if(TimeCurrent() - m_inFlightSince < 30) { why = "request_in_flight"; return(false); }
         m_inFlight = false;
        }
      if(!g_sym.RefreshDynamic()) { why = "quotes_unavailable"; return(false); }
      double entry = (dir == (int)SIGNAL_BUY ? g_sym.Ask() : g_sym.Bid());
      double exitRef = (dir == (int)SIGNAL_BUY ? g_sym.Bid() : g_sym.Ask());
      double slDist = g_risk.ComputeStopDistancePrice(t, (dir == (int)SIGNAL_BUY ? 1 : -1));
      if(slDist <= 0.0) { why = "stop_distance_invalid"; return(false); }
      double sl = (dir == (int)SIGNAL_BUY ? exitRef - slDist : exitRef + slDist);
      double tp = 0.0;
      if(InpTpMode == TP_RR)         tp = (dir == (int)SIGNAL_BUY ? entry + slDist * InpRewardRiskRatio
                                                                  : entry - slDist * InpRewardRiskRatio);
      else if(InpTpMode == TP_POINTS) tp = (dir == (int)SIGNAL_BUY ? entry + (double)InpTpPips * (double)InpPipSizePoints * g_sym.Point()
                                                                    : entry - (double)InpTpPips * (double)InpPipSizePoints * g_sym.Point());
      sl = g_sym.NormalizePrice(sl);
      if(tp > 0.0) tp = g_sym.NormalizePrice(tp);
      // hard side sanity (never send a crossed stop/target)
      if(dir == (int)SIGNAL_BUY  && !(sl < exitRef && (tp == 0.0 || tp > entry))) { why = "price_side_invalid"; return(false); }
      if(dir == (int)SIGNAL_SELL && !(sl > exitRef && (tp == 0.0 || tp < entry))) { why = "price_side_invalid"; return(false); }
      double lots = 0.0;
      if(!g_risk.PreTradeCheck(dir, entry, sl, tp, t, lots, why)) return(false);
      MqlTradeRequest req; MqlTradeResult res; SgsResetRequest(req);
      req.action = TRADE_ACTION_DEAL;
      req.symbol = g_cfg.symbol;
      req.magic = InpMagicNumber;
      req.type = (dir == (int)SIGNAL_BUY ? ORDER_TYPE_BUY : ORDER_TYPE_SELL);
      req.volume = lots;
      req.price = entry;
      req.sl = sl; req.tp = tp;
      req.deviation = (ulong)((long)InpDeviationPips * (long)InpPipSizePoints); // broker API takes points
      req.type_filling = g_sym.PreferredFilling();
      req.type_time = ORDER_TIME_GTC;
      req.comment = g_cfg.comment;
      if(InpDryRun)
        {
         if(g_journal.IsHealthy())
            g_journal.Append((int)JR_ORDER_REQUEST, (int)DUR_STATE, 1,
               StringFormat("op=dry_run;dir=%s;vol=%.2f;price=%s;sl=%s;tp=%s",
                            SgsDirText(dir), lots, DoubleToString(entry, g_sym.Digits()),
                            DoubleToString(sl, g_sym.Digits()), DoubleToString(tp, g_sym.Digits())));
         why = "dry_run_ok";
         return(true);
        }
      m_inFlight = true; m_inFlightSince = TimeCurrent();
      string err;
      bool ok = SendWithRetry(req, res, "open_market", err);
      m_inFlight = false;
      if(!ok) { why = err; return(false); }
      // register resulting position (immediate; transaction path is dedup-safe)
      ulong ticket = ResolvePositionTicket(res.order, res.deal);
      if(ticket > 0)
        {
         if(RegisterFromTerminal(ticket, false))
           {
            int idx = FindByTicket(ticket);
            if(idx >= 0)
              {
               m_pos[idx].journaledOpen = true;
               if(g_journal.IsHealthy())
                  g_journal.Append((int)JR_POSITION_OPEN, (int)DUR_FINANCIAL, 0,
                     StringFormat("ticket=%I64u;pid=%I64u;dir=%s;vol=%.2f;entry=%s;sl=%s;tp=%s;src=send",
                        m_pos[idx].ticket, m_pos[idx].posId, (m_pos[idx].dir > 0 ? "BUY" : "SELL"),
                        m_pos[idx].volume, DoubleToString(m_pos[idx].entry, g_sym.Digits()),
                        DoubleToString(m_pos[idx].sl, g_sym.Digits()),
                        DoubleToString(m_pos[idx].tp, g_sym.Digits())));
              }
           }
        }
      else if(g_journal.IsHealthy())
         g_journal.Append((int)JR_ERROR, (int)DUR_FINANCIAL, 0,
            StringFormat("op=resolve_position_failed;order=%I64u;deal=%I64u", res.order, res.deal));
      g_risk.RecountDaily();
      return(true);
     }
   //---
   void     ManagePositions(const SGsTech &t, const int oppositeDir)
     {
      if(!g_sym.RefreshDynamic()) return;
      double pt = g_sym.Point();
      double minStop = g_sym.MinStopDistancePrice();
      double freezeD = (double)g_sym.FreezeLevel() * pt;
      for(int i = ArraySize(m_pos) - 1; i >= 0; i--)
        {
         SGsPosTrack tr = m_pos[i];            // work on a copy; persist at end
         if(!PositionSelectByTicket(tr.ticket))
           {
            // closed while we watched (or between ticks): transaction path journals fully
            int idx0 = FindByTicket(tr.ticket);
            if(idx0 >= 0) RemoveAt(idx0);
            continue;
           }
         double curSl = PositionGetDouble(POSITION_SL);
         double curTp = PositionGetDouble(POSITION_TP);
         double curVol = PositionGetDouble(POSITION_VOLUME);
         tr.volume = curVol;
         // manual/external change detection (self-ops are marked around our requests)
         bool selfOp = (m_selfOpTicket == tr.ticket && TimeCurrent() - m_selfOpAt < 5);
         if(!selfOp && (curSl != tr.sl || curTp != tr.tp))
           {
            if(!tr.manualTouched && (tr.sl != 0.0 || tr.tp != 0.0))
              {
               tr.manualTouched = true;
               if(g_journal.IsHealthy())
                  g_journal.Append((int)JR_MANUAL, (int)DUR_FINANCIAL, 0,
                     StringFormat("ticket=%I64u;kind=sltp_external;sl=%s;tp=%s",
                        tr.ticket, DoubleToString(curSl, g_sym.Digits()),
                        DoubleToString(curTp, g_sym.Digits())));
              }
           }
         tr.sl = curSl; tr.tp = curTp;         // terminal is truth
         double entry = tr.entry;
         double profitPts = (tr.dir > 0 ? (g_sym.Bid() - entry) : (entry - g_sym.Ask())) / pt;
         if(!(tr.manualTouched && InpRespectManualChanges))
           {
            // ---- partial close
            if(InpUsePartialClose && !tr.partialDone && profitPts >= (double)InpPartialTriggerPips * (double)InpPipSizePoints)
              {
               double part = MathFloor((curVol * InpPartialClosePercent / 100.0 + 1e-12) / g_sym.VolStep()) * g_sym.VolStep();
               part = NormalizeDouble(part, 8);
               if(part >= g_sym.VolMin() && (curVol - part) >= g_sym.VolMin())
                 {
                  if(CloseVolume(tr, part, "partial"))
                    { tr.partialDone = true; tr.volume = curVol - part; }
                 }
               else tr.partialDone = true;     // size infeasible: don't retry every tick
              }
            // ---- break-even
            if(InpUseBreakEven && !tr.beDone && profitPts >= (double)InpBeTriggerPips * (double)InpPipSizePoints)
              {
               double beSl = entry + (tr.dir > 0 ? 1 : -1) * InpBeOffsetPips * (double)InpPipSizePoints * pt;
               beSl = g_sym.NormalizePrice(beSl);
               bool improves = (tr.dir > 0 ? (tr.sl == 0.0 || beSl > tr.sl) : (tr.sl == 0.0 || beSl < tr.sl));
               double distToPx = (tr.dir > 0 ? g_sym.Bid() - beSl : beSl - g_sym.Ask());
               if(improves && distToPx >= minStop && distToPx > freezeD)
                 {
                  if(ModifySLTP(tr, beSl, tr.tp, "break_even"))
                    { tr.beDone = true; }
                 }
              }
            // ---- break-even stage 2 (locks profit once stage-2 trigger is reached)
            if(InpUseBreakEven && tr.beDone && !tr.be2Done && InpBe2TriggerPips > 0 &&
               profitPts >= (double)InpBe2TriggerPips * (double)InpPipSizePoints)
              {
               double be2 = entry + (tr.dir > 0 ? 1 : -1) * InpBe2LockPips * (double)InpPipSizePoints * pt;
               be2 = g_sym.NormalizePrice(be2);
               bool improves2b = (tr.dir > 0 ? (tr.sl == 0.0 || be2 > tr.sl) : (tr.sl == 0.0 || be2 < tr.sl));
               double distToPx2b = (tr.dir > 0 ? g_sym.Bid() - be2 : be2 - g_sym.Ask());
               if(improves2b && distToPx2b >= minStop && distToPx2b > freezeD)
                 {
                  if(ModifySLTP(tr, be2, tr.tp, "break_even_2"))
                    { tr.be2Done = true; }
                 }
              }
            // ---- trailing
            if(InpTrailMode != TRAIL_OFF && profitPts >= (double)InpTrailStartPips * (double)InpPipSizePoints)
              {
               double tgt = 0.0;
               bool   trailOk = false;
               if(InpTrailMode == TRAIL_STRUCT)
                 {
                  // trail to the latest confirmed swing pivot +/- buffer (round-14);
                  // no confirmed pivot this bar -> leave the stop unchanged (documented).
                  double bufT = (t.ok ? InpStructTrailBufferAtrMult * t.atr1 : 0.0);
                  if(tr.dir > 0 && g_engine.HasPivotLow())
                    { tgt = g_sym.NormalizePrice(g_engine.LastPLow()  - bufT); trailOk = true; }
                  if(tr.dir < 0 && g_engine.HasPivotHigh())
                    { tgt = g_sym.NormalizePrice(g_engine.LastPHigh() + bufT); trailOk = true; }
                 }
               else
                 {
                  double dist = (InpTrailMode == TRAIL_POINTS ?
                                 (double)InpTrailDistancePips * (double)InpPipSizePoints * pt :
                                 (t.ok ? t.atr1 * InpTrailAtrMult : 0.0));
                  if(dist >= minStop)
                    {
                     tgt = (tr.dir > 0 ? g_sym.Bid() - dist : g_sym.Ask() + dist);
                     tgt = g_sym.NormalizePrice(tgt);
                     trailOk = true;
                    }
                 }
               if(trailOk)
                 {
                  double stepD = InpTrailStepPips * (double)InpPipSizePoints * pt;
                  bool improves2 = (tr.dir > 0 ? (tgt > tr.sl + stepD || tr.sl == 0.0)
                                               : (tgt < tr.sl - stepD || tr.sl == 0.0));
                  double distToPx2 = (tr.dir > 0 ? g_sym.Bid() - tgt : tgt - g_sym.Ask());
                  if(improves2 && distToPx2 >= minStop && distToPx2 > freezeD)
                    {
                     // first trailing move may jump from SL=0: allow without step requirement
                     bool firstNoSl = (tr.sl == 0.0);
                     if(firstNoSl || (tr.dir > 0 ? tgt > tr.sl : tgt < tr.sl))
                        ModifySLTP(tr, tgt, tr.tp, (InpTrailMode == TRAIL_STRUCT ? "trailing_struct" : "trailing"));
                    }
                 }
              }
            // ---- time-based exit
            if(InpMaxTradeDurationMin > 0 &&
               TimeCurrent() - tr.openTime >= (long)InpMaxTradeDurationMin * 60)
              {
               if(CloseVolume(tr, tr.volume, "time_exit"))
                 {
                  if(!PositionSelectByTicket(tr.ticket))          // fully closed and gone
                    { RemoveAt(FindByTicket(tr.ticket)); continue; }
                  tr.volume = PositionGetDouble(POSITION_VOLUME); // partial fill: remainder stays managed
                 }
              }
            // ---- momentum-decay exit (RSI moving against the position for N consecutive closed bars)
            if(InpUseMomentumDecayExit && t.ok)
              {
               if(t.barTime != tr.lastDecayBar)          // evaluated once per closed bar per position
                 {
                  tr.lastDecayBar = t.barTime;
                  bool decaying = (tr.dir > 0 ? (t.rsi1 < t.rsi2) : (t.rsi1 > t.rsi2));
                  tr.momDecay = (decaying ? tr.momDecay + 1 : 0);
                 }
               if(tr.momDecay >= InpMomentumDecayBars)
                 {
                  if(CloseVolume(tr, tr.volume, "momentum_decay_exit"))
                    {
                     if(!PositionSelectByTicket(tr.ticket))        // fully closed and gone
                       { RemoveAt(FindByTicket(tr.ticket)); continue; }
                     tr.volume = PositionGetDouble(POSITION_VOLUME); // partial fill: keep remainder, state intact
                    }
                 }
              }
            // ---- opposite-signal exit
            if(InpUseOppositeSignalExit && oppositeDir != 0 && oppositeDir == -tr.dir)
              {
               if(CloseVolume(tr, tr.volume, "opposite_signal"))
                 {
                  if(!PositionSelectByTicket(tr.ticket))          // fully closed and gone
                    { RemoveAt(FindByTicket(tr.ticket)); continue; }
                  tr.volume = PositionGetDouble(POSITION_VOLUME); // partial fill: keep remainder, state intact
                 }
              }
           }
         int idx = FindByTicket(tr.ticket);
         if(idx >= 0) m_pos[idx] = tr;   // unconditional: terminal-is-truth sync must persist
        }
     }
   //---
   int      CollectOurs(ulong &tickets[])  // terminal-driven enumeration
     {
      ArrayResize(tickets, 0);
      for(int i = PositionsTotal() - 1; i >= 0; i--)
        {
         ulong tk = PositionGetTicket(i);
         if(tk == 0) continue;
         if((long)PositionGetInteger(POSITION_MAGIC) != InpMagicNumber) continue;
         if(PositionGetString(POSITION_SYMBOL) != g_cfg.symbol) continue;
         int n = ArraySize(tickets);
         ArrayResize(tickets, n + 1);
         tickets[n] = tk;
        }
      return(ArraySize(tickets));
     }
   //---
   int      EmergencyCloseAll(const string reason)
     {
      ulong tickets[];
      int n = CollectOurs(tickets);
      int closed = 0;
      for(int i = 0; i < n; i++)
        {
         int idx = FindByTicket(tickets[i]);
         SGsPosTrack tr; ZeroMemory(tr);
         bool have = (idx >= 0);
         if(have) tr = m_pos[idx];
         else { if(!RegisterFromTerminal(tickets[i], true)) continue; idx = FindByTicket(tickets[i]); tr = m_pos[idx]; }
         SGsPosTrack tmp = tr;
         if(CloseVolume(tmp, tmp.volume, "emergency:" + reason)) closed++;
        }
      if(g_journal.IsHealthy())
         g_journal.Append((int)JR_GUARD, (int)DUR_FINANCIAL, 0,
            StringFormat("guard=emergency_close;reason=%s;closed=%d;of=%d", reason, closed, n));
      return(closed);
     }
   //---
   void     OnTradeTransaction(const MqlTradeTransaction &tr,
                               const MqlTradeRequest &rq,
                               const MqlTradeResult &rs)
     {
      if(tr.type != TRADE_TRANSACTION_DEAL_ADD) return;
      if(tr.deal == 0 || DealKnown(tr.deal)) return;   // idempotency on deal id
      MarkDeal(tr.deal);
      if(!HistoryDealSelect(tr.deal)) return;
      if((long)HistoryDealGetInteger(tr.deal, DEAL_MAGIC) != InpMagicNumber) return;
      if(HistoryDealGetString(tr.deal, DEAL_SYMBOL) != g_cfg.symbol) return;
      long entry = HistoryDealGetInteger(tr.deal, DEAL_ENTRY);
      long dtype = HistoryDealGetInteger(tr.deal, DEAL_TYPE);
      double vol = HistoryDealGetDouble(tr.deal, DEAL_VOLUME);
      double prc = HistoryDealGetDouble(tr.deal, DEAL_PRICE);
      double pnl = HistoryDealGetDouble(tr.deal, DEAL_PROFIT) +
                   HistoryDealGetDouble(tr.deal, DEAL_SWAP) +
                   HistoryDealGetDouble(tr.deal, DEAL_COMMISSION);
      ulong pid = (ulong)HistoryDealGetInteger(tr.deal, DEAL_POSITION_ID);
      if(g_journal.IsHealthy())
         g_journal.Append((int)JR_DEAL, (int)DUR_FINANCIAL, 0,
            StringFormat("deal=%I64u;pid=%I64u;entry=%d;type=%d;vol=%.2f;price=%s;pnl=%.2f",
               tr.deal, pid, (int)entry, (int)dtype, vol,
               DoubleToString(prc, g_sym.Digits()), pnl));
      if(entry == DEAL_ENTRY_OUT || entry == DEAL_ENTRY_INOUT || entry == DEAL_ENTRY_OUT_BY)
        {
         int csvIdx = (pid > 0 ? FindByPosId(pid) : -1);   // tracked management state (entry/sl/tp/open time)
         string rsn = (pid > 0 ? TakeCloseReason(pid) : "");      // round-17: true managed reason, else generic
         SgsCsvAppendClosedDeal(tr.deal, pid, dtype, vol, prc, pnl, (rsn != "" ? rsn : "close"),
                                (csvIdx >= 0 ? m_pos[csvIdx].entry : 0.0),
                                (csvIdx >= 0 ? m_pos[csvIdx].sl : 0.0),
                                (csvIdx >= 0 ? m_pos[csvIdx].tp : 0.0),
                                (csvIdx >= 0 ? m_pos[csvIdx].openTime : 0));
        }
      if(entry == DEAL_ENTRY_IN)
        {
         if(pid > 0 && FindByPosId(pid) < 0)
           {
            ulong tk = ResolvePositionTicket(0, tr.deal);
            if(tk > 0 && RegisterFromTerminal(tk, false))
              {
               int idx = FindByTicket(tk);
               if(idx >= 0) m_pos[idx].journaledOpen = true;
               if(g_journal.IsHealthy())
                  g_journal.Append((int)JR_POSITION_OPEN, (int)DUR_FINANCIAL, 0,
                     StringFormat("ticket=%I64u;pid=%I64u;src=transaction", tk, pid));
              }
           }
        }
      else if(entry == DEAL_ENTRY_OUT || entry == DEAL_ENTRY_INOUT || entry == DEAL_ENTRY_OUT_BY)
        {
         int idx = FindByPosId(pid);
         bool alive = (idx >= 0 && PositionSelectByTicket(m_pos[idx].ticket));
         if(idx >= 0 && !alive)
           {
            if(g_journal.IsHealthy())
               g_journal.Append((int)JR_POSITION_CLOSE, (int)DUR_FINANCIAL, 0,
                  StringFormat("ticket=%I64u;pid=%I64u;reason=deal_out;pnl=%.2f",
                               m_pos[idx].ticket, pid, pnl));
            RemoveAt(idx);
           }
         else if(idx >= 0)
            m_pos[idx].volume = PositionGetDouble(POSITION_VOLUME);
         g_risk.RecountDaily();
         g_risk.RecountConsecutiveLosses();
        }
     }
  };

CSgsTrade g_trade;

//+------------------------------------------------------------------+
//| Reconciler: runs BEFORE any trading after init/restart.          |
//| Unknown pendings with our magic => ambiguity => RECOVERY.        |
//+------------------------------------------------------------------+
class CSgsReconcile
  {
public:
   bool   Run(string &report)
     {
      report = "";
      g_rt.reconciled = false;
      g_trade.Init();
      // 1) unexpected pending orders => financial ambiguity
      int orphPend = 0;
      for(int i = OrdersTotal() - 1; i >= 0; i--)
        {
         ulong tk = OrderGetTicket(i);
         if(tk == 0) continue;
         if((long)OrderGetInteger(ORDER_MAGIC) != InpMagicNumber) continue;
         if(OrderGetString(ORDER_SYMBOL) != g_cfg.symbol) continue;
         orphPend++;
         if(g_journal.IsHealthy())
            g_journal.Append((int)JR_MANUAL, (int)DUR_FINANCIAL, 0,
               StringFormat("kind=unexpected_pending;ticket=%I64u", tk));
        }
      if(orphPend > 0)
        {
         report = "unexpected_pending_orders:" + IntegerToString(orphPend);
         return(false);
        }
      // 2) adopt or reject open positions
      ulong tickets[];
      int n = g_trade.CollectOurs(tickets);
      int adopted = 0;
      for(int i = 0; i < n; i++)
        {
         if(!InpRecoveryAdoptOrphans)
           {
            report = "orphan_positions_present:" + IntegerToString(n);
            return(false);
           }
         if(!g_trade.RegisterFromTerminal(tickets[i], true))
           { report = "adopt_failed:" + IntegerToString((int)tickets[i]); return(false); }
         adopted++;
         if(g_journal.IsHealthy())
           {
            g_journal.Append((int)JR_RECONCILE, (int)DUR_FINANCIAL, 0,
               StringFormat("event=adopt;ticket=%I64u", tickets[i]));
            SGsPosTrack tr; ZeroMemory(tr);
            int idx = -1;
            for(int k = 0; k < g_trade.ManagedCount(); k++)
              { g_trade.GetTrack(k, tr); if(tr.ticket == tickets[i]) { idx = k; break; } }
            if(idx >= 0)
               g_journal.Append((int)JR_POSITION_OPEN, (int)DUR_FINANCIAL, 0,
                  StringFormat("ticket=%I64u;pid=%I64u;dir=%d;vol=%.2f;entry=%s;sl=%s;tp=%s;src=adopt",
                     tr.ticket, tr.posId, tr.dir, tr.volume,
                     DoubleToString(tr.entry, g_sym.Digits()),
                     DoubleToString(tr.sl, g_sym.Digits()),
                     DoubleToString(tr.tp, g_sym.Digits())));
           }
        }
      // 3) rebuild risk counters from history (restart-safe)
      g_risk.RecountDaily();
      g_risk.RecountConsecutiveLosses();
      g_risk.LoadPeakEquity();
      g_rt.reconciled = true;
      report = StringFormat("positions=%d;adopted=%d;day_pnl=%.2f;day_trades=%d;consec_losses=%d",
                            n, adopted, g_rt.dayClosedPnl, g_rt.dayTradeCount, g_rt.consecLosses);
      if(g_journal.IsHealthy())
         g_journal.Append((int)JR_RECONCILE, (int)DUR_FINANCIAL, 0, "event=complete;" + report);
      return(true);
     }
  };

CSgsReconcile g_reconcile;

//+------------------------------------------------------------------+
//| Dashboard data contract (main fills; dashboard renders strings)  |
//+------------------------------------------------------------------+
#define SGS_DASH_ROWS 30
struct SGsDashData
  {
   string cap[SGS_DASH_ROWS];
   string val[SGS_DASH_ROWS];
   int    sev[SGS_DASH_ROWS];    // 0=neutral 1=ok 2=warn 3=bad
  };

// Current managed position protective levels for the dashboard (round-14);
// terminal is the source of truth.
string SgsManagedSlTpText()
  {
   int    n = 0;
   ulong  firstTk = 0; double firstSl = 0.0, firstTp = 0.0;
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      ulong tk = PositionGetTicket(i);
      if(tk == 0) continue;
      if((long)PositionGetInteger(POSITION_MAGIC) != InpMagicNumber) continue;
      if(PositionGetString(POSITION_SYMBOL) != g_cfg.symbol) continue;
      n++;
      if(firstTk == 0) { firstTk = tk; firstSl = PositionGetDouble(POSITION_SL); firstTp = PositionGetDouble(POSITION_TP); }
     }
   if(n == 0) return("-");
   return(StringFormat("t=%I64u sl=%s tp=%s%s", firstTk,
          (firstSl > 0.0 ? DoubleToString(firstSl, g_sym.Digits()) : "-"),
          (firstTp > 0.0 ? DoubleToString(firstTp, g_sym.Digits()) : "-"),
          (n > 1 ? " +" + IntegerToString(n - 1) + " more" : "")));
  }
// Management-stage flags of the first tracked position for the dashboard
// (round-20): BE / BE2 / PTL show what ManagePositions HAS applied (done flags),
// or '-' when the feature itself is disabled; TRL shows the configured trail mode.
string SgsManagedMgmtText()
  {
   SGsPosTrack tr; ZeroMemory(tr);
   if(!g_trade.GetTrack(0, tr)) return("-");
   string beTxt  = (InpUseBreakEven   ? (tr.beDone     ? "1" : "0") : "-");
   string be2Txt = (InpUseBreakEven && InpBe2TriggerPips > 0 ? (tr.be2Done ? "1" : "0") : "-");
   string ptlTxt = (InpUsePartialClose ? (tr.partialDone ? "1" : "0") : "-");
   string trlTxt = (InpTrailMode == TRAIL_OFF    ? "-"   :
                    (InpTrailMode == TRAIL_POINTS ? "PTS" :
                     (InpTrailMode == TRAIL_ATR   ? "ATR" : "STR")));
   string s = "BE=" + beTxt + " BE2=" + be2Txt + " PTL=" + ptlTxt + " TRL=" + trlTxt;
   if(g_trade.ManagedCount() > 1)
      s += " +" + IntegerToString(g_trade.ManagedCount() - 1) + " more";
   return(s);
  }
// (round-23): day profit-lock row: '-' (feature off) / 'idle' / 'armed>floor' / 'LOCKED'.
// Mirrors the TickGuards predicate exactly, so the panel always reports the real lock state.
string SgsDayProfitLockText()
  {
   if(!InpUseDayProfitLock) return("-");
   if(g_rt.dayKey != SgsDayKey(TimeCurrent()) || g_rt.dayStartEquity <= 0.0 ||
      g_rt.dayPeakClosedPnl <= 0.0)
      return("idle");
   double peakPct = g_rt.dayPeakClosedPnl / g_rt.dayStartEquity * 100.0;
   if(peakPct < InpDayProfitLockActivatePct) return("idle");
   double lockFloor = g_rt.dayPeakClosedPnl * (1.0 - InpDayProfitLockRetracePct / 100.0);
   if(g_rt.dayClosedPnl <= lockFloor + 1e-9) return("LOCKED");
   return("armed>" + DoubleToString(lockFloor, 2));
  }
//+------------------------------------------------------------------+
//| Dashboard: flicker-free (text-only updates, timer-throttled),    |
//| unique object prefix, full cleanup, hide/show toggle button.     |
//+------------------------------------------------------------------+
class CSgsDash
  {
private:
   string m_pfx;
   bool   m_created;
   bool   m_visible;
   color  m_bg, m_fg, m_ok, m_warn, m_bad, m_border, m_title;
   color  m_track, m_accent;           // round-25: gauge track + brand accent strip
   int    m_gaugeH;                    // round-25: confidence gauge band height (px)
   int    m_fontSize;
   int    m_w;                       // panel width (px), set in Create() — drives value clipping
   int    m_valX;                    // value-column offset from panel X (px)
   //---
   string ObjName(const string s) const { return(m_pfx + s); }
   void   MakeLabel(const string name, const int x, const int y, const int size)
     {
      if(ObjectFind(0, name) < 0) ObjectCreate(0, name, OBJ_LABEL, 0, 0, 0);
      ObjectSetInteger(0, name, OBJPROP_CORNER, CORNER_LEFT_UPPER);
      ObjectSetInteger(0, name, OBJPROP_XDISTANCE, x);
      ObjectSetInteger(0, name, OBJPROP_YDISTANCE, y);
      ObjectSetInteger(0, name, OBJPROP_FONTSIZE, size);
      ObjectSetString(0, name, OBJPROP_FONT, "Consolas");
      ObjectSetInteger(0, name, OBJPROP_ANCHOR, ANCHOR_LEFT_UPPER);
      ObjectSetInteger(0, name, OBJPROP_BACK, false);
      ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
      ObjectSetInteger(0, name, OBJPROP_HIDDEN, true); // object-list hygiene (visibility via TIMEFRAMES)
     }
   void   MakeRect(const string name, const int x, const int y, const int rw, const int rh, const color fill)
     {                                                          // round-25: flat strip helper (accent/divider/gauge)
      if(ObjectFind(0, name) < 0) ObjectCreate(0, name, OBJ_RECTANGLE_LABEL, 0, 0, 0);
      ObjectSetInteger(0, name, OBJPROP_CORNER, CORNER_LEFT_UPPER);
      ObjectSetInteger(0, name, OBJPROP_XDISTANCE, x);
      ObjectSetInteger(0, name, OBJPROP_YDISTANCE, y);
      ObjectSetInteger(0, name, OBJPROP_XSIZE, rw);
      ObjectSetInteger(0, name, OBJPROP_YSIZE, rh);
      ObjectSetInteger(0, name, OBJPROP_BGCOLOR, fill);
      ObjectSetInteger(0, name, OBJPROP_BORDER_TYPE, BORDER_FLAT);
      ObjectSetInteger(0, name, OBJPROP_COLOR, fill);          // border coloured like fill => seamless strip
      ObjectSetInteger(0, name, OBJPROP_BACK, false);
      ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
      ObjectSetInteger(0, name, OBJPROP_HIDDEN, true);
     }
   void   SetText(const string name, const string txt, const color c)
     {
      string cur = "";
      ObjectGetString(0, name, OBJPROP_TEXT, 0, cur);
      if(cur != txt) ObjectSetString(0, name, OBJPROP_TEXT, txt);
      color cc = (color)ObjectGetInteger(0, name, OBJPROP_COLOR);
      if(cc != c) ObjectSetInteger(0, name, OBJPROP_COLOR, c);
     }
public:
   CSgsDash()
     {
      m_pfx = "SGSP_"; m_created = false; m_visible = true; m_fontSize = 9;
      m_w = 0; m_valX = 124;
      m_bg = C'24,26,32'; m_fg = clrGainsboro; m_ok = clrLimeGreen;
      m_warn = clrGold; m_bad = clrTomato; m_border = clrDimGray; m_title = clrGold;
      m_track = C'40,44,54'; m_accent = clrGold; m_gaugeH = 24;   // round-25 defaults (dark)
     }
   bool   Created() const { return(m_created); }
   bool   Visible() const { return(m_visible); }
   //---
   void   Create()
     {
      if(!InpDashboardEnabled) return;
      if(InpDashboardTheme == THEME_LIGHT)
        {
         m_bg = C'238,240,244'; m_fg = C'40,42,50'; m_ok = C'20,130,60';
         m_warn = C'170,120,10'; m_bad = C'180,40,40'; m_border = clrSilver; m_title = C'140,90,0';
         m_track = C'208,212,220';                              // round-25: light-theme gauge track
        }
      m_accent = m_title;                                        // round-25: brand strip follows title colour
      m_fontSize = (int)MathMax(6L, (long)(9 * InpDashboardScalePercent / 100));
      string bg = ObjName("BG");
      if(ObjectFind(0, bg) < 0)
         ObjectCreate(0, bg, OBJ_RECTANGLE_LABEL, 0, 0, 0);
      int rowH = m_fontSize + 6;
      m_w = 368; int w = m_w, h = (SGS_DASH_ROWS + 2) * rowH + 26 + m_gaugeH;   // round-25: +gauge band
      ObjectSetInteger(0, bg, OBJPROP_CORNER, CORNER_LEFT_UPPER);
      ObjectSetInteger(0, bg, OBJPROP_XDISTANCE, InpDashboardX);
      ObjectSetInteger(0, bg, OBJPROP_YDISTANCE, InpDashboardY);
      ObjectSetInteger(0, bg, OBJPROP_XSIZE, w);
      ObjectSetInteger(0, bg, OBJPROP_YSIZE, h);
      ObjectSetInteger(0, bg, OBJPROP_BGCOLOR, m_bg);
      ObjectSetInteger(0, bg, OBJPROP_BORDER_TYPE, BORDER_FLAT);
      ObjectSetInteger(0, bg, OBJPROP_COLOR, m_border);
      ObjectSetInteger(0, bg, OBJPROP_BACK, false);
      ObjectSetInteger(0, bg, OBJPROP_SELECTABLE, false);
      ObjectSetInteger(0, bg, OBJPROP_HIDDEN, true); // object-list hygiene
      for(int i = 0; i < SGS_DASH_ROWS; i++)
        {
         MakeLabel(ObjName("C" + IntegerToString(i)), InpDashboardX + 8,
                   InpDashboardY + 22 + i * rowH, m_fontSize);
         MakeLabel(ObjName("V" + IntegerToString(i)), InpDashboardX + m_valX,
                   InpDashboardY + 22 + i * rowH, m_fontSize);
        }
      // round-25: visual polish — brand accent strip, title divider, confidence gauge band.
      // All prefixed objects: Toggle()/Destroy() cover them automatically (prefix-wide).
      int gy = InpDashboardY + h - 18;                          // gauge band baseline inside panel
      MakeRect(ObjName("ACC"), InpDashboardX + 4, InpDashboardY + 4, w - 58, 2, m_accent);
      MakeRect(ObjName("DIV"), InpDashboardX + 4, InpDashboardY + 20 + rowH, w - 8, 1, m_border);
      MakeRect(ObjName("GTR"), InpDashboardX + 8, gy, m_w - 88, 8, m_track);
      MakeRect(ObjName("GFI"), InpDashboardX + 8, gy, 0, 8, m_ok);
      MakeLabel(ObjName("GTX"), InpDashboardX + m_w - 72, gy - 1,
                (int)MathMax(6L, (long)m_fontSize - 1));
      string btn = ObjName("BTN");
      if(ObjectFind(0, btn) < 0) ObjectCreate(0, btn, OBJ_BUTTON, 0, 0, 0);
      ObjectSetInteger(0, btn, OBJPROP_CORNER, CORNER_LEFT_UPPER);
      ObjectSetInteger(0, btn, OBJPROP_XDISTANCE, InpDashboardX + w - 46);
      ObjectSetInteger(0, btn, OBJPROP_YDISTANCE, InpDashboardY + 3);
      ObjectSetInteger(0, btn, OBJPROP_XSIZE, 42);
      ObjectSetInteger(0, btn, OBJPROP_YSIZE, 16);
      ObjectSetString(0, btn, OBJPROP_TEXT, "hide");
      ObjectSetInteger(0, btn, OBJPROP_FONTSIZE, 7);
      m_created = true;
     }
   //---
   void   Toggle()
     {
      if(!m_created) return;
      m_visible = !m_visible;
      int total = ObjectsTotal(0, 0, -1);
      for(int i = total - 1; i >= 0; i--)
        {
         string nm = ObjectName(0, i, 0, -1);
         if(StringFind(nm, m_pfx) != 0) continue;
         if(nm == ObjName("BTN")) continue;
         ObjectSetInteger(0, nm, OBJPROP_TIMEFRAMES, m_visible ? OBJ_ALL_PERIODS : OBJ_NO_PERIODS);
        }
      ObjectSetString(0, ObjName("BTN"), OBJPROP_TEXT, m_visible ? "hide" : "show");
      ChartRedraw(0);
     }
   //---
   void   Update(const SGsDashData &d)
     {
      if(!m_created || !m_visible) return;
      // pixel budget for the value column; Consolas advance ~= 0.62 * pt size (conservative).
      // Over-long rows are clipped with ".." so nothing ever spills past the panel's right edge.
      int maxChars = (m_w > 0 && m_fontSize > 0 ?
                      (int)MathMax(10L, (long)MathFloor((double)(m_w - m_valX - 8) / (m_fontSize * 0.62))) : 60);
      color rowc;
      for(int i = 0; i < SGS_DASH_ROWS; i++)
        {
         if(d.sev[i] == 1) rowc = m_ok;
         else if(d.sev[i] == 2) rowc = m_warn;
         else if(d.sev[i] == 3) rowc = m_bad;
         else rowc = m_fg;
         string capNm = ObjName("C" + IntegerToString(i));
         string valNm = ObjName("V" + IntegerToString(i));
         string vtxt = d.val[i];
         if(StringLen(vtxt) > maxChars) vtxt = StringSubstr(vtxt, 0, maxChars - 2) + "..";
         SetText(capNm, d.cap[i], (i == 0 ? m_title : m_fg));
         SetText(valNm, vtxt, rowc);
        }
     }
   //---
   // round-25: confidence gauge — renders last evaluated signal's confidence as a
   // colour-coded fill (sev: 1>=min ok, 2>=min/2 warn, else neutral). Width is
   // clamped to the track; label shows the rounded percent. Display-only.
   void   UpdateGauge(const double frac, const int sev)
     {
      if(!m_created || !m_visible) return;
      double f = MathMax(0.0, MathMin(1.0, frac));
      int    tw = m_w - 88;                        // gauge track width (px)
      int    fw = (int)MathFloor(tw * f + 1e-9);   // fill width 0..tw
      color  fc = (sev == 1 ? m_ok : (sev == 2 ? m_warn : m_fg));
      string gf = ObjName("GFI");
      ObjectSetInteger(0, gf, OBJPROP_XSIZE, fw);
      ObjectSetInteger(0, gf, OBJPROP_BGCOLOR, fc);
      ObjectSetInteger(0, gf, OBJPROP_COLOR, fc);
      SetText(ObjName("GTX"),
              "conf " + IntegerToString((int)MathRound(f * 100.0)) + "%", fc);
     }
   //---
   void   Destroy()
     {
      ObjectsDeleteAll(0, m_pfx, 0, -1);
      m_created = false;
     }
  };

CSgsDash g_dash;

//+------------------------------------------------------------------+
//| Main-module runtime scope                                        |
//+------------------------------------------------------------------+
bool     g_initDone = false;
datetime g_lastBarTime = 0;
datetime g_lastEntryBarTime = 0;
string   g_lastDenyReason = "";            // round-15: most recent entry denial reason (dashboard)
bool     g_emergencyDone = false;
datetime g_emergencyAt = 0;                 // round-16: bounded emergency retry throttle (1s)
int      g_dashTickCounter = 0;
string   g_permReason = "";
string   g_lastTradeDesc = "-";
SGsTech  g_tech;
SGsSignalOut g_sig;

//+------------------------------------------------------------------+
//| Known-answer / self tests (run on init when enabled):            |
//| CRC32("123456789") == 0xCBF43926  (zlib-compatible vector)       |
//| SHA256("abc") == ba7816bf...20015ad (NIST vector)                |
//| plus journal write->rescan round-trip when dummy records asked.  |
//+------------------------------------------------------------------+
bool SgsRunSelfTests(string &fails)
  {
   fails = "";
   if(SgsCrc32OfString("123456789") != 0xCBF43926) fails += "crc32_kat;";
   uchar a[];
   int n = StringToCharArray("abc", a, 0, WHOLE_ARRAY, CP_UTF8);
   if(n > 0) ArrayResize(a, n - 1);
   uchar h[32];
   if(!SgsSha256(a, h) ||
      SgsHex(h, 32) != "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad")
      fails += "sha256_kat;";
   // SgsSha256Pair self-consistency: H(a||b) == H(join(a,b))
   uchar b2[];
   int n2 = StringToCharArray("def", b2, 0, WHOLE_ARRAY, CP_UTF8);
   if(n2 > 0) ArrayResize(b2, n2 - 1);
   uchar hp[32];
   if(!SgsSha256Pair(a, b2, hp)) fails += "sha256_pair_fail;";
   else
     {
      uchar joined[];
      int ja = ArraySize(a), jb = ArraySize(b2);
      ArrayResize(joined, ja + jb);
      for(int i = 0; i < ja; i++) joined[i] = a[i];
      for(int j = 0; j < jb; j++) joined[ja + j] = b2[j];
      if(!SgsSha256(joined, h)) fails += "sha256_join_fail;";
      else if(!SgsBytesEqual(hp, h, 32)) fails += "sha256_pair_mismatch;";
     }
   return(fails == "");
  }

//+------------------------------------------------------------------+
//| Graceful idempotent cleanup (used by failed init and deinit)     |
//+------------------------------------------------------------------+
void SgsCleanupAll(const int reasonCode)
  {
   if(g_journal.IsOpen())
     {
      if(g_journal.IsHealthy())
         g_journal.Append((int)JR_SESSION_END, (int)DUR_STATE, 0,
                          StringFormat("reason=%d;seq_end=%I64u", reasonCode, g_journal.NextSequence()));
      g_journal.Close();
     }
   g_ind.Release();
   EventKillTimer();
   g_dash.Destroy();
   g_lock.Release();
   g_rt.lockOwned = false;
  }

//+------------------------------------------------------------------+
//| Permission cache string for the dashboard                        |
//+------------------------------------------------------------------+
string SgsPermissionText()
  {
   string why = "";
   if(!SgsEnvTradeAllowed(why)) return("BLOCKED(" + why + ")");
   if(InpDryRun) return("DRY-RUN");
   return("OK");
  }

//+------------------------------------------------------------------+
//| Dashboard data assembly                                          |
//+------------------------------------------------------------------+
// (round-26): one orderly dashboard row listing every ACTIVE filter together with the
// score weight assigned to it in the code. The five scored components show their exact
// Evaluate weights (TR=+30, RS=+25, XU=+15, CB=+15, PB=+15; CB appears only when
// InpBodyConfirmRatio > 0 — the achievable ceiling is then 85, mirroring maxScore).
// Binary gates carry NO score in the code, so they are listed as two-letter tokens in
// the exact order of the gates contract string; UPPERCASE = passed on the latest
// evaluation, lowercase = failed. Only ENABLED switches appear (the active filters).
// An uppercased scored token means its points were earned on the latest bar for the
// dominant side (buyScore >= sellScore). Row severity: 2 = an enabled gate is failing.
string SgsFilterScoreText(int &outSev)
  {
   outSev = 0;
   if(!InpShowFilterScoreboard) return("-");
   bool buySide = (g_sig.buyScore >= g_sig.sellScore);
   uint rsn     = g_sig.reasons;
   uint bTr = (buySide ? (uint)RSN_TREND_UP      : (uint)RSN_TREND_DOWN);
   uint bRs = (buySide ? (uint)RSN_RSI_BULL_ZONE : (uint)RSN_RSI_BEAR_ZONE);
   uint bXu = (buySide ? (uint)RSN_RSI_CROSS_UP  : (uint)RSN_RSI_CROSS_DOWN);
   uint bCb = (buySide ? (uint)RSN_CANDLE_BULL   : (uint)RSN_CANDLE_BEAR);
   uint bPb = (buySide ? (uint)RSN_PULLBACK_BUY    : (uint)RSN_PULLBACK_SELL);
   string s = "";
   s += ((rsn & bTr) != 0 ? "TR30 " : "tr30 ");
   s += ((rsn & bRs) != 0 ? "RS25 " : "rs25 ");
   s += ((rsn & bXu) != 0 ? "XU15 " : "xu15 ");
   if(InpBodyConfirmRatio > 0.0)
      s += ((rsn & bCb) != 0 ? "CB15 " : "cb15 ");
   s += ((rsn & bPb) != 0 ? "PB15" : "pb15");
   // binary gates: token / enabling switch / live state — order = gates-string contract
   string tok[22]; bool en[22]; bool st[22];
   tok[0]="SP";  en[0]=InpUseSpreadFilter;         st[0]=g_sig.gateSpread;
   tok[1]="VL";  en[1]=InpUseVolatilityFilter;     st[1]=g_sig.gateVolatility;
   tok[2]="SS";  en[2]=InpUseSessionFilter;        st[2]=g_sig.gateSession;
   tok[3]="RO";  en[3]=InpUseRolloverFilter;       st[3]=g_sig.gateRollover;
   tok[4]="NW";  en[4]=InpUseNewsFilter;           st[4]=g_sig.gateNews;
   tok[5]="HS";  en[5]=true;                       st[5]=g_sig.gateHistory;
   tok[6]="TG";  en[6]=InpUseTrendGate;            st[6]=g_sig.gateTrend;
   tok[7]="HT";  en[7]=InpUseHtfTrendConfirm;      st[7]=g_sig.gateHtf;
   tok[8]="CP";  en[8]=InpUseClosePosFilter;       st[8]=g_sig.gateClosePos;
   tok[9]="RM";  en[9]=InpUseRsiMomentumFilter;    st[9]=g_sig.gateRsiMom;
   tok[10]="NX"; en[10]=InpUseExtensionFilter;     st[10]=g_sig.gateNoExtension;
   tok[11]="SR"; en[11]=InpUseSwingSRFilter;       st[11]=g_sig.gateSrSpace;
   tok[12]="FV"; en[12]=InpUseFvgFilter;           st[12]=g_sig.gateFvg;
   tok[13]="MS"; en[13]=InpUseMssFilter;           st[13]=g_sig.gateMss;
   tok[14]="SL"; en[14]=InpUseEmaSlopeFilter;      st[14]=g_sig.gateEmaSlope;
   tok[15]="AX"; en[15]=InpUseAdxFilter;           st[15]=g_sig.gateAdx;
   tok[16]="MC"; en[16]=InpUseMacdFilter;          st[16]=g_sig.gateMacd;
   tok[17]="CA"; en[17]=InpUseCandlePatternFilter; st[17]=g_sig.gateCandlePattern;
   tok[18]="SD"; en[18]=InpUseSupplyDemandFilter;  st[18]=g_sig.gateSupplyDemand;
   tok[19]="LQ"; en[19]=InpUseLiquidityFilter;     st[19]=g_sig.gateLiquidity;
   tok[20]="GP"; en[20]=InpUseGapJumpFilter;       st[20]=g_sig.gateGapJump;
   tok[21]="DH"; en[21]=InpUseDayHiLoFilter;       st[21]=g_sig.gateDayHiLo;
   bool anyFail = false;
   for(int i = 0; i < 22; i++)
     {
      if(!en[i]) continue;                          // inactive filters are not shown
      if(!st[i]) anyFail = true;
      string tk = tok[i];
      if(!st[i]) StringToLower(tk);                 // failing gate -> lowercase token
      s += " " + tk;
     }
   outSev = (anyFail ? 2 : 1);
   return(s);
  }

void SgsFillDash(SGsDashData &d)
  {
   for(int i = 0; i < SGS_DASH_ROWS; i++) { d.cap[i] = ""; d.val[i] = ""; d.sev[i] = 0; }
   int r = 0;
   d.cap[r] = "EA";           d.val[r] = "Smart Gold Scalper Pro v" + SGS_VERSION_TEXT; d.sev[r] = 1; r++;
   d.cap[r] = "Symbol/TF";    d.val[r] = g_cfg.symbol + " " + EnumToString(InpTimeframe) +
                              " d=" + IntegerToString(g_sym.Digits()); r++;
   d.cap[r] = "State";        d.val[r] = SgsStateName(g_rt.state);
   d.sev[r] = (g_rt.state == SGS_TRADING_ENABLED ? 1 :
               (g_rt.state == SGS_FAULTED || g_rt.state == SGS_RECOVERY_REQUIRED ? 3 : 2)); r++;
   d.cap[r] = "Permission";   d.val[r] = g_permReason; d.sev[r] = (g_permReason == "OK" ? 1 : 2); r++;
   d.cap[r] = "Spread(pip)";  d.val[r] = IntegerToString((int)MathRound((double)g_sym.SpreadPoints() / (double)InpPipSizePoints)) + " / " +
                              IntegerToString(InpMaxSpreadPips);
   d.sev[r] = (!InpUseSpreadFilter ? 0 :                                    // no alarm when the filter itself is disabled (round-19)
               (g_sym.SpreadPoints() <= (long)InpMaxSpreadPips * (long)InpPipSizePoints ? 1 : 3)); r++;
   datetime now2 = TimeCurrent();
   int nowMin = SgsMinutesOfDay(now2);
   bool inSess = !InpUseSessionFilter || SgsInWindow(nowMin, g_cfg.sessionStartMin, g_cfg.sessionEndMin);
   d.cap[r] = "Session";      d.val[r] = InpSessionStart + "-" + InpSessionEnd +
                              (inSess ? " IN" : " OUT"); d.sev[r] = (inSess ? 1 : 2); r++;
   string trend = "flat";
   if(g_tech.ok)
     {
      if(g_tech.close1 > g_tech.emaSlow1 && g_tech.emaFast1 > g_tech.emaSlow1) trend = "up";
      else if(g_tech.close1 < g_tech.emaSlow1 && g_tech.emaFast1 < g_tech.emaSlow1) trend = "down";
     }
   d.cap[r] = "Trend";        d.val[r] = trend + (g_tech.ok ? "" : " (n/a)"); r++;
   d.cap[r] = "Signal";       d.val[r] = SgsDirText(g_sig.dir) +
                              " conf=" + DoubleToString(g_sig.confidence, 2);
   d.sev[r] = (g_sig.dir == (int)SIGNAL_NONE ? 0 : 1); r++;
   d.cap[r] = "Scores B/S";   d.val[r] = IntegerToString(g_sig.buyScore) + " / " +
                              IntegerToString(g_sig.sellScore) + " thr=" + IntegerToString(InpMinScoreToTrade); r++;
   int fsSev = 0;
   d.cap[r] = "Filters";   d.val[r] = SgsFilterScoreText(fsSev); d.sev[r] = fsSev; r++;   // round-26
   d.cap[r] = "RiskMode";     d.val[r] = (InpRiskMode == RISK_PERCENT ?
                              DoubleToString(MathMin(InpRiskPercentPerTrade, InpMaxRiskPercentPerTrade), 2) + "%/trade" :
                              "FIXED " + DoubleToString(InpFixedLot, 2) + " lot"); r++;
   d.cap[r] = "Last trade";   d.val[r] = g_lastTradeDesc; r++;
   d.cap[r] = "Daily P/L";    d.val[r] = DoubleToString(g_rt.dayClosedPnl, 2);
   d.sev[r] = (g_rt.dayClosedPnl >= 0.0 ? 1 : 2); r++;
   d.cap[r] = "Floating P/L"; d.val[r] = DoubleToString(g_risk.FloatingPnl(), 2);
   d.sev[r] = (g_risk.FloatingPnl() >= 0.0 ? 1 : 2); r++;
   double eq = AccountInfoDouble(ACCOUNT_EQUITY);
   double ddT = (g_rt.peakEquity > 0.0 ? MathMax(0.0, g_rt.peakEquity - eq) / g_rt.peakEquity * 100.0 : 0.0);
   double ddD = (g_rt.dayStartEquity > 0.0 ? MathMax(0.0, (g_rt.dayStartEquity - eq)) / g_rt.dayStartEquity * 100.0 : 0.0);
   d.cap[r] = "DD day/total"; d.val[r] = DoubleToString(ddD, 2) + "% / " + DoubleToString(ddT, 2) + "%";
   d.sev[r] = (ddT >= InpMaxTotalDDPercent * 0.7 ? 2 : 1); r++;
   d.cap[r] = "Trades today"; d.val[r] = IntegerToString(g_rt.dayTradeCount) + " / " +
                              IntegerToString(InpMaxTradesPerDay) + " open=" + IntegerToString(g_trade.ManagedCount()); r++;
   d.cap[r] = "Loss streak";  d.val[r] = IntegerToString(g_rt.consecLosses) + " / " + IntegerToString(InpConsecLossLimit);
   d.sev[r] = (InpConsecLossLimit > 0 && g_rt.consecLosses >= InpConsecLossLimit ? 3 : 0); r++;
   d.cap[r] = "Journal";      d.val[r] = (InpJournalEnabled ?
                              (g_journal.IsHealthy() ? "OK gen=" + IntegerToString((int)g_journal.Generation()) +
                               " seq=" + IntegerToString((int)g_journal.NextSequence()) +
                               " " + IntegerToString((int)(g_journal.CurrentSize() / 1024)) + "KB" : "UNHEALTHY") :
                              "DISABLED");
   d.sev[r] = (InpJournalEnabled ? (g_journal.IsHealthy() ? 1 : 3) : 2); r++;
   d.cap[r] = "Lock";         d.val[r] = (g_rt.lockOwned ? "OWNED" : "NOT OWNED");
   d.sev[r] = (g_rt.lockOwned ? 1 : 3); r++;
   d.cap[r] = "News";         d.val[r] = (!g_news.EffectiveEnabled() ?
                              "off" + (g_news.Reason() != "" ? " (" + g_news.Reason() + ")" : "") :
                              (g_news.IsBlocked() ? "BLOCKED " + g_news.Reason() : "clear"));
   d.sev[r] = (g_news.IsBlocked() ? 2 : 0); r++;
   d.cap[r] = "Last error";   d.val[r] = (g_rt.lastError == "" ? "-" : g_rt.lastError);
   d.sev[r] = (g_rt.lastError == "" ? 0 : 3); r++;
   long cdLeft = (long)g_rt.lossCooldownUntil - (long)now2;
   d.cap[r] = "Cooldown";     d.val[r] = (cdLeft > 0 ? "loss " + IntegerToString((int)(cdLeft / 60)) + "m" :
                              (TimeCurrent() - g_rt.lastSignalTime < InpSignalCooldownSec ? "signal" : "-")); r++;
   {                                      // spec: gate layer overview (entry/reject visibility)
    string gs = g_sig.gates;
    if(gs == "") gs = "-";
    if(StringLen(gs) > 42) gs = StringSubstr(gs, 0, 42);   // panel width guard
    d.cap[r] = "Gates";        d.val[r] = gs; r++;
   }
   d.cap[r] = "Win/Loss";     d.val[r] = IntegerToString(g_rt.dayWins) + "/" + IntegerToString(g_rt.dayLosses);
   d.sev[r] = (g_rt.dayLosses > g_rt.dayWins ? 2 : 1); r++;
   double openRisk = g_risk.OpenRiskPercent();
   d.cap[r] = "Active risk";  d.val[r] = DoubleToString(openRisk, 2) + "%" +
                              (InpMaxTotalRiskPercentOpen > 0.0 ? " / " + DoubleToString(InpMaxTotalRiskPercentOpen, 2) + "%" : "");
   d.sev[r] = (InpMaxTotalRiskPercentOpen > 0.0 && openRisk >= InpMaxTotalRiskPercentOpen ? 3 : 0); r++;
   d.cap[r] = "Last deny";    d.val[r] = (g_lastDenyReason == "" ? "-" : g_lastDenyReason);
   d.sev[r] = (g_lastDenyReason == "" ? 0 : 2); r++;
   d.cap[r] = "Pos SL/TP";    d.val[r] = SgsManagedSlTpText(); d.sev[r] = 1; r++;
   d.cap[r] = "Trade mgmt";   d.val[r] = SgsManagedMgmtText();
   d.sev[r] = (d.val[r] == "-" ? 0 : 1); r++;
   d.cap[r] = "Profit lock";  d.val[r] = SgsDayProfitLockText();
   d.sev[r] = (d.val[r] == "LOCKED" ? 2 : (d.val[r] == "-" ? 0 : 1)); r++;
   d.cap[r] = "Updated";      d.val[r] = TimeToString(now2, TIME_SECONDS); r++;
  }

//+------------------------------------------------------------------+
//| Expert initialization                                            |
//+------------------------------------------------------------------+
int OnInit()
  {
   bridge.Init(InpBridgeURL, InpSecret, InpTimeoutMs);

   g_rt.state = SGS_CREATED;
   g_rt.initOk = false; g_rt.reconciled = false; g_rt.journalHealthy = false;
   g_rt.lockOwned = false; g_rt.lastError = ""; g_rt.consecutiveErrors = 0;
   g_rt.lastSignalBarTime = 0; g_rt.lastSignalDir = (int)SIGNAL_NONE;
   g_rt.lastSignalTime = 0; g_rt.lastSignalConf = 0.0;
   g_rt.dayKey = 0; g_rt.dayStartEquity = 0.0; g_rt.dayClosedPnl = 0.0;
   g_rt.dayPeakClosedPnl = 0.0;   // round-23
   g_rt.weekKey = 0; g_rt.weekStartEquity = 0.0; g_rt.weekClosedPnl = 0.0;
   g_rt.dayWins = 0; g_rt.dayLosses = 0;
   g_rt.dayTradeCount = 0; g_rt.consecLosses = 0; g_rt.lossCooldownUntil = 0;
   g_rt.streakEpoch = 0;
   g_rt.peakEquity = 0.0; g_rt.hardGuardHit = false;

   CSgsState::Transition(SGS_INITIALIZING, "on_init");
   string err = "";
   bool journalBlocked = false;   // journal integrity problem: RECOVERY_REQUIRED, never trade
   // 1) configuration (pure inputs, dependency validation)
   if(!CSgsConfig::Validate(err))
     {
      Print("SGS INIT CONFIG REJECTED: ", err);
      g_rt.lastError = "config:" + err;
      return(INIT_PARAMETERS_INCORRECT);
     }
   // 2) symbol / contract spec
   if(!g_sym.Init(g_cfg.symbol, err))
     {
      Print("SGS INIT SYMBOL FAILED: ", err);
      g_rt.lastError = "symbol:" + err;
      return(INIT_FAILED);
     }
   // 3) identity
   g_rt.instanceId = SgsMakeInstanceId(g_cfg.symbol);
   g_rt.sessionId  = SgsMakeSessionId();
   // 4) instance lock BEFORE journal (recovery precondition: lock held)
   g_lock.Setup(g_rt.instanceId, g_rt.sessionId);
   string ldetail = "";
   int lr = g_lock.Acquire(ldetail);
   if(lr != 0)
     {
      Print("SGS INIT LOCK FAILED: ", ldetail, " (file: ", g_lock.Name(), ")");
      g_rt.lastError = "lock:" + ldetail;
      return(INIT_FAILED);
     }
   g_rt.lockOwned = true;
   // 5) journal
   if(InpJournalEnabled)
     {
      g_journal.Setup(InpJournalFileName, g_rt.instanceId);
      if(!g_journal.OpenOrCreate(g_rt.sessionId, err))
        {
         // spec: recovery refusal / journal corruption => RECOVERY_REQUIRED, never trade
         Print("SGS INIT JOURNAL FAILED -> RECOVERY_REQUIRED: ", err);
         g_rt.lastError = "journal:" + err;
         journalBlocked = true;
         CSgsState::Transition(SGS_RECOVERY_REQUIRED, "journal:" + err);
        }
      if(InpJournalSelfTestOnOpen && g_journal.IsOpen())   // round-27: skip when open failed (avoids double self-transition)
        {
         string why = "";
         if(!g_journal.VerifyCrossGeneration(why) && why != "archive_pruned_ok")
           {
            Print("SGS INIT JOURNAL CHAIN FAILED -> RECOVERY_REQUIRED: ", why);
            g_rt.lastError = "journal_chain:" + why;
            journalBlocked = true;
            if(g_rt.state != SGS_RECOVERY_REQUIRED)   // round-27: no illegal self-transition
               CSgsState::Transition(SGS_RECOVERY_REQUIRED, "journal_chain:" + why);
           }
        }
      g_rt.journalHealthy = g_journal.IsHealthy();
     }
   else
     {
      Print("SGS WARNING: journal disabled by input (reduced auditability mode)");
      g_rt.journalHealthy = false;
     }
   // 6) session + config snapshot records
   if(g_journal.IsHealthy())
     {
      g_journal.Append((int)JR_SESSION_START, (int)DUR_STATE, 0,
         StringFormat("instance=%I64u;session=%I64u;version=%s;build=%d;tester=%d",
            g_rt.instanceId, g_rt.sessionId, SGS_VERSION_TEXT,
            (int)TerminalInfoInteger(TERMINAL_BUILD), (int)(bool)MQLInfoInteger(MQL_TESTER)));
      string cfg = StringFormat(
         "sym=%s;tf=%s;magic=%d;dir=%d;risk=%d;fixlot=%.2f;riskpct=%.2f;maxdd=%.2f;"
         "emaf=%d;emas=%d;rsi=%d;atr=%d;minscore=%d;minconf=%.2f;slmode=%d;tpmode=%d;"
         "rr=%.2f;be=%d;trail=%d;partial=%d;session=%d;news=%d;journal_verified=1;cfg_crc=%u",
         g_cfg.symbol, EnumToString(InpTimeframe), (int)InpMagicNumber, (int)InpTradeDirection,
         (int)InpRiskMode, InpFixedLot, InpRiskPercentPerTrade, InpMaxTotalDDPercent,
         InpEmaFastPeriod, InpEmaSlowPeriod, InpRsiPeriod, InpAtrPeriod,
         InpMinScoreToTrade, InpMinConfidence, (int)InpSlMode, (int)InpTpMode,
         InpRewardRiskRatio, (int)InpUseBreakEven, (int)InpTrailMode, (int)InpUsePartialClose,
         (int)InpUseSessionFilter, (int)InpUseNewsFilter, SgsCrc32OfString(SGS_VERSION_TEXT));
      g_journal.Append((int)JR_CONFIG, (int)DUR_STATE, 0, cfg);
     }
   // 7) crypto self-tests (known-answer) - a broken codec means unsafe journal
   if(InpSelfTestOnInit)
     {
      string fails = "";
      if(!SgsRunSelfTests(fails))
        {
         // crypto codec broken: defect, not recoverable-in-place => FAULTED, never trade
         Print("SGS INIT SELFTEST FAILED -> FAULTED: ", fails);
         g_rt.lastError = "selftest:" + fails;
         journalBlocked = true;
         CSgsState::Transition(SGS_FAULTED, "selftest:" + fails);
        }
      if(InpSelfTestDummyRecords > 0 && g_journal.IsHealthy())
        {
         int before = 0;
         SGsScanReport repPre; repPre.Reset();
         g_journal.FullScan(g_journal.ResolvedName(), g_rt.instanceId, true, repPre);
         before = repPre.recordCount;
         for(int i = 0; i < InpSelfTestDummyRecords; i++)
            g_journal.Append((int)JR_META_OPEN, (int)DUR_AUDIT, 0, "dummy=" + IntegerToString(i));
         SGsScanReport repPost; repPost.Reset();
         bool okScan = g_journal.FullScan(g_journal.ResolvedName(), g_rt.instanceId, true, repPost);
         if(!okScan || repPost.recordCount != before + InpSelfTestDummyRecords)
           {
            Print("SGS INIT JOURNAL ROUNDTRIP FAILED -> RECOVERY_REQUIRED");
            g_rt.lastError = "journal_roundtrip";
            journalBlocked = true;
            CSgsState::Transition(SGS_RECOVERY_REQUIRED, "journal_roundtrip");
           }
        }
     }
   // 8) indicators
   if(!g_ind.Init(g_cfg.symbol, InpTimeframe, err))
     {
      Print("SGS INIT INDICATORS FAILED: ", err);
      g_rt.lastError = "indicators:" + err;
      SgsCleanupAll(REASON_INITFAILED);
      return(INIT_FAILED);
     }
   // 9) news filter
   g_news.Init();
   // 9b) strict closed-bar policy: NO signal evaluation on the attach bar.
   //     Seeding here makes the first possible entry wait for the CURRENT bar
   //     to fully close (SgsIsNewBar fires on the next bar transition only).
   g_lastBarTime = iTime(g_cfg.symbol, InpTimeframe, 0);
   if(g_journal.IsHealthy())
      g_journal.Append((int)JR_META_OPEN, (int)DUR_AUDIT, 0,
         "event=bar_seed_attach;bar=" + TimeToString(g_lastBarTime));
   // 10) risk counters from history
   g_risk.LoadPeakEquity();
   g_risk.RecountDaily();
   g_risk.RecountConsecutiveLosses();
   // 11) reconciliation BEFORE trading becomes possible
   CSgsState::Transition(SGS_RECONCILING, "init_reconcile");
   string rep = "";
   if(!g_reconcile.Run(rep))
     {
      Print("SGS RECONCILE FAILED: ", rep);
      g_rt.lastError = "reconcile:" + rep;
      if(g_rt.state != SGS_RECOVERY_REQUIRED)   // round-27: already there from the journal veto
         CSgsState::Transition(SGS_RECOVERY_REQUIRED, rep);
     }
   else
     {
      // journal integrity holds veto power: even with clean reconcile, no trading
      if(journalBlocked)
         Print("SGS stays in ", SgsStateName(g_rt.state),
               " (journal integrity); trading disabled until manual recovery");
      else
        {
         CSgsState::Transition(SGS_READY, "reconcile_ok");
         CSgsState::Transition(SGS_TRADING_ENABLED, "init_complete");
        }
     }
   // 12) timer + dashboard
   EventSetTimer(1);
   g_dash.Create();
   g_permReason = SgsPermissionText();
   g_initDone = true;
   g_rt.initOk = true;
   Print("SGS INIT OK state=", SgsStateName(g_rt.state),
         " symbol=", g_cfg.symbol,
         " instance=", g_rt.instanceId,
         " journal=", g_journal.ResolvedName());
   return(INIT_SUCCEEDED);
  }

//+------------------------------------------------------------------+
//| Expert deinitialization                                          |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
   if(g_initDone)
     {
      CSgsState::Transition(SGS_SHUTTING_DOWN, "deinit_reason_" + IntegerToString(reason));
     }
   SgsCleanupAll(reason);
   if(g_initDone) CSgsState::Transition(SGS_STOPPED, "stopped");
   g_initDone = false;
   g_rt.initOk = false;
  }

//+------------------------------------------------------------------+
//| New-bar detection helper (no future data: evaluation uses shift1)|
//+------------------------------------------------------------------+
bool SgsIsNewBar()
  {
   datetime cur = iTime(g_cfg.symbol, InpTimeframe, 0);
   if(cur == 0) return(false);
   if(cur != g_lastBarTime)
     {
      g_lastBarTime = cur;
      return(true);
     }
   return(false);
  }

//+------------------------------------------------------------------+
//| Tick handler                                                     |
//+------------------------------------------------------------------+
void OnTick()
  {
   if(!g_initDone) return;
   if(!g_sym.RefreshDynamic()) return;
   // equity/DD guards run even when not trading
   string gwhy = "";
   bool guardsOk = g_risk.TickGuards(gwhy);
   if(g_rt.hardGuardHit && InpCloseOnHardGuard && !g_emergencyDone)
     {
      if(TimeCurrent() - g_emergencyAt >= 1)           // bounded retry while any position remains
        {
         g_emergencyAt = TimeCurrent();
         g_trade.EmergencyCloseAll("hard_guard_total_dd");
         if(g_risk.CountOursOpen() == 0) g_emergencyDone = true;   // latched only when all closed
        }
     }
   // protective management of existing positions runs in ALL live states;
   // opposite-signal exits use only FRESH signals (handled after Evaluate)
   if(g_trade.ManagedCount() > 0)
      g_trade.ManagePositions(g_tech, 0);
   // entry evaluation only on a fresh closed bar and only when trading
   if(g_rt.state != SGS_TRADING_ENABLED || !guardsOk) return;
   if(!SgsIsNewBar()) return;
   if(!g_ind.Refresh(g_tech)) return;                 // history/indicator warmup gate
   if(InpUseSwingSRFilter || InpUseFvgFilter || InpUseMssFilter ||
      InpSlMode == SL_STRUCT || InpTrailMode == TRAIL_STRUCT ||
      InpUseSupplyDemandFilter || InpUseLiquidityFilter)
      g_engine.ComputeStructure(g_tech);        // memoized per closed bar; no double cost
   g_engine.Evaluate(g_tech, g_sym.SpreadPoints(), g_sig);
   if(InpUseOppositeSignalExit && g_trade.ManagedCount() > 0 &&
      (g_sig.dir == (int)SIGNAL_BUY || g_sig.dir == (int)SIGNAL_SELL))
      g_trade.ManagePositions(g_tech, g_sig.dir);    // exit-only pass: entry gates do NOT gate exits
   bool verbose = InpVerboseJournal;
   if(g_journal.IsHealthy() &&
      (g_sig.dir != (int)SIGNAL_NONE || verbose))
      g_journal.Append((int)JR_SIGNAL, (int)DUR_AUDIT, 0,
         StringFormat("bar=%I64d;dir=%s;buy=%d;sell=%d;conf=%.2f;gates=%s;rsn=%s",
            (long)g_sig.barTime, SgsDirText(g_sig.dir), g_sig.buyScore, g_sig.sellScore,
            g_sig.confidence, g_sig.gates, SgsReasonBitsToText(g_sig.reasons)));
   if(g_sig.dir == (int)SIGNAL_NONE || g_sig.dir == (int)SIGNAL_CONFLICT) return;
   // duplicate-signal suppression (same bar + same direction)
   if(InpOneTradePerBar && g_sig.barTime == g_lastEntryBarTime) return;
   if(g_sig.barTime == g_rt.lastSignalBarTime && g_sig.dir == g_rt.lastSignalDir) return;
   // signal cooldown
   if(InpSignalCooldownSec > 0 &&
      TimeCurrent() - g_rt.lastSignalTime < InpSignalCooldownSec) return;
   if(!g_sig.GatesAllPass()) return;
   // record signal consumption BEFORE opening (anti double-fire on this bar)
   g_rt.lastSignalBarTime = g_sig.barTime;
   g_rt.lastSignalDir = g_sig.dir;
   string why = "";
   bool wasInFlightDry = InpDryRun;
   bool ok = g_trade.OpenBySignal(g_sig.dir, g_tech, why);
   if(ok)
     {
      g_rt.lastSignalTime = TimeCurrent();
      g_rt.lastSignalConf = g_sig.confidence;
      g_lastEntryBarTime = g_sig.barTime;
      g_lastTradeDesc = SgsDirText(g_sig.dir) + (wasInFlightDry ? " DRY" : " OPEN") +
                        " @" + DoubleToString(g_sym.RefreshDynamic() ?
                           (g_sig.dir == (int)SIGNAL_BUY ? g_sym.Ask() : g_sym.Bid()) : 0.0,
                           g_sym.Digits());
     }
   else
     {
      g_rt.lastError = why;
      g_lastDenyReason = why;                          // surfaced on the dashboard (spec: reject reason)
      if(g_journal.IsHealthy())
         g_journal.Append((int)JR_RISK_EVENT, (int)DUR_STATE, 0,
            "event=entry_denied;dir=" + SgsDirText(g_sig.dir) + ";why=" + SgsKvEscape(why));
     }
  }

//+------------------------------------------------------------------+
//| Timer handler (1s): heartbeat, news, dashboard, rotation, timers |
//+------------------------------------------------------------------+
void OnTimer()
  {
   if(!g_initDone) return;
   // 1) lock heartbeat - losing ownership is a fault (fail-safe)
   if(g_rt.lockOwned)
     {
      if(!g_lock.Heartbeat())
        {
         g_rt.lockOwned = false;
         g_rt.lastError = "lock_lost";
         if(g_rt.state == SGS_TRADING_ENABLED || g_rt.state == SGS_PAUSED ||
            g_rt.state == SGS_READY)
            CSgsState::Transition(SGS_FAULTED, "lock_ownership_lost");
        }
     }
   // 2) day roll / auto-resume from daily-limit pauses
   if(SgsDayKey(TimeCurrent()) != g_rt.dayKey)
     {
      g_risk.RecountDaily();
      if(g_rt.state == SGS_PAUSED)
        {
         string w = "";
         if(g_risk.TickGuards(w) && !g_rt.hardGuardHit && g_rt.reconciled)
            CSgsState::Transition(SGS_TRADING_ENABLED, "new_day_auto_resume");
        }
     }
   // 3) news
   g_news.Refresh();
   // 4) guards also on timer (covers tick-less periods)
   string gw = "";
   g_risk.TickGuards(gw);
   // 5) journal rotation
   if(InpJournalEnabled && InpRotationEnabled && g_journal.IsHealthy() && g_journal.NeedsRotation())
     {
      string rerr = "";
      if(!g_journal.Rotate(rerr))
        {
         g_rt.lastError = "rotation:" + rerr;
         CSgsState::Transition(SGS_FAULTED, "rotation_failed:" + rerr);
        }
      else if(InpJournalSelfTestOnOpen)
        {
         string why2 = "";
         if(!g_journal.VerifyCrossGeneration(why2) && why2 != "archive_pruned_ok")
           {
            g_rt.lastError = "rotation_chain:" + why2;
            CSgsState::Transition(SGS_FAULTED, "rotation_chain_broken");
           }
        }
     }
   // 6) permission cache + dashboard (throttled)
   g_dashTickCounter++;
   if(g_dashTickCounter >= InpDashboardRefreshSec)
     {
      g_dashTickCounter = 0;
      g_permReason = SgsPermissionText();
      SGsDashData d;
      SgsFillDash(d);
      g_dash.Update(d);
      // round-25: confidence gauge drive (display-only; mirrors the last evaluated signal)
      double confNow = (g_sig.dir == (int)SIGNAL_BUY || g_sig.dir == (int)SIGNAL_SELL ?
                        g_sig.confidence : 0.0);
      g_dash.UpdateGauge(confNow, (confNow >= InpMinConfidence ? 1 :
                                   (confNow >= InpMinConfidence * 0.5 ? 2 : 0)));
      ChartRedraw(0);
     }
  }

//+------------------------------------------------------------------+
//| Trade transactions: routed to the trade manager, deal summary    |
//+------------------------------------------------------------------+
void OnTradeTransaction(const MqlTradeTransaction &trans,
                        const MqlTradeRequest &request,
                        const MqlTradeResult &result)
  {
   if(!g_initDone) return;
   g_trade.OnTradeTransaction(trans, request, result);
   if(trans.type == TRADE_TRANSACTION_DEAL_ADD && trans.deal > 0 && HistoryDealSelect(trans.deal))
     {
      if((long)HistoryDealGetInteger(trans.deal, DEAL_MAGIC) == InpMagicNumber &&
         HistoryDealGetString(trans.deal, DEAL_SYMBOL) == g_cfg.symbol)
        {
         long entry = HistoryDealGetInteger(trans.deal, DEAL_ENTRY);
         if(entry == DEAL_ENTRY_OUT || entry == DEAL_ENTRY_INOUT || entry == DEAL_ENTRY_OUT_BY)
           {
            double pnl = HistoryDealGetDouble(trans.deal, DEAL_PROFIT) +
                         HistoryDealGetDouble(trans.deal, DEAL_SWAP) +
                         HistoryDealGetDouble(trans.deal, DEAL_COMMISSION);
            g_lastTradeDesc = StringFormat("CLOSE pnl=%.2f", pnl);
           }
        }
     }
  }

//+------------------------------------------------------------------+
//| Chart events: dashboard show/hide toggle                         |
//+------------------------------------------------------------------+
void OnChartEvent(const int id, const long &lparam, const double &dparam, const string &sparam)
  {
   if(!g_initDone) return;
   if(id == CHARTEVENT_OBJECT_CLICK && g_dash.Created() && sparam == "SGSP_BTN")
      g_dash.Toggle();
  }
//+------------------------------------------------------------------+