//+------------------------------------------------------------------+
//|                                                  RobotBridge.mqh  |
//|   پُلِ ارسالِ سیگنالِ ربات‌های متاتریدر ۵ به «برنامهٔ تحلیل»       |
//|                                                                  |
//|  به‌جای ارسالِ مستقیمِ سفارش به کارگزار (OrderSend)، سفارش را به   |
//|  برنامه می‌فرستد؛ برنامه آن را با سیگنالِ داخلی و/یا هوش مصنوعی   |
//|  امتیازدهی می‌کند و تنها در صورتِ تأیید، عینِ همان مشخصات را به   |
//|  متاتریدر ارسال می‌کند.                                          |
//|                                                                  |
//|  === پیش‌نیازِ حیاتی: اجازهٔ WebRequest ===                        |
//|  در متاتریدر: Tools ▸ Options ▸ Expert Advisors ▸                |
//|  «Allow WebRequest for listed URL» را تیک بزنید و آدرسِ برنامه   |
//|  را دقیقاً اضافه کنید، مثلاً:  http://127.0.0.1:8000              |
//|  (بدونِ این کار WebRequest خطای 4014 می‌دهد.)                     |
//+------------------------------------------------------------------+
#property copyright "BTC Agent - Robot Signal Bridge"
#property strict

//--- کدهای بازگشتی (retcode) که در MqlTradeResult.retcode قرار می‌گیرند
#define BRIDGE_RETCODE_DONE       10009   // = TRADE_RETCODE_DONE : به متاتریدر ارسال شد
#define BRIDGE_RETCODE_ERROR      20000   // خطای شبکه/سرور/اعتبارسنجی
#define BRIDGE_RETCODE_REJECTED   20001   // توسطِ فیلترِ برنامه رد شد
#define BRIDGE_RETCODE_NOT_SENT   20002   // تأیید شد ولی ارسالِ خودکار خاموش/ناموفق بود

//+------------------------------------------------------------------+
//| نتیجهٔ ارسالِ یک سفارش به پُل                                     |
//+------------------------------------------------------------------+
struct BridgeResult
{
   bool     ok;          // آیا درخواست بدونِ خطا پردازش شد؟
   bool     approved;    // آیا فیلترِ برنامه سفارش را تأیید کرد؟
   bool     forwarded;   // آیا واقعاً به متاتریدر فرستاده شد؟
   int      http;        // کدِ وضعیتِ HTTP (یا -1 در خطای WebRequest)
   int      retcode;     // یکی از BRIDGE_RETCODE_*
   string   comment;     // توضیحِ متنی/خطا
   string   raw;         // پاسخِ خامِ JSON (برای عیب‌یابی)
};

//+------------------------------------------------------------------+
//| کلاسِ کلاینتِ پُل                                                 |
//+------------------------------------------------------------------+
class CRobotBridge
{
private:
   string   m_base_url;      // مثل http://127.0.0.1:8000
   string   m_secret;        // توکنِ امنیتیِ مشترک (اختیاری)
   int      m_timeout;       // مهلتِ درخواست (میلی‌ثانیه)

   //--- ابزارِ JSON --------------------------------------------------
   string   JsonEscape(const string s) const;
   string   NumToStr(const double v, const int digits) const;
   bool     JsonGetBool(const string js, const string key, const bool defv=false) const;
   string   JsonGetStr(const string js, const string key) const;

   //--- ارسالِ HTTP -------------------------------------------------
   bool     Post(const string path, const string body, BridgeResult &out);

public:
            CRobotBridge(void);
   void     Init(const string base_url, const string secret="", const int timeout_ms=10000);

   //--- تبدیلِ نوعِ سفارشِ MT5 به BUY/SELL
   static string DirFromType(const int order_type);
   //--- تبدیلِ دورهٔ نمودار به رشتهٔ تایم‌فریمِ برنامه (15m/1h/4h/1d/1w)
   static string TFfromPeriod(const ENUM_TIMEFRAMES period);

   //--- بررسیِ در دسترس بودنِ برنامه
   bool     Ping(void);

   //--- سبکِ ساده: ارسالِ یک سیگنال/سفارش
   BridgeResult Send(const string symbol,
                     const string direction,    // "BUY" یا "SELL"
                     const double volume,
                     const double sl=0.0,
                     const double tp=0.0,
                     const double entry=0.0,
                     const string tf="",
                     const string robot_id="",
                     const string comment="",
                     const long   magic=0,
                     const int    price_digits=-1,
                     const bool   test=false);

   //--- سبکِ ساده با سه حد سود
   BridgeResult SendMultiTP(const string symbol,
                            const string direction,
                            const double volume,
                            const double sl,
                            const double &tps[],       // آرایهٔ حد سودها
                            const double entry=0.0,
                            const string tf="",
                            const string robot_id="",
                            const string comment="",
                            const long   magic=0,
                            const int    price_digits=-1,
                            const bool   test=false);

   //--- جایگزینِ مستقیمِ OrderSend (کمترین تغییر در EAهای موجود)
   bool     OrderSendBridge(MqlTradeRequest &request,
                            MqlTradeResult &result,
                            const string tf="",
                            const bool   test=false);
};

//+------------------------------------------------------------------+
CRobotBridge::CRobotBridge(void)
{
   m_base_url = "http://127.0.0.1:8000";
   m_secret   = "";
   m_timeout  = 10000;
}

//+------------------------------------------------------------------+
void CRobotBridge::Init(const string base_url, const string secret, const int timeout_ms)
{
   m_base_url = base_url;
   // حذفِ اسلشِ انتهایی
   int n = StringLen(m_base_url);
   while(n>0 && StringGetCharacter(m_base_url, n-1)=='/')
   {
      m_base_url = StringSubstr(m_base_url, 0, n-1);
      n--;
   }
   m_secret  = secret;
   m_timeout = (timeout_ms>0 ? timeout_ms : 10000);
}

//+------------------------------------------------------------------+
//| تبدیلِ ENUM_ORDER_TYPE به BUY/SELL (زوج=خرید، فرد=فروش)          |
//+------------------------------------------------------------------+
string CRobotBridge::DirFromType(const int order_type)
{
   // 0 BUY,1 SELL,2 BUY_LIMIT,3 SELL_LIMIT,4 BUY_STOP,5 SELL_STOP,...
   return((order_type % 2)==0 ? "BUY" : "SELL");
}

//+------------------------------------------------------------------+
//| تبدیلِ دوره به رشتهٔ تایم‌فریمِ موردِ پذیرشِ برنامه               |
//+------------------------------------------------------------------+
string CRobotBridge::TFfromPeriod(const ENUM_TIMEFRAMES period)
{
   switch(period)
   {
      case PERIOD_M1:  return "1m";
      case PERIOD_M5:  return "5m";
      case PERIOD_M10: return "10m";
      case PERIOD_M15: return "15m";
      case PERIOD_M30: return "30m";
      case PERIOD_H1:  return "1h";
      case PERIOD_H2:  return "2h";
      case PERIOD_H4:  return "4h";
      case PERIOD_D1:  return "1d";
      case PERIOD_W1:  return "1w";
      default:         return "1h";   // پیش‌فرضِ امن (M2/M3/M6/M12/H3/H6/H8/MN1)
   }
}

//+------------------------------------------------------------------+
//| فرارِ کاراکترهای خاصِ رشته برای JSON                              |
//+------------------------------------------------------------------+
string CRobotBridge::JsonEscape(const string s) const
{
   string r = s;
   StringReplace(r, "\\", "\\\\");
   StringReplace(r, "\"", "\\\"");
   StringReplace(r, "\n", "\\n");
   StringReplace(r, "\r", "\\r");
   StringReplace(r, "\t", "\\t");
   return r;
}

//+------------------------------------------------------------------+
//| عدد به رشتهٔ JSON (با حذفِ صفرهای اضافی)                          |
//+------------------------------------------------------------------+
string CRobotBridge::NumToStr(const double v, const int digits) const
{
   int d = (digits>=0 ? digits : 8);
   string s = DoubleToString(v, d);
   // حذفِ صفرهای انتهاییِ اعشار برای تمیزی (اختیاری)
   if(StringFind(s, ".")>=0)
   {
      int len = StringLen(s);
      while(len>0 && StringGetCharacter(s, len-1)=='0'){ s=StringSubstr(s,0,len-1); len--; }
      if(len>0 && StringGetCharacter(s, len-1)=='.'){ s=StringSubstr(s,0,len-1); }
   }
   return s;
}

//+------------------------------------------------------------------+
//| خواندنِ مقدارِ بولین از JSON (اولین رخداد = سطحِ بالا)            |
//+------------------------------------------------------------------+
bool CRobotBridge::JsonGetBool(const string js, const string key, const bool defv) const
{
   int p = StringFind(js, "\""+key+"\"");
   if(p<0) return defv;
   int c = StringFind(js, ":", p+StringLen(key)+2);
   if(c<0) return defv;
   string rest = StringSubstr(js, c+1, 8);
   StringTrimLeft(rest);
   if(StringFind(rest, "true")==0)  return true;
   if(StringFind(rest, "false")==0) return false;
   return defv;
}

//+------------------------------------------------------------------+
//| خواندنِ مقدارِ رشته‌ای از JSON (ساده، برای فیلدِ error)           |
//+------------------------------------------------------------------+
string CRobotBridge::JsonGetStr(const string js, const string key) const
{
   int p = StringFind(js, "\""+key+"\"");
   if(p<0) return "";
   int c = StringFind(js, ":", p+StringLen(key)+2);
   if(c<0) return "";
   int q1 = StringFind(js, "\"", c+1);
   if(q1<0) return "";
   int q2 = StringFind(js, "\"", q1+1);
   if(q2<0) return "";
   return StringSubstr(js, q1+1, q2-q1-1);
}

//+------------------------------------------------------------------+
//| ارسالِ POST به برنامه و پُر کردنِ BridgeResult                    |
//+------------------------------------------------------------------+
bool CRobotBridge::Post(const string path, const string body, BridgeResult &out)
{
   out.ok=false; out.approved=false; out.forwarded=false;
   out.http=-1; out.retcode=BRIDGE_RETCODE_ERROR; out.comment=""; out.raw="";

   string url = m_base_url + path;

   //--- اصلاح (REM-NET-004): secret نباید روی HTTPِ بدونِ TLS به میزبانِ غیرلوکال
   //--- ارسال شود (خطرِ شنود/بازپخشِ X-Robot-Secret). HTTP فقط برای loopback مجاز است.
   bool loopback_http = (StringFind(m_base_url, "http://127.0.0.1:") == 0 ||
                         StringFind(m_base_url, "http://127.0.0.1/") == 0 ||
                         StringFind(m_base_url, "http://localhost:")  == 0 ||
                         StringFind(m_base_url, "http://localhost/")  == 0 ||
                         StringFind(m_base_url, "http://[::1]:")      == 0);
   if(StringLen(m_secret) > 0 && StringFind(m_base_url, "https://") != 0 && !loopback_http)
   {
      out.comment = "برای ارسالِ secret به میزبانِ غیرلوکال، HTTPS لازم است.";
      return false;
   }

   string headers = "Content-Type: application/json\r\n";
   if(StringLen(m_secret)>0)
      headers += "X-Robot-Secret: " + m_secret + "\r\n";

   //--- بدنه به آرایهٔ بایتِ UTF-8 (با حذفِ نال‌ترمیناتورِ انتهایی)
   char data[];
   int len = StringToCharArray(body, data, 0, WHOLE_ARRAY, CP_UTF8);
   if(len>0 && data[len-1]==0) ArrayResize(data, len-1);

   char     result[];
   string   result_headers;
   ResetLastError();
   int status = WebRequest("POST", url, headers, m_timeout, data, result, result_headers);

   if(status==-1)
   {
      int err = GetLastError();
      out.http=-1;
      out.retcode=BRIDGE_RETCODE_ERROR;
      if(err==4014)
         out.comment = "خطا 4014: آدرسِ «"+url+"» در فهرستِ WebRequestِ متاتریدر مجاز نیست. "
                       "از Tools ▸ Options ▸ Expert Advisors آن را اضافه کنید.";
      else
         out.comment = "WebRequest ناموفق (خطا "+IntegerToString(err)+"). "
                       "اتصال/آدرس/فعال بودنِ برنامه را بررسی کنید.";
      Print("[RobotBridge] ", out.comment);
      return false;
   }

   string resp = CharArrayToString(result, 0, WHOLE_ARRAY, CP_UTF8);
   out.http = status;
   out.raw  = resp;
   out.ok        = JsonGetBool(resp, "ok", false);
   out.approved  = JsonGetBool(resp, "approved", false);
   out.forwarded = JsonGetBool(resp, "forwarded", false);

   if(!out.ok)
   {
      out.retcode = BRIDGE_RETCODE_ERROR;
      out.comment = JsonGetStr(resp, "error");
      if(StringLen(out.comment)==0) out.comment = "خطای نامشخص (HTTP "+IntegerToString(status)+")";
   }
   else if(out.forwarded)
   {
      out.retcode = BRIDGE_RETCODE_DONE;
      out.comment = "به متاتریدر ارسال شد";
   }
   else if(out.approved)
   {
      out.retcode = BRIDGE_RETCODE_NOT_SENT;
      out.comment = "تأیید شد ولی به متاتریدر ارسال نشد (ارسالِ خودکار خاموش یا ارسال ناموفق)";
   }
   else
   {
      out.retcode = BRIDGE_RETCODE_REJECTED;
      out.comment = "توسطِ فیلترِ برنامه رد شد";
   }
   return out.ok;
}

//+------------------------------------------------------------------+
//| بررسیِ در دسترس بودنِ برنامه (GET /health)                        |
//+------------------------------------------------------------------+
bool CRobotBridge::Ping(void)
{
   char data[]; char result[]; string rh;
   ResetLastError();
   int st = WebRequest("GET", m_base_url+"/health", "", m_timeout, data, result, rh);
   return(st==200);
}

//+------------------------------------------------------------------+
//| سبکِ ساده: ارسالِ یک سیگنال                                      |
//+------------------------------------------------------------------+
BridgeResult CRobotBridge::Send(const string symbol, const string direction,
                                const double volume, const double sl, const double tp,
                                const double entry, const string tf,
                                const string robot_id, const string comment,
                                const long magic, const int price_digits, const bool test)
{
   BridgeResult res;
   int pd = (price_digits>=0 ? price_digits
             : (int)SymbolInfoInteger(symbol, SYMBOL_DIGITS));
   if(pd<=0) pd = 5;

   string j = "{";
   j += "\"platform\":\"mql5\",";     // ÙÙØ¹Ù Ø³Ú©Ù Ø¨Ø±Ø§Û ØªÙÚ©ÛÚ© Ø¯Ø± ÙØ§Ú¯Ù Ø³Ø±ÙØ±
   j += "\"symbol\":\""    + JsonEscape(symbol) + "\",";
   j += "\"direction\":\"" + JsonEscape(direction) + "\",";
   j += "\"volume\":"      + NumToStr(volume, 2);
   if(sl>0.0)    j += ",\"sl\":"    + NumToStr(sl, pd);
   if(tp>0.0)    j += ",\"tp\":"    + NumToStr(tp, pd);
   if(entry>0.0) j += ",\"entry\":" + NumToStr(entry, pd);
   if(StringLen(tf)>0)       j += ",\"tf\":\""       + JsonEscape(tf) + "\"";
   if(StringLen(robot_id)>0) j += ",\"robot_id\":\"" + JsonEscape(robot_id) + "\"";
   if(StringLen(comment)>0)  j += ",\"comment\":\""  + JsonEscape(comment) + "\"";
   if(magic!=0)              j += ",\"magic\":"      + IntegerToString(magic);
   j += "}";

   Post(test ? "/api/robot/test" : "/api/robot/order", j, res);
   return res;
}

//+------------------------------------------------------------------+
//| سبکِ ساده با چند حد سود                                          |
//+------------------------------------------------------------------+
BridgeResult CRobotBridge::SendMultiTP(const string symbol, const string direction,
                                       const double volume, const double sl,
                                       const double &tps[], const double entry,
                                       const string tf, const string robot_id,
                                       const string comment, const long magic,
                                       const int price_digits, const bool test)
{
   BridgeResult res;
   int pd = (price_digits>=0 ? price_digits
             : (int)SymbolInfoInteger(symbol, SYMBOL_DIGITS));
   if(pd<=0) pd = 5;

   string j = "{";
   j += "\"platform\":\"mql5\",";     // ÙÙØ¹Ù Ø³Ú©Ù Ø¨Ø±Ø§Û ØªÙÚ©ÛÚ© Ø¯Ø± ÙØ§Ú¯Ù Ø³Ø±ÙØ±
   j += "\"symbol\":\""    + JsonEscape(symbol) + "\",";
   j += "\"direction\":\"" + JsonEscape(direction) + "\",";
   j += "\"volume\":"      + NumToStr(volume, 2);
   if(sl>0.0) j += ",\"sl\":" + NumToStr(sl, pd);

   int cnt = ArraySize(tps);
   if(cnt>0)
   {
      j += ",\"take_profits\":[";
      for(int i=0;i<cnt;i++)
      {
         if(i>0) j += ",";
         j += NumToStr(tps[i], pd);
      }
      j += "]";
   }
   if(entry>0.0) j += ",\"entry\":" + NumToStr(entry, pd);
   if(StringLen(tf)>0)       j += ",\"tf\":\""       + JsonEscape(tf) + "\"";
   if(StringLen(robot_id)>0) j += ",\"robot_id\":\"" + JsonEscape(robot_id) + "\"";
   if(StringLen(comment)>0)  j += ",\"comment\":\""  + JsonEscape(comment) + "\"";
   if(magic!=0)              j += ",\"magic\":"      + IntegerToString(magic);
   j += "}";

   Post(test ? "/api/robot/test" : "/api/robot/order", j, res);
   return res;
}

//+------------------------------------------------------------------+
//| جایگزینِ مستقیمِ OrderSend                                        |
//|  در EAِ خود، «OrderSend(req,res)» را با                          |
//|  «bridge.OrderSendBridge(req,res)» عوض کنید.                     |
//|  خروجی: true اگر واقعاً به متاتریدر ارسال شده باشد؛              |
//|  result.retcode == 10009 (TRADE_RETCODE_DONE) در حالتِ موفق.     |
//+------------------------------------------------------------------+
bool CRobotBridge::OrderSendBridge(MqlTradeRequest &request, MqlTradeResult &result,
                                   const string tf, const bool test)
{
   ZeroMemory(result);
   string dir = DirFromType((int)request.type);
   BridgeResult br = Send(request.symbol, dir, request.volume,
                          request.sl, request.tp, request.price,
                          tf, IntegerToString(request.magic),
                          request.comment, (long)request.magic, -1, test);

   result.retcode = (uint)br.retcode;   // 10009 در موفقیت
   result.comment = br.comment;
   result.volume  = request.volume;
   result.price   = request.price;
   return br.forwarded;
}
//+------------------------------------------------------------------+
