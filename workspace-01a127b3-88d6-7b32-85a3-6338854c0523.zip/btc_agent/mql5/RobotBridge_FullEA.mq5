//+------------------------------------------------------------------+
//|                                          RobotBridge_FullEA.mq5   |
//|   نسخهٔ کاملِ خودبسنده (همه‌چیز در یک فایل — بدونِ نیاز به .mqh)   |
//|                                                                  |
//|   یک Expert Advisorِ کاملِ آمادهٔ کامپایل که:                     |
//|     • یک استراتژیِ نمونه (تقاطعِ EMA سریع/کند) دارد،             |
//|     • به‌جای OrderSendِ مستقیم، هر ورودی را به «برنامهٔ تحلیل»    |
//|       می‌فرستد تا با سیگنالِ داخلی و/یا هوش مصنوعی امتیاز بگیرد،  |
//|     • تنها در صورتِ تأیید، برنامه عیناً همان معامله را به         |
//|       متاتریدر ارسال می‌کند.                                     |
//|                                                                  |
//|   ★★ پیش‌نیازِ حیاتی: اجازهٔ WebRequest ★★                        |
//|   در متاتریدر:  Tools ▸ Options ▸ Expert Advisors ▸             |
//|   «Allow WebRequest for listed URL» را تیک بزنید و آدرسِ برنامه  |
//|   را دقیقاً اضافه کنید، مثلاً:  http://127.0.0.1:8000            |
//|   بدونِ این کار WebRequest خطای 4014 می‌دهد.                      |
//|   (WebRequest در «تسترِ استراتژی» کار نمی‌کند؛ روی چارتِ زنده    |
//|    اجرا کنید.)                                                    |
//+------------------------------------------------------------------+
#property copyright "BTC Agent - Robot Signal Bridge (Full EA)"
#property version   "1.10"
#property strict

//==================================================================//
//                         ۱) ورودی‌های EA                           //
//==================================================================//
//--- اتصال به برنامه
input string   InpBridgeURL      = "http://127.0.0.1:8000"; // آدرسِ برنامه
input string   InpSecret         = "";                       // توکنِ امنیتیِ مشترک (در صورتِ تنظیم در تب)
input int      InpTimeoutMs      = 10000;                    // مهلتِ درخواست (میلی‌ثانیه)
input bool     InpUseTestEndpoint= true;  // اصلاح (AUD-001): پیش‌فرضِ امن — برای معاملهٔ واقعی آگاهانه false کنید                    // ارسال به /api/robot/test (فقط آزمایش، بدونِ معاملهٔ واقعی)

//--- تنظیماتِ معامله
input double   InpVolume         = 0.10;   // حجم (لات) — عیناً همین به متاتریدر می‌رود
input long     InpMagic          = 234000; // عددِ مجیک / شناسهٔ ربات
input int      InpSLPips         = 300;    // فاصلهٔ استاپ (پیپ) — ۰ یعنی بدونِ استاپ
input int      InpTP1Pips        = 300;    // حد سودِ ۱ (پیپ)
input int      InpTP2Pips        = 600;    // حد سودِ ۲ (پیپ) — برای حالتِ چندهدفه
input int      InpTP3Pips        = 900;    // حد سودِ ۳ (پیپ) — برای حالتِ چندهدفه
input bool     InpUseMultiTP     = false;  // ارسالِ سه حد سود؟ (در غیر این صورت فقط TP1)

//--- استراتژیِ نمونه (تقاطعِ میانگینِ متحرک)
input int      InpFastMA         = 20;     // دورهٔ EMA سریع
input int      InpSlowMA         = 50;     // دورهٔ EMA کند
input bool     InpOneSignalPerBar= true;   // فقط یک سیگنال در هر کندل
input bool     InpBlockIfInPos   = true;   // اگر پوزیشنِ باز روی این نماد هست، سیگنالِ جدید نفرست
input string   InpTFOverride     = "";     // تایم‌فریمِ ارزیابی (خالی=خودکار از چارت): 15m/1h/4h/1d/1w

//==================================================================//
//              ۲) کدهای بازگشتی و ساختارِ نتیجهٔ پُل                 //
//==================================================================//
#define BRIDGE_RETCODE_DONE       10009   // = TRADE_RETCODE_DONE : به متاتریدر ارسال شد
#define BRIDGE_RETCODE_ERROR      20000   // خطای شبکه/سرور/اعتبارسنجی
#define BRIDGE_RETCODE_REJECTED   20001   // توسطِ فیلترِ برنامه رد شد
#define BRIDGE_RETCODE_NOT_SENT   20002   // تأیید شد ولی ارسالِ خودکار خاموش/ناموفق بود

struct BridgeResult
{
   bool     ok;          // آیا درخواست بدونِ خطا پردازش شد؟
   bool     approved;    // آیا فیلترِ برنامه سفارش را تأیید کرد؟
   bool     forwarded;   // آیا واقعاً به متاتریدر فرستاده شد؟
   int      http;        // کدِ HTTP (یا -1 در خطای WebRequest)
   int      retcode;     // یکی از BRIDGE_RETCODE_*
   string   comment;     // توضیح/خطا
   string   raw;         // پاسخِ خامِ JSON
};

//==================================================================//
//                 ۳) کلاسِ پُل (کاملاً تعبیه‌شده)                    //
//==================================================================//
class CRobotBridge
{
private:
   string   m_base_url;
   string   m_secret;
   int      m_timeout;

   string   JsonEscape(const string s) const
   {
      string r=s;
      StringReplace(r,"\\","\\\\");
      StringReplace(r,"\"","\\\"");
      StringReplace(r,"\n","\\n");
      StringReplace(r,"\r","\\r");
      StringReplace(r,"\t","\\t");
      return r;
   }

   string   NumToStr(const double v,const int digits) const
   {
      int d=(digits>=0?digits:8);
      string s=DoubleToString(v,d);
      if(StringFind(s,".")>=0)
      {
         int len=StringLen(s);
         while(len>0 && StringGetCharacter(s,len-1)=='0'){ s=StringSubstr(s,0,len-1); len--; }
         if(len>0 && StringGetCharacter(s,len-1)=='.') s=StringSubstr(s,0,len-1);
      }
      return s;
   }

   bool     JsonGetBool(const string js,const string key,const bool defv=false) const
   {
      int p=StringFind(js,"\""+key+"\"");
      if(p<0) return defv;
      int c=StringFind(js,":",p+StringLen(key)+2);
      if(c<0) return defv;
      string rest=StringSubstr(js,c+1,8);
      StringTrimLeft(rest);
      if(StringFind(rest,"true")==0)  return true;
      if(StringFind(rest,"false")==0) return false;
      return defv;
   }

   string   JsonGetStr(const string js,const string key) const
   {
      int p=StringFind(js,"\""+key+"\"");
      if(p<0) return "";
      int c=StringFind(js,":",p+StringLen(key)+2);
      if(c<0) return "";
      int q1=StringFind(js,"\"",c+1);
      if(q1<0) return "";
      int q2=StringFind(js,"\"",q1+1);
      if(q2<0) return "";
      return StringSubstr(js,q1+1,q2-q1-1);
   }

   bool     Post(const string path,const string body,BridgeResult &out)
   {
      out.ok=false; out.approved=false; out.forwarded=false;
      out.http=-1; out.retcode=BRIDGE_RETCODE_ERROR; out.comment=""; out.raw="";

      string url=m_base_url+path;

      //--- اصلاح (REM-NET-005): همان گاردِ RobotBridge.mqh؛ secret روی HTTPِ بدونِ TLS
      //--- فقط برای loopback مجاز است تا X-Robot-Secret شنود/بازپخش نشود.
      bool loopback_http=(StringFind(m_base_url,"http://127.0.0.1:")==0 ||
                          StringFind(m_base_url,"http://127.0.0.1/")==0 ||
                          StringFind(m_base_url,"http://localhost:")==0 ||
                          StringFind(m_base_url,"http://localhost/")==0 ||
                          StringFind(m_base_url,"http://[::1]:")==0);
      if(StringLen(m_secret)>0 && StringFind(m_base_url,"https://")!=0 && !loopback_http)
      {
         out.comment="برای ارسالِ secret به میزبانِ غیرلوکال، HTTPS لازم است.";
         return false;
      }

      string headers="Content-Type: application/json\r\n";
      if(StringLen(m_secret)>0) headers+="X-Robot-Secret: "+m_secret+"\r\n";

      char data[];
      int len=StringToCharArray(body,data,0,WHOLE_ARRAY,CP_UTF8);
      if(len>0 && data[len-1]==0) ArrayResize(data,len-1);

      char   result[];
      string result_headers;
      ResetLastError();
      int status=WebRequest("POST",url,headers,m_timeout,data,result,result_headers);

      if(status==-1)
      {
         int err=GetLastError();
         out.http=-1; out.retcode=BRIDGE_RETCODE_ERROR;
         if(err==4014)
            out.comment="خطا 4014: آدرسِ «"+url+"» در فهرستِ WebRequest مجاز نیست. "
                        "از Tools ▸ Options ▸ Expert Advisors اضافه کنید.";
         else
            out.comment="WebRequest ناموفق (خطا "+IntegerToString(err)+"). "
                        "اتصال/آدرس/فعال بودنِ برنامه را بررسی کنید.";
         Print("[RobotBridge] ",out.comment);
         return false;
      }

      string resp=CharArrayToString(result,0,WHOLE_ARRAY,CP_UTF8);
      out.http=status; out.raw=resp;
      out.ok        =JsonGetBool(resp,"ok",false);
      out.approved  =JsonGetBool(resp,"approved",false);
      out.forwarded =JsonGetBool(resp,"forwarded",false);

      if(!out.ok)
      {
         out.retcode=BRIDGE_RETCODE_ERROR;
         out.comment=JsonGetStr(resp,"error");
         if(StringLen(out.comment)==0) out.comment="خطای نامشخص (HTTP "+IntegerToString(status)+")";
      }
      else if(out.forwarded)
      {
         out.retcode=BRIDGE_RETCODE_DONE;
         out.comment="به متاتریدر ارسال شد";
      }
      else if(out.approved)
      {
         out.retcode=BRIDGE_RETCODE_NOT_SENT;
         out.comment="تأیید شد ولی به متاتریدر ارسال نشد (ارسالِ خودکار خاموش یا ارسال ناموفق)";
      }
      else
      {
         out.retcode=BRIDGE_RETCODE_REJECTED;
         out.comment="توسطِ فیلترِ برنامه رد شد";
      }
      return out.ok;
   }

public:
            CRobotBridge(void){ m_base_url="http://127.0.0.1:8000"; m_secret=""; m_timeout=10000; }

   void     Init(const string base_url,const string secret="",const int timeout_ms=10000)
   {
      m_base_url=base_url;
      int n=StringLen(m_base_url);
      while(n>0 && StringGetCharacter(m_base_url,n-1)=='/'){ m_base_url=StringSubstr(m_base_url,0,n-1); n--; }
      m_secret=secret;
      m_timeout=(timeout_ms>0?timeout_ms:10000);
   }

   static string DirFromType(const int order_type){ return((order_type%2)==0?"BUY":"SELL"); }

   static string TFfromPeriod(const ENUM_TIMEFRAMES period)
   {
      switch(period)
      {
         case PERIOD_M15: return "15m";
         case PERIOD_H1:  return "1h";
         case PERIOD_H4:  return "4h";
         case PERIOD_D1:  return "1d";
         case PERIOD_W1:  return "1w";
         default:         return "1h";
      }
   }

   bool     Ping(void)
   {
      char data[]; char result[]; string rh;
      ResetLastError();
      int st=WebRequest("GET",m_base_url+"/health","",m_timeout,data,result,rh);
      return(st==200);
   }

   BridgeResult Send(const string symbol,const string direction,const double volume,
                     const double sl=0.0,const double tp=0.0,const double entry=0.0,
                     const string tf="",const string robot_id="",const string comment="",
                     const long magic=0,const int price_digits=-1,const bool test=false)
   {
      BridgeResult res;
      int pd=(price_digits>=0?price_digits:(int)SymbolInfoInteger(symbol,SYMBOL_DIGITS));
      if(pd<=0) pd=5;
      string j="{";
      j+="\"symbol\":\""   +JsonEscape(symbol)+"\",";
      j+="\"direction\":\""+JsonEscape(direction)+"\",";
      j+="\"volume\":"     +NumToStr(volume,2);
      if(sl>0.0)    j+=",\"sl\":"    +NumToStr(sl,pd);
      if(tp>0.0)    j+=",\"tp\":"    +NumToStr(tp,pd);
      if(entry>0.0) j+=",\"entry\":" +NumToStr(entry,pd);
      if(StringLen(tf)>0)       j+=",\"tf\":\""      +JsonEscape(tf)+"\"";
      if(StringLen(robot_id)>0) j+=",\"robot_id\":\""+JsonEscape(robot_id)+"\"";
      if(StringLen(comment)>0)  j+=",\"comment\":\"" +JsonEscape(comment)+"\"";
      if(magic!=0)              j+=",\"magic\":"     +IntegerToString(magic);
      j+="}";
      Post(test?"/api/robot/test":"/api/robot/order",j,res);
      return res;
   }

   BridgeResult SendMultiTP(const string symbol,const string direction,const double volume,
                            const double sl,const double &tps[],const double entry=0.0,
                            const string tf="",const string robot_id="",const string comment="",
                            const long magic=0,const int price_digits=-1,const bool test=false)
   {
      BridgeResult res;
      int pd=(price_digits>=0?price_digits:(int)SymbolInfoInteger(symbol,SYMBOL_DIGITS));
      if(pd<=0) pd=5;
      string j="{";
      j+="\"symbol\":\""   +JsonEscape(symbol)+"\",";
      j+="\"direction\":\""+JsonEscape(direction)+"\",";
      j+="\"volume\":"     +NumToStr(volume,2);
      if(sl>0.0) j+=",\"sl\":"+NumToStr(sl,pd);
      int cnt=ArraySize(tps);
      if(cnt>0)
      {
         j+=",\"take_profits\":[";
         for(int i=0;i<cnt;i++){ if(i>0) j+=","; j+=NumToStr(tps[i],pd); }
         j+="]";
      }
      if(entry>0.0) j+=",\"entry\":"+NumToStr(entry,pd);
      if(StringLen(tf)>0)       j+=",\"tf\":\""      +JsonEscape(tf)+"\"";
      if(StringLen(robot_id)>0) j+=",\"robot_id\":\""+JsonEscape(robot_id)+"\"";
      if(StringLen(comment)>0)  j+=",\"comment\":\"" +JsonEscape(comment)+"\"";
      if(magic!=0)              j+=",\"magic\":"     +IntegerToString(magic);
      j+="}";
      Post(test?"/api/robot/test":"/api/robot/order",j,res);
      return res;
   }

   //--- جایگزینِ مستقیمِ OrderSend
   bool     OrderSendBridge(MqlTradeRequest &request,MqlTradeResult &result,
                            const string tf="",const bool test=false)
   {
      ZeroMemory(result);
      string dir=DirFromType((int)request.type);
      BridgeResult br=Send(request.symbol,dir,request.volume,request.sl,request.tp,
                           request.price,tf,IntegerToString((long)request.magic),
                           request.comment,(long)request.magic,-1,test);
      result.retcode=(uint)br.retcode;
      result.comment=br.comment;
      result.volume =request.volume;
      result.price  =request.price;
      return br.forwarded;
   }
};

//==================================================================//
//                    ۴) متغیرها و توابعِ کمکیِ EA                   //
//==================================================================//
CRobotBridge  bridge;
int           hFast=INVALID_HANDLE;   // هندلِ EMA سریع
int           hSlow=INVALID_HANDLE;   // هندلِ EMA کند
datetime      g_lastBarTime=0;        // برای تشخیصِ کندلِ جدید
int           g_lastSignal=0;         // آخرین سیگنال روی همین کندل: 0=هیچ،1=خرید،-1=فروش

//--- اندازهٔ یک پیپ بر اساس رقمِ اعشارِ نماد
double PipSize()
{
   int digits=(int)SymbolInfoInteger(_Symbol,SYMBOL_DIGITS);
   double point=SymbolInfoDouble(_Symbol,SYMBOL_POINT);
   return((digits==3 || digits==5) ? point*10.0 : point);
}

//--- آیا پوزیشنِ بازی با این مجیک روی این نماد وجود دارد؟
bool HasOpenPosition()
{
   for(int i=PositionsTotal()-1;i>=0;i--)
   {
      ulong ticket=PositionGetTicket(i);
      if(ticket==0) continue;
      if(PositionGetString(POSITION_SYMBOL)==_Symbol &&
         (long)PositionGetInteger(POSITION_MAGIC)==InpMagic)
         return true;
   }
   return false;
}

//--- چاپِ نتیجهٔ پُل در لاگ
void LogResult(const string title,const BridgeResult &r)
{
   PrintFormat("[%s] approved=%s forwarded=%s http=%d retcode=%d | %s",
               title,(r.approved?"true":"false"),(r.forwarded?"true":"false"),
               r.http,r.retcode,r.comment);
}

//--- ارسالِ یک سیگنال از طریقِ پُل (خرید/فروش) با محاسبهٔ SL/TP از پیپ
void RouteSignal(const string dir)
{
   string tf=(StringLen(InpTFOverride)>0 ? InpTFOverride
              : CRobotBridge::TFfromPeriod((ENUM_TIMEFRAMES)_Period));
   double pip=PipSize();
   int    dg =(int)SymbolInfoInteger(_Symbol,SYMBOL_DIGITS);
   double ask=SymbolInfoDouble(_Symbol,SYMBOL_ASK);
   double bid=SymbolInfoDouble(_Symbol,SYMBOL_BID);

   double sl=0.0, tp1=0.0, tp2=0.0, tp3=0.0;
   if(dir=="BUY")
   {
      if(InpSLPips>0)  sl =NormalizeDouble(ask-InpSLPips *pip,dg);
      if(InpTP1Pips>0) tp1=NormalizeDouble(ask+InpTP1Pips*pip,dg);
      if(InpTP2Pips>0) tp2=NormalizeDouble(ask+InpTP2Pips*pip,dg);
      if(InpTP3Pips>0) tp3=NormalizeDouble(ask+InpTP3Pips*pip,dg);
   }
   else // SELL
   {
      if(InpSLPips>0)  sl =NormalizeDouble(bid+InpSLPips *pip,dg);
      if(InpTP1Pips>0) tp1=NormalizeDouble(bid-InpTP1Pips*pip,dg);
      if(InpTP2Pips>0) tp2=NormalizeDouble(bid-InpTP2Pips*pip,dg);
      if(InpTP3Pips>0) tp3=NormalizeDouble(bid-InpTP3Pips*pip,dg);
   }

   BridgeResult r;
   if(InpUseMultiTP)
   {
      double tps[3]; tps[0]=tp1; tps[1]=tp2; tps[2]=tp3;
      r=bridge.SendMultiTP(_Symbol,dir,InpVolume,sl,tps,0.0,tf,
                           "FullEA-"+IntegerToString(InpMagic),
                           "EMA cross "+dir,InpMagic,dg,InpUseTestEndpoint);
   }
   else
   {
      r=bridge.Send(_Symbol,dir,InpVolume,sl,tp1,0.0,tf,
                    "FullEA-"+IntegerToString(InpMagic),
                    "EMA cross "+dir,InpMagic,dg,InpUseTestEndpoint);
   }

   LogResult("Route/"+dir,r);
   if(r.retcode==BRIDGE_RETCODE_DONE)
      PrintFormat("   ➜ سیگنالِ %s پس از تأییدِ برنامه به متاتریدر ارسال شد (vol=%.2f sl=%s tp=%s).",
                  dir,InpVolume,DoubleToString(sl,dg),DoubleToString(tp1,dg));
   else if(r.retcode==BRIDGE_RETCODE_REJECTED)
      Print("   ⛔ برنامه سیگنال را رد کرد (سیگنالِ داخلی/AI هم‌سو/کافی نبود).");
}

//==================================================================//
//                       ۵) رویدادهای EA                            //
//==================================================================//
int OnInit()
{
   // ساخت هندلِ اندیکاتورها
   hFast=iMA(_Symbol,_Period,InpFastMA,0,MODE_EMA,PRICE_CLOSE);
   hSlow=iMA(_Symbol,_Period,InpSlowMA,0,MODE_EMA,PRICE_CLOSE);
   if(hFast==INVALID_HANDLE || hSlow==INVALID_HANDLE)
   {
      Print("⛔ ساختِ هندلِ میانگینِ متحرک ناموفق بود.");
      return(INIT_FAILED);
   }

   bridge.Init(InpBridgeURL,InpSecret,InpTimeoutMs);

   if(bridge.Ping())
      Print("✅ اتصال به برنامه برقرار است: ",InpBridgeURL);
   else
   {
      Print("⚠️ برنامه پاسخ نداد یا آدرس در فهرستِ WebRequest مجاز نیست.");
      Print("   (۱) app.py در حال اجراست؟  (۲) آدرس در Tools ▸ Options ▸ Expert Advisors اضافه شده؟");
   }

   PrintFormat("RobotBridge FullEA آماده شد | نماد=%s تایم‌فریم=%s حجم=%.2f مجیک=%d حالت=%s",
               _Symbol,CRobotBridge::TFfromPeriod((ENUM_TIMEFRAMES)_Period),
               InpVolume,(int)InpMagic,(InpUseMultiTP?"MultiTP":"SingleTP"));
   return(INIT_SUCCEEDED);
}

void OnDeinit(const int reason)
{
   if(hFast!=INVALID_HANDLE) IndicatorRelease(hFast);
   if(hSlow!=INVALID_HANDLE) IndicatorRelease(hSlow);
}

void OnTick()
{
   // فقط روی کندلِ جدید تصمیم بگیر (کاهشِ نویز و درخواستِ اضافه)
   datetime t=iTime(_Symbol,_Period,0);
   bool newBar=(t!=g_lastBarTime);
   if(newBar){ g_lastBarTime=t; g_lastSignal=0; }
   if(!newBar && InpOneSignalPerBar) return;

   // خواندنِ EMAها روی کندل‌های بسته‌شده (شیفت ۱ و ۲)
   double fast[], slow[];
   ArraySetAsSeries(fast,true);
   ArraySetAsSeries(slow,true);
   if(CopyBuffer(hFast,0,0,3,fast)<3) return;
   if(CopyBuffer(hSlow,0,0,3,slow)<3) return;

   bool crossUp   =(fast[2]<=slow[2] && fast[1]>slow[1]);   // تقاطعِ صعودی
   bool crossDown =(fast[2]>=slow[2] && fast[1]<slow[1]);   // تقاطعِ نزولی
   if(!crossUp && !crossDown) return;

   // جلوگیری از ارسالِ تکراری روی همان کندل
   if(InpOneSignalPerBar && g_lastSignal!=0) return;

   // در صورتِ تنظیم، اگر پوزیشنِ باز داریم سیگنالِ جدید نفرست
   if(InpBlockIfInPos && HasOpenPosition())
   {
      Print("ℹ️ پوزیشنِ باز روی این نماد هست؛ سیگنالِ جدید ارسال نشد.");
      g_lastSignal=(crossUp?1:-1);
      return;
   }

   if(crossUp){  g_lastSignal=1;  RouteSignal("BUY");  }
   else       {  g_lastSignal=-1; RouteSignal("SELL"); }
}
//+------------------------------------------------------------------+
