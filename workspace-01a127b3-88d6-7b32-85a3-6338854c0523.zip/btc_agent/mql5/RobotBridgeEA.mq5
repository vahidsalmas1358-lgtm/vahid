//+------------------------------------------------------------------+
//|                                               RobotBridgeEA.mq5   |
//|   نمونهٔ Expert Advisor برای استفاده از «پُلِ سیگنالِ ربات‌ها».   |
//|                                                                  |
//|   این EA نشان می‌دهد چگونه به‌جای ارسالِ مستقیمِ سفارش به کارگزار،|
//|   آن را به «برنامهٔ تحلیل» بفرستید تا پس از تأییدِ سیگنالِ داخلی/ |
//|   هوش مصنوعی، عیناً به متاتریدر ارسال شود.                        |
//|                                                                  |
//|   ★ پیش‌نیاز: Tools ▸ Options ▸ Expert Advisors ▸               |
//|     «Allow WebRequest for listed URL» را تیک بزنید و آدرسِ       |
//|     برنامه (مثلاً http://127.0.0.1:8000) را اضافه کنید.          |
//|   ★ WebRequest در «تسترِ استراتژی» کار نمی‌کند؛ روی چارتِ زنده   |
//|     اجرا کنید.                                                    |
//+------------------------------------------------------------------+
#property copyright "BTC Agent"
#property version   "1.00"
#property strict

#include <RobotBridge.mqh>
//  اگر فایلِ .mqh را در پوشهٔ MQL5\Include گذاشته‌اید از < > استفاده کنید،
//  و اگر کنارِ همین EA (در MQL5\Experts) گذاشته‌اید از "RobotBridge.mqh".

//--- ورودی‌ها -------------------------------------------------------
input string InpBridgeURL   = "http://127.0.0.1:8000"; // آدرسِ برنامه
input string InpSecret      = "";                       // توکنِ امنیتیِ مشترک (در صورتِ تنظیم در تب)
input int    InpTimeoutMs   = 10000;                    // مهلتِ درخواست (میلی‌ثانیه)
input double InpVolume      = 0.10;                     // حجمِ نمونه (لات)
input long   InpMagic       = 234000;                   // عددِ مجیک/شناسهٔ ربات
input bool   InpSendTestOnInit = true;                  // هنگامِ راه‌اندازی یک سفارشِ آزمایشی بفرست؟
input bool   InpUseTestEndpoint = true;  // اصلاح (AUD-001): پیش‌فرضِ امن — برای معاملهٔ واقعی آگاهانه false کنید               // به /api/robot/test برود؟ (فقط آزمایش)

//--- شیءِ سراسریِ پُل
CRobotBridge bridge;

//+------------------------------------------------------------------+
//| کمک: چاپِ نتیجه در لاگ                                            |
//+------------------------------------------------------------------+
void PrintResult(const string title, const BridgeResult &r)
{
   PrintFormat("[%s] approved=%s forwarded=%s http=%d retcode=%d | %s",
               title,
               (r.approved ? "true":"false"),
               (r.forwarded? "true":"false"),
               r.http, r.retcode, r.comment);
}

//+------------------------------------------------------------------+
int OnInit()
{
   bridge.Init(InpBridgeURL, InpSecret, InpTimeoutMs);

   if(!bridge.Ping())
   {
      Print("⛔ برنامه در دسترس نیست یا آدرس در فهرستِ WebRequest مجاز نشده است.");
      Print("   بررسی کنید: (۱) app.py در حال اجراست؟ (۲) آدرس در Options ▸ Expert Advisors اضافه شده؟");
      // ادامه می‌دهیم تا کاربر خطای دقیق را در ارسال ببیند
   }
   else
      Print("✅ اتصال به برنامه برقرار است: ", InpBridgeURL);

   if(InpSendTestOnInit)
   {
      // --- نمونهٔ ۱: سبکِ ساده ---
      string tf = CRobotBridge::TFfromPeriod((ENUM_TIMEFRAMES)_Period);
      BridgeResult r1 = bridge.Send(_Symbol, "BUY", InpVolume,
                                    0.0, 0.0, 0.0,     // sl, tp, entry (۰ = ندارد)
                                    tf, "RobotBridgeEA", "demo buy",
                                    InpMagic, _Digits, InpUseTestEndpoint);
      PrintResult("Send/BUY", r1);
      if(r1.retcode==BRIDGE_RETCODE_DONE)
         Print("   ➜ سفارش پس از تأییدِ فیلتر به متاتریدر ارسال شد.");

      // --- نمونهٔ ۲: چند حد سود ---
      double tps[3];
      double ask = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
      double pt  = SymbolInfoDouble(_Symbol, SYMBOL_POINT);
      tps[0]=ask+500*pt; tps[1]=ask+1000*pt; tps[2]=ask+1500*pt;
      double sl = ask-500*pt;
      BridgeResult r2 = bridge.SendMultiTP(_Symbol, "BUY", InpVolume, sl, tps,
                                           0.0, tf, "RobotBridgeEA", "demo multi-tp",
                                           InpMagic, _Digits, InpUseTestEndpoint);
      PrintResult("SendMultiTP", r2);

      // --- نمونهٔ ۳: سبکِ سازگار با OrderSend (کمترین تغییر) ---
      MqlTradeRequest req; MqlTradeResult  res;
      ZeroMemory(req);
      req.action = TRADE_ACTION_DEAL;
      req.symbol = _Symbol;
      req.volume = InpVolume;
      req.type   = ORDER_TYPE_BUY;            // 0 = خرید
      req.price  = ask;
      req.sl     = sl;
      req.tp     = tps[0];
      req.magic  = InpMagic;
      req.comment= "demo order_send";

      // قبلاً:  bool ok = OrderSend(req, res);
      bool ok = bridge.OrderSendBridge(req, res, tf, InpUseTestEndpoint);
      PrintFormat("[OrderSendBridge] ok=%s retcode=%d | %s",
                  (ok?"true":"false"), res.retcode, res.comment);
      if(res.retcode==TRADE_RETCODE_DONE)   // 10009
         Print("   ➜ معادلِ موفقیتِ OrderSend: به متاتریدر ارسال شد.");
   }

   return(INIT_SUCCEEDED);
}

//+------------------------------------------------------------------+
void OnTick()
{
   //---------------------------------------------------------------
   //  الگوی استفاده در ربات‌های واقعیِ شما:
   //  هرجا قبلاً منطقِ ورود داشتید و OrderSend می‌زدید، به‌جایش
   //  یکی از این‌ها را صدا بزنید. برنامه فقط در صورتِ تأییدِ سیگنالِ
   //  داخلی/هوش مصنوعی معامله را واقعاً باز می‌کند.
   //
   //  مثال (شبه‌کد):
   //    if(MyBuyCondition())
   //    {
   //       string tf = CRobotBridge::TFfromPeriod((ENUM_TIMEFRAMES)_Period);
   //       double ask = SymbolInfoDouble(_Symbol,SYMBOL_ASK);
   //       double pt  = SymbolInfoDouble(_Symbol,SYMBOL_POINT);
   //       BridgeResult r = bridge.Send(_Symbol,"BUY",InpVolume,
   //                                    ask-300*pt, ask+600*pt, 0.0,
   //                                    tf,"MyEA","",InpMagic,_Digits);
   //       if(r.forwarded) Print("باز شد");
   //       else            Print("رد/نامعتبر: ", r.comment);
   //    }
   //---------------------------------------------------------------
}
//+------------------------------------------------------------------+
