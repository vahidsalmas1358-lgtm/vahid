//+------------------------------------------------------------------+
//|                                              MyEA_Template.mq5    |
//|   قالبِ آمادهٔ «اکسپرتِ خودِ شما» برای ارسالِ سیگنال به برنامه     |
//|                                                                  |
//|   شما فقط دو تابعِ زیر را با منطقِ خودتان پر می‌کنید:             |
//|        MyBuySignal()  → true اگر الان باید بخرید                 |
//|        MySellSignal() → true اگر الان باید بفروشید              |
//|   بقیهٔ کار (ساختِ سفارش، ارسال به برنامه، خواندنِ پاسخ) آماده است.|
//|                                                                  |
//|   ★ پیش‌نیازِ حیاتی: Tools ▸ Options ▸ Expert Advisors ▸        |
//|     «Allow WebRequest for listed URL» را تیک بزنید و آدرسِ       |
//|     برنامه را اضافه کنید (مثلاً http://127.0.0.1:8000).          |
//|   ★ دکمهٔ «Algo Trading» روشن باشد. WebRequest در تسترِ استراتژی  |
//|     کار نمی‌کند؛ روی چارتِ زنده اجرا کنید.                        |
//+------------------------------------------------------------------+
#property copyright "My EA - sends signals to BTC Agent"
#property version   "1.00"
#property strict

//  از کتابخانهٔ آمادهٔ همین پروژه استفاده می‌کنیم تا کدِ شبکه ننویسید.
//  RobotBridge.mqh را در پوشهٔ  MQL5\Include\  بگذارید (یا کنارِ همین EA و
//  آنگاه به‌جای < > از "RobotBridge.mqh" استفاده کنید).
#include <RobotBridge.mqh>

//==================================================================//
//                         ۱) ورودی‌ها                              //
//==================================================================//
input string InpBridgeURL   = "http://127.0.0.1:8000"; // آدرسِ برنامه
input string InpSecret      = "";                       // توکنِ مشترک (اگر تنظیم کرده‌اید)
input int    InpTimeoutMs   = 10000;                    // مهلتِ درخواست
input double InpVolume      = 0.10;                     // حجم (لات)
input long   InpMagic       = 555001;                   // شناسهٔ ربات
input int    InpSLPips      = 300;                      // فاصلهٔ استاپ (پیپ) — ۰ = بدونِ استاپ
input int    InpTP1Pips     = 300;                      // TP1 (پیپ)
input int    InpTP2Pips     = 600;                      // TP2 (پیپ)
input int    InpTP3Pips     = 900;                      // TP3 (پیپ)
input bool   InpUseMultiTP  = true;                     // سه حد سود بفرست؟ (وگرنه فقط TP1)
input bool   InpOnePerBar   = true;                     // فقط یک سیگنال در هر کندل
input bool   InpUseTestEndpoint = true;                 // true = فقط آزمایش (بدونِ معاملهٔ واقعی)

//==================================================================//
//                     ۲) شیءِ پُل و متغیرها                         //
//==================================================================//
CRobotBridge bridge;
datetime     g_lastBar = 0;

//==================================================================//
//         ۳) ★★★ منطقِ استراتژیِ شما اینجاست ★★★                   //
//   فقط این دو تابع را با شرط‌های خودتان پر کنید. true یعنی سیگنال. //
//==================================================================//
bool MyBuySignal()
{
   //  ── نمونه (شبه‌کد) — حذف و منطقِ خودتان را بنویسید: ──────────────
   //   double ma_fast[], ma_slow[];  // مقادیرِ اندیکاتورِ خودتان
   //   ...
   //   return (ma_fast[1] > ma_slow[1] && ma_fast[2] <= ma_slow[2]); // تقاطعِ صعودی
   //  ────────────────────────────────────────────────────────────────
   return false;   // پیش‌فرض: بدونِ سیگنالِ خرید. (این را عوض کنید.)
}

bool MySellSignal()
{
   //  نمونه:
   //   return (ma_fast[1] < ma_slow[1] && ma_fast[2] >= ma_slow[2]); // تقاطعِ نزولی
   return false;   // پیش‌فرض: بدونِ سیگنالِ فروش. (این را عوض کنید.)
}

//==================================================================//
//             ۴) موتورِ آماده — نیازی به تغییر نیست               //
//==================================================================//
double PipSize()
{
   int digits = (int)SymbolInfoInteger(_Symbol, SYMBOL_DIGITS);
   double point = SymbolInfoDouble(_Symbol, SYMBOL_POINT);
   return((digits==3 || digits==5) ? point*10.0 : point);
}

//  یک سیگنال را می‌سازد و از طریقِ پُل به برنامه می‌فرستد
void RouteSignal(const string dir)   // dir = "BUY" یا "SELL"
{
   string tf = CRobotBridge::TFfromPeriod((ENUM_TIMEFRAMES)_Period);
   double pip = PipSize();
   int    dg  = (int)SymbolInfoInteger(_Symbol, SYMBOL_DIGITS);
   double ask = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
   double bid = SymbolInfoDouble(_Symbol, SYMBOL_BID);

   double sl=0.0, tp1=0.0, tp2=0.0, tp3=0.0;
   if(dir=="BUY")
   {
      if(InpSLPips>0)  sl =NormalizeDouble(ask-InpSLPips *pip, dg);
      if(InpTP1Pips>0) tp1=NormalizeDouble(ask+InpTP1Pips*pip, dg);
      if(InpTP2Pips>0) tp2=NormalizeDouble(ask+InpTP2Pips*pip, dg);
      if(InpTP3Pips>0) tp3=NormalizeDouble(ask+InpTP3Pips*pip, dg);
   }
   else
   {
      if(InpSLPips>0)  sl =NormalizeDouble(bid+InpSLPips *pip, dg);
      if(InpTP1Pips>0) tp1=NormalizeDouble(bid-InpTP1Pips*pip, dg);
      if(InpTP2Pips>0) tp2=NormalizeDouble(bid-InpTP2Pips*pip, dg);
      if(InpTP3Pips>0) tp3=NormalizeDouble(bid-InpTP3Pips*pip, dg);
   }

   BridgeResult r;
   if(InpUseMultiTP)
   {
      double tps[3]; tps[0]=tp1; tps[1]=tp2; tps[2]=tp3;
      r = bridge.SendMultiTP(_Symbol, dir, InpVolume, sl, tps, 0.0, tf,
                             "MyEA-"+IntegerToString(InpMagic), "my signal "+dir,
                             InpMagic, dg, InpUseTestEndpoint);
   }
   else
   {
      r = bridge.Send(_Symbol, dir, InpVolume, sl, tp1, 0.0, tf,
                      "MyEA-"+IntegerToString(InpMagic), "my signal "+dir,
                      InpMagic, dg, InpUseTestEndpoint);
   }

   PrintFormat("[MyEA/%s] approved=%s forwarded=%s retcode=%d | %s",
               dir, (r.approved?"true":"false"), (r.forwarded?"true":"false"),
               r.retcode, r.comment);
   if(r.retcode==BRIDGE_RETCODE_DONE)
      Print("   ➜ پس از تأییدِ برنامه به متاتریدر ارسال شد.");
   else if(r.retcode==BRIDGE_RETCODE_REJECTED)
      Print("   ⛔ برنامه سیگنال را رد کرد.");
}

//==================================================================//
//                       ۵) رویدادهای EA                            //
//==================================================================//
int OnInit()
{
   bridge.Init(InpBridgeURL, InpSecret, InpTimeoutMs);
   if(bridge.Ping())
      Print("✅ اتصال به برنامه برقرار است: ", InpBridgeURL);
   else
      Print("⚠️ برنامه پاسخ نداد یا آدرس در فهرستِ WebRequest مجاز نیست.");
   PrintFormat("MyEA آماده شد | نماد=%s حجم=%.2f مجیک=%d حالتِ آزمایش=%s",
               _Symbol, InpVolume, (int)InpMagic, (InpUseTestEndpoint?"true":"false"));
   return(INIT_SUCCEEDED);
}

void OnTick()
{
   // فقط روی کندلِ جدید تصمیم بگیر (اختیاری ولی توصیه‌شده)
   datetime t = iTime(_Symbol, _Period, 0);
   bool newBar = (t != g_lastBar);
   if(newBar) g_lastBar = t;
   if(InpOnePerBar && !newBar) return;

   // ← منطقِ شما فراخوانی می‌شود:
   if(MyBuySignal())       RouteSignal("BUY");
   else if(MySellSignal()) RouteSignal("SELL");
}
//+------------------------------------------------------------------+
