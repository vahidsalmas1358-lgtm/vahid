"""زمان‌بندیِ فعال/غیرفعال بودنِ کلِ برنامه بر اساسِ «ساعتِ سرورِ کارگزار».

کاربر می‌تواند تا دو بازهٔ کاری در شبانه‌روز تعریف کند (۴ ورودیِ ساعت‌ودقیقهٔ مجزا:
شروعِ۱/پایانِ۱ و شروعِ۲/پایانِ۲). وقتی زمان‌بندی فعال باشد، برنامه فقط در داخلِ این
بازه‌ها اجازهٔ ارسالِ معامله (ربات‌ها، ارسالِ خودکار و ارسالِ دستی) را می‌دهد.

زمان‌ها بر مبنای ساعتِ سرور (همان چیزی که در Market Watch متاتریدر دیده می‌شود) هستند.
این ماژول «خالص» است و به متاتریدر وابسته نیست؛ فقط با «دقیقهٔ روز» کار می‌کند.
"""
from __future__ import annotations
import os
import json
import threading

CONFIG_PATH = os.path.join(os.path.dirname(__file__), "schedule_config.json")
_lock = threading.RLock()


def _default_config() -> dict:
    return {
        "enabled": False,   # آیا زمان‌بندی اعمال شود؟
        "on1": "",          # شروعِ بازهٔ ۱  "HH:MM"
        "off1": "",         # پایانِ بازهٔ ۱ "HH:MM"
        "on2": "",          # شروعِ بازهٔ ۲  "HH:MM"
        "off2": "",         # پایانِ بازهٔ ۲ "HH:MM"
    }


def load_config() -> dict:
    cfg = _default_config()
    if os.path.exists(CONFIG_PATH):
        try:
            with open(CONFIG_PATH, encoding="utf-8") as f:
                saved = json.load(f)
            # اصلاح (SCHEDULE-001): فایلِ غیرdict نباید load_config/_program_gate را بشکند.
            if isinstance(saved, dict):
                cfg.update(saved)
        except Exception:  # noqa
            pass
    return cfg


def save_config(patch: dict) -> dict:
    cfg = load_config()
    for k, v in (patch or {}).items():
        if k == "enabled":
            # اصلاح (هم‌خانوادهٔ DISP-001): bool("false") == True
            cfg[k] = (v.strip().lower() not in ("", "0", "false", "no", "off", "none")
                      if isinstance(v, str) else bool(v))
        elif k in ("on1", "off1", "on2", "off2"):
            cfg[k] = _norm_hhmm(v)
    with _lock:
        with open(CONFIG_PATH, "w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False, indent=2)
    return cfg


def _norm_hhmm(v) -> str:
    """ورودی را به قالبِ استانداردِ "HH:MM" تبدیل می‌کند؛ نامعتبر → رشتهٔ خالی."""
    m = to_minutes(v)
    if m is None:
        return ""
    return f"{m // 60:02d}:{m % 60:02d}"


def to_minutes(v):
    """«HH:MM» یا دیکشنری {h,m} را به دقیقهٔ روز (0..1439) تبدیل می‌کند، وگرنه None."""
    if v is None or v == "":
        return None
    try:
        if isinstance(v, dict):
            h = int(v.get("h", v.get("hour", 0)))
            m = int(v.get("m", v.get("min", v.get("minute", 0))))
        else:
            s = str(v).strip()
            if ":" in s:
                parts = s.split(":")
                h = int(parts[0]); m = int(parts[1])
            else:
                # عددِ خام را ساعت فرض می‌کنیم
                h = int(float(s)); m = 0
    except Exception:  # noqa
        return None
    if not (0 <= h <= 23 and 0 <= m <= 59):
        return None
    return h * 60 + m


def _window_active(minute: int, on_min, off_min) -> bool:
    """آیا دقیقهٔ فعلی در بازهٔ [on, off) است؟ (پشتیبانی از بازهٔ شب‌گذر)."""
    if on_min is None or off_min is None:
        return False
    if on_min == off_min:
        return False  # بازهٔ صفر → نادیده
    if on_min < off_min:
        return on_min <= minute < off_min
    # بازهٔ شب‌گذر (مثلاً 22:00 تا 06:00)
    return minute >= on_min or minute < off_min


def is_active(minute_of_day: int, cfg: dict = None) -> dict:
    """آیا برنامه در «این دقیقهٔ روز» (ساعتِ سرور) باید فعال باشد؟

    خروجی: {enabled, active, matched (1|2|None), windows, has_windows}
    """
    cfg = cfg or load_config()
    windows = []
    w1 = (to_minutes(cfg.get("on1")), to_minutes(cfg.get("off1")))
    w2 = (to_minutes(cfg.get("on2")), to_minutes(cfg.get("off2")))
    for w in (w1, w2):
        if w[0] is not None and w[1] is not None and w[0] != w[1]:
            windows.append(w)

    if not cfg.get("enabled"):
        return {"enabled": False, "active": True, "matched": None,
                "windows": windows, "has_windows": bool(windows),
                "reason": "زمان‌بندی غیرفعال است (برنامه همیشه فعال)."}

    if not windows:
        # فعال است ولی هیچ بازهٔ معتبری تعریف نشده → چیزی برای محدودسازی نیست
        return {"enabled": True, "active": True, "matched": None,
                "windows": windows, "has_windows": False,
                "reason": "زمان‌بندی فعال است اما هیچ بازهٔ معتبری تعریف نشده."}

    m = int(minute_of_day) % 1440
    matched = None
    if _window_active(m, to_minutes(cfg.get("on1")), to_minutes(cfg.get("off1"))):
        matched = 1
    elif _window_active(m, to_minutes(cfg.get("on2")), to_minutes(cfg.get("off2"))):
        matched = 2

    active = matched is not None
    reason = (f"داخلِ بازهٔ کاریِ {matched}." if active
              else "خارج از بازه‌های کاریِ تعریف‌شده — ارسالِ معامله متوقف است.")
    return {"enabled": True, "active": active, "matched": matched,
            "windows": windows, "has_windows": True, "reason": reason}
