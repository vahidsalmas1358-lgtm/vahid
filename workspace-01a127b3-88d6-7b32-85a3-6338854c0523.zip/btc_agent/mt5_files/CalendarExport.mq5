//+------------------------------------------------------------------+
//|                                              CalendarExport.mq5   |
//|   سرویسِ صدور «تقویمِ اقتصادیِ خودِ متاتریدر ۵» به فایلِ JSON       |
//|                                                                  |
//|   چه می‌کند؟                                                       |
//|   توابعِ تقویمِ MQL5 (CalendarValueHistory/…) را می‌خواند و رویدادها |
//|   را در فایلِ  Common\Files\mt5_calendar.json  می‌ریزد تا برنامهٔ    |
//|   تحلیلِ پایتون آن را به‌عنوانِ «منبعِ اصلیِ اخبار» بخواند (به‌جای    |
//|   Forex Factory / TradingView).                                   |
//|                                                                  |
//|   نصب و اجرا:                                                      |
//|   ۱) این فایل را در MetaEditor باز کنید (منوی MT5 → IDE).          |
//|   ۲) F7 بزنید تا کامپایل شود (CalendarExport.ex5 ساخته می‌شود).    |
//|   ۳) در پنجرهٔ Navigator زیرِ «Services» روی CalendarExport         |
//|      راست‌کلیک → Add Service → OK. سرویس در پس‌زمینه اجرا می‌شود.   |
//|   ۴) همین بس! هر ۵ دقیقه فایلِ تقویم به‌روز می‌شود.                  |
//|                                                                  |
//|   نکته: توابعِ تقویم فقط با اتصالِ زندهٔ ترمینال کار می‌کنند و در    |
//|   Strategy Tester خروجی نمی‌دهند.                                  |
//+------------------------------------------------------------------+
#property service
#property copyright "MultiMarket Analysis Agent"
#property version   "1.00"

// ── ورودی‌ها (قابلِ تنظیم هنگامِ افزودنِ سرویس) ──
input int    RefreshMinutes = 5;      // فاصلهٔ به‌روزرسانی (دقیقه)
input int    DaysBack       = 7;      // چند روزِ گذشته
input int    DaysAhead      = 30;     // چند روزِ آینده
input string FileName       = "mt5_calendar.json"; // نامِ فایل در Common\Files
input string Countries      = "US,EU,GB,JP,AU,CA,CH,NZ,CN,DE,FR"; // کشورها (خالی = همه)

//+------------------------------------------------------------------+
//| نگاشتِ اهمیت → برچسب و رتبه (سازگار با برنامهٔ پایتون)             |
//+------------------------------------------------------------------+
void ImpactToText(ENUM_CALENDAR_EVENT_IMPORTANCE imp, string &label, int &rank)
{
   switch(imp)
   {
      case CALENDAR_IMPORTANCE_HIGH:     label="High";    rank=3; break;
      case CALENDAR_IMPORTANCE_MODERATE: label="Medium";  rank=2; break;
      case CALENDAR_IMPORTANCE_LOW:      label="Low";     rank=1; break;
      default:                           label="Holiday"; rank=0; break;
   }
}

//+------------------------------------------------------------------+
//| فرمت‌کردنِ مقدارِ عددیِ رویداد (با احترام به واحد/ضریب/اعشار)        |
//+------------------------------------------------------------------+
string FormatValue(double v, const MqlCalendarEvent &ev)
{
   if(!MathIsValidNumber(v))
      return "";
   // ضریب (هزار/میلیون/…)
   string suffix="";
   switch(ev.multiplier)
   {
      case CALENDAR_MULTIPLIER_THOUSANDS: suffix="K"; break;
      case CALENDAR_MULTIPLIER_MILLIONS:  suffix="M"; break;
      case CALENDAR_MULTIPLIER_BILLIONS:  suffix="B"; break;
      case CALENDAR_MULTIPLIER_TRILLIONS: suffix="T"; break;
      default: suffix=""; break;
   }
   string s=DoubleToString(v, ev.digits);
   s=s+suffix;
   // واحد (درصد و…)
   if(ev.unit==CALENDAR_UNIT_PERCENT) s=s+"%";
   return s;
}

//+------------------------------------------------------------------+
//| فرارِ کاراکترهای ویژه برای رشتهٔ JSON                              |
//+------------------------------------------------------------------+
string JsonEscape(string s)
{
   string out="";
   int n=StringLen(s);
   for(int i=0;i<n;i++)
   {
      ushort c=StringGetCharacter(s,i);
      if(c=='"')       out+="\\\"";
      else if(c=='\\') out+="\\\\";
      else if(c=='\n') out+="\\n";
      else if(c=='\r') out+="\\r";
      else if(c=='\t') out+="\\t";
      else             out+=ShortToString(c);
   }
   return out;
}

//+------------------------------------------------------------------+
//| ساخت و نوشتنِ فایلِ تقویم                                          |
//+------------------------------------------------------------------+
bool BuildAndWrite()
{
   datetime from = TimeTradeServer() - (datetime)DaysBack  * 86400;
   datetime to   = TimeTradeServer() + (datetime)DaysAhead * 86400;

   // اختلافِ زمانِ سرور با UTC/GMT برای تبدیلِ زمانِ رویدادها به epochِ UTC
   long gmt_offset = (long)TimeGMT() - (long)TimeTradeServer();

   // کشورهای موردنظر
   string cc[];
   int ccn = 0;
   if(StringLen(Countries) > 0)
      ccn = StringSplit(Countries, ',', cc);

   string body = "";
   int total = 0;

   // اگر لیستِ کشور تهی بود، یک بار با فیلترِ NULL همهٔ رویدادها را می‌گیریم
   int passes = (ccn > 0) ? ccn : 1;

   for(int p=0; p<passes; p++)
   {
      string country_code = (ccn > 0) ? cc[p] : NULL;
      MqlCalendarValue values[];
      int got = CalendarValueHistory(values, from, to, country_code, NULL);
      if(got <= 0)
         continue;

      for(int i=0; i<got; i++)
      {
         MqlCalendarEvent ev;
         if(!CalendarEventById(values[i].event_id, ev))
            continue;
         MqlCalendarCountry cn;
         CalendarCountryById(ev.country_id, cn);

         string label; int rank;
         ImpactToText(ev.importance, label, rank);

         long utc_ts = (long)values[i].time + gmt_offset;

         string fc = FormatValue(values[i].GetForecastValue(), ev);
         string pv = FormatValue(values[i].GetPreviousValue(), ev);
         string ac = FormatValue(values[i].GetActualValue(),   ev);

         if(total > 0) body += ",";
         body += "\n  {";
         body += "\"title\":\""    + JsonEscape(ev.name)      + "\",";
         body += "\"currency\":\"" + JsonEscape(cn.currency)  + "\",";
         body += "\"country\":\""  + JsonEscape(cn.code)      + "\",";
         body += "\"impact\":\""   + label                    + "\",";
         body += "\"impact_rank\":"+ IntegerToString(rank)    + ",";
         body += "\"forecast\":\"" + JsonEscape(fc)           + "\",";
         body += "\"previous\":\"" + JsonEscape(pv)           + "\",";
         body += "\"actual\":\""   + JsonEscape(ac)           + "\",";
         body += "\"ts\":"         + IntegerToString(utc_ts);
         body += "}";
         total++;
      }
   }

   long now_utc = (long)TimeGMT();
   string json = "{\n";
   json += "\"generated_ts\":" + IntegerToString(now_utc) + ",\n";
   json += "\"source\":\"MetaTrader5\",\n";
   json += "\"count\":" + IntegerToString(total) + ",\n";
   json += "\"events\":[" + body + "\n]\n}\n";

   // FILE_COMMON → پوشهٔ مشترکِ همهٔ ترمینال‌ها که پایتون هم آن را می‌خواند
   // CP_UTF8 → خروجی حتماً UTF-8 باشد (پایتون فایل را UTF-8 می‌خواند؛ بدونِ این،
   // نام‌های دارای حروفِ غیرانگلیسی مثل «Geschäftsklima» فایل را خراب می‌کنند)
   int h = FileOpen(FileName, FILE_WRITE|FILE_TXT|FILE_ANSI|FILE_COMMON, '\t', CP_UTF8);
   if(h == INVALID_HANDLE)
   {
      PrintFormat("CalendarExport: خطا در بازکردنِ فایل %s (err=%d)", FileName, GetLastError());
      return false;
   }
   FileWriteString(h, json);
   FileClose(h);
   PrintFormat("CalendarExport: %d رویداد در %s نوشته شد.", total, FileName);
   return true;
}

//+------------------------------------------------------------------+
//| نقطهٔ ورودِ سرویس                                                  |
//+------------------------------------------------------------------+
void OnStart()
{
   int wait_ms = MathMax(1, RefreshMinutes) * 60 * 1000;
   // چند تلاشِ اولیه چون پس از استارتِ ترمینال، تقویم بلافاصله آماده نیست
   while(!IsStopped())
   {
      bool ok = BuildAndWrite();
      if(!ok)
      {
         // اگر داده هنوز آماده نبود، کمی صبر و دوباره
         for(int s=0; s<30 && !IsStopped(); s++) Sleep(1000);
      }
      // خوابِ اصلی تا دورِ بعد (با احترام به توقفِ سرویس)
      int slept = 0;
      while(slept < wait_ms && !IsStopped())
      {
         Sleep(1000);
         slept += 1000;
      }
   }
}
//+------------------------------------------------------------------+
