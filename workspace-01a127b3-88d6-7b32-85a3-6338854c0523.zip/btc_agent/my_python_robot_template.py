# -*- coding: utf-8 -*-
"""
my_python_robot_template.py  —  قالبِ آمادهٔ «رباتِ پایتونیِ خودِ شما»
====================================================================

این فایل یک «اسکلتِ آماده» است تا رباتِ پایتونیِ خودتان را طوری بنویسید که
سیگنالِ خرید/فروش را به «برنامهٔ تحلیل» بفرستد. برنامه سیگنال را با سیگنالِ داخلی
و/یا هوش مصنوعی امتیاز می‌دهد و تنها در صورتِ تأیید، عیناً به متاتریدر ارسال می‌کند.

شما فقط باید یک کار انجام دهید:
    ▶ داخلِ تابعِ  my_strategy(...)  منطقِ خودتان را بنویسید و "BUY" یا "SELL"
      (یا None برای «هیچ سیگنالی») برگردانید. تمام!

بقیهٔ کارها (اتصال، ارسال، تلاشِ مجدد، خواندنِ پاسخ) آماده است.

اجرا:
    pip install requests
    python my_python_robot_template.py

نکته: تا وقتی USE_TEST_ENDPOINT = True است، هیچ معاملهٔ واقعی‌ای باز نمی‌شود
(فقط مسیرِ آزمایشی صدا زده می‌شود). وقتی مطمئن شدید، آن را False کنید.
"""

from __future__ import annotations
import time

# از کلاینتِ آمادهٔ همین پروژه استفاده می‌کنیم (نیازی به نوشتنِ کدِ شبکه نیست):
# اتصالِ محلی — همه‌چیز روی یک کامپیوتر (localhost):
from robot_client_example import RobotBridge


# ─────────────────────────────────────────────────────────────────────────────
#  ۱) تنظیماتِ اتصال  (این‌ها را مطابقِ خودتان تغییر دهید)
# ─────────────────────────────────────────────────────────────────────────────
BASE_URL   = "http://127.0.0.1:8000"   # آدرسِ برنامه (همه‌چیز روی یک کامپیوتر)
SECRET     = ""                        # توکنِ مشترک (اگر در تبِ برنامه تنظیم کرده‌اید)
SYMBOL     = "XAUUSD"                   # نمادِ کارگزارِ شما (یا نمادِ داخلی مثل "BTC")
VOLUME     = 0.10                       # حجم (لات) — عیناً همین به متاتریدر می‌رود
TIMEFRAME  = "1h"                       # تایم‌فریمِ ارزیابیِ برنامه: 1m/5m/10m/15m/30m/1h/2h/4h/1d/1w
ROBOT_ID   = "MyPythonBot"             # یک نامِ دلخواه برای شناساییِ ربات در گزارش‌ها

USE_TEST_ENDPOINT = True               # True = فقط آزمایش (بدونِ معاملهٔ واقعی). بعداً False کنید.
POLL_SECONDS      = 60                  # هر چند ثانیه یک‌بار استراتژی بررسی شود


# ─────────────────────────────────────────────────────────────────────────────
#  ۲) ★★★ منطقِ استراتژیِ شما اینجاست ★★★
#     فقط این تابع را با شرط‌های خودتان پر کنید و یکی از این‌ها را برگردانید:
#        return "BUY"   → سیگنالِ خرید
#        return "SELL"  → سیگنالِ فروش
#        return None    → هیچ سیگنالی (کاری نکن)
# ─────────────────────────────────────────────────────────────────────────────
def my_strategy() -> str | None:
    """اینجا تصمیم بگیرید که آیا الان سیگنالِ خرید/فروش دارید یا نه.

    داده‌ها را از هر منبعی که دارید بگیرید (متاتریدر، صرافی، فایل، …).
    نمونهٔ زیر فقط برای نشان‌دادنِ ساختار است؛ آن را با منطقِ خودتان جایگزین کنید.
    """
    # ── نمونه (شبه‌کد) — این‌ها را حذف و منطقِ خودتان را بنویسید: ──────────────
    #
    #   close  = get_my_prices()          # قیمت‌های بستهٔ خودتان
    #   ema_fast = ema(close, 20)
    #   ema_slow = ema(close, 50)
    #   if ema_fast[-2] <= ema_slow[-2] and ema_fast[-1] > ema_slow[-1]:
    #       return "BUY"
    #   if ema_fast[-2] >= ema_slow[-2] and ema_fast[-1] < ema_slow[-1]:
    #       return "SELL"
    #
    # ──────────────────────────────────────────────────────────────────────────
    return None   # پیش‌فرض: هیچ سیگنالی. (این خط را با return خودتان عوض کنید.)


# ─────────────────────────────────────────────────────────────────────────────
#  ۳) (اختیاری) حد ضرر و سه حد سودِ خودتان را حساب کنید.
#     اگر None برگردانید، برنامه بدونِ SL/TP سفارش را پردازش می‌کند.
# ─────────────────────────────────────────────────────────────────────────────
def my_sl_tps(direction: str):
    """اگر می‌خواهید SL و تا سه TP بفرستید، این‌ها را برگردانید (وگرنه None).

    خروجی: (sl, [tp1, tp2, tp3])  یا  (None, None)
    """
    # نمونه (حذف/جایگزین کنید):
    #   entry = get_my_last_price()
    #   if direction == "BUY":
    #       return entry - 3.0, [entry + 3.0, entry + 6.0, entry + 9.0]
    #   else:
    #       return entry + 3.0, [entry - 3.0, entry - 6.0, entry - 9.0]
    return None, None


# ─────────────────────────────────────────────────────────────────────────────
#  ۴) موتورِ آماده — لازم نیست چیزی را اینجا تغییر دهید.
# ─────────────────────────────────────────────────────────────────────────────
def build_bridge() -> RobotBridge:
    return RobotBridge(BASE_URL, secret=SECRET, default_tf=TIMEFRAME)


def send_once(bridge: RobotBridge, direction: str) -> None:
    """یک سیگنال را می‌سازد و به برنامه می‌فرستد و نتیجه را چاپ می‌کند."""
    sl, tps = my_sl_tps(direction)
    res = bridge.send(
        symbol=SYMBOL,
        direction=direction,        # "BUY" یا "SELL"
        volume=VOLUME,
        sl=sl,                      # می‌تواند None باشد
        take_profits=tps,           # لیستِ حد سودها یا None
        tf=TIMEFRAME,
        robot_id=ROBOT_ID,
        comment="signal from my bot",
        test=USE_TEST_ENDPOINT,     # True = بدونِ معاملهٔ واقعی
    )
    if res.forwarded:
        print(f"✅ {direction}: پس از تأییدِ برنامه به متاتریدر ارسال شد.")
    elif res.approved:
        print(f"🟡 {direction}: تأیید شد ولی ارسال نشد ({res.comment}).")
    else:
        print(f"⛔ {direction}: رد شد — {res.comment}")
        for r in res.reasons:
            print("     -", r)


def main() -> None:
    bridge = build_bridge()

    if not bridge.ping():
        print("⛔ برنامه در دسترس نیست. مطمئن شوید در حال اجراست و آدرس/پورت درست است.")
        return
    print(f"✅ اتصال برقرار شد: {BASE_URL}  | نماد={SYMBOL}  حجم={VOLUME}  "
          f"تایم‌فریم={TIMEFRAME}  حالتِ آزمایش={USE_TEST_ENDPOINT}")

    last_dir = None   # جلوگیری از ارسالِ تکراریِ پشتِ‌هم در یک جهت
    try:
        while True:
            signal = my_strategy()            # ← منطقِ شما
            if signal in ("BUY", "SELL") and signal != last_dir:
                send_once(bridge, signal)
                last_dir = signal
            elif signal is None:
                pass                          # سیگنالی نبود
            time.sleep(POLL_SECONDS)
    except KeyboardInterrupt:
        print("\nربات متوقف شد.")


if __name__ == "__main__":
    main()
