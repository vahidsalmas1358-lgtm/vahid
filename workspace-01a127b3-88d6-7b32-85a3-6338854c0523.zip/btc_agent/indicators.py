"""محاسبه اندیکاتورهای تحلیل تکنیکال با numpy/pandas خالص (بدون کتابخانه خارجی)."""
from __future__ import annotations
import numpy as np
import pandas as pd


def ema(series: pd.Series, period: int) -> pd.Series:
    return series.ewm(span=period, adjust=False).mean()


def sma(series: pd.Series, period: int) -> pd.Series:
    return series.rolling(period).mean()


def rsi(series: pd.Series, period: int = 14) -> pd.Series:
    delta = series.diff()
    gain = delta.clip(lower=0.0)
    loss = -delta.clip(upper=0.0)
    avg_gain = gain.ewm(alpha=1 / period, adjust=False).mean()
    avg_loss = loss.ewm(alpha=1 / period, adjust=False).mean()
    rs = avg_gain / avg_loss.replace(0, np.nan)
    out = 100 - (100 / (1 + rs))
    # حالتِ لبه: میانگینِ ضرر صفر است. طبقِ تعریفِ استاندارد اگر سودی وجود داشته باشد
    # RSI = ۱۰۰ (اشباعِ خرید)، و اگر هیچ حرکتی نباشد (سود هم صفر) RSI = ۵۰ (خنثی).
    # بدونِ این اصلاح، fillna(50) به‌اشتباه یک روندِ صعودیِ خالص را «خنثی» نشان می‌داد.
    out = out.mask((avg_loss == 0) & (avg_gain > 0), 100.0)
    return out.fillna(50.0)


def macd(series: pd.Series, fast: int = 12, slow: int = 26, signal: int = 9):
    macd_line = ema(series, fast) - ema(series, slow)
    signal_line = ema(macd_line, signal)
    hist = macd_line - signal_line
    return macd_line, signal_line, hist


def bollinger(series: pd.Series, period: int = 20, mult: float = 2.0):
    mid = sma(series, period)
    std = series.rolling(period).std()
    upper = mid + mult * std
    lower = mid - mult * std
    return upper, mid, lower


def atr(df: pd.DataFrame, period: int = 14) -> pd.Series:
    high, low, close = df["high"], df["low"], df["close"]
    prev_close = close.shift(1)
    tr = pd.concat([
        (high - low),
        (high - prev_close).abs(),
        (low - prev_close).abs(),
    ], axis=1).max(axis=1)
    return tr.ewm(alpha=1 / period, adjust=False).mean()


def stochastic(df: pd.DataFrame, k: int = 14, d: int = 3):
    low_k = df["low"].rolling(k).min()
    high_k = df["high"].rolling(k).max()
    percent_k = 100 * (df["close"] - low_k) / (high_k - low_k).replace(0, np.nan)
    percent_d = percent_k.rolling(d).mean()
    return percent_k.fillna(50.0), percent_d.fillna(50.0)


def adx(df: pd.DataFrame, period: int = 14):
    """شاخص جهت‌دار میانگین (قدرت روند) به‌همراه +DI و -DI."""
    high, low, close = df["high"], df["low"], df["close"]
    up_move = high.diff()
    down_move = -low.diff()
    plus_dm = pd.Series(np.where((up_move > down_move) & (up_move > 0), up_move, 0.0), index=df.index)
    minus_dm = pd.Series(np.where((down_move > up_move) & (down_move > 0), down_move, 0.0), index=df.index)
    prev_close = close.shift(1)
    tr = pd.concat([(high - low), (high - prev_close).abs(), (low - prev_close).abs()], axis=1).max(axis=1)
    atr_ = tr.ewm(alpha=1 / period, adjust=False).mean().replace(0, np.nan)
    plus_di = 100 * plus_dm.ewm(alpha=1 / period, adjust=False).mean() / atr_
    minus_di = 100 * minus_dm.ewm(alpha=1 / period, adjust=False).mean() / atr_
    dx = 100 * (plus_di - minus_di).abs() / (plus_di + minus_di).replace(0, np.nan)
    adx_ = dx.ewm(alpha=1 / period, adjust=False).mean()
    return adx_.fillna(0.0), plus_di.fillna(0.0), minus_di.fillna(0.0)


def ichimoku(df: pd.DataFrame, tenkan_p: int = 9, kijun_p: int = 26, senkou_b_p: int = 52):
    """اجزای ایچیموکو: تنکان، کیجون، سنکو A و سنکو B (ابر)."""
    high, low = df["high"], df["low"]
    tenkan = (high.rolling(tenkan_p).max() + low.rolling(tenkan_p).min()) / 2
    kijun = (high.rolling(kijun_p).max() + low.rolling(kijun_p).min()) / 2
    senkou_a = ((tenkan + kijun) / 2).shift(kijun_p)
    senkou_b = ((high.rolling(senkou_b_p).max() + low.rolling(senkou_b_p).min()) / 2).shift(kijun_p)
    return tenkan, kijun, senkou_a, senkou_b


def price_decimals(price: float) -> int:
    """تعداد ارقام اعشار مناسب برای گِرد کردن قیمت/سطوح، بر اساس بزرگی قیمت.

    منبعِ حقیقتِ واحد (single source of truth) برای همهٔ ماژول‌ها
    (indicators / engine / backtest) تا رفتارِ اعشار در سراسرِ برنامه یکسان بماند.

    این تابع بحرانی است: گِرد کردنِ ثابت (مثلاً یک رقم اعشار) برای فارکس
    (EURUSD≈۱٫۰۸، GBPUSD≈۱٫۲۷) همه‌ی سطوح را به ۱٫۰/۱٫۱ فرومی‌پاشد و
    محاسبات حد سود/ضرر را خراب می‌کند. بنابراین اعشار پویا لازم است.

    قاعدهٔ مرجع (یکسان با آزمونِ test_60_trades):
        ≥100 → ۲ ،  ≥1 → ۴ ،  ≥0.01 → ۵ ،  در غیر این‌صورت → ۸
    نکته: بازهٔ ≥۱۰۰۰ عمداً ۲ رقم می‌گیرد (نه ۱) تا برای طلا/بیت‌کوین/شاخص‌ها
    دقتِ سطوح با نقشهٔ معامله (engine._dec) هم‌تراز بماند.
    """
    try:
        p = abs(float(price))
    except Exception:  # noqa
        return 2
    if p >= 100:      # شاملِ ≥۱۰۰۰ هم می‌شود → همیشه ۲ رقم (هم‌تراز با engine/backtest)
        return 2
    if p >= 1:
        return 4
    if p >= 0.01:
        return 5
    return 8


# نامِ قدیمی برای سازگاری با فراخوانی‌های داخلیِ این ماژول (alias واحد)
def _level_decimals(price: float) -> int:
    return price_decimals(price)


def fibonacci_levels(df: pd.DataFrame, lookback: int = 90):
    """سطوحِ فیبوناچیِ بازگشتی (Retracement) و گسترشی (Extension) بر مبنای آخرین موجِ مهم.

    روش (کاملاً عینی و قابلِ تکرار):
      - در پنجرهٔ اخیر (lookback کندلِ آخر) بالاترین سقف و پایین‌ترین کف پیدا می‌شود.
      - جهتِ «موج» از روی این‌که کدام‌یک تازه‌تر است تعیین می‌گردد:
          سقفِ تازه‌تر از کف  → موجِ صعودی (up)  → اصلاح‌ها از سقف به‌سمتِ کف، گسترش‌ها بالای سقف.
          کفِ تازه‌تر از سقف  → موجِ نزولی (down) → اصلاح‌ها از کف به‌سمتِ سقف، گسترش‌ها زیرِ کف.
      - نسبت‌های استاندارد: اصلاح 0.236/0.382/0.5/0.618/0.786 و گسترش 1.272/1.618/2.0.
      - «ناحیهٔ طلایی» بازهٔ 0.5 تا 0.618 است.

    خروجی: دیکشنری با کلیدهای available/direction/swing_high/swing_low/range/
            retracements[]/extensions[]/pos_ratio/in_golden/nearest.
    """
    if df is None or len(df) < 10:
        return {"available": False}
    highs = df["high"].values
    lows = df["low"].values
    price = float(df["close"].values[-1])
    dec = _level_decimals(price)

    n = len(df)
    start = max(0, n - int(lookback))
    seg_h = highs[start:]
    seg_l = lows[start:]
    hi_rel = int(np.argmax(seg_h))
    lo_rel = int(np.argmin(seg_l))
    swing_high = float(seg_h[hi_rel])
    swing_low = float(seg_l[lo_rel])
    rng = swing_high - swing_low
    if rng <= 0:
        return {"available": False}

    hi_idx = start + hi_rel
    lo_idx = start + lo_rel
    up_leg = hi_idx > lo_idx          # سقف تازه‌تر از کف → موجِ صعودی

    retr = [0.236, 0.382, 0.5, 0.618, 0.786]
    extn = [1.272, 1.618, 2.0]

    if up_leg:
        direction = "up"
        retracements = [{"ratio": r, "price": round(swing_high - r * rng, dec)} for r in retr]
        extensions = [{"ratio": e, "price": round(swing_low + e * rng, dec)} for e in extn]
        # جایگاهِ قیمت در موج: 0 روی سقف، 1 روی کف
        pos_ratio = (swing_high - price) / rng
    else:
        direction = "down"
        retracements = [{"ratio": r, "price": round(swing_low + r * rng, dec)} for r in retr]
        extensions = [{"ratio": e, "price": round(swing_high - e * rng, dec)} for e in extn]
        # جایگاهِ قیمت در موج: 0 روی کف، 1 روی سقف
        pos_ratio = (price - swing_low) / rng

    pos_ratio = float(max(-1.0, min(2.0, pos_ratio)))
    in_golden = 0.5 <= pos_ratio <= 0.618
    nearest = min(retracements, key=lambda x: abs(x["price"] - price))

    return {
        "available": True,
        "direction": direction,
        "swing_high": round(swing_high, dec),
        "swing_low": round(swing_low, dec),
        "range": round(rng, dec),
        "retracements": retracements,
        "extensions": extensions,
        "pos_ratio": round(pos_ratio, 3),
        "in_golden": bool(in_golden),
        "nearest": {"ratio": nearest["ratio"], "price": nearest["price"],
                    "dist": round(abs(nearest["price"] - price), dec)},
    }


def swing_levels(df: pd.DataFrame, lookback: int = 5, n_levels: int = 3):
    """یافتن حمایت/مقاومت از روی سقف و کف‌های محلی (pivot points).

    اعشارِ گِرد کردن بر اساس بزرگی قیمت انتخاب می‌شود تا برای همه‌ی دارایی‌ها
    (کریپتو، طلا، شاخص، فارکس با اعشار زیاد) درست کار کند.
    """
    highs, lows = df["high"].values, df["low"].values
    price = float(df["close"].values[-1])
    dec = _level_decimals(price)
    res, sup = [], []
    for i in range(lookback, len(df) - lookback):
        window_h = highs[i - lookback:i + lookback + 1]
        window_l = lows[i - lookback:i + lookback + 1]
        if highs[i] == window_h.max():
            res.append(highs[i])
        if lows[i] == window_l.min():
            sup.append(lows[i])
    resistances = sorted({round(float(r), dec) for r in res if r > price})[:n_levels]
    supports = sorted({round(float(s), dec) for s in sup if s < price}, reverse=True)[:n_levels]
    return supports, resistances


# ======================================================================
#  ابزارهای پرایس‌اکشن / اسمارت‌مانی: نواحیِ S/R، پیوت، سقف‌وکفِ روزانه،
#  تِرندلاین، لیکوئیدیتی و FVG — همه با numpy/pandas خالص و کاملاً عینی.
# ======================================================================

def _resample_ohlc(df: pd.DataFrame, rule: str):
    """کندل‌های یک تایم‌فریمِ بالاتر (روزانه/هفتگی) را از روی «time» (ms) می‌سازد."""
    if df is None or "time" not in df.columns or len(df) < 2:
        return None
    d = df.copy()
    d["dt"] = pd.to_datetime(d["time"], unit="ms")
    d = d.set_index("dt")
    try:
        o = d["open"].resample(rule).first()
        h = d["high"].resample(rule).max()
        l = d["low"].resample(rule).min()
        c = d["close"].resample(rule).last()
    except Exception:  # noqa
        return None
    out = pd.DataFrame({"open": o, "high": h, "low": l, "close": c}).dropna()
    return out if len(out) else None


def sr_zones(df: pd.DataFrame, lookback: int = 5, n_levels: int = 4, merge_atr: float = None):
    """نواحیِ حمایت/مقاومت (نه خطِ تک) با ادغامِ پیوت‌های نزدیک و شمارشِ «قدرت» (تعداد برخورد).

    خروجی: {supports:[{price,low,high,strength}], resistances:[...]} — از نزدیک به دور نسبت به قیمت.
    """
    if df is None or len(df) < (2 * lookback + 2):
        return {"available": False, "supports": [], "resistances": []}
    highs, lows = df["high"].values, df["low"].values
    price = float(df["close"].values[-1])
    dec = _level_decimals(price)
    atr_val = merge_atr if merge_atr else float((df["high"] - df["low"]).tail(14).mean() or 0)
    tol = max(atr_val * 0.6, price * 0.0015)  # پهنای ادغامِ ناحیه

    piv_res, piv_sup = [], []
    for i in range(lookback, len(df) - lookback):
        wh = highs[i - lookback:i + lookback + 1]
        wl = lows[i - lookback:i + lookback + 1]
        if highs[i] == wh.max():
            piv_res.append(float(highs[i]))
        if lows[i] == wl.min():
            piv_sup.append(float(lows[i]))

    def _cluster(points):
        pts = sorted(points)
        zones = []
        for p in pts:
            if zones and abs(p - zones[-1]["_sum"] / zones[-1]["strength"]) <= tol:
                zones[-1]["_sum"] += p
                zones[-1]["strength"] += 1
                zones[-1]["low"] = min(zones[-1]["low"], p)
                zones[-1]["high"] = max(zones[-1]["high"], p)
            else:
                zones.append({"_sum": p, "strength": 1, "low": p, "high": p})
        for z in zones:
            z["price"] = round(z["_sum"] / z["strength"], dec)
            z["low"] = round(z["low"], dec)
            z["high"] = round(z["high"], dec)
            del z["_sum"]
        return zones

    res_zones = [z for z in _cluster(piv_res) if z["price"] > price]
    sup_zones = [z for z in _cluster(piv_sup) if z["price"] < price]
    res_zones.sort(key=lambda z: z["price"])                 # نزدیک‌ترین بالا
    sup_zones.sort(key=lambda z: z["price"], reverse=True)   # نزدیک‌ترین پایین
    return {"available": True,
            "supports": sup_zones[:n_levels],
            "resistances": res_zones[:n_levels]}


def pivot_points(df: pd.DataFrame):
    """پیوتِ کلاسیکِ فلور بر مبنای دورهٔ کاملِ قبلی (روزانه؛ در نبودِ داده، هفتگی)."""
    price = float(df["close"].values[-1])
    dec = _level_decimals(price)
    agg, basis = _resample_ohlc(df, "1D"), "daily"
    if agg is None or len(agg) < 2:
        agg, basis = _resample_ohlc(df, "1W"), "weekly"
    if agg is None or len(agg) < 2:
        return {"available": False}
    prev = agg.iloc[-2]  # آخرین دورهٔ کامل (دورهٔ جاری هنوز در حال شکل‌گیری است)
    H, L, C = float(prev["high"]), float(prev["low"]), float(prev["close"])
    P = (H + L + C) / 3.0
    rng = H - L
    out = {
        "available": True, "basis": basis,
        "P": round(P, dec),
        "R1": round(2 * P - L, dec), "S1": round(2 * P - H, dec),
        "R2": round(P + rng, dec), "S2": round(P - rng, dec),
        "R3": round(H + 2 * (P - L), dec), "S3": round(L - 2 * (H - P), dec),
    }
    return out


def daily_levels(df: pd.DataFrame):
    """سقف/کف/بستهٔ روزِ قبل (PDH/PDL/PDC) و سقف/کفِ هفتهٔ قبل (PWH/PWL) + سقف/کفِ امروز."""
    price = float(df["close"].values[-1])
    dec = _level_decimals(price)
    out = {"available": False}
    daily = _resample_ohlc(df, "1D")
    if daily is not None and len(daily) >= 2:
        prev, cur = daily.iloc[-2], daily.iloc[-1]
        out.update(available=True,
                   pdh=round(float(prev["high"]), dec),
                   pdl=round(float(prev["low"]), dec),
                   pdc=round(float(prev["close"]), dec),
                   cdh=round(float(cur["high"]), dec),
                   cdl=round(float(cur["low"]), dec))
    weekly = _resample_ohlc(df, "1W")
    if weekly is not None and len(weekly) >= 2:
        pw = weekly.iloc[-2]
        out.update(pwh=round(float(pw["high"]), dec),
                   pwl=round(float(pw["low"]), dec))
    return out


def _swing_idx(vals, left, right, kind):
    out = []
    for i in range(left, len(vals) - right):
        w = vals[i - left:i + right + 1]
        if kind == "high" and vals[i] == w.max():
            out.append(i)
        elif kind == "low" and vals[i] == w.min():
            out.append(i)
    return out


def trendline(df: pd.DataFrame, lookback: int = 80, pivot: int = 3):
    """تِرندلاینِ حمایتی/مقاومتی با برازشِ خطی روی آخرین پیوت‌های کف/سقف + تشخیصِ شکست."""
    if df is None or len(df) < (2 * pivot + 6):
        return {"available": False}
    n = len(df)
    start = max(0, n - lookback)
    highs = df["high"].values[start:]
    lows = df["low"].values[start:]
    price = float(df["close"].values[-1])
    dec = _level_decimals(price)
    last_x = len(highs) - 1

    def _fit(idxs, vals):
        if len(idxs) >= 2:
            pts = idxs[-3:] if len(idxs) >= 3 else idxs[-2:]
            touches = len(pts)
        else:
            # فالبک: برازشِ خطی روی کلِ نقاطِ پنجره (روندِ کلی) وقتی پیوتِ کافی نیست
            pts = list(range(len(vals)))
            touches = len(idxs)
        if len(pts) < 2:
            return None
        x = np.array(pts, dtype=float)
        y = np.array([vals[i] for i in pts], dtype=float)
        slope, intercept = np.polyfit(x, y, 1)
        return {"slope": float(slope), "value": round(float(slope * last_x + intercept), dec),
                "touches": int(touches)}

    sup = _fit(_swing_idx(lows, pivot, pivot, "low"), lows)
    res = _fit(_swing_idx(highs, pivot, pivot, "high"), highs)

    direction, broken, note = "خنثی", None, "روندِ افقی/نامشخص"
    if sup and res:
        if sup["slope"] > 0 and res["slope"] > 0:
            direction, note = "صعودی", "کانالِ صعودی"
        elif sup["slope"] < 0 and res["slope"] < 0:
            direction, note = "نزولی", "کانالِ نزولی"
    if sup and price < sup["value"]:
        broken, note = "support", "شکستِ خطِ حمایت (نزولی)"
    elif res and price > res["value"]:
        broken, note = "resistance", "شکستِ خطِ مقاومت (صعودی)"
    return {"available": bool(sup or res), "support": sup, "resistance": res,
            "direction": direction, "broken": broken, "note": note}


def liquidity(df: pd.DataFrame, lookback: int = 90, pivot: int = 3, atr: float = None):
    """نواحیِ لیکوئیدیتی (سقف/کف‌های برابر) + تشخیصِ «جاروی نقدینگی» (stop-hunt) در کندل‌های اخیر."""
    if df is None or len(df) < (2 * pivot + 6):
        return {"available": False, "buy_side": [], "sell_side": [], "sweep": None}
    n = len(df)
    start = max(0, n - lookback)
    highs = df["high"].values[start:]
    lows = df["low"].values[start:]
    closes = df["close"].values[start:]
    price = float(df["close"].values[-1])
    dec = _level_decimals(price)
    atr_val = atr if atr else float((df["high"] - df["low"]).tail(14).mean() or 0)
    tol = max(atr_val * 0.25, price * 0.0008)

    hi_idx = _swing_idx(highs, pivot, pivot, "high")
    lo_idx = _swing_idx(lows, pivot, pivot, "low")

    def _equal(idxs, vals):  # noqa
        levels = []
        used = [False] * len(idxs)
        for a in range(len(idxs)):
            if used[a]:
                continue
            group = [vals[idxs[a]]]
            for b in range(a + 1, len(idxs)):
                if not used[b] and abs(vals[idxs[b]] - vals[idxs[a]]) <= tol:
                    group.append(vals[idxs[b]]); used[b] = True
            if len(group) >= 2:   # فقط سقف/کفِ «برابر» (لیکوئیدیتیِ خوشه‌ای)
                levels.append(round(float(np.mean(group)), dec))
        return levels

    buy_side = sorted({p for p in _equal(hi_idx, highs) if p > price})           # نقدینگیِ بالای بازار
    sell_side = sorted({p for p in _equal(lo_idx, lows) if p < price}, reverse=True)  # نقدینگیِ زیرِ بازار

    # جاروی نقدینگی: ۲ کندلِ آخر سقف/کفِ پیشین را شکسته‌اند اما بسته‌شدن به سطح برگشته است
    sweep = None
    if len(highs) >= 5:
        prior_hi = float(highs[:-2].max())
        prior_lo = float(lows[:-2].min())
        last_hi = float(highs[-2:].max())
        last_lo = float(lows[-2:].min())
        if last_hi > prior_hi and closes[-1] < prior_hi:
            sweep = {"type": "buyside", "price": round(prior_hi, dec)}   # سقف جارو شد → نزولی
        elif last_lo < prior_lo and closes[-1] > prior_lo:
            sweep = {"type": "sellside", "price": round(prior_lo, dec)}  # کف جارو شد → صعودی
    return {"available": True, "buy_side": buy_side[:3], "sell_side": sell_side[:3], "sweep": sweep}


def fair_value_gaps(df: pd.DataFrame, lookback: int = 40):
    """گپ‌های ارزشِ منصفانه (FVG / عدمِ تعادلِ ۳کندلی) که هنوز پُر نشده‌اند."""
    if df is None or len(df) < 6:
        return {"available": False, "bullish": [], "bearish": [],
                "nearest_support": None, "nearest_resistance": None}
    highs, lows = df["high"].values, df["low"].values
    price = float(df["close"].values[-1])
    dec = _level_decimals(price)
    n = len(df)
    start = max(2, n - lookback)
    bull, bear = [], []
    for i in range(start, n):
        # صعودی: کفِ کندلِ i از سقفِ کندلِ i-2 بالاتر است
        if lows[i] > highs[i - 2]:
            top, bot = float(lows[i]), float(highs[i - 2])
            filled = bool(np.min(lows[i + 1:]) <= bot) if i + 1 < n else False
            if not filled:
                bull.append({"top": round(top, dec), "bottom": round(bot, dec),
                             "mid": round((top + bot) / 2, dec)})
        # نزولی: سقفِ کندلِ i از کفِ کندلِ i-2 پایین‌تر است
        if highs[i] < lows[i - 2]:
            top, bot = float(lows[i - 2]), float(highs[i])
            filled = bool(np.max(highs[i + 1:]) >= top) if i + 1 < n else False
            if not filled:
                bear.append({"top": round(top, dec), "bottom": round(bot, dec),
                             "mid": round((top + bot) / 2, dec)})
    near_sup = None
    below = [g for g in bull if g["top"] <= price]
    if below:
        near_sup = max(below, key=lambda g: g["top"])
    near_res = None
    above = [g for g in bear if g["bottom"] >= price]
    if above:
        near_res = min(above, key=lambda g: g["bottom"])
    return {"available": True, "bullish": bull[-4:], "bearish": bear[-4:],
            "nearest_support": near_sup, "nearest_resistance": near_res}


def market_structure(df: pd.DataFrame, lookback: int = 120, pivot: int = 3):
    """ساختارِ بازار: HH/HL/LH/LL و تشخیصِ BOS (شکستِ ساختار) و CHOCH (تغییرِ کاراکتر).

    روش (کاملاً عینی):
      ۱) پیوت‌های سقف/کف پیدا و به یک «زیگزاگِ» متناوب (سقف، کف، سقف…) تبدیل می‌شوند.
      ۲) هر سقف نسبت به سقفِ قبلی HH/LH و هر کف نسبت به کفِ قبلی HL/LL برچسب می‌خورد.
      ۳) روند: توالیِ HH+HL → صعودی، LH+LL → نزولی، وگرنه رِنج.
      ۴) BOS: شکستِ آخرین سوینگِ «هم‌جهت با روند» (ادامهٔ روند).
         CHOCH: شکستِ آخرین سوینگِ «خلافِ روند» (هشدارِ برگشت).

    خروجی: {available, trend, event(BOS/CHOCH/None), dir(+1/-1/0), note,
             last_high, last_low, high_label, low_label, swings[]}
    """
    if df is None or len(df) < (2 * pivot + 6):
        return {"available": False}
    n = len(df)
    start = max(0, n - lookback)
    highs = df["high"].values
    lows = df["low"].values
    price = float(df["close"].values[-1])
    dec = _level_decimals(price)

    hi_idx = [i for i in _swing_idx(highs, pivot, pivot, "high") if i >= start]
    lo_idx = [i for i in _swing_idx(lows, pivot, pivot, "low") if i >= start]

    pts = ([{"idx": i, "price": float(highs[i]), "kind": "H"} for i in hi_idx]
           + [{"idx": i, "price": float(lows[i]), "kind": "L"} for i in lo_idx])
    pts.sort(key=lambda p: p["idx"])
    if len(pts) < 2:
        return {"available": False}

    # زیگزاگِ متناوب: بینِ دو پیوتِ هم‌نوعِ پیاپی، فقط «حدی‌ترین» را نگه می‌داریم
    zz = []
    for p in pts:
        if not zz:
            zz.append(dict(p))
            continue
        if p["kind"] == zz[-1]["kind"]:
            if p["kind"] == "H" and p["price"] >= zz[-1]["price"]:
                zz[-1] = dict(p)
            elif p["kind"] == "L" and p["price"] <= zz[-1]["price"]:
                zz[-1] = dict(p)
        else:
            zz.append(dict(p))

    highs_seq = [p for p in zz if p["kind"] == "H"]
    lows_seq = [p for p in zz if p["kind"] == "L"]
    if not highs_seq or not lows_seq:
        return {"available": False}

    for i, p in enumerate(highs_seq):
        p["label"] = "H" if i == 0 else ("HH" if p["price"] > highs_seq[i - 1]["price"] else "LH")
    for i, p in enumerate(lows_seq):
        p["label"] = "L" if i == 0 else ("HL" if p["price"] > lows_seq[i - 1]["price"] else "LL")

    lh = highs_seq[-1]["label"] if len(highs_seq) >= 2 else None
    ll = lows_seq[-1]["label"] if len(lows_seq) >= 2 else None

    # روند از روی «آخرین شکستِ تأییدشده» (ماشینِ حالت روی سوینگ‌های زیگزاگ)
    trend = None
    ph = pl = None
    for p in zz:
        if p["kind"] == "H":
            if ph is not None and p["price"] > ph:
                trend = "up"          # سقفِ بالاتر → شکستِ صعودی
            ph = p["price"]
        else:
            if pl is not None and p["price"] < pl:
                trend = "down"        # کفِ پایین‌تر → شکستِ نزولی
            pl = p["price"]
    if trend is None:
        if lh == "HH" and ll == "HL":
            trend = "up"
        elif lh == "LH" and ll == "LL":
            trend = "down"
        else:
            trend = "range"

    last_H = highs_seq[-1]["price"]
    last_L = lows_seq[-1]["price"]

    # رویدادِ زنده: قیمتِ فعلی آخرین سطحِ ساختاری را می‌شکند؟
    event, edir, note = None, 0, ""
    if price > last_H:
        edir = 1
        if trend == "up":
            event, note = "BOS", "شکستِ ساختارِ صعودی (ادامهٔ روندِ صعودی)"
        elif trend == "down":
            event, note = "CHOCH", "تغییرِ کاراکترِ صعودی (هشدارِ برگشت به صعودی)"
        else:
            event, note = "BOS", "شکستِ سقفِ ساختار (آغازِ روندِ صعودی)"
    elif price < last_L:
        edir = -1
        if trend == "down":
            event, note = "BOS", "شکستِ ساختارِ نزولی (ادامهٔ روندِ نزولی)"
        elif trend == "up":
            event, note = "CHOCH", "تغییرِ کاراکترِ نزولی (هشدارِ برگشت به نزولی)"
        else:
            event, note = "BOS", "شکستِ کفِ ساختار (آغازِ روندِ نزولی)"
    else:
        note = {"up": "ساختارِ صعودی سالم (HH/HL)",
                "down": "ساختارِ نزولی سالم (LH/LL)",
                "range": "ساختارِ رِنج/نامشخص"}[trend]

    return {
        "available": True, "trend": trend, "event": event, "dir": edir, "note": note,
        "last_high": round(last_H, dec), "last_low": round(last_L, dec),
        "high_label": highs_seq[-1]["label"], "low_label": lows_seq[-1]["label"],
        "swings": [{"idx": int(p["idx"]), "price": round(p["price"], dec),
                    "kind": p["kind"], "label": p.get("label")} for p in zz[-8:]],
    }
