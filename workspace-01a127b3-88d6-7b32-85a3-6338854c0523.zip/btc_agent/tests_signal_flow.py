"""تستِ عمیقِ سه مسیرِ ارسالِ سیگنال به متاتریدر ۵:

  ۱) سیگنال‌های داخلیِ برنامه  (/api/signal → _program_auto_dispatch)
  ۲) سیگنال‌های هوش مصنوعی      (source=ai / رأی‌گیری both)
  ۳) سیگنال‌های ربات‌ها/اکسپرت‌ها (/api/robot/order , /api/robot/test)

همهٔ وابستگی‌های بیرونی (هوش مصنوعی، اخبار، زمان‌بندی، ارسال به MT5، ساختِ سیگنالِ
داخلی) با mock جایگزین می‌شوند تا رفتارِ منطقِ تصمیم/ارسال قطعی و قابلِ تکرار باشد.

اجرا:  python3 tests_signal_flow.py   (خروجی نانمونه‌ی صفر یعنی همه پاس شدند)
"""
import os as _os_env; _os_env.environ.setdefault("BTC_AGENT_ALLOW_INSECURE_ROBOT", "1")  # محیط تست
import sys
import app
import dispatch
import robots

PASS = 0
FAIL = 0
SENT = []          # فراخوان‌های send_order ثبت می‌شوند


def check(name, cond, extra=""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"  \033[32mPASS\033[0m  {name}")
    else:
        FAIL += 1
        print(f"  \033[31mFAIL\033[0m  {name}   {extra}")


# ----------------------------------------------------------------- mocks
def make_data(direction="LONG", score=50.0, price=100.0, symbol="BTC"):
    return {
        "symbol": symbol, "symbol_name": "Bitcoin", "pair": "BTC/USDT",
        "interval": "1h", "direction": direction,
        "total_score": score, "internal_score": score,
        "confidence": 70, "price": price, "atr": 2.0,
        "technical": {"score": score, "rsi": 55, "trend": "up", "atr": 2.0,
                      "supports": [price - 5, price - 10],
                      "resistances": [price + 5, price + 10],
                      "signals": [], "fibonacci": None,
                      "conf_supports": [], "conf_resistances": []},
        "fundamental": {"available": True, "score": 10, "signals": []},
        "sentiment": {"title": "F&G", "value": 50, "score": 5,
                      "classification": "Neutral", "kind": "fg"},
        "plan": {"entry": price, "stop_loss": price - 2,
                 "take_profits": [{"price": price + 2}, {"price": price + 4},
                                  {"price": price + 6}]},
        "generated_at": "now",
    }


# جهت/امتیازِ سیگنالِ داخلیِ mockشده (تست‌ها این‌ها را تغییر می‌دهند)
INTERNAL = {"direction": "LONG", "score": 50.0}
# نتیجهٔ هوش مصنوعیِ mockشده
AI = {"available": True, "direction": "LONG", "score": 50.0}
# مسدودسازیِ اخبار / وضعیتِ زمان‌بندی
NEWS_BLOCK = {"blocked": False}
SCHEDULE_ACTIVE = True


def mock_signal_for(raw, tf, with_ai=False, htf=None, ai_weight=None):
    d = make_data(INTERNAL["direction"], INTERNAL["score"], symbol=str(raw).upper())
    return d, str(raw).upper(), ""


def mock_ai_eval(data):
    return dict(AI)


def mock_news_blocked(symbol, before_min=30, after_min=30, min_impact="High", source="both"):
    return dict(NEWS_BLOCK)


def mock_program_gate():
    return (SCHEDULE_ACTIVE,
            {"enabled": True, "active": SCHEDULE_ACTIVE, "broker_time": "12:00:00",
             "reason": "" if SCHEDULE_ACTIVE else "خارج از بازهٔ کاری"})


def mock_send_order(internal_symbol, direction, plan, volume=None,
                    dry_run=False, overrides=None, skip_news_filter=False):
    SENT.append({"symbol": internal_symbol, "direction": direction,
                 "plan": plan, "volume": volume, "overrides": overrides,
                 "skip_news_filter": skip_news_filter, "dry_run": dry_run})
    # اصلاح (DISP-TRUTH): ماک باید dry_run را «انعکاس» دهد؛ قبلاً همیشه
    # simulated=True برمی‌گرداند و پس از اصلاحِ صداقتِ لاگ (شبیه‌سازی ≠ ارسالِ
    # واقعی) تست‌های دِدوپ/فورواردِ واقعی بی‌جهت شکست می‌خوردند.
    return {"ok": True, "dry_run": bool(dry_run), "simulated": bool(dry_run),
            "ticket": 999, "tickets": ([] if dry_run else [999]),
            "broker_symbol": internal_symbol, "direction": direction}


def install_mocks():
    app._signal_for = mock_signal_for
    app._ai_eval_for_signal = mock_ai_eval
    app.news.is_blocked = mock_news_blocked
    app._program_gate = mock_program_gate
    app.mt5_bridge.send_order = mock_send_order
    # پوزیشن‌ها/داوری را ساده نگه‌دار (fail-open)
    app.mt5_bridge.positions = lambda magic_only=True: {"ok": False}


def reset(program_source="internal", program_enabled=True,
          news=True, schedule=True, min_i=15, min_a=15,
          robot_mode="internal", robot_enabled=True, robot_match=True,
          robot_secret="", conflict_guard=False, auto_forward=True):
    SENT.clear()
    app._last_dispatch_dir.clear()
    dispatch.save_config({
        "program_enabled": program_enabled, "program_source": program_source,
        "program_min_internal": min_i, "program_min_ai": min_a,
        "news_filter_enabled": news, "schedule_filter_enabled": schedule,
        "news_impact": "High", "news_before_min": 30, "news_after_min": 30,
    })
    robots.save_config({
        "enabled": robot_enabled, "filter_mode": robot_mode,
        "require_direction_match": robot_match,
        "min_internal_score": min_i, "min_ai_score": min_a,
        "auto_forward": auto_forward, "respect_robot_volume": True,
        "shared_secret": robot_secret, "conflict_guard_enabled": conflict_guard,
        "aggregate_window_sec": 0.0, "dedupe_window_sec": 0.0,
    })
    global NEWS_BLOCK, SCHEDULE_ACTIVE
    NEWS_BLOCK = {"blocked": False}
    SCHEDULE_ACTIVE = True


client = None


def robot_post(order, test=True, headers=None):
    url = "/api/robot/test" if test else "/api/robot/order"
    return client.post(url, json=order, headers=headers or {})


# ============================================================ TESTS
def t_internal():
    print("\n[۱] سیگنال‌های داخلیِ برنامه (source=internal)")
    global INTERNAL

    reset(program_source="internal", min_i=15)
    INTERNAL = {"direction": "LONG", "score": 50.0}
    r = client.get("/api/signal?symbol=BTC&tf=1h").get_json()
    check("پاسخِ /api/signal موفق", r.get("ok"), r)
    check("ارسالِ داخلی انجام شد (۱ سفارش)", len(SENT) == 1, SENT)
    check("جهتِ ارسال LONG", SENT and SENT[0]["direction"] == "LONG", SENT)

    # دِدوپ: همان جهت دوباره ارسال نشود
    client.get("/api/signal?symbol=BTC&tf=1h")
    check("دِدوپ: جهتِ تکراری دوباره ارسال نشد", len(SENT) == 1, SENT)

    # تغییرِ جهت → ارسالِ جدید
    INTERNAL = {"direction": "SHORT", "score": 50.0}
    client.get("/api/signal?symbol=BTC&tf=1h")
    check("تغییرِ جهت → ارسالِ جدید (SHORT)",
          len(SENT) == 2 and SENT[-1]["direction"] == "SHORT", SENT)

    # امتیازِ کمتر از حد → ارسال نشود
    reset(program_source="internal", min_i=80)
    INTERNAL = {"direction": "LONG", "score": 50.0}
    client.get("/api/signal?symbol=BTC&tf=1h")
    check("امتیازِ زیرِ حدِ نصاب → ارسال نشد", len(SENT) == 0, SENT)

    # NEUTRAL → ارسال نشود
    reset(program_source="internal", min_i=0)
    INTERNAL = {"direction": "NEUTRAL", "score": 0.0}
    client.get("/api/signal?symbol=BTC&tf=1h")
    check("جهتِ NEUTRAL → ارسال نشد", len(SENT) == 0, SENT)

    # program_enabled=False → ارسال نشود
    reset(program_source="internal", program_enabled=False, min_i=0)
    INTERNAL = {"direction": "LONG", "score": 50.0}
    client.get("/api/signal?symbol=BTC&tf=1h")
    check("غیرفعال بودنِ ارسالِ برنامه → ارسال نشد", len(SENT) == 0, SENT)


def t_ai_and_vote():
    print("\n[۲] سیگنال‌های هوش مصنوعی و رأی‌گیری (source=ai / both)")
    global INTERNAL, AI

    # --- فقط هوش مصنوعی: تأیید ---
    reset(program_source="ai", min_a=15)
    INTERNAL = {"direction": "SHORT", "score": 0.0}    # داخلی بی‌اهمیت
    AI = {"available": True, "direction": "LONG", "score": 60.0}
    client.get("/api/signal?symbol=BTC&tf=1h")
    check("AI-only: تأیید و ارسال بر پایهٔ جهتِ AI (LONG)",
          len(SENT) == 1 and SENT[0]["direction"] == "LONG", SENT)

    # --- فقط هوش مصنوعی: امتیازِ کم → رد ---
    reset(program_source="ai", min_a=70)
    AI = {"available": True, "direction": "LONG", "score": 60.0}
    client.get("/api/signal?symbol=BTC&tf=1h")
    check("AI-only: امتیازِ زیرِ حد → ارسال نشد", len(SENT) == 0, SENT)

    # --- فقط هوش مصنوعی: در دسترس نیست → رد ---
    reset(program_source="ai", min_a=10)
    AI = {"available": False, "error": "no key"}
    client.get("/api/signal?symbol=BTC&tf=1h")
    check("AI-only: در دسترس نبودن AI → ارسال نشد", len(SENT) == 0, SENT)

    # --- رأی‌گیری both: هر دو هم‌جهت → تأیید ---
    reset(program_source="both", min_i=15, min_a=15)
    INTERNAL = {"direction": "LONG", "score": 40.0}
    AI = {"available": True, "direction": "LONG", "score": 40.0}
    client.get("/api/signal?symbol=BTC&tf=1h")
    check("both: توافقِ هم‌جهت → ارسال (LONG)",
          len(SENT) == 1 and SENT[0]["direction"] == "LONG", SENT)

    # --- رأی‌گیری both: جهتِ ناهم‌سو → رد ---
    reset(program_source="both", min_i=15, min_a=15)
    INTERNAL = {"direction": "LONG", "score": 40.0}
    AI = {"available": True, "direction": "SHORT", "score": 40.0}
    client.get("/api/signal?symbol=BTC&tf=1h")
    check("both: جهتِ ناهم‌سو (LONG≠SHORT) → ارسال نشد", len(SENT) == 0, SENT)

    # --- رأی‌گیری both: AI در دسترس نیست → رد ---
    reset(program_source="both", min_i=0, min_a=0)
    INTERNAL = {"direction": "LONG", "score": 40.0}
    AI = {"available": False, "error": "no key"}
    client.get("/api/signal?symbol=BTC&tf=1h")
    check("both: نبودِ AI → ارسال نشد", len(SENT) == 0, SENT)

    # --- رأی‌گیری both: داخلی زیرِ حد → رد ---
    reset(program_source="both", min_i=50, min_a=0)
    INTERNAL = {"direction": "LONG", "score": 40.0}
    AI = {"available": True, "direction": "LONG", "score": 40.0}
    client.get("/api/signal?symbol=BTC&tf=1h")
    check("both: داخلی زیرِ حد → ارسال نشد", len(SENT) == 0, SENT)


def t_robot():
    print("\n[۳] سیگنال‌های ربات‌ها/اکسپرت‌ها (/api/robot/*)")
    global INTERNAL, AI

    # --- internal mode: جهتِ هم‌سو → تأیید و ارسال ---
    reset(robot_mode="internal", min_i=15)
    INTERNAL = {"direction": "LONG", "score": 50.0}
    r = robot_post({"symbol": "BTC", "direction": "BUY", "volume": 0.1,
                    "sl": 95, "tp": 110}).get_json()
    check("ربات internal: تأیید", r.get("approved") is True, r)
    check("ربات internal: ارسال به MT5", r.get("forwarded") is True, r)
    check("ربات: حجمِ دقیقِ ربات حفظ شد", SENT and SENT[-1]["volume"] == 0.1, SENT)

    # --- internal mode: جهتِ ناهم‌سو + require_match → رد ---
    reset(robot_mode="internal", robot_match=True, min_i=15)
    INTERNAL = {"direction": "LONG", "score": 50.0}
    r = robot_post({"symbol": "BTC", "direction": "SELL", "volume": 0.1}).get_json()
    check("ربات internal: جهتِ ناهم‌سو → رد", r.get("approved") is False, r)
    check("ربات internal: ناهم‌سو → ارسال نشد", r.get("forwarded") is False, r)

    # --- require_match=False: جهتِ ناهم‌سو ولی امتیاز کافی → تأیید ---
    reset(robot_mode="internal", robot_match=False, min_i=15)
    INTERNAL = {"direction": "LONG", "score": 50.0}
    r = robot_post({"symbol": "BTC", "direction": "SELL", "volume": 0.1}).get_json()
    check("ربات internal: بدونِ الزامِ تطبیقِ جهت → تأیید", r.get("approved") is True, r)

    # --- ai mode ---
    reset(robot_mode="ai", min_a=15)
    AI = {"available": True, "direction": "LONG", "score": 50.0}
    r = robot_post({"symbol": "BTC", "direction": "BUY", "volume": 0.2}).get_json()
    check("ربات ai: تأیید و ارسال", r.get("approved") and r.get("forwarded"), r)

    reset(robot_mode="ai", min_a=15)
    AI = {"available": True, "direction": "SHORT", "score": 50.0}
    r = robot_post({"symbol": "BTC", "direction": "BUY", "volume": 0.2}).get_json()
    check("ربات ai: جهتِ AI ناهم‌سو → رد", r.get("approved") is False, r)

    # --- both mode ---
    reset(robot_mode="both", min_i=15, min_a=15)
    INTERNAL = {"direction": "LONG", "score": 40.0}
    AI = {"available": True, "direction": "LONG", "score": 40.0}
    r = robot_post({"symbol": "BTC", "direction": "BUY", "volume": 0.3}).get_json()
    check("ربات both: توافق → تأیید و ارسال", r.get("approved") and r.get("forwarded"), r)

    reset(robot_mode="both", min_i=15, min_a=15)
    INTERNAL = {"direction": "LONG", "score": 40.0}
    AI = {"available": False, "error": "no key"}
    r = robot_post({"symbol": "BTC", "direction": "BUY", "volume": 0.3}).get_json()
    check("ربات both: نبودِ AI → رد", r.get("approved") is False, r)

    # --- اعتبارسنجی: حجمِ نامعتبر ---
    reset(robot_mode="internal")
    resp = robot_post({"symbol": "BTC", "direction": "BUY"})
    check("ربات: حجمِ نامعتبر → کدِ ۴۰۰", resp.status_code == 400, resp.status_code)

    # --- اعتبارسنجی: جهتِ نامعتبر ---
    resp = robot_post({"symbol": "BTC", "direction": "HODL", "volume": 0.1})
    check("ربات: جهتِ نامعتبر → کدِ ۴۰۰", resp.status_code == 400, resp.status_code)

    # --- اعتبارسنجی: نمادِ خالی ---
    resp = robot_post({"direction": "BUY", "volume": 0.1})
    check("ربات: نمادِ خالی → کدِ ۴۰۰", resp.status_code == 400, resp.status_code)

    # --- توکنِ امنیتی ---
    reset(robot_mode="internal", robot_secret="s3cr3t")
    INTERNAL = {"direction": "LONG", "score": 50.0}
    resp = robot_post({"symbol": "BTC", "direction": "BUY", "volume": 0.1},
                      test=False)  # وب‌هوکِ واقعی، بدونِ توکن
    check("ربات: توکنِ اشتباه → کدِ ۴۰۱", resp.status_code == 401, resp.status_code)
    resp = robot_post({"symbol": "BTC", "direction": "BUY", "volume": 0.1},
                      test=False, headers={"X-Robot-Secret": "s3cr3t"})
    check("ربات: توکنِ درست → پذیرفته شد", resp.status_code == 200, resp.status_code)

    # --- پُل غیرفعال ---
    reset(robot_mode="internal", robot_enabled=False)
    r = robot_post({"symbol": "BTC", "direction": "BUY", "volume": 0.1}).get_json()
    check("ربات: پُلِ غیرفعال → forwarded=False", r.get("forwarded") in (False, None), r)

    # --- auto_forward=False: تأیید ولی ارسال نشود ---
    reset(robot_mode="internal", auto_forward=False, min_i=15)
    INTERNAL = {"direction": "LONG", "score": 50.0}
    r = robot_post({"symbol": "BTC", "direction": "BUY", "volume": 0.1}).get_json()
    check("ربات: auto_forward خاموش → تأیید بله، ارسال خیر",
          r.get("approved") is True and r.get("forwarded") is False, r)

    # --- مترادف‌های جهت/حجم/تی‌پی (اکسپرتِ MT5) ---
    reset(robot_mode="internal", robot_match=False, min_i=0)
    INTERNAL = {"direction": "LONG", "score": 50.0}
    r = robot_post({"instrument": "BTC", "order_type": "ORDER_TYPE_SELL",
                    "lots": 0.5, "stoploss": 90,
                    "take_profits": [105, 110, 115], "platform": "mql5"}).get_json()
    o = r.get("order", {})
    check("اکسپرت MT5: نگاشتِ مترادف‌ها (SELL/lots/tps)",
          o.get("direction") == "SHORT" and o.get("volume") == 0.5
          and o.get("tps") == [105, 110, 115], o)


def t_filters():
    print("\n[۴] فیلترهای مشترکِ اخبار و زمان‌بندی (روی همهٔ مسیرها)")
    global INTERNAL, NEWS_BLOCK, SCHEDULE_ACTIVE

    # --- برنامهٔ داخلی: اخبار مسدود می‌کند ---
    reset(program_source="internal", min_i=0, news=True)
    INTERNAL = {"direction": "LONG", "score": 50.0}
    NEWS_BLOCK = {"blocked": True, "event": {"title": "NFP", "country": "US"}}
    client.get("/api/signal?symbol=BTC&tf=1h")
    check("برنامه: فیلترِ اخبار → ارسال نشد", len(SENT) == 0, SENT)

    # --- همان حالت اما فیلترِ اخبار خاموش → ارسال ---
    reset(program_source="internal", min_i=0, news=False)
    INTERNAL = {"direction": "LONG", "score": 50.0}
    NEWS_BLOCK = {"blocked": True, "event": {"title": "NFP", "country": "US"}}
    client.get("/api/signal?symbol=BTC&tf=1h")
    check("برنامه: فیلترِ اخبار خاموش → با وجودِ خبر ارسال شد", len(SENT) == 1, SENT)

    # --- برنامهٔ داخلی: خارج از ساعاتِ کاری ---
    reset(program_source="internal", min_i=0, schedule=True)
    INTERNAL = {"direction": "LONG", "score": 50.0}
    SCHEDULE_ACTIVE = False
    client.get("/api/signal?symbol=BTC&tf=1h")
    check("برنامه: فیلترِ زمان‌بندی → ارسال نشد", len(SENT) == 0, SENT)

    # --- ربات: اخبار مسدود می‌کند (تأیید بله، ارسال خیر) ---
    reset(robot_mode="internal", min_i=15, news=True)
    INTERNAL = {"direction": "LONG", "score": 50.0}
    NEWS_BLOCK = {"blocked": True, "event": {"title": "CPI", "country": "US"}}
    r = robot_post({"symbol": "BTC", "direction": "BUY", "volume": 0.1}).get_json()
    check("ربات: اخبار مسدود کرد → forwarded=False",
          r.get("approved") is True and r.get("forwarded") is False, r)
    check("ربات: پرچمِ news_blocked ست شد", r.get("news_blocked") is True, r)

    # --- ربات: خارج از ساعاتِ کاری ---
    reset(robot_mode="internal", min_i=15, schedule=True)
    INTERNAL = {"direction": "LONG", "score": 50.0}
    SCHEDULE_ACTIVE = False
    r = robot_post({"symbol": "BTC", "direction": "BUY", "volume": 0.1}).get_json()
    check("ربات: زمان‌بندی مسدود کرد → forwarded=False",
          r.get("forwarded") is False and r.get("schedule_blocked") is True, r)


def t_conflict_guard():
    print("\n[۵] مدیریتِ سیگنال‌های تکراری/متضاد (conflict guard)")
    global INTERNAL

    # دِدوپِ زمانی: دو سیگنالِ هم‌جهتِ پشتِ‌سرِ هم → دومی رد
    reset(robot_mode="internal", robot_match=False, min_i=0, conflict_guard=True)
    robots.save_config({"dedupe_window_sec": 60.0, "aggregate_window_sec": 0.0,
                        "block_duplicate_open": True, "block_opposite_open": True})
    INTERNAL = {"direction": "LONG", "score": 50.0}
    # مسیرِ واقعی (test=False): دِدوپ فقط پس از «ارسالِ واقعی» و ثبتِ حافظه معنا دارد؛
    # دکمهٔ «آزمایش» عمداً حافظه را ثبت نمی‌کند تا سیگنالِ واقعی را مسدود نکند.
    r1 = robot_post({"symbol": "ETHDUP", "direction": "BUY", "volume": 0.1}, test=False).get_json()
    r2 = robot_post({"symbol": "ETHDUP", "direction": "BUY", "volume": 0.1}, test=False).get_json()
    check("conflict guard: سیگنالِ اول ارسال شد", r1.get("forwarded") is True, r1)
    check("conflict guard: سیگنالِ هم‌جهتِ تکراری رد شد",
          r2.get("forwarded") is False, r2)


def t_send_order_news():
    print("\n[۶] فیلترِ اخبارِ متمرکز داخلِ send_order (ارسالِ دستی + skip)")
    # send_order در install_mocks جایگزین شده؛ برای بازرسیِ منبعِ واقعی، فایل را می‌خوانیم.
    src = open("mt5_bridge.py", encoding="utf-8").read()
    # منبعِ فیلترِ اخبار باید dispatch باشد، نه cfg (تنظیماتِ mt5)
    check("send_order اخبار را از dispatch می‌خواند (منبعِ واحد)",
          "dispatch.load_config()" in src
          and '_dcfg.get("news_filter_enabled"' in src, "")
    check("send_order پارامترِ skip_news_filter دارد",
          "skip_news_filter: bool = False" in src, "")
    check("send_order دیگر news را از cfg (mt5) نمی‌خواند",
          'cfg.get("news_filter_enabled")' not in src, "")
    # مسیرهای خودکار باید skip_news_filter=True بفرستند
    asrc = open("app.py", encoding="utf-8").read()
    check("برنامه skip_news_filter=True می‌فرستد (اخبار قبلاً اعمال شده)",
          asrc.count("skip_news_filter=True") >= 2, asrc.count("skip_news_filter=True"))
    # و ارسالِ دستی نباید skip کند (تا فیلترِ مرکزی روی آن اعمال شود)
    check("مسیرهای خودکار پرچمِ skip را ست می‌کنند (تستِ رفتاری)",
          all(s.get("skip_news_filter") for s in SENT) if SENT else True, SENT)


def t_tf_normalization():
    """[۷.الف] نگاشتِ تایم‌فریمِ متاتریدر (M5/H1/…) → قالبِ داخلی (5m/1h/…).

    رگرسیون: ربات‌های MQL5 تایم‌فریم را به سبکِ متاتریدر می‌فرستند؛ اگر نگاشت نشوند،
    در ارزیابی به تایم‌فریمِ پیش‌فرض سقوط می‌کنند و سیگنال روی تایم‌فریمِ اشتباه سنجیده می‌شود.
    """
    print("\n[۷.الف] نرمال‌سازیِ تایم‌فریمِ متاتریدر در سفارشِ ربات")
    import robots as rb
    tf_cases = {"M1": "1m", "M5": "5m", "M10": "10m", "M15": "15m",
                "H1": "1h", "H4": "4h", "D1": "1d", "W1": "1w",
                "5m": "5m", "1h": "1h", "10m": "10m", "h4": "4h", "": ""}
    ok_all = all(rb.normalize_tf(k) == v for k, v in tf_cases.items())
    check("تایم‌فریمِ متاتریدر (M5/H1/H4/D1/W1…) درست به قالبِ داخلی نگاشت می‌شود", ok_all,
          {k: rb.normalize_tf(k) for k in tf_cases})
    o = rb.normalize_order({"symbol": "XAUUSD", "direction": "BUY",
                            "volume": 0.01, "tf": "M5"})
    check("سفارشِ نرمال‌شده tf را به 5m تبدیل می‌کند (نه M5)", o["tf"] == "5m", o)


def t_rsi_edge_cases():
    """[۷.ب] رگرسیونِ RSI در حالتِ لبه (میانگینِ ضرر صفر).

    باگِ اصلاح‌شده: در یک روندِ صعودیِ خالص (بدونِ هیچ کندلِ نزولی) میانگینِ ضرر صفر
    می‌شود و rs=NaN؛ پیش از اصلاح، fillna(50) به‌اشتباه RSI را «خنثی=۵۰» نشان می‌داد
    درحالی‌که تعریفِ استاندارد RSI=۱۰۰ (اشباعِ خرید) است. این بر _technical_score
    اثر می‌گذاشت (۵۰→صعودی به‌جای ۱۰۰→نزولی/اشباع).
    """
    print("\n[۷.ب] رگرسیونِ حالتِ لبهٔ RSI (میانگینِ ضرر صفر)")
    import pandas as pd
    import indicators as ind
    up = pd.Series([float(x) for x in range(1, 40)])
    down = pd.Series([float(x) for x in range(40, 1, -1)])
    flat = pd.Series([7.0] * 40)
    ru = float(ind.rsi(up, 14).iloc[-1])
    rd = float(ind.rsi(down, 14).iloc[-1])
    rf = float(ind.rsi(flat, 14).iloc[-1])
    check("روندِ صعودیِ خالص → RSI ≈ ۱۰۰ (نه ۵۰)", ru >= 99.9, ru)
    check("روندِ نزولیِ خالص → RSI ≈ ۰", rd <= 0.1, rd)
    check("بازارِ تخت → RSI = ۵۰ (خنثی)", abs(rf - 50.0) < 1e-6, rf)
    # مقادیر همیشه در بازهٔ [۰,۱۰۰] و بدونِ NaN
    allv = list(ind.rsi(up, 14)) + list(ind.rsi(down, 14)) + list(ind.rsi(flat, 14))
    ok_range = all((v == v) and 0.0 <= v <= 100.0 for v in allv)
    check("همهٔ مقادیرِ RSI در [۰،۱۰۰] و بدونِ NaN", ok_range)


def t_symbol_resolution():
    """[۷] نگاشتِ نمادِ کارگزار → نمادِ داخلی (شاملِ پسوندهای کارگزار)."""
    print("\n[۷] نگاشتِ نمادِ کارگزار و حفظِ حجم در تقسیمِ پله‌ها")
    import mt5_bridge as mb
    import symbols as sym
    cases = {
        "XAUUSD": "XAU", "XAUUSDm": "XAU", "XAUUSD.r": "XAU", "GOLD": "XAU",
        "EURUSD": "EURUSD", "EURUSDm": "EURUSD", "GBPUSD": "GBPUSD",
        "USDJPY": "USDJPY", "BTCUSD": "BTC", "BTCUSDT": "BTC", "ETHUSD": "ETH",
        "US500": "SPX", "NAS100": "NASDAQ", "USTEC": "NASDAQ",
        "XTIUSD": "WTI", "USOIL": "WTI", "XAGUSD": "XAG", "SILVER": "XAG",
    }
    ok_all = True
    for broker, want in cases.items():
        got = mb.internal_for_broker(broker)
        if got != want or not sym.valid(got):
            ok_all = False
            print(f"       x {broker} -> {got!r} (want {want})")
    check("نمادهای کارگزار (با پسوند) درست به نمادِ داخلی نگاشت می‌شوند", ok_all, "")
    check("نمادِ پشتیبانی‌نشده (AUDUSD) نگاشتِ داخلی ندارد",
          mb.internal_for_broker("AUDUSD") == "", mb.internal_for_broker("AUDUSD"))

    class _Info:
        def __init__(self, vmin=0.01, vmax=100.0, vstep=0.01):
            self.volume_min = vmin; self.volume_max = vmax; self.volume_step = vstep
    vol_ok = True
    for vol, tps, mode, info in [
        (0.01, [1, 2, 3], "split", _Info()),
        (0.03, [1, 2, 3], "split", _Info()),
        (0.05, [1, 2, 3], "split", _Info()),
        (1.00, [1, 2, 3], "split", _Info()),
        (0.30, [1, 2, 3], "split", _Info(0.10, 100, 0.10)),
        # رگرسیونِ باگِ تورمِ حجم (کشف‌شده توسطِ fuzz): 0.25 با min=0.1/step=0.01
        # نباید به 0.3 برسد؛ باید کف بگیرد (۲ پله) نه گِرد (۳ پله).
        (0.25, [1, 2, 3], "split", _Info(0.10, 100, 0.01)),
        (0.25, [1, 2, 3], "partial", _Info(0.10, 100, 0.01)),
        (0.35, [1, 2, 3], "split", _Info(0.10, 100, 0.01)),
        (0.19, [1, 2, 3], "split", _Info(0.10, 100, 0.01)),
        (2.50, [1, 2, 3], "split", _Info(1.00, 100, 1.00)),
    ]:
        legs = mb._legs(vol, tps, mode, info)
        total = round(sum(v for v, _ in legs), 6)
        want = mb._norm_volume(info, vol)
        # مجموع نباید از حجمِ نرمال‌شده بیشتر شود (تورمِ حجم) و هر پله ≥ حداقلِ لات
        if total > want + 1e-9 or any(v < info.volume_min - 1e-9 for v, _ in legs):
            vol_ok = False
            print(f"       x vol={vol} -> legs={legs} sum={total} want={want}")
    check("تقسیمِ حجم بینِ پله‌ها مجموع را حفظ می‌کند (بدونِ تورمِ حجم)", vol_ok, "")


def t_robot_stats_source():
    """[۸] آمارِ رباتْ باید از همان منبعِ لاگ (SQLite) خوانده شود، نه فایلِ JSONِ بازنشسته."""
    print("\n[۸] هم‌منبع‌بودنِ آمارِ ربات با لاگِ ربات (رفعِ باگِ آمارِ صفر)")
    import robots
    before = robots.stats()
    robots.append_log({"symbol": "XAUUSD", "approved": True, "forwarded": True})
    robots.append_log({"symbol": "XAUUSD", "approved": False, "error": "تست"})
    after = robots.stats()
    # اصلاح (ROBOT-TAB-005): آمارِ total فقط رکوردهای «غیرآزمایشی» را می‌شمارد
    log_len = len([r for r in robots.read_log(1000) if not r.get("test")])
    check("stats().total با تعدادِ رکوردهای غیرآزمایشیِ لاگ هم‌خوان است",
          after["total"] == log_len, f"total={after['total']} log_len={log_len}")
    check("افزودنِ ۲ رکورد، total را ۲تا زیاد کرد (منبعِ زنده، نه فایلِ بازنشسته)",
          after["total"] == before["total"] + 2, f"{before['total']} -> {after['total']}")
    check("approved/forwarded/errors با افزودنِ رکوردها به‌روز شدند",
          after["approved"] >= before["approved"] + 1
          and after["forwarded"] >= before["forwarded"] + 1
          and after["errors"] >= before["errors"] + 1, after)


def t_trade_plan_contract():
    """[۱۰] نقشهٔ معامله باید همیشه ورود + ۱ استاپ + ۳ تیک‌پروفیتِ مجزا و مرتب بدهد،
    حتی وقتی ATR صفر/نامعتبر است (کندلِ تخت، نمادِ تازه، دادهٔ ناقص)."""
    print("\n[۱۰] قراردادِ نقشهٔ معامله (شاملِ ATRِ صفر/نامعتبر)")
    import engine

    def plan_ok(d, price, atr, sup, res):
        p = engine.build_trade_plan(d, price, atr, sup, res, 6.0, engine._dec(price))
        e = p.get("entry"); sl = p.get("stop_loss")
        tps = [t.get("price") if isinstance(t, dict) else t for t in (p.get("take_profits") or [])]
        if e is None or sl is None or len(tps) != 3:
            return False
        if len(set(tps)) != 3 or any(t == e for t in tps):
            return False  # تیک‌پروفیت‌ها نباید روی هم یا روی نقطهٔ ورود جمع شوند
        if d == "LONG":
            return sl < e < tps[0] < tps[1] < tps[2]
        return sl > e > tps[0] > tps[1] > tps[2]

    normal = all(plan_ok(d, 100.0, 2.0, [98, 96, 94], [102, 104, 106]) for d in ("LONG", "SHORT"))
    check("ATRِ عادی: ورود+۱ استاپ+۳ تیک‌پروفیتِ مرتب برای هر دو جهت", normal, "")

    degenerate = all([
        plan_ok("LONG", 100.0, 0.0, [98, 96, 94], [102, 104, 106]),
        plan_ok("SHORT", 100.0, 0.0, [], []),
        plan_ok("LONG", 3900.0, None, [], []),
        plan_ok("SHORT", 100.0, -5.0, [], []),
    ])
    check("ATRِ صفر/None/منفی: تیک‌پروفیت‌ها دیگر روی نقطهٔ ورود جمع نمی‌شوند (رفعِ باگ)", degenerate, "")


def t_test_button_dryrun():
    """[۱۲] دکمهٔ «آزمایش» (/api/robot/test) باید همیشه شبیه‌سازی باشد، نه معاملهٔ واقعی."""
    print("\n[۱۲] ایمنیِ دکمهٔ «آزمایش»: همیشه dry-run و بدونِ آلودنِ حافظهٔ داوری")
    global INTERNAL
    import signal_arbiter

    # مسیرِ آزمایش: باید تأیید و «شبیه‌سازی» شود و send_order با dry_run=True صدا بخورد
    # (conflict_guard روشن تا مسیرِ داوری/ثبتِ حافظه فعال باشد و تفاوتِ آزمایش/واقعی سنجیده شود)
    reset(robot_mode="internal", min_i=15, conflict_guard=True)
    signal_arbiter.reset()
    INTERNAL = {"direction": "LONG", "score": 50.0}
    r = robot_post({"symbol": "BTC", "direction": "BUY", "volume": 0.1,
                    "sl": 95, "tp": 110}, test=True).get_json()
    check("آزمایش: سفارش تأیید شد", r.get("approved") is True, r)
    check("آزمایش: پرچمِ simulated ست شد (نه معاملهٔ واقعی)", r.get("simulated") is True, r)
    check("آزمایش: send_order با dry_run=True صدا خورد",
          bool(SENT) and SENT[-1].get("dry_run") is True, SENT)
    # نباید حافظهٔ «ارسالِ اخیر» را آلوده کند (وگرنه سیگنالِ واقعیِ بعدی رد می‌شود)
    check("آزمایش: حافظهٔ داوری آلوده نشد (recent تهی است)",
          signal_arbiter.recent("BTC", 999) is None, "recent باید None باشد")

    # مسیرِ واقعی: باید dry_run=False باشد و حافظهٔ اخیر را ثبت کند
    reset(robot_mode="internal", min_i=15, conflict_guard=True)
    signal_arbiter.reset()
    INTERNAL = {"direction": "LONG", "score": 50.0}
    r = robot_post({"symbol": "BTC", "direction": "BUY", "volume": 0.1,
                    "sl": 95, "tp": 110}, test=False).get_json()
    check("واقعی: forwarded=True و simulated نیست", r.get("forwarded") is True and not r.get("simulated"), r)
    check("واقعی: send_order با dry_run=False صدا خورد",
          bool(SENT) and SENT[-1].get("dry_run") is False, SENT)
    check("واقعی: حافظهٔ داوری ثبت شد (recent موجود)",
          signal_arbiter.recent("BTC", 999) is not None, "recent باید موجود باشد")
    signal_arbiter.reset()


def t_schedule_and_resolver():
    """[۱۱] زمان‌بندیِ شب‌گذر + نگاشتِ نمادِ کارگزار بدونِ تطبیقِ نادرست."""
    print("\n[۱۱] زمان‌بندیِ شب‌گذر و ایمنیِ نگاشتِ نماد")
    import schedule_hours as sh
    cfg = {"enabled": True, "on1": "22:00", "off1": "06:00", "on2": "08:00", "off2": "16:00"}
    exp = [(23, 0, True), (2, 0, True), (5, 59, True), (6, 0, False), (7, 0, False),
           (8, 0, True), (15, 59, True), (16, 0, False), (20, 0, False), (22, 0, True)]
    ok = all(sh.is_active(hh * 60 + mm, cfg)["active"] == e for hh, mm, e in exp)
    check("بازهٔ کاریِ شب‌گذر (۲۲:۰۰–۰۶:۰۰) درست ارزیابی می‌شود", ok, "")

    import mt5_bridge as mb
    # هیچ‌کدام از این نمادهای پشتیبانی‌نشده نباید به نمادِ اشتباه نگاشت شوند
    must_empty = ["USDCHF", "USDCAD", "AUDUSD", "NZDUSD", "EURGBP", "EURJPY",
                  "US30", "GER40", "UK100", "JP225", "XAUEUR", "BTCEUR", "ETHBTC"]
    no_mismap = all(mb.internal_for_broker(s) == "" for s in must_empty)
    check("نمادهای پشتیبانی‌نشده به نمادِ اشتباه نگاشت نمی‌شوند (بدونِ mis-map)",
          no_mismap, {s: mb.internal_for_broker(s) for s in must_empty if mb.internal_for_broker(s)})
    # و نمادهای پشتیبانی‌شده باید درست نگاشت شوند
    good = {"XAUUSD": "XAU", "EURUSD": "EURUSD", "US500": "SPX",
            "NAS100": "NASDAQ", "BTCUSD": "BTC", "USOIL": "WTI"}
    all_good = all(mb.internal_for_broker(s) == w for s, w in good.items())
    check("نمادهای پشتیبانی‌شده درست نگاشت می‌شوند", all_good, "")


def t_news_currencies():
    """[۹] نگاشتِ نماد→ارز برای فیلترِ اخبار باید پسوندهای کارگزار را هم بپوشاند."""
    print("\n[۹] نگاشتِ نماد به ارزهای مرتبط برای فیلترِ اخبار")
    import news
    cases = {
        "EURUSD": ["EUR", "USD"], "EURUSDm": ["EUR", "USD"],
        "EURUSD.r": ["EUR", "USD"], "GBPUSDm": ["GBP", "USD"],
        "USDJPY.pro": ["USD", "JPY"], "XAUUSD": ["USD"], "XAG": ["USD"],
    }
    ok = all(news.currencies_for(s) == w for s, w in cases.items())
    check("جفت‌ارزهای کارگزار (با پسوند) به هر دو ارز نگاشت می‌شوند (اخبار از قلم نمی‌افتد)",
          ok, {s: news.currencies_for(s) for s in cases})


def t_silent_failures():
    """[۱۰] شکستِ خاموش: وقتی تقویمِ اخبار/ساعتِ سرور در دسترس نیست."""
    print("\n[۱۰] شکستِ خاموشِ فیلترها (اخبار/زمان‌بندی در دسترس نیست)")
    global INTERNAL, NEWS_BLOCK
    import server_log

    # --- واحد: _eval_news_gate در حالتِ «تقویم در دسترس نیست» (error) ---
    NEWS_BLOCK = {"blocked": False, "error": "کلندر ۴۲۹"}
    g_open = app._eval_news_gate(
        "BTC", {"news_filter_enabled": True, "news_fail_closed": False}, "test")
    check("gate fail-open: blocked=False ولی inoperative=True (شکست دیگر پنهان نیست)",
          g_open["blocked"] is False and g_open["inoperative"] is True, g_open)
    g_closed = app._eval_news_gate(
        "BTC", {"news_filter_enabled": True, "news_fail_closed": True}, "test")
    check("gate fail-closed: blocked=True (معاملهٔ محتاطانه مسدود)",
          g_closed["blocked"] is True and g_closed["inoperative"] is True, g_closed)

    # --- واحد: استثنا هنگام فراخوانیِ فیلترِ اخبار ---
    def _boom(*a, **k):
        raise RuntimeError("net down")
    app.news.is_blocked = _boom
    g_exc = app._eval_news_gate(
        "BTC", {"news_filter_enabled": True, "news_fail_closed": True}, "test")
    check("gate استثنا + fail-closed → blocked=True و inoperative=True",
          g_exc["blocked"] is True and g_exc["inoperative"] is True, g_exc)
    g_exc_open = app._eval_news_gate(
        "BTC", {"news_filter_enabled": True, "news_fail_closed": False}, "test")
    check("gate استثنا + fail-open → blocked=False ولی inoperative=True",
          g_exc_open["blocked"] is False and g_exc_open["inoperative"] is True, g_exc_open)
    app.news.is_blocked = mock_news_blocked  # بازگردانی

    # --- انتها-به-انتها روی مسیرِ ربات: تقویم down، حالتِ fail-open ---
    reset(robot_mode="internal", robot_match=False, min_i=0)
    dispatch.save_config({"news_fail_closed": False})
    NEWS_BLOCK = {"blocked": False, "error": "کلندر ۴۲۹"}
    INTERNAL = {"direction": "LONG", "score": 50.0}
    w0 = server_log.stats().get("warn", 0)
    r = robot_post({"symbol": "BTC", "direction": "BUY", "volume": 0.1},
                   test=False).get_json()
    w1 = server_log.stats().get("warn", 0)
    check("fail-open: سفارش با وجودِ نبودِ تقویم ارسال شد", r.get("forwarded") is True, r)
    check("fail-open: هشدارِ «فیلترِ اخبار در دسترس نبود» در لاگ ثبت شد (دیگر خاموش نیست)",
          w1 > w0, (w0, w1))
    reasons = " ".join((r.get("eval") or {}).get("reasons", []))
    check("fail-open: در evalِ سفارش، غیرفعال‌بودنِ فیلتر نمایان است",
          "در دسترس" in reasons, reasons)

    # --- fail-closed: همان سناریو باید مسدود شود ---
    reset(robot_mode="internal", robot_match=False, min_i=0)
    dispatch.save_config({"news_fail_closed": True})
    NEWS_BLOCK = {"blocked": False, "error": "کلندر ۴۲۹"}
    INTERNAL = {"direction": "LONG", "score": 50.0}
    r2 = robot_post({"symbol": "BTC", "direction": "BUY", "volume": 0.1},
                    test=False).get_json()
    check("fail-closed: سفارش مسدود شد (forwarded=False)",
          r2.get("forwarded") is False, r2)
    dispatch.save_config({"news_fail_closed": False})

    # --- زمان‌بندی: ساعتِ سرور نامشخص (unknown) ---
    def _gate_unknown():
        return (True, {"enabled": True, "active": True, "unknown": True,
                       "broker_time": "", "reason": "ساعتِ سرور در دسترس نیست"})
    app._program_gate = _gate_unknown
    # fail-open: عبور می‌کند ولی هشدار می‌دهد
    reset(robot_mode="internal", robot_match=False, min_i=0)
    dispatch.save_config({"schedule_fail_closed": False})
    NEWS_BLOCK = {"blocked": False}
    INTERNAL = {"direction": "LONG", "score": 50.0}
    w0 = server_log.stats().get("warn", 0)
    r3 = robot_post({"symbol": "BTC", "direction": "BUY", "volume": 0.1},
                    test=False).get_json()
    w1 = server_log.stats().get("warn", 0)
    check("زمان‌بندیِ نامشخص fail-open: سفارش عبور کرد و هشدار ثبت شد",
          r3.get("forwarded") is True and w1 > w0, (r3.get("forwarded"), w0, w1))
    # fail-closed: مسدود
    reset(robot_mode="internal", robot_match=False, min_i=0)
    dispatch.save_config({"schedule_fail_closed": True})
    NEWS_BLOCK = {"blocked": False}
    INTERNAL = {"direction": "LONG", "score": 50.0}
    r4 = robot_post({"symbol": "BTC", "direction": "BUY", "volume": 0.1},
                    test=False).get_json()
    check("زمان‌بندیِ نامشخص fail-closed: سفارش مسدود شد",
          r4.get("forwarded") is False, r4)
    dispatch.save_config({"schedule_fail_closed": False})
    app._program_gate = mock_program_gate  # بازگردانی


def t_position_guard_failopen():
    """[۱۱] شکستِ خاموشِ محافظِ پوزیشنِ باز (متاتریدر هست ولی خواندنِ پوزیشن‌ها ناموفق)."""
    print("\n[۱۱] شکستِ خاموشِ محافظِ پوزیشنِ باز (خواندنِ پوزیشن ناموفق)")
    global INTERNAL
    import server_log

    orig_avail = getattr(app.mt5_bridge, "MT5_AVAILABLE", False)
    orig_pos = app.mt5_bridge.positions
    try:
        # متاتریدر «هست» ولی خواندنِ پوزیشن‌ها خطا می‌دهد → محافظ عملاً دور زده می‌شود
        app.mt5_bridge.MT5_AVAILABLE = True
        app.mt5_bridge.positions = lambda magic_only=True: {"ok": False, "error": "خطای خواندنِ پوزیشن"}

        # --- fail-open (پیش‌فرض): عبور می‌کند ولی هشدار ثبت می‌شود ---
        reset(robot_mode="internal", robot_match=False, min_i=0, conflict_guard=True)
        robots.save_config({"position_guard_fail_closed": False})
        INTERNAL = {"direction": "LONG", "score": 50.0}
        w0 = server_log.stats().get("warn", 0)
        r = robot_post({"symbol": "BTC", "direction": "BUY", "volume": 0.1},
                       test=False).get_json()
        w1 = server_log.stats().get("warn", 0)
        check("fail-open: با نبودِ امکانِ خواندنِ پوزیشن، سفارش ارسال شد", r.get("forwarded") is True, r)
        check("fail-open: هشدارِ «محافظِ پوزیشنِ باز اعمال نشد» ثبت شد (خاموش نیست)", w1 > w0, (w0, w1))

        # --- fail-closed: همان حالت باید مسدود شود ---
        reset(robot_mode="internal", robot_match=False, min_i=0, conflict_guard=True)
        robots.save_config({"position_guard_fail_closed": True})
        INTERNAL = {"direction": "LONG", "score": 50.0}
        r2 = robot_post({"symbol": "BTC", "direction": "BUY", "volume": 0.1},
                        test=False).get_json()
        check("fail-closed: سفارش محتاطانه مسدود شد (forwarded=False)", r2.get("forwarded") is False, r2)
        check("fail-closed: علتِ مسدودی «نامشخص‌بودنِ پوزیشن» است",
              bool(r2.get("arb_blocked")) or "پوزیشن" in " ".join((r2.get("eval") or {}).get("reasons", [])), r2)

        # --- وقتی متاتریدر اصلاً در دسترس نیست (حالتِ عادیِ «فقط‌ربات») → بدونِ هشدار/مسدودی ---
        app.mt5_bridge.MT5_AVAILABLE = False
        reset(robot_mode="internal", robot_match=False, min_i=0, conflict_guard=True)
        robots.save_config({"position_guard_fail_closed": True})
        INTERNAL = {"direction": "LONG", "score": 50.0}
        w0 = server_log.stats().get("warn", 0)
        r3 = robot_post({"symbol": "BTC", "direction": "BUY", "volume": 0.1},
                        test=False).get_json()
        w1 = server_log.stats().get("warn", 0)
        check("MT5-نصب‌نشده: fail-closed مانع نمی‌شود (محافظِ درون‌فرایندی موضوعیت ندارد)",
              r3.get("forwarded") is True, r3)
        check("MT5-نصب‌نشده: هشدارِ اضافیِ محافظِ پوزیشن ثبت نمی‌شود (بدونِ اسپمِ لاگ)",
              w1 == w0, (w0, w1))
    finally:
        app.mt5_bridge.MT5_AVAILABLE = orig_avail
        app.mt5_bridge.positions = orig_pos


def main():
    global client
    # اصلاح (TEST-CFG-001): بکاپ/بازگردانیِ کانفیگ‌هایی که این سوئیت تغییر می‌دهد.
    import shutil, os, atexit
    _dir = os.path.dirname(os.path.abspath(__file__))
    for _i, _name in enumerate(("mt5_config.json", "dispatch_config.json",
                                "robot_config.json")):
        _p = os.path.join(_dir, _name)
        if os.path.exists(_p):
            _b = f"/tmp/sigflow_cfg_{_i}.bak"
            shutil.copy(_p, _b)
            atexit.register(shutil.copy, _b, _p)
    app.app.config["TESTING"] = True
    client = app.app.test_client()
    install_mocks()
    print("=" * 60)
    print(" تستِ عمیقِ مسیرهای ارسالِ سیگنال به متاتریدر ۵")
    print("=" * 60)
    t_internal()
    t_ai_and_vote()
    t_robot()
    t_filters()
    t_conflict_guard()
    t_send_order_news()
    t_tf_normalization()
    t_rsi_edge_cases()
    t_symbol_resolution()
    t_robot_stats_source()
    t_trade_plan_contract()
    t_test_button_dryrun()
    t_schedule_and_resolver()
    t_news_currencies()
    t_silent_failures()
    t_position_guard_failopen()
    print("\n" + "=" * 60)
    print(f"  نتیجه: {PASS} پاس · {FAIL} ناموفق")
    print("=" * 60)
    # بازگرداندنِ کانفیگ به پیش‌فرضِ امن
    dispatch.save_config({"program_enabled": False, "program_source": "internal"})
    robots.save_config({"filter_mode": "both", "enabled": True, "shared_secret": "",
                        "auto_forward": True, "dedupe_window_sec": 60.0,
                        "aggregate_window_sec": 2.0})
    sys.exit(1 if FAIL else 0)


if __name__ == "__main__":
    main()
