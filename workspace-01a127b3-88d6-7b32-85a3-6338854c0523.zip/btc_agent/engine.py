"""موتور تحلیل: ترکیب تکنیکال + فاندامنتال + سنتیمنتال و ساخت سیگنال معاملاتی.

خروجی شامل: جهت (لانگ/شورت/خنثی)، نقطه ورود، سه تیک‌پروفیت، استاپ‌لاس،
امتیاز هر بخش و توضیحات هر سیگنال. مبنای حد سود/ضرر ترکیبی از ATR و سطوح S/R است.
"""
from __future__ import annotations
import math
import numpy as np
import pandas as pd   # OP5-ENG-HTF: نرمال‌سازیِ ستونِ close در htf_trend_dir
from datetime import datetime, timezone
from concurrent.futures import ThreadPoolExecutor

import indicators as ind
import data_sources as ds
import symbols as sym
import market_hours as mh
import ai_bridge as ai

# executorِ مشترک برای دریافتِ موازیِ کندل/فاندامنتال/سنتیمنت (I/O bound)
_IO_POOL = ThreadPoolExecutor(max_workers=48, thread_name_prefix="io")


def _r(x, d=1):
    try:
        return round(float(x), d)
    except Exception:  # noqa
        return None


def _dec(price):
    """تعداد ارقام اعشار مناسب بر اساس بزرگی قیمت (طلا/بیت‌کوین کم، یورو/دوج زیاد).

    به منبعِ حقیقتِ واحدِ indicators.price_decimals واگذار می‌شود تا رفتارِ اعشارِ
    نقشهٔ معامله دقیقاً با گِرد کردنِ سطوحِ اندیکاتورها و بک‌تست یکسان بماند.
    """
    return ind.price_decimals(price)


# جدولِ وزن‌های تکنیکال — «منبعِ حقیقتِ واحد» (اصلاحِ OP5-ENG-SCALE / R3).
# موتورِ زنده و بک‌تست هر دو از همین جدول استفاده می‌کنند تا مقیاسِ امتیاز
# (-100..100) یکی باشد و آستانه‌های بهینه‌ساز قابلِ انتقال به اجرای زنده باشند.
TECH_WEIGHTS = {
    "ema_trend": 1.5,   # روند EMA20/50
    "ema200": 0.8,      # بایاس بلندمدت
    "rsi": 1.0,         # RSI(14)
    "macd": 1.0,        # MACD histogram
    "stoch": 0.6,       # Stochastic %K
    "bollinger": 0.5,   # بولینگر
    "adx": 1.0,         # ADX + DI
    "ichimoku": 1.2,    # ابر کومو
    "fib": 1.0,         # فیبوناچیِ موج تأییدشده
    "zones": 0.8,       # نواحیِ حمایت/مقاومت
    "pivot": 0.7,       # پیوتِ کلاسیک
    "daily": 0.6,       # سقف/کفِ روزِ قبل
    "trendline": 0.9,   # تِرندلاین
    "liquidity": 0.8,   # لیکوئیدیتی / جارو
    "fvg": 0.8,         # گپِ ارزشِ منصفانه
    "structure": 1.2,   # ساختارِ بازار (BOS/CHOCH)
}
TECH_MAX_WEIGHT = round(sum(TECH_WEIGHTS.values()), 2)   # = 14.4
HTF_WEIGHT = 2.0                                          # وزنِ اختیاریِ تاییدیهٔ تایم‌فریمِ بالاتر


# ---------------------------------------------------------------- تکنیکال
def htf_trend_dir(df):
    """جهتِ روندِ تایم‌فریمِ بالاتر بر پایهٔ EMA20/50 (۱ صعودی، −۱ نزولی، ۰ خنثی).

    برای معیارِ «تاییدیهٔ تایم‌فریم بالاتر» استفاده می‌شود؛ همان منطقِ معیارِ روندِ EMA
    ولی روی دادهٔ تایم‌فریمِ بزرگ‌تر.
    """
    # جایگزینِ کاملِ ممیزی (OP5-ENG-HTF): با کمتر از ۵۰ کندل، EMA50 «جعلی» است و
    # می‌تواند تأییدیهٔ تایم‌فریمِ بالاترِ بی‌معنا بسازد؛ همچنین قیمتِ NaN باید بی‌صدا
    # خنثی شود (۰) نه اینکه عددِ نامعتبر تولید کند.
    try:
        if df is None or len(df) < 50:
            return 0
        close = pd.to_numeric(df["close"], errors="coerce").astype(float)
        if not np.isfinite(close.iloc[-1]):
            return 0
        e20 = ind.ema(close, 20).iloc[-1]
        e50 = ind.ema(close, 50).iloc[-1]
        if not np.isfinite(e20) or not np.isfinite(e50):
            return 0
        return 1 if close.iloc[-1] > e50 and e20 > e50 else \
            -1 if close.iloc[-1] < e50 and e20 < e50 else 0
    except (KeyError, TypeError, ValueError, IndexError):
        return 0


def analyze_technical(df, htf_dir=None, htf_label=""):
    close = df["close"]
    price = float(close.iloc[-1])

    ema20 = ind.ema(close, 20)
    ema50 = ind.ema(close, 50)
    # اصلاح (ENG-002): با دادهٔ کمتر از ۲۰۰ کندل، EMAِ کوتاه‌تر «پراکسی» است و باید
    # در برچسبِ سیگنال اعلام شود تا کاربر آن را EMA200 واقعی تصور نکند.
    _ema200_proxy = len(close) < 200
    ema200 = ind.ema(close, 200) if not _ema200_proxy else ind.ema(close, min(len(close) - 1, 100))
    rsi = ind.rsi(close, 14)
    macd_line, signal_line, hist = ind.macd(close)
    up, mid, low = ind.bollinger(close)
    atr = ind.atr(df, 14)
    k, d = ind.stochastic(df)
    adx_s, plus_di, minus_di = ind.adx(df, 14)
    tenkan, kijun, senkou_a, senkou_b = ind.ichimoku(df)
    supports, resistances = ind.swing_levels(df)
    fib = ind.fibonacci_levels(df)
    # سیاستِ صریحِ NA (اصلاحِ OP5-IND-01/02/03): اندیکاتورهای وایلدری در دورهٔ
    # گرم‌شدن NaN برمی‌گردانند؛ این‌جا یک مرزِ واحد، مقدارِ آخرِ هر سری را «معتبرسازی»
    # می‌کند تا NaN به امتیاز/JSON/نقشهٔ معامله نشت نکند.
    def _last_ok(series, fallback):
        try:
            v = float(series.iloc[-1])
        except (TypeError, ValueError, IndexError):
            return fallback
        return v if math.isfinite(v) else fallback

    _rsi_na = not math.isfinite(_last_ok(rsi, float("nan")))
    _adx_na = not math.isfinite(_last_ok(adx_s, float("nan")))
    _tr_floor = float((df["high"] - df["low"]).tail(14).mean() or 0.0)
    _atr_last = _last_ok(atr, _tr_floor)
    _atr_na = not math.isfinite(_last_ok(atr, float("nan")))
    srz = ind.sr_zones(df, merge_atr=_atr_last)
    piv = ind.pivot_points(df)
    dly = ind.daily_levels(df)
    trl = ind.trendline(df)
    liq = ind.liquidity(df, atr=_atr_last)
    fvg = ind.fair_value_gaps(df)
    mst = ind.market_structure(df)

    signals = []      # (label, value, +1/0/-1, note)
    score = 0.0

    # روند EMA
    e20, e50, e200 = ema20.iloc[-1], ema50.iloc[-1], ema200.iloc[-1]
    if price > e50 and e20 > e50:
        trend, tdir = "صعودی", 1
    elif price < e50 and e20 < e50:
        trend, tdir = "نزولی", -1
    else:
        trend, tdir = "خنثی", 0
    score += tdir * TECH_WEIGHTS["ema_trend"]
    signals.append({"name": "روند (EMA 20/50)", "value": trend, "dir": tdir,
                    "note": f"قیمت {'بالای' if price>e50 else 'زیر'} EMA50"})

    # EMA200
    d200 = 1 if price > e200 else -1
    score += d200 * TECH_WEIGHTS["ema200"]
    _l200 = "EMA200" if not _ema200_proxy else "EMA بلند (پراکسی EMA200)"
    signals.append({"name": f"روند بلندمدت ({_l200})", "value": f"بالای {_l200}" if d200 > 0 else f"زیر {_l200}",
                    "dir": d200,
                    "note": "بایاس کلی" if not _ema200_proxy
                            else "دادهٔ کمتر از ۲۰۰ کندل؛ EMA کوتاه‌تر جایگزین شد"})

    # RSI
    rv = _last_ok(rsi, 50.0)
    if _rsi_na:
        rdir, rnote = 0, "دادهٔ کافی برای گرم‌شدنِ RSI نیست (خنثی)"
    elif rv < 30:
        rdir, rnote = 1, "اشباع فروش"
    elif rv > 70:
        rdir, rnote = -1, "اشباع خرید"
    elif rv >= 50:
        rdir, rnote = 1, "متمایل به صعود"
    else:
        rdir, rnote = -1, "متمایل به نزول"
    score += rdir * TECH_WEIGHTS["rsi"]
    signals.append({"name": "RSI (14)", "value": _r(rv), "dir": rdir, "note": rnote})

    # MACD
    mdir = 1 if hist.iloc[-1] > 0 else -1
    cross = ""
    if hist.iloc[-1] > 0 and hist.iloc[-2] <= 0:
        cross = " (کراس صعودی تازه)"
        mdir = 1
    elif hist.iloc[-1] < 0 and hist.iloc[-2] >= 0:
        cross = " (کراس نزولی تازه)"
        mdir = -1
    score += mdir * TECH_WEIGHTS["macd"]
    signals.append({"name": "MACD", "value": "مثبت" if hist.iloc[-1] > 0 else "منفی",
                    "dir": mdir, "note": f"هیستوگرام {_r(hist.iloc[-1],1)}{cross}"})

    # Stochastic
    kv = k.iloc[-1]
    if kv < 20:
        sdir, snote = 1, "اشباع فروش"
    elif kv > 80:
        sdir, snote = -1, "اشباع خرید"
    else:
        sdir, snote = (1 if kv > d.iloc[-1] else -1), "خنثی"
    score += sdir * TECH_WEIGHTS["stoch"]
    signals.append({"name": "Stochastic %K", "value": _r(kv), "dir": sdir, "note": snote})

    # Bollinger
    if price <= low.iloc[-1]:
        bdir, bnote = 1, "برخورد باند پایین"
    elif price >= up.iloc[-1]:
        bdir, bnote = -1, "برخورد باند بالا"
    else:
        bdir, bnote = 0, "داخل باند"
    score += bdir * TECH_WEIGHTS["bollinger"]
    signals.append({"name": "Bollinger Bands", "value": bnote, "dir": bdir,
                    "note": f"{_r(low.iloc[-1])} تا {_r(up.iloc[-1])}"})

    # ADX (قدرت روند) + DI
    adx_v = _last_ok(adx_s, 0.0)
    if _adx_na:
        adir, anote = 0, "دادهٔ کافی برای ADX نیست (خنثی)"
    elif adx_v >= 20:
        adir = 1 if _last_ok(plus_di, 0.0) > _last_ok(minus_di, 0.0) else -1
        anote = f"روند قوی ({'صعودی' if adir>0 else 'نزولی'})"
    else:
        adir, anote = 0, "روند ضعیف/رنج"
    score += adir * TECH_WEIGHTS["adx"]
    signals.append({"name": "ADX (14)", "value": _r(adx_v, 1), "dir": adir, "note": anote})

    # Ichimoku (ابر کومو)
    price_now = price
    sa, sb = senkou_a.iloc[-1], senkou_b.iloc[-1]
    if not (np.isnan(sa) or np.isnan(sb)):
        cloud_top, cloud_bot = max(sa, sb), min(sa, sb)
        if price_now > cloud_top and tenkan.iloc[-1] > kijun.iloc[-1]:
            idir, inote = 1, "بالای ابر (صعودی)"
        elif price_now < cloud_bot and tenkan.iloc[-1] < kijun.iloc[-1]:
            idir, inote = -1, "زیر ابر (نزولی)"
        elif price_now > cloud_top:
            idir, inote = 1, "بالای ابر"
        elif price_now < cloud_bot:
            idir, inote = -1, "زیر ابر"
        else:
            idir, inote = 0, "داخل ابر (بلاتکلیف)"
    else:
        idir, inote = 0, "داده ناکافی"
    score += idir * TECH_WEIGHTS["ichimoku"]
    signals.append({"name": "Ichimoku", "value": inote, "dir": idir,
                    "note": f"تنکان/کیجون: {_r(tenkan.iloc[-1],1)}/{_r(kijun.iloc[-1],1)}"})

    # فیبوناچی (اصلاح/گسترش بر مبنای آخرین موجِ مهم)
    if fib.get("available"):
        pr = fib["pos_ratio"]
        pct = int(round(pr * 100))
        if fib["direction"] == "up":
            fval = f"موج صعودی · اصلاح ٪{pct}"
            if 0.382 <= pr <= 0.786:
                fdir = 1
                fnote = ("پول‌بک در ناحیهٔ طلایی (فرصت خرید)" if fib["in_golden"]
                         else "پول‌بک در ناحیهٔ فیبو (متمایل به خرید)")
            elif pr < 0.382:
                fdir = 1
                fnote = "نزدیک سقفِ موج (ادامهٔ روندِ صعودی)"
            else:  # pr > 0.786 → شکستِ ساختارِ صعودی
                fdir = -1
                fnote = "شکست زیر ۰٫۷۸۶ (ضعفِ ساختارِ صعودی)"
        else:
            fval = f"موج نزولی · اصلاح ٪{pct}"
            if 0.382 <= pr <= 0.786:
                fdir = -1
                fnote = ("پول‌بک در ناحیهٔ طلایی (فرصت فروش)" if fib["in_golden"]
                         else "پول‌بک در ناحیهٔ فیبو (متمایل به فروش)")
            elif pr < 0.382:
                fdir = -1
                fnote = "نزدیک کفِ موج (ادامهٔ روندِ نزولی)"
            else:  # pr > 0.786 → شکستِ ساختارِ نزولی
                fdir = 1
                fnote = "شکست بالای ۰٫۷۸۶ (ضعفِ ساختارِ نزولی)"
    else:
        fdir, fval, fnote = 0, "-", "دادهٔ کافی برای موج نیست"
    score += fdir * TECH_WEIGHTS["fib"]
    signals.append({"name": "فیبوناچی", "value": fval, "dir": fdir,
                    "note": fnote + (f" · سقف/کف موج {_r(fib.get('swing_high'),1)}/{_r(fib.get('swing_low'),1)}"
                                     if fib.get("available") else "")})

    atr_last = _atr_last

    # --- نواحیِ حمایت/مقاومت (Zones) ---
    sdir, sval, snote = 0, "-", "بدون ناحیهٔ نزدیک"
    if srz.get("available"):
        near_sup = srz["supports"][0] if srz["supports"] else None
        near_res = srz["resistances"][0] if srz["resistances"] else None
        # نکته: از نام‌های dsu/dru استفاده می‌کنیم تا ماژولِ «data_sources as ds» را سایه نزنند.
        dsu = abs(price - near_sup["price"]) if near_sup else 1e18
        dru = abs(near_res["price"] - price) if near_res else 1e18
        thr = 0.6 * atr_last if atr_last else price * 0.003
        if dsu <= thr and dsu <= dru:
            sdir = 1
            sval = f"نزدیکِ حمایت {_r(near_sup['price'],1)}"
            snote = f"قدرتِ ناحیه {near_sup['strength']}"
        elif dru <= thr:
            sdir = -1
            sval = f"نزدیکِ مقاومت {_r(near_res['price'],1)}"
            snote = f"قدرتِ ناحیه {near_res['strength']}"
        else:
            sval = (f"S:{_r(near_sup['price'],1) if near_sup else '—'} / "
                    f"R:{_r(near_res['price'],1) if near_res else '—'}")
            snote = "قیمت بینِ نواحی"
    score += sdir * TECH_WEIGHTS["zones"]
    signals.append({"name": "نواحیِ حمایت/مقاومت", "value": sval, "dir": sdir, "note": snote})

    # --- پیوت‌ها (کلاسیک) ---
    pdir, pval, pnote = 0, "-", "دادهٔ پیوت ناکافی"
    if piv.get("available"):
        P = piv["P"]
        pdir = 1 if price > P else -1
        pval = f"{'بالای' if pdir > 0 else 'زیرِ'} پیوت {_r(P,1)}"
        pnote = f"R1 {_r(piv['R1'],1)} · S1 {_r(piv['S1'],1)} ({piv['basis']})"
    score += pdir * TECH_WEIGHTS["pivot"]
    signals.append({"name": "پیوت (کلاسیک)", "value": pval, "dir": pdir, "note": pnote})

    # --- سقف/کفِ روزِ قبل (PDH/PDL) ---
    ddir, dval, dnote = 0, "-", "دادهٔ روزانه ناکافی"
    if dly.get("available"):
        pdh, pdl = dly["pdh"], dly["pdl"]
        if price > pdh:
            ddir, dval, dnote = 1, f"شکست بالای PDH {_r(pdh,1)}", "بریک‌اوتِ صعودی"
        elif price < pdl:
            ddir, dval, dnote = -1, f"شکست زیر PDL {_r(pdl,1)}", "بریک‌داونِ نزولی"
        else:
            dval, dnote = "داخلِ بازهٔ دیروز", f"PDH {_r(pdh,1)} · PDL {_r(pdl,1)}"
    score += ddir * TECH_WEIGHTS["daily"]
    signals.append({"name": "سقف/کفِ روزِ قبل", "value": dval, "dir": ddir, "note": dnote})

    # --- تِرندلاین ---
    tldir, tlval, tlnote = 0, "-", ""
    if trl.get("available"):
        tlval = trl.get("note", "-")
        if trl.get("broken") == "resistance":
            tldir = 1
        elif trl.get("broken") == "support":
            tldir = -1
        elif trl.get("direction") == "صعودی":
            tldir = 1
        elif trl.get("direction") == "نزولی":
            tldir = -1
        sl_ = trl.get("support") or {}
        rs_ = trl.get("resistance") or {}
        tlnote = f"خطِ حمایت≈{_r(sl_.get('value'),1)} / مقاومت≈{_r(rs_.get('value'),1)}"
    score += tldir * TECH_WEIGHTS["trendline"]
    signals.append({"name": "تِرندلاین", "value": tlval, "dir": tldir, "note": tlnote})

    # --- لیکوئیدیتی (نقدینگی + جاروی نقدینگی) ---
    ldir, lval, lnote = 0, "بدونِ جارو", ""
    if liq.get("available"):
        sw = liq.get("sweep")
        if sw and sw["type"] == "sellside":
            ldir, lval, lnote = 1, f"جاروی نقدینگیِ کف {_r(sw['price'],1)}", "استاپ‌هانت → صعودی"
        elif sw and sw["type"] == "buyside":
            ldir, lval, lnote = -1, f"جاروی نقدینگیِ سقف {_r(sw['price'],1)}", "استاپ‌هانت → نزولی"
        else:
            bs = liq.get("buy_side") or []
            ss = liq.get("sell_side") or []
            lval = "نقدینگیِ فعال"
            lnote = (f"بالا: {'، '.join(str(_r(x,1)) for x in bs) or '—'} · "
                     f"پایین: {'، '.join(str(_r(x,1)) for x in ss) or '—'}")
    score += ldir * TECH_WEIGHTS["liquidity"]
    signals.append({"name": "لیکوئیدیتی", "value": lval, "dir": ldir, "note": lnote})

    # --- FVG (گپِ ارزشِ منصفانه / عدمِ‌تعادل) ---
    gdir, gval, gnote = 0, "بدونِ گپِ فعال", ""
    if fvg.get("available"):
        ns = fvg.get("nearest_support")
        nr = fvg.get("nearest_resistance")
        if ns and not nr:
            gdir, gval, gnote = 1, f"FVG صعودی زیرِ قیمت {_r(ns['mid'],1)}", "حمایتِ عدمِ‌تعادل"
        elif nr and not ns:
            gdir, gval, gnote = -1, f"FVG نزولی بالای قیمت {_r(nr['mid'],1)}", "مقاومتِ عدمِ‌تعادل"
        elif ns and nr:
            if abs(price - ns["top"]) <= abs(nr["bottom"] - price):
                gdir, gval, gnote = 1, f"FVG صعودی نزدیک {_r(ns['mid'],1)}", "حمایتِ عدمِ‌تعادل"
            else:
                gdir, gval, gnote = -1, f"FVG نزولی نزدیک {_r(nr['mid'],1)}", "مقاومتِ عدمِ‌تعادل"
        else:
            nb = len(fvg.get("bullish") or [])
            nbe = len(fvg.get("bearish") or [])
            gval = f"گپ‌های باز: {nb} صعودی / {nbe} نزولی"
    score += gdir * TECH_WEIGHTS["fvg"]
    signals.append({"name": "FVG (عدمِ‌تعادل)", "value": gval, "dir": gdir, "note": gnote})

    # --- ساختارِ بازار: BOS (شکستِ ساختار) و CHOCH (تغییرِ کاراکتر) ---
    msdir, msval, msnote, ms_contrib = 0, "-", "", 0.0
    if mst.get("available"):
        ev = mst.get("event")
        trfa = {"up": "صعودی", "down": "نزولی", "range": "رِنج"}.get(mst.get("trend"), "?")
        if ev == "BOS":
            msdir = mst["dir"]
            ms_contrib = TECH_WEIGHTS["structure"] * mst["dir"]         # شکستِ ساختار = سیگنالِ قویِ ادامهٔ روند
            msval = f"BOS {'صعودی' if mst['dir'] > 0 else 'نزولی'}"
        elif ev == "CHOCH":
            msdir = mst["dir"]
            ms_contrib = 0.7 * mst["dir"]  # رویدادِ CHOCH وزنِ سبک‌ترِ خودش را دارد         # تغییرِ کاراکتر = هشدار (وزنِ کمتر)
            msval = f"CHOCH {'صعودی' if mst['dir'] > 0 else 'نزولی'}"
        else:
            msval = f"ساختارِ {trfa} سالم"
        msnote = (mst.get("note", "") +
                  f" · سقف/کفِ ساختار {_r(mst.get('last_high'),1)}/{_r(mst.get('last_low'),1)}"
                  f" · روند {trfa}")
    score += ms_contrib
    signals.append({"name": "ساختارِ بازار (BOS/CHOCH)", "value": msval, "dir": msdir, "note": msnote})

    # ---- سطوحِ هم‌گراییِ اضافی برای نقشهٔ معامله (SL/TP دقیق‌تر) ----
    dloc = ind._level_decimals(price)
    conf_sup, conf_res = [], []

    def _add_level(v):
        if v is None:
            return
        try:
            fv = float(v)
        except (TypeError, ValueError):
            return
        if fv <= 0:
            return
        (conf_sup if fv < price else conf_res).append(round(fv, dloc))

    if piv.get("available"):
        for k in ("P", "R1", "R2", "R3", "S1", "S2", "S3"):
            _add_level(piv.get(k))
    if dly.get("available"):
        for k in ("pdh", "pdl", "pdc", "pwh", "pwl"):
            _add_level(dly.get(k))
    if srz.get("available"):
        for z in srz.get("supports", []):
            _add_level(z.get("price"))
        for z in srz.get("resistances", []):
            _add_level(z.get("price"))
    if liq.get("available"):
        for v in (liq.get("buy_side") or []):
            _add_level(v)
        for v in (liq.get("sell_side") or []):
            _add_level(v)
    if fvg.get("available"):
        for g in (fvg.get("bullish") or []):
            _add_level(g.get("mid"))
        for g in (fvg.get("bearish") or []):
            _add_level(g.get("mid"))
    if mst.get("available"):
        _add_level(mst.get("last_high"))
        _add_level(mst.get("last_low"))
    conf_sup = sorted(set(conf_sup), reverse=True)
    conf_res = sorted(set(conf_res))

    # حجم
    vol = df["volume"]
    vol_ma = vol.rolling(20).mean().iloc[-1]
    vdir = 1 if vol.iloc[-1] > vol_ma else 0
    signals.append({"name": "حجم", "value": "بالاتر از میانگین" if vdir else "زیر میانگین",
                    "dir": 0, "note": f"MA20 حجم: {_r(vol_ma,1)}"})

    # --- تاییدیهٔ تایم‌فریمِ بالاتر (HTF confirmation) ---
    # اگر تایم‌فریمِ بالاتر داده شده باشد، هم‌سوییِ روندِ آن یک معیارِ امتیازیِ مجزا می‌شود:
    # روندِ صعودیِ HTF امتیاز را به‌سمتِ خرید و روندِ نزولی به‌سمتِ فروش می‌بَرد. وزن به
    # مخرجِ نرمال‌سازی هم افزوده می‌شود تا مقیاسِ امتیاز دست‌نخورده بماند.
    norm = TECH_MAX_WEIGHT
    if htf_dir is not None:
        HTF_W = HTF_WEIGHT
        hdir = 1 if htf_dir > 0 else (-1 if htf_dir < 0 else 0)
        if hdir > 0:
            hval, hnote = f"روندِ {htf_label} صعودی", "هم‌سو با خرید (تاییدیهٔ صعودی)"
        elif hdir < 0:
            hval, hnote = f"روندِ {htf_label} نزولی", "هم‌سو با فروش (تاییدیهٔ نزولی)"
        else:
            hval, hnote = f"روندِ {htf_label} خنثی", "بدونِ تاییدیهٔ مشخص"
        score += hdir * HTF_W
        norm += HTF_W
        signals.append({"name": f"تاییدیهٔ تایم‌فریمِ بالاتر ({htf_label})",
                        "value": hval, "dir": hdir, "note": hnote})

    # نرمال‌سازی امتیاز تکنیکال به بازه -100..100
    # (مجموعِ حداکثرِ وزن‌ها ≈ 14.4 + وزنِ اختیاریِ تاییدیهٔ تایم‌فریمِ بالاتر)
    tscore = float(np.clip(score / norm * 100, -100, 100))

    return {
        "price": price,
        "atr": float(_atr_last),
        "rsi": float(rv),
        "supports": supports,
        "resistances": resistances,
        "fibonacci": fib,
        "sr_zones": srz,
        "pivots": piv,
        "daily_levels": dly,
        "trendline": trl,
        "liquidity": liq,
        "fvg": fvg,
        "market_structure": mst,
        "conf_supports": conf_sup,
        "conf_resistances": conf_res,
        "ema20": float(e20), "ema50": float(e50), "ema200": float(e200),
        "signals": signals,
        "score": tscore,
        "trend": trend,
        "source": df.attrs.get("source", "?"),
        # سیاستِ صریحِ NA: کدام اندیکاتورهای وایلدری هنوز دورهٔ گرم‌شدن را کامل
        # نکرده‌اند (مقدارشان خنثی/جایگزین شده و نباید سیگنال واقعی تلقی شود).
        "warmup": {"rsi": bool(_rsi_na), "adx": bool(_adx_na), "atr": bool(_atr_na)},
    }


# ---------------------------------------------------------------- فاندامنتال
def analyze_fundamental(f):
    if not f.get("ok"):
        return {"score": 0.0, "signals": [{"name": "فاندامنتال", "value": "در دسترس نیست",
                "dir": 0, "note": f.get("error", "")}], "available": False}
    signals = []
    score = 0.0

    for label, key, w in [("تغییر ۲۴ ساعته", "change_24h", 1.0),
                          ("تغییر ۷ روزه", "change_7d", 1.2),
                          ("تغییر ۳۰ روزه", "change_30d", 1.0)]:
        v = f.get(key)
        if v is None:
            continue
        d = 1 if v > 0 else -1
        score += d * w * min(abs(v) / 5, 1)
        signals.append({"name": label, "value": f"{_r(v,2)}%", "dir": d,
                        "note": "مومنتوم مثبت" if d > 0 else "مومنتوم منفی"})

    # اصلاح (FUND-MACRO-001): رویدادهای کلانِ پیش‌رو (تقویم اقتصادی) — اطلاع‌رسان
    for ev in (f.get("macro_events") or [])[:4]:
        try:
            _h = float(ev.get("in_hours", 0))
            _when = (f"{int(round(_h))} ساعت دیگر" if _h >= 1.5
                     else f"{int(round(_h * 60))} دقیقه دیگر")
            signals.append({"name": f"📅 رویداد کلان {ev.get('country', '')}",
                            "value": str(ev.get("title", ""))[:60],
                            "dir": 0,
                            "note": f"{ev.get('impact', 'High')} · {_when}"})
        except Exception:  # noqa
            continue

    # فاصله تا ATH / سقف ۵۲ هفته
    athc = f.get("ath_change_pct")
    if athc is not None:
        d = 1 if athc > -15 else (-1 if athc < -50 else 0)
        lbl = "فاصله تا سقف ۵۲ هفته" if f.get("is_metal") else "فاصله تا ATH"
        signals.append({"name": lbl, "value": f"{_r(athc,1)}%", "dir": d,
                        "note": "نزدیک سقف" if athc > -15 else "فضای رشد"})
        score += d * 0.5

    # نسبت حجم به مارکت‌کپ (نقدشوندگی)
    mc, vol = f.get("market_cap"), f.get("total_volume")
    if mc and vol:
        ratio = vol / mc * 100
        signals.append({"name": "نقدشوندگی (حجم/مارکت‌کپ)", "value": f"{_r(ratio,2)}%",
                        "dir": 0, "note": f"مارکت‌کپ ${mc/1e9:.0f}B"})

    fscore = float(np.clip(score / 3.7 * 100, -100, 100))
    return {"score": fscore, "signals": signals, "available": True,
            "market_cap": mc, "total_volume": vol}


# ---------------------------------------------------------------- سنتیمنتال
def analyze_sentiment(s):
    title = s.get("title", "سنتیمنت")
    if not s.get("ok"):
        return {"score": 0.0, "signals": [{"name": title, "value": "در دسترس نیست",
                "dir": 0, "note": s.get("error", "")}], "available": False, "value": None,
                "title": title, "kind": s.get("kind", "fng")}

    # --- سنتیمنت مبتنی بر شاخص دلار (جهت‌دار با علامت dxy_k) ---
    if s.get("kind") == "dxy":
        chg5 = s.get("dxy_chg_5d", 0.0)
        bull = s.get("bull", -chg5)          # bull>0 یعنی صعودی برای این دارایی
        d = 1 if bull > 0 else (-1 if bull < 0 else 0)
        score = float(np.clip(bull * 12, -100, 100))
        signals = [
            {"name": "شاخص دلار (DXY)", "value": s.get("dxy"),
             "dir": d, "note": s.get("classification", "")},
            {"name": "تغییر ۵ روزه دلار", "value": f"{_r(chg5,2)}%", "dir": d,
             "note": "همسو با صعود این دارایی" if d > 0 else "همسو با نزول این دارایی"},
        ]
        return {"score": score, "signals": signals, "available": True,
                "value": s.get("value"), "classification": s.get("classification"),
                "history": [], "title": title, "kind": "dxy"}

    # --- سنتیمنت شاخص سهام: مبتنی بر VIX (جهت‌دار) ---
    if s.get("kind") == "vix":
        chg5 = s.get("vix_chg_5d", 0.0)
        val = s.get("value", 50)
        d = 1 if val >= 55 else (-1 if val <= 45 else 0)
        score = float(np.clip((val - 50) * 1.6 - chg5 * 4, -100, 100))
        signals = [
            {"name": "شاخص نوسان (VIX)", "value": s.get("vix"),
             "dir": d, "note": s.get("classification", "")},
            {"name": "تغییر ۵ روزه VIX", "value": f"{_r(chg5,2)}%",
             "dir": (-1 if chg5 > 0 else 1),
             "note": "نوسان کاهشی = مثبت سهام" if chg5 <= 0 else "نوسان صعودی = منفی سهام"},
        ]
        return {"score": score, "signals": signals, "available": True,
                "value": val, "classification": s.get("classification"),
                "history": [], "title": title, "kind": "vix"}

    # --- سنتیمنت کریپتو: شاخص ترس و طمع (کنترین) ---
    v = s["value"]
    # طمع شدید => احتیاط (کنترین). ترس شدید => فرصت خرید.
    if v <= 25:
        d, note = 1, "ترس شدید (فرصت خرید کنترین)"
    elif v <= 45:
        d, note = 1, "ترس"
    elif v <= 55:
        d, note = 0, "خنثی"
    elif v <= 75:
        d, note = -1, "طمع"
    else:
        d, note = -1, "طمع شدید (ریسک اصلاح)"

    trend_note = ""
    hist = s.get("history", [])
    if len(hist) >= 2:
        diff = hist[0] - hist[-1]
        trend_note = f"روند ۷ روزه: {'+' if diff>=0 else ''}{diff}"

    signals = [{"name": "شاخص ترس و طمع", "value": f"{v} ({s['classification']})",
                "dir": d, "note": note}]
    if trend_note:
        signals.append({"name": "روند سنتیمنت", "value": trend_note, "dir": 0, "note": ""})

    sscore = float(np.clip((50 - v) / 50 * 100, -100, 100)) * 0.9  # کنترین
    return {"score": sscore, "signals": signals, "available": True, "value": v,
            "classification": s["classification"], "history": hist,
            "title": title, "kind": "fng"}


# ---------------------------------------------------------------- ترکیب و سیگنال
WEIGHTS = {"technical": 0.55, "fundamental": 0.20, "sentiment": 0.25}


def ai_status_stub():
    """اصلاح (AIDASH-004): وقتی تب/درخواست AI را «لحاظ» نکرده (with_ai=False)،
    قبلاً فقط {"used": False} برمی‌گشت و UI به‌اشتباه «غیرفعال» نشان می‌داد —
    حتی وقتی مدل فعال و متصل بود. این استابِ بدونِ هزینه، وضعیتِ واقعی را می‌دهد."""
    try:
        cfg = ai.load_config()
        return {"used": False, "requested": False,
                "enabled": bool(cfg.get("enabled")),
                "use_in_signal": bool(cfg.get("use_in_signal"))}
    except Exception:  # noqa
        return {"used": False, "requested": False, "enabled": False, "use_in_signal": False}


def analyze_ai(symbol, interval, tech, fund, sent, price, weight_override=None):
    """تحلیلِ حرفه‌ایِ هوش مصنوعی (تکنیکال+فاندامنتال+سنتیمنتال) و امتیازِ آن.

    فقط وقتی هوش مصنوعی «فعال» و «استفاده در سیگنال» روشن باشد اجرا می‌شود.
    خروجی همیشه شاملِ کلیدِ used است تا موتور بداند در امتیازِ نهایی لحاظش کند یا نه.
    """
    try:
        cfg = ai.load_config()
    except Exception:  # noqa
        return {"used": False, "enabled": False, "use_in_signal": False}
    enabled = bool(cfg.get("enabled"))
    use = bool(cfg.get("use_in_signal"))
    if not (enabled and use):
        return {"used": False, "enabled": enabled, "use_in_signal": use}

    snapshot = {
        "symbol": symbol, "timeframe": interval, "price": price,
        "internal_scores": {
            "technical": round(float(tech.get("score", 0)), 1),
            "fundamental": round(float(fund.get("score", 0)), 1),
            "sentiment": round(float(sent.get("score", 0)), 1),
        },
        "technical": {
            "rsi": round(float(tech.get("rsi", 0)), 1),
            "trend": tech.get("trend"),
            "atr": tech.get("atr"),
            "supports": tech.get("supports"),
            "resistances": tech.get("resistances"),
            "fibonacci": ({
                "direction": (tech.get("fibonacci") or {}).get("direction"),
                "swing_high": (tech.get("fibonacci") or {}).get("swing_high"),
                "swing_low": (tech.get("fibonacci") or {}).get("swing_low"),
                "pos_ratio": (tech.get("fibonacci") or {}).get("pos_ratio"),
                "in_golden": (tech.get("fibonacci") or {}).get("in_golden"),
                "extensions": [e.get("price") for e in (tech.get("fibonacci") or {}).get("extensions", [])],
            } if (tech.get("fibonacci") or {}).get("available") else None),
            "pivots": ({k: (tech.get("pivots") or {}).get(k) for k in ("basis", "P", "R1", "S1")}
                       if (tech.get("pivots") or {}).get("available") else None),
            "daily_levels": ({k: (tech.get("daily_levels") or {}).get(k) for k in ("pdh", "pdl", "pwh", "pwl")}
                             if (tech.get("daily_levels") or {}).get("available") else None),
            "trendline": ({"direction": (tech.get("trendline") or {}).get("direction"),
                           "broken": (tech.get("trendline") or {}).get("broken")}
                          if (tech.get("trendline") or {}).get("available") else None),
            "market_structure": ({"trend": (tech.get("market_structure") or {}).get("trend"),
                                  "event": (tech.get("market_structure") or {}).get("event"),
                                  "last_high": (tech.get("market_structure") or {}).get("last_high"),
                                  "last_low": (tech.get("market_structure") or {}).get("last_low")}
                                 if (tech.get("market_structure") or {}).get("available") else None),
            "liquidity": ((tech.get("liquidity") or {}).get("sweep")
                          if (tech.get("liquidity") or {}).get("available") else None),
            "fvg": ({"bull_support": ((tech.get("fvg") or {}).get("nearest_support") or {}).get("mid"),
                     "bear_resistance": ((tech.get("fvg") or {}).get("nearest_resistance") or {}).get("mid")}
                    if (tech.get("fvg") or {}).get("available") else None),
            "signals": [{"name": s.get("name"), "value": s.get("value"), "dir": s.get("dir")}
                        for s in (tech.get("signals") or [])][:21],
        },
        "fundamental": {
            "available": fund.get("available"),
            "market_cap": fund.get("market_cap"),
            "signals": [{"name": s.get("name"), "value": s.get("value"), "dir": s.get("dir")}
                        for s in (fund.get("signals") or [])][:10],
        },
        "sentiment": {
            "title": sent.get("title"), "value": sent.get("value"),
            "classification": sent.get("classification"), "kind": sent.get("kind"),
        },
    }
    res = ai.analyze_market(snapshot)
    if not res.get("ok"):
        return {"used": False, "enabled": True, "use_in_signal": True,
                "error": res.get("error"), "raw": res.get("raw")}
    try:
        _sw = float(weight_override if weight_override is not None else cfg.get("signal_weight", 0.30))
    except Exception:  # noqa
        _sw = 0.30
    w = max(0.0, min(0.9, _sw))
    return {
        "used": True, "enabled": True, "use_in_signal": True, "weight": w,
        "score": res["overall_score"],
        "technical_score": res["technical_score"],
        "fundamental_score": res["fundamental_score"],
        "sentiment_score": res["sentiment_score"],
        "overall_score": res["overall_score"],
        "direction": res["direction"], "confidence": res["confidence"],
        "summary": res["summary"], "reasons": res["reasons"],
        "model": res.get("model"), "ms": res.get("ms"),
        # اصلاح (AIDASH-007): تحلیل‌های متنیِ جداگانه + سطوحِ کلیدیِ مدل (اختیاری)
        "technical_analysis": res.get("technical_analysis"),
        "fundamental_analysis": res.get("fundamental_analysis"),
        "sentiment_analysis": res.get("sentiment_analysis"),
        "key_levels": res.get("key_levels"),
    }


def _blend_with_ai(internal_total, ai_res, base_weights=None):
    """ترکیبِ امتیازِ داخلی با امتیازِ AI (در صورت فعال‌بودن) و برگرداندنِ (total, weights).

    base_weights: وزن‌های پایه (تکنیکال/فاندامنتال/سنتیمنت). اگر داده نشود از WEIGHTS استفاده می‌شود.
    برای سیگنال‌های «فقط تکنیکالِ متاتریدر» وزنِ تکنیکال ۱٫۰ پاس داده می‌شود.
    """
    bw = dict(base_weights) if base_weights else dict(WEIGHTS)
    if ai_res.get("used"):
        w = max(0.0, min(0.9, float(ai_res.get("weight", 0.30))))
        total = internal_total * (1 - w) + float(ai_res.get("score", 0.0)) * w
        weights = {
            "technical": round(bw.get("technical", 0.0) * (1 - w), 4),
            "fundamental": round(bw.get("fundamental", 0.0) * (1 - w), 4),
            "sentiment": round(bw.get("sentiment", 0.0) * (1 - w), 4),
            "ai": round(w, 4),
        }
        return total, weights
    return internal_total, bw


def _candles_payload(df, tech, n=120):
    """آماده‌سازی داده کندل و اندیکاتورها برای نمودار (فقط n کندل آخر)."""
    close = df["close"]
    dec = _dec(close.iloc[-1])
    ema20 = ind.ema(close, 20)
    ema50 = ind.ema(close, 50)
    sub = df.tail(n)
    idx = sub.index
    candles = [{
        "t": int(r["time"]),
        "o": _r(r["open"], dec), "h": _r(r["high"], dec),
        "l": _r(r["low"], dec), "c": _r(r["close"], dec),
        "v": _r(r["volume"], 2),
    } for _, r in sub.iterrows()]
    return {
        "candles": candles,
        "ema20": [_r(ema20.loc[i], dec) for i in idx],
        "ema50": [_r(ema50.loc[i], dec) for i in idx],
    }


def build_signal(symbol="BTC", interval="1h", with_ai=False, htf=None, ai_weight=None):
    cfg = sym.resolve(symbol)
    if not cfg:
        raise ValueError(f"نمادِ پشتیبانی‌نشده: {symbol!r}")
    # چهار فراخوانیِ مستقلِ شبکه‌ای هم‌زمان اجرا می‌شوند (تأخیر = بیشینه، نه مجموع)
    f_candles = _IO_POOL.submit(ds.get_candles, symbol, interval)
    f_fund = _IO_POOL.submit(ds.get_fundamentals, symbol)
    f_sent = _IO_POOL.submit(ds.get_sentiment, symbol)
    f_htf = _IO_POOL.submit(ds.get_candles, symbol, htf) if (htf and htf != interval) else None
    df = f_candles.result()
    htf_dir, htf_label = None, ""
    if f_htf is not None:
        try:
            htf_dir, htf_label = htf_trend_dir(f_htf.result()), htf
        except Exception:  # noqa
            htf_dir, htf_label = None, ""
    tech = analyze_technical(df, htf_dir=htf_dir, htf_label=htf_label)
    fund = analyze_fundamental(f_fund.result())
    sent = analyze_sentiment(f_sent.result())

    internal_total = (tech["score"] * WEIGHTS["technical"]
                      + fund["score"] * WEIGHTS["fundamental"]
                      + sent["score"] * WEIGHTS["sentiment"])

    price = tech["price"]
    atr = tech["atr"]

    # تحلیلِ هوش مصنوعی (فقط در مسیرِ داشبورد و در صورت فعال‌بودن)
    ai_res = analyze_ai(symbol, interval, tech, fund, sent, price, weight_override=ai_weight) if with_ai else ai_status_stub()
    total, weights_out = _blend_with_ai(internal_total, ai_res)

    if total >= 15:
        direction, conf = "LONG", "خرید"
    elif total <= -15:
        direction, conf = "SHORT", "فروش"
    else:
        direction, conf = "NEUTRAL", "خنثی / انتظار"

    dec = _dec(price)
    plan = build_trade_plan(direction, price, atr, tech["supports"], tech["resistances"], abs(total), dec, fib=tech.get("fibonacci"), extra_sup=tech.get("conf_supports"), extra_res=tech.get("conf_resistances"))

    chart = _candles_payload(df, tech)
    # OP5-DS-FINALIZE: اگر تحلیل روی دادهٔ کش‌شده/کهنه انجام شده، صریحاً اعلام کن
    # (data_sources در df.attrs نشانه می‌گذارد) تا UI بنرِ هشدار نشان دهد و کاربر
    # سیگنال را تازه نپندارد.
    _attrs = getattr(df, "attrs", {}) or {}
    _stale = bool(_attrs.get("stale"))
    _age = _attrs.get("stale_since")

    return {
        "data_stale": _stale,
        "data_age_sec": (round(float(_age), 1) if (_stale and _age is not None) else None),
        "data_source": _attrs.get("source"),
        "symbol": symbol.upper(),
        "symbol_name": cfg["name"],
        "pair": cfg["pair"],
        "interval": interval,
        "chart": chart,
        "generated_at": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"),
        "price": _r(price, dec),
        "atr": _r(atr, dec),
        "direction": direction,
        "direction_fa": conf,
        "total_score": _r(total, 1),
        "internal_score": _r(internal_total, 1),
        "confidence": _r(min(abs(total) + 20, 99), 0),
        "technical": tech,
        "fundamental": fund,
        "sentiment": sent,
        "ai": ai_res,
        "plan": plan,
        "weights": weights_out,
        "market": mh.status(symbol),
    }


def build_signal_from_rows(name, interval="1h", rows=None, source="MT5", digits=None, with_ai=False,
                           htf_dir=None, htf_label="", ai_weight=None):
    """ساخت سیگنال برای نمادی که فقط از متاتریدر داده دارد (تحلیلِ تکنیکالِ خالص).

    فاندامنتال/سنتیمنتِ رایگان برای این نمادها موجود نیست، پس خنثی درنظر گرفته می‌شوند
    و امتیازِ کل تنها بر پایه‌ی تکنیکالِ همان دادهٔ متاتریدر (و در صورت فعال‌بودن، AI) محاسبه می‌شود.
    """
    df = ds._df_from_rows(rows or [])
    if df is None or len(df) < 30:
        raise ValueError(f"دادهٔ کافی برای تحلیلِ «{name}» از متاتریدر موجود نیست.")

    tech = analyze_technical(df, htf_dir=htf_dir, htf_label=htf_label)
    # اصلاح (MT5-FUNDSENT-001): متاتریدر فاندامنتال/سنتیمنت نمی‌دهد؛ اما اگر نمادِ
    # بروکر معادلِ داخلی داشته باشد (XAUUSD.m→XAU، BTCUSD→BTC، US500→SPX…)، همان
    # تحلیل‌ها از منابعِ رایگان (CoinGecko/FNG/VIX/DXY/Yahoo) واکشی و با وزنِ
    # استاندارد در امتیازِ کل ترکیب می‌شوند — قبلاً همیشه «ناموجود/خنثی» بودند.
    _twin = None
    try:
        import mt5_bridge as _mb
        _twin = (_mb.internal_for_broker(str(name)) or "").upper() or None
    except Exception:  # noqa
        _twin = None
    if _twin and _twin in getattr(sym, "SYMBOLS", {}):
        f_fund = _IO_POOL.submit(ds.get_fundamentals, _twin)
        f_sent = _IO_POOL.submit(ds.get_sentiment, _twin)
        try:
            fund = analyze_fundamental(f_fund.result())
        except Exception as _e:  # noqa
            fund = analyze_fundamental({"ok": False, "error": str(_e)})
        try:
            sent = analyze_sentiment(f_sent.result())
        except Exception as _e:  # noqa
            sent = analyze_sentiment({"ok": False, "title": "سنتیمنت", "error": str(_e)})
        if isinstance(fund, dict) and fund.get("available"):
            fund["note"] = f"از معادلِ داخلیِ {_twin} (منبعِ رایگان)"
        if isinstance(sent, dict) and sent.get("available"):
            sent["note"] = f"از معادلِ داخلیِ {_twin} (منبعِ رایگان)"
    else:
        fund = analyze_fundamental({"ok": False,
            "error": f"دادهٔ فاندامنتالِ رایگان برای «{name}» موجود نیست (منبع: {source})."})
        sent = analyze_sentiment({"ok": False, "title": "سنتیمنت",
            "error": f"منبعِ سنتیمنت برای «{name}» موجود نیست."})

    # چون فاندامنتال/سنتیمنت از متاتریدر در دسترس نیست، امتیازِ کل «فقط تکنیکال» است.
    # برای اینکه امتیاز رقیق نشود، وزنِ تکنیکال ۱٫۰ درنظر گرفته می‌شود (نه ۰٫۵۵).
    fund_ok = bool(fund.get("available"))
    sent_ok = bool(sent.get("available"))
    if not fund_ok and not sent_ok:
        internal_total = tech["score"]
        base_weights = {"technical": 1.0, "fundamental": 0.0, "sentiment": 0.0}
    else:
        internal_total = (tech["score"] * WEIGHTS["technical"]
                          + fund["score"] * WEIGHTS["fundamental"]
                          + sent["score"] * WEIGHTS["sentiment"])
        base_weights = dict(WEIGHTS)
    price = tech["price"]
    atr = tech["atr"]

    ai_res = analyze_ai(name, interval, tech, fund, sent, price, weight_override=ai_weight) if with_ai else ai_status_stub()
    total, weights_out = _blend_with_ai(internal_total, ai_res, base_weights=base_weights)

    if total >= 15:
        direction, conf = "LONG", "خرید"
    elif total <= -15:
        direction, conf = "SHORT", "فروش"
    else:
        direction, conf = "NEUTRAL", "خنثی / انتظار"

    # OP5-ENG-DEC: digits=0 هم معتبر است (نمادهای بدونِ اعشار)؛ شرطِ قبلیِ
    # digits>0 آن را نادیده می‌گرفت و روی اعشارِ حدسی می‌رفت.
    dec = digits if isinstance(digits, int) and 0 <= digits <= 8 else _dec(price)
    plan = build_trade_plan(direction, price, atr, tech["supports"], tech["resistances"], abs(total), dec, fib=tech.get("fibonacci"), extra_sup=tech.get("conf_supports"), extra_res=tech.get("conf_resistances"))
    chart = _candles_payload(df, tech)

    return {
        # دادهٔ مسیرِ متاتریدر تازه است (کشِ دیسکِ MT5 در app مدیریت می‌شود)
        "data_stale": False, "data_age_sec": None, "data_source": source,
        "symbol": str(name).upper(),
        "symbol_name": str(name),
        "pair": str(name),
        "interval": interval,
        "chart": chart,
        "generated_at": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"),
        "price": _r(price, dec),
        "atr": _r(atr, dec),
        "direction": direction,
        "direction_fa": conf,
        "total_score": _r(total, 1),
        "internal_score": _r(internal_total, 1),
        "confidence": _r(min(abs(total) + 20, 99), 0),
        "technical": tech,
        "fundamental": fund,
        "sentiment": sent,
        "ai": ai_res,
        "plan": plan,
        "weights": weights_out,
        "market": {"open": True, "asset_class": "mt5", "always_open": False,
                   "next_change_ts": None, "next_change_in_min": None,
                   "reason_fa": "نماد مستقیماً از متاتریدر ۵ خوانده می‌شود",
                   "reason_en": "Symbol data served directly from MetaTrader 5"},
        "source": source,
        "mt5_only": True,
    }


def build_trade_plan(direction, price, atr, supports, resistances, strength, dec=1, fib=None,
                     extra_sup=None, extra_res=None):
    """محاسبه ورود، ۳ تیک‌پروفیت و استاپ‌لاس بر مبنای ATR، سطوح S/R و فیبوناچی.

    اگر `fib` (خروجیِ indicators.fibonacci_levels) داده شود و هم‌جهت با معامله باشد:
      - نقطهٔ ورود به نزدیک‌ترین سطحِ اصلاحیِ فیبوناچی (در محدودهٔ منطقی) snap می‌شود.
      - استاپ‌لاس تا پشتِ عمیق‌ترین سطحِ اصلاحی (بی‌اعتبارشدنِ ساختار) گسترش می‌یابد (با سقفِ ۳×ATR).
      - سطوحِ گسترشیِ فیبوناچی به‌عنوان اهدافِ کاندید برای تیک‌پروفیت‌ها لحاظ می‌شوند.
    """
    if direction == "NEUTRAL":
        return {
            "direction": "NEUTRAL",
            "entry": _r(price, dec),
            "note": "امتیاز کل در محدوده خنثی است؛ بهتر است تا شکل‌گیری روند مشخص صبر کنید.",
            "take_profits": [], "stop_loss": None, "rr": None,
        }

    long = direction == "LONG"

    # محافظت در برابرِ ATRِ صفر/نامعتبر (کندلِ تخت، نمادِ تازه، یا دادهٔ ناقص):
    # اگر ATR صفر یا منفی باشد، step و همهٔ فاصله‌ها صفر می‌شوند و هر ۳ تیک‌پروفیت
    # روی نقطهٔ ورود جمع می‌شوند (TP == entry) که نقشهٔ نامعتبری برای ارسال به MT5 است.
    # پس یک «کفِ منطقی» بر مبنای قیمت می‌گذاریم که فقط در همین حالتِ خراب فعال می‌شود
    # و روی ATRهای عادی هیچ اثری ندارد.
    try:
        atr = float(atr)
    except Exception:  # noqa
        atr = 0.0
    # اصلاح (ENG-001): ATRِ غیرهانتم (NaN/inf) هم باید به مسیرِ کف منطقی بیفتد؛
    # قبلاً NaN→پلنِ NaN و inf→سطوحِ ∓inf تولید می‌شد.
    if not math.isfinite(atr):
        atr = 0.0
    try:
        price = float(price)
    except Exception:  # noqa
        price = 0.0
    if not math.isfinite(price) or price <= 0:
        raise ValueError("قیمتِ ورودیِ نقشهٔ معامله نامعتبر است.")
    if not atr or atr <= 0:
        atr = (abs(float(price)) * 0.001) if price else 1e-6
        if atr <= 0:
            atr = 1e-6
    # اصلاح (ENG-001): اگر ATR از دقتِ اعشارِ خروجی (شبکهٔ گردکردن) بسیار کوچک‌تر
    # باشد، پس از گردکردن همهٔ سطوح روی هم جمع می‌شوند (TP==SL==entry).
    # کفِ ۴ پله‌ی شبکه فقط در همین حالتِ خراب فعال می‌شود.
    try:
        _grid = 10.0 ** (-int(dec))
    except Exception:  # noqa
        _grid = 0.1
    if _grid > 0 and atr < 4 * _grid:
        atr = 4 * _grid

    # ورود کمی بهتر از قیمت فعلی (پول‌بک 0.25 ATR)
    entry = price - 0.25 * atr if long else price + 0.25 * atr

    # هم‌راستاییِ فیبوناچی با جهتِ معامله (up→LONG ، down→SHORT)
    fib_ok = bool(fib and fib.get("available") and
                  ((long and fib.get("direction") == "up") or
                   ((not long) and fib.get("direction") == "down")))
    fib_used = False

    # ورود: snap به نزدیک‌ترین سطحِ اصلاحیِ فیبوناچی (فقط اگر تا ۰٫۷۵×ATR فاصله دارد)
    if fib_ok:
        retr_prices = [r["price"] for r in fib.get("retracements", [])]
        valid = [p for p in retr_prices if (p <= price if long else p >= price)]
        if valid:
            nearest_r = min(valid, key=lambda p: abs(p - entry))
            if abs(nearest_r - entry) <= 0.75 * atr:
                entry = float(nearest_r)
                fib_used = True

    # سطوحِ ادغام‌شده: swing + سطوحِ هم‌گرایی (پیوت/PDH-PDL/نواحی/لیکوئیدیتی/FVG)
    m_sup = sorted(set(list(supports or []) + list(extra_sup or [])), reverse=True)
    m_res = sorted(set(list(resistances or []) + list(extra_res or [])))

    # استاپ: 1.5 ATR + احترام به نزدیک‌ترین سطحِ هم‌گرا
    if long:
        sl = entry - 1.5 * atr
        below = [s for s in m_sup if s < entry]
        if below:
            sl = min(sl, max(below) - 0.3 * atr)
    else:
        sl = entry + 1.5 * atr
        above = [r for r in m_res if r > entry]
        if above:
            sl = max(sl, min(above) + 0.3 * atr)

    # استاپِ ساختاری بر مبنای عمیق‌ترین اصلاحِ فیبوناچی (بی‌اعتبارشدن)، با سقفِ ۳×ATR
    if fib_ok:
        if long:
            below = [r["price"] for r in fib.get("retracements", []) if r["price"] < entry]
            if below:
                cand = min(below) - 0.3 * atr
                if cand >= entry - 3.0 * atr:
                    sl = min(sl, cand); fib_used = True
        else:
            above = [r["price"] for r in fib.get("retracements", []) if r["price"] > entry]
            if above:
                cand = max(above) + 0.3 * atr
                if cand <= entry + 3.0 * atr:
                    sl = max(sl, cand); fib_used = True

    risk = abs(entry - sl)
    # تیک‌پروفیت‌ها بر مبنای مضرب‌های ATR؛ در صورت وجود سطح S/R «نزدیک» به آن snap می‌شوند
    tp_mult = [1.0, 2.0, 3.2]
    step = 1.5 * atr
    # سطوح معتبر در جهت معامله و آن‌سوی نقطه ورود (S/R + هم‌گرایی + گسترشِ فیبوناچی)
    if long:
        levels = [r for r in m_res if r > entry]
        if fib_ok:
            levels += [e["price"] for e in fib.get("extensions", []) if e["price"] > entry]
        levels = sorted(set(levels))
    else:
        levels = [s for s in m_sup if s < entry]
        if fib_ok:
            levels += [e["price"] for e in fib.get("extensions", []) if e["price"] < entry]
        levels = sorted(set(levels), reverse=True)

    raw = []
    for m in tp_mult:
        base = entry + m * step if long else entry - m * step
        # نزدیک‌ترین سطح؛ فقط اگر تا نصف یک گام ATR فاصله دارد، به آن snap کن
        if levels:
            nearest = min(levels, key=lambda lv: abs(lv - base))
            if abs(nearest - base) <= 0.5 * step:
                base = nearest
        raw.append(base)

    # تضمین ترتیب صعودی/نزولی و فاصله حداقلی بین اهداف
    ordered = []
    prev = entry
    for i, base in enumerate(raw):
        min_gap = 0.5 * step
        if long:
            base = max(base, prev + min_gap)
        else:
            base = min(base, prev - min_gap)
        ordered.append(base)
        prev = base

    # اصلاح (PLAN-MINRR-001): وقتی استاپِ ساختاری دور می‌افتد (مثلاً نزدیک‌ترین
    # سطحِ هم‌گرا چند ATR آن‌طرف‌تر است)، TP1ِ مبتنی بر ATR نسبت به ریسک پرت می‌شد
    # (مثلاً R:R=۰٫۱۶). کفِ فاصلهٔ TP1 = ۰٫۵×ریسک؛ روی نقشه‌های عادی (ریسک ≈۱٫۵ATR)
    # هیچ اثری ندارد چون همان ۰٫۷۵ATRِ قبلی می‌شود.
    _min_tp1 = 0.5 * risk
    if risk > 0 and abs(ordered[0] - entry) < _min_tp1 - 1e-12:
        bump = entry + _min_tp1 if long else entry - _min_tp1
        cand = [lv for lv in levels if (lv >= bump if long else lv <= bump)]
        if cand:
            near = min(cand) if long else max(cand)
            if abs(near - bump) <= 0.5 * step:
                bump = near
        ordered[0] = bump
        prev = ordered[0]
        for _i in (1, 2):
            mg = 0.5 * step
            ordered[_i] = max(ordered[_i], prev + mg) if long else min(ordered[_i], prev - mg)
            prev = ordered[_i]

    tps = []
    for i, base in enumerate(ordered):
        rr = abs(base - entry) / risk if risk else 0
        tps.append({"label": f"TP{i+1}", "price": _r(base, dec), "rr": _r(rr, 2),
                    "close_pct": [40, 35, 25][i]})

    # اصلاح (ENG-001، پسا-گردکردن): تضمینِ ترتیبِ اکید روی شبکهٔ اعشارِ خروجی؛
    # اگر snap/گردکردن دو سطح را روی هم انداخت، به‌اندازهٔ یک پلهٔ شبکه جدا می‌شوند.
    if _grid > 0:
        _e = _r(entry, dec)
        _prev = _e
        for _t in tps:
            if long and _t["price"] <= _prev:
                _t["price"] = _r(_prev + _grid, dec)
            elif (not long) and _t["price"] >= _prev:
                _t["price"] = _r(_prev - _grid, dec)
            _prev = _t["price"]
        _slr = _r(sl, dec)
        if long and _slr >= _e:
            sl = _e - _grid
        elif (not long) and _slr <= _e:
            sl = _e + _grid

    # OP5-ENG-RR (ممیزی §۳-۸): RR باید از قیمت‌های «منتشرشده» (پس از گردکردن و
    # اصلاحِ شبکه/گپ) ساخته شود. قبلاً rr هر پله از مقادیرِ خامِ پیش از گردکردن
    # می‌آمد و UI/position-sizing عددی می‌دید که با سفارشِ واقعی نمی‌خواند.
    _e_rr = _r(entry, dec)
    _sl_rr = _r(sl, dec)
    _pub_risk_rr = abs(_e_rr - _sl_rr)
    for _t in tps:
        _t["rr"] = (_r(abs(_t["price"] - _e_rr) / _pub_risk_rr, 2)
                    if _pub_risk_rr else None)
    final_rr = tps[-1]["rr"] if tps else None
    note = "پیشنهاد: بستن پله‌ای پوزیشن در هر تیک‌پروفیت و انتقال استاپ به نقطه ورود پس از TP1."
    if fib_used:
        note += " (ورود/استاپ/اهداف با سطوحِ فیبوناچی هم‌تراز شده‌اند.)"
    # اصلاح (PLAN-RISKR-001): ریسکِ واحد باید از «مقادیرِ گردشدهٔ منتشرشده» محاسبه
    # شود؛ قبلاً از ریسکِ خام (پیش از جابه‌جایی‌های گردکردن/حداقل‌گپ) می‌آمد و در
    # نمادهای کم‌اعشار (مثل JPY) با |entry−sl| نمایش‌داده‌شده نمی‌خواند.
    _e_pub, _sl_pub = _r(entry, dec), _r(sl, dec)
    return {
        "direction": direction,
        "entry": _e_pub,
        "stop_loss": _sl_pub,
        "risk_per_unit": _r(abs(_e_pub - _sl_pub), dec),
        "take_profits": tps,
        "rr": final_rr,
        "fib_used": bool(fib_used),
        "note": note,
    }


if __name__ == "__main__":
    import json
    print(json.dumps(build_signal("BTC", "1h"), ensure_ascii=False, indent=2, default=str)[:1200])
