# -*- coding: utf-8 -*-
"""
robot_client_example.py
=======================

کلاینتِ آماده برای ربات‌های تریدرِ متاتریدر ۵ شما (نوشته‌شده با پایتون).

هدف: ربات‌های شما به‌جای ارسالِ مستقیمِ سفارش به متاتریدر، سفارش را به «برنامهٔ تحلیل»
می‌فرستند. برنامه سفارش را دقیق دریافت می‌کند، آن را با «سیگنالِ داخلی» و/یا «هوش مصنوعی»
امتیازدهی می‌کند و تنها در صورتِ تأیید، عینِ همان مشخصات و مقادیر را به متاتریدر می‌فرستد.

این فایل دو سبکِ استفاده می‌دهد تا با «کمترین تغییر» در ربات‌های موجود کار کند:

  ۱) سبکِ ساده (توصیه‌شده):
        from robot_client_example import RobotBridge
        bridge = RobotBridge("http://127.0.0.1:8000", secret="")   # آدرسِ برنامه
        res = bridge.send(symbol="XAUUSD", direction="BUY", volume=0.10,
                          sl=2345.0, tp=2360.0, tf="1h")
        if res.forwarded:
            print("به متاتریدر ارسال شد ✅")
        else:
            print("رد شد:", res.comment)

  ۲) سبکِ سازگار با MetaTrader5 (جایگزینِ مستقیمِ mt5.order_send):
        # کدِ قبلی:
        #   result = mt5.order_send(request)
        # فقط همین یک خط را عوض کنید:
        result = bridge.order_send(request)   # همان دیکشنریِ استانداردِ MT5
        if result.retcode == 10009:           # TRADE_RETCODE_DONE
            print("انجام شد")

راه‌اندازی:
    pip install requests
    آدرسِ برنامه و توکنِ امنیتی (در صورتِ تنظیم در تب) را در RobotBridge بدهید.

نکته: هیچ کلید/رمزی لازم نیست مگر اینکه در تبِ «سیگنال‌های ورودی ربات‌ها» توکنِ مشترک
(shared secret) تنظیم کرده باشید؛ در آن صورت همان توکن را به RobotBridge بدهید.
"""

from __future__ import annotations

import time
import json
import logging
from typing import Any, Iterable, Optional

try:
    import requests
except ImportError as exc:  # pragma: no cover
    raise SystemExit(
        "کتابخانهٔ requests نصب نیست. اجرا کنید:  pip install requests"
    ) from exc


# --------------------------------------------------------------------------- #
#  ثابت‌ها و ابزارِ سازگاری با MetaTrader5
# --------------------------------------------------------------------------- #

# کدهای بازگشتیِ سازگار با متاتریدر (برای سبکِ order_send)
TRADE_RETCODE_DONE = 10009          # عیناً مطابقِ MT5: معامله با موفقیت انجام شد

# کدهای اختصاصیِ این پُل (خارج از محدودهٔ کدهای واقعیِ MT5 تا تداخل نکنند)
BRIDGE_REJECTED = 20001             # فیلترِ برنامه سفارش را رد کرد
BRIDGE_APPROVED_NOT_SENT = 20002    # تأیید شد ولی «ارسالِ خودکار» خاموش بود
BRIDGE_FORWARD_FAILED = 20003       # تأیید شد ولی ارسال به متاتریدر ناموفق بود
BRIDGE_ERROR = 20000               # خطای شبکه/سرور/اعتبارسنجی

# نگاشتِ نوعِ سفارشِ عددیِ متاتریدر → BUY/SELL
#   0 BUY · 1 SELL · 2 BUY_LIMIT · 3 SELL_LIMIT · 4 BUY_STOP · 5 SELL_STOP
#   6 BUY_STOP_LIMIT · 7 SELL_STOP_LIMIT   (زوج = خرید، فرد = فروش)
_MT5_TYPE_TO_DIR = {
    0: "BUY", 1: "SELL", 2: "BUY", 3: "SELL",
    4: "BUY", 5: "SELL", 6: "BUY", 7: "SELL",
}

log = logging.getLogger("robot_bridge")


def _coerce_direction(value: Any) -> str:
    """جهتِ سفارش را به BUY/SELL استاندارد می‌کند (رشته یا عددِ نوعِ MT5)."""
    if isinstance(value, bool):  # اصلاح (CLI-002): bool جهتِ معتبر نیست
        return ""
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return _MT5_TYPE_TO_DIR.get(int(value), "")
    s = str(value or "").strip().upper()
    if s.isdigit():
        return _MT5_TYPE_TO_DIR.get(int(s), "")
    # اصلاح (CLI-002): تطبیقِ دقیق به‌جای substring؛ قبلاً NOTBUY/SELLING هم معتبر می‌شد.
    if s in ("BUY", "LONG", "BUY_LIMIT", "BUY_STOP", "ORDER_TYPE_BUY",
             "POSITION_TYPE_BUY", "DEAL_TYPE_BUY"):
        return "BUY"
    if s in ("SELL", "SHORT", "SELL_LIMIT", "SELL_STOP", "ORDER_TYPE_SELL",
             "POSITION_TYPE_SELL", "DEAL_TYPE_SELL"):
        return "SELL"
    return ""


def _as_tp_list(tp: Any, take_profits: Any) -> list:
    """حد سود(ها) را به لیستِ عددی تبدیل می‌کند (تک‌مقدار یا چندمقدار)."""
    out: list = []
    if isinstance(take_profits, Iterable) and not isinstance(take_profits, (str, bytes)):
        for t in take_profits:
            try:
                out.append(float(t["price"] if isinstance(t, dict) else t))
            except (TypeError, ValueError):
                pass
    if tp is not None and tp != "":
        try:
            v = float(tp)
            if v not in out:
                out.append(v)
        except (TypeError, ValueError):
            pass
    # اصلاح (CLI-002): حذفِ NaN/inf و سقفِ ۳ حدِ سود (هم‌قرارداد با سرور)
    import math as _math
    return [v for v in out if _math.isfinite(v)][:3]


# --------------------------------------------------------------------------- #
#  نتیجهٔ برگشتی (سازگار با mt5.order_send + فیلدهای اضافیِ پُل)
# --------------------------------------------------------------------------- #

class BridgeResult:
    """نتیجهٔ ارسالِ یک سفارش به پُل.

    فیلدهای سازگار با MT5:
        retcode  → 10009 یعنی به متاتریدر ارسال شد (TRADE_RETCODE_DONE)
        comment  → توضیحِ متنی
    فیلدهای اختصاصیِ پُل:
        ok        → آیا درخواست بدونِ خطا پردازش شد؟
        approved  → آیا فیلترِ برنامه سفارش را تأیید کرد؟
        forwarded → آیا واقعاً به متاتریدر فرستاده شد؟
        eval      → جزئیاتِ امتیازدهی (سیگنالِ داخلی/AI/دلایل)
        forward   → پاسخِ خامِ ارسال به متاتریدر (در صورتِ ارسال)
        raw       → کلِ پاسخِ خامِ JSON سرور
        http_status، error
    """

    __slots__ = ("ok", "approved", "forwarded", "retcode", "comment",
                 "eval", "forward", "order", "raw", "http_status", "error")

    def __init__(self, **kw: Any) -> None:
        self.ok: bool = kw.get("ok", False)
        self.approved: bool = kw.get("approved", False)
        self.forwarded: bool = kw.get("forwarded", False)
        self.retcode: int = kw.get("retcode", BRIDGE_ERROR)
        self.comment: str = kw.get("comment", "")
        self.eval: dict = kw.get("eval", {}) or {}
        self.forward: dict = kw.get("forward", {}) or {}
        self.order: dict = kw.get("order", {}) or {}
        self.raw: dict = kw.get("raw", {}) or {}
        self.http_status: Optional[int] = kw.get("http_status")
        self.error: Optional[str] = kw.get("error")

    # کمکِ خوانایی
    @property
    def internal_ok(self) -> Optional[bool]:
        return self.eval.get("internal_ok")

    @property
    def ai_ok(self) -> Optional[bool]:
        return self.eval.get("ai_ok")

    @property
    def reasons(self) -> list:
        return self.eval.get("reasons", []) or []

    def __bool__(self) -> bool:
        """در شرطِ if، «موفقیت» یعنی واقعاً به متاتریدر ارسال شده باشد."""
        return bool(self.forwarded)

    def __repr__(self) -> str:
        return (f"<BridgeResult forwarded={self.forwarded} approved={self.approved} "
                f"retcode={self.retcode} comment={self.comment!r}>")


# --------------------------------------------------------------------------- #
#  کلاینتِ اصلی
# --------------------------------------------------------------------------- #

class RobotBridge:
    """کلاینتِ ارسالِ سیگنالِ ربات به «برنامهٔ تحلیل».

    پارامترها:
        base_url : آدرسِ برنامه، مثل "http://127.0.0.1:8000"
        secret   : توکنِ امنیتیِ مشترک (اگر در تب تنظیم کرده‌اید)، وگرنه خالی
        timeout  : مهلتِ هر درخواست (ثانیه)
        retries  : تعدادِ تلاشِ مجدد در صورتِ خطای شبکه
        default_tf : تایم‌فریمِ پیش‌فرضِ ارزیابی وقتی در سفارش نیاید
        raise_on_error : اگر True باشد، خطاهای شبکه/سرور استثنا پرتاب می‌کنند
    """

    def __init__(self, base_url: str = "http://127.0.0.1:8000",
                 secret: str = "", timeout: float = 10.0, retries: int = 2,
                 default_tf: Optional[str] = None,
                 raise_on_error: bool = False) -> None:
        self.base_url = base_url.rstrip("/")
        self.secret = (secret or "").strip()
        self.timeout = float(timeout)
        self.retries = max(0, int(retries))
        self.default_tf = default_tf
        self.raise_on_error = bool(raise_on_error)
        self._session = requests.Session()
        # اصلاح (CLI-003): هشدار دربارهٔ ارسالِ secret روی HTTPِ بدونِ رمزنگاری به میزبانِ راه دور
        if (self.secret and self.base_url.startswith("http://")
                and "://127.0.0.1" not in self.base_url
                and "://localhost" not in self.base_url):
            log.warning("هشدارِ امنیتی: secret روی HTTPِ ساده به میزبانِ غیرمحلی ارسال می‌شود؛ "
                        "برای ارتباطِ راهِ دور از HTTPS یا تونلِ امن استفاده کنید.")

    # ----------------------------------------------------------------- داخلی
    def _endpoint(self, use_test: bool) -> str:
        return f"{self.base_url}/api/robot/{'test' if use_test else 'order'}"

    def _post(self, payload: dict, use_test: bool) -> BridgeResult:
        headers = {"Content-Type": "application/json",
                   "User-Agent": "SP2L-PythonRobot/1.0 (python-requests)"}
        if self.secret:
            headers["X-Robot-Secret"] = self.secret  # احرازِ هویت (روشِ توصیه‌شده)
            payload = {**payload, "secret": self.secret}  # روشِ جایگزین برای وب‌هوک‌های ساده

        url = self._endpoint(use_test)
        last_exc: Optional[Exception] = None

        # اصلاح (CLI-001): برای سفارشِ «واقعی» تلاشِ مجدد خودکار انجام نمی‌شود؛
        # اگر timeout بعد از رسیدنِ درخواست به سرور رخ دهد، retry یعنی سفارشِ تکراری.
        # فقط مسیرِ /test (بدونِ معامله) چند بار تلاش می‌کند.
        attempts = (self.retries + 1) if use_test else 1
        for attempt in range(attempts):
            try:
                resp = self._session.post(url, json=payload, headers=headers,
                                          timeout=self.timeout)
                try:
                    body = resp.json()
                except ValueError:
                    body = {"ok": False, "error": f"پاسخِ نامعتبر ({resp.status_code}): "
                                                  f"{resp.text[:200]}"}
                return self._to_result(body, resp.status_code)
            except requests.RequestException as exc:
                last_exc = exc
                log.warning("robot bridge: تلاش %d ناموفق: %s", attempt + 1, exc)
                if attempt < attempts - 1:
                    time.sleep(0.6 * (attempt + 1))

        msg = f"اتصال به برنامه ({url}) برقرار نشد: {last_exc}"
        if self.raise_on_error:
            raise ConnectionError(msg)
        return BridgeResult(ok=False, retcode=BRIDGE_ERROR, comment=msg, error=msg)

    @staticmethod
    def _to_result(body: dict, status: int) -> BridgeResult:
        """پاسخِ JSON سرور را به BridgeResult (با retcode مناسب) تبدیل می‌کند."""
        ok = bool(body.get("ok"))
        approved = bool(body.get("approved"))
        forwarded = bool(body.get("forwarded"))
        ev = body.get("eval", {}) or {}
        fwd = body.get("forward", {}) or {}

        if not ok:
            comment = body.get("error", "خطای نامشخص")
            retcode = BRIDGE_ERROR
        elif forwarded:
            comment = "به متاتریدر ارسال شد"
            retcode = TRADE_RETCODE_DONE
        elif approved:
            comment = ("تأیید شد ولی به متاتریدر ارسال نشد "
                       "(ارسالِ خودکار خاموش است یا ارسال ناموفق بود)")
            # تفکیکِ «ارسال ناموفق» از «ارسالِ خودکار خاموش»
            retcode = (BRIDGE_FORWARD_FAILED
                       if (fwd and fwd.get("ok") is False)
                       else BRIDGE_APPROVED_NOT_SENT)
            if retcode == BRIDGE_FORWARD_FAILED and fwd.get("error"):
                comment = f"ارسال به متاتریدر ناموفق: {fwd.get('error')}"
        else:
            reasons = ev.get("reasons", []) or []
            comment = "؛ ".join(reasons[-2:]) if reasons else "توسطِ فیلتر رد شد"
            retcode = BRIDGE_REJECTED

        return BridgeResult(ok=ok, approved=approved, forwarded=forwarded,
                            retcode=retcode, comment=comment, eval=ev, forward=fwd,
                            order=body.get("order", {}), raw=body, http_status=status,
                            error=(None if ok else body.get("error")))

    # ---------------------------------------------------------- API عمومی
    def send(self, symbol: str, direction: Any, volume: float,
             sl: Optional[float] = None, tp: Optional[float] = None,
             take_profits: Optional[Iterable] = None,
             entry: Optional[float] = None, tf: Optional[str] = None,
             robot_id: str = "", comment: str = "",
             magic: Optional[int] = None, test: bool = False,
             **extra: Any) -> BridgeResult:
        """یک سیگنال/سفارش را به برنامه می‌فرستد (سبکِ ساده).

        symbol    : نمادِ کارگزار، مثل "XAUUSD" یا نمادِ داخلی مثل "BTC"
        direction : "BUY"/"SELL" یا نوعِ عددیِ MT5 (0/1/…)
        volume    : حجم به لات (عیناً همین مقدار به متاتریدر می‌رود)
        sl, tp    : حدِ ضرر و حدِ سود (اختیاری)
        take_profits : لیستِ چند حدِ سود (اختیاری، جایگزینِ tp)
        entry     : قیمتِ ورود (اختیاری؛ نبودنش یعنی بازار)
        tf        : تایم‌فریمِ ارزیابیِ سیگنال (اختیاری)
        robot_id  : شناسهٔ ربات برای گزارش‌گیری
        magic     : عددِ مجیکِ MT5 (در صورتِ نبودِ robot_id به‌عنوان شناسه استفاده می‌شود)
        test      : اگر True، به /api/robot/test می‌رود (برای آزمایش)
        """
        dir_norm = _coerce_direction(direction)
        payload: dict = {
            "symbol": symbol,
            "direction": dir_norm or direction,
            "volume": volume,
            "robot_id": robot_id or (str(magic) if magic is not None else ""),
            "platform": "python",   # نوعِ سکو برای تفکیک در لاگِ سرور
        }
        if sl is not None:
            payload["sl"] = sl
        tps = _as_tp_list(tp, take_profits)
        if len(tps) == 1:
            payload["tp"] = tps[0]
        elif len(tps) > 1:
            payload["take_profits"] = tps
        if entry is not None:
            payload["entry"] = entry
        tf_final = tf or self.default_tf
        if tf_final:
            payload["tf"] = tf_final
        if comment:
            payload["comment"] = comment
        if magic is not None:
            payload["magic"] = magic
        payload.update(extra)  # هر فیلدِ اضافیِ دلخواه

        return self._post(payload, use_test=test)

    def order_send(self, request: dict, test: bool = False) -> BridgeResult:
        """جایگزینِ مستقیمِ mt5.order_send.

        همان دیکشنریِ استانداردِ متاتریدر را بپذیرید (با کلیدهای symbol/volume/type/
        price/sl/tp/…). این متد آن را به سفارشِ پُل تبدیل و ارسال می‌کند و نتیجه‌ای با
        فیلدِ .retcode (۱۰۰۰۹ = انجام‌شده) برمی‌گرداند تا کدِ قبلیِ شما کار کند.

        مثال:
            request = {"action": mt5.TRADE_ACTION_DEAL, "symbol": "EURUSD",
                       "volume": 0.1, "type": mt5.ORDER_TYPE_BUY,
                       "price": price, "sl": sl, "tp": tp,
                       "magic": 234000, "comment": "my ea"}
            result = bridge.order_send(request)      # به‌جای mt5.order_send(request)
            if result.retcode == 10009: ...
        """
        req = dict(request or {})
        # اصلاح (CLI-001): این API فقط بازکردنِ market را پشتیبانی می‌کند. درخواستِ
        # بستن/تغییرِ SLTP/pending (action غیر از DEAL یا دارای position) قبلاً بی‌صدا
        # به یک BUY/SELL «جدید» تبدیل می‌شد — یعنی به‌جای بستن، پوزیشنِ تکراری باز می‌شد!
        _action = req.get("action")
        if (_action is not None and _action != 1) or req.get("position") is not None:
            _msg = ("این پل فقط بازکردنِ سفارشِ market را پشتیبانی می‌کند؛ "
                    "close/SLTP/pending باید مستقیم با خودِ MetaTrader5 انجام شود.")
            return BridgeResult(ok=False, retcode=BRIDGE_ERROR, comment=_msg, error=_msg)
        return self.send(
            symbol=req.get("symbol", ""),
            direction=req.get("type", req.get("direction", "")),
            volume=req.get("volume", req.get("lot", 0)),
            sl=req.get("sl"),
            tp=req.get("tp"),
            entry=req.get("price"),
            comment=req.get("comment", ""),
            magic=req.get("magic"),
            tf=req.get("tf"),
            test=test,
        )

    # ---------------------------------------------------------- کمک‌ها
    def ping(self) -> bool:
        """بررسیِ در دسترس بودنِ برنامه."""
        try:
            r = self._session.get(f"{self.base_url}/health", timeout=self.timeout)
            return r.ok
        except requests.RequestException:
            return False

    def config(self) -> dict:
        """تنظیماتِ فعلیِ پُل را از برنامه می‌خواند (برای تشخیصِ حالتِ فیلتر و…)."""
        try:
            r = self._session.get(f"{self.base_url}/api/robot/config",
                                  timeout=self.timeout)
            return r.json().get("data", {})
        except (requests.RequestException, ValueError):
            return {}


# --------------------------------------------------------------------------- #
#  توابعِ سطحِ ماژول (برای وقتی که نمی‌خواهید شیء بسازید)
# --------------------------------------------------------------------------- #

_DEFAULT: Optional[RobotBridge] = None


def configure(base_url: str = "http://127.0.0.1:8000", secret: str = "",
              **kwargs: Any) -> RobotBridge:
    """کلاینتِ پیش‌فرضِ سطحِ ماژول را می‌سازد تا از send_signal() استفاده کنید."""
    global _DEFAULT
    _DEFAULT = RobotBridge(base_url, secret=secret, **kwargs)
    return _DEFAULT


def send_signal(symbol: str, direction: Any, volume: float, **kwargs: Any) -> BridgeResult:
    """میان‌برِ ارسال با کلاینتِ پیش‌فرض (ابتدا configure() را صدا بزنید)."""
    if _DEFAULT is None:
        configure()  # پیش‌فرض: localhost:8000 بدونِ توکن
    assert _DEFAULT is not None
    return _DEFAULT.send(symbol, direction, volume, **kwargs)


# --------------------------------------------------------------------------- #
#  نمونهٔ اجرا / راهنمای مهاجرت
# --------------------------------------------------------------------------- #

def _demo() -> None:
    """نمونهٔ کاربردی — این‌ها را با آدرس/نمادهای خودتان تنظیم کنید."""
    # ۱) ساختِ کلاینت (اگر توکنِ مشترک در تب تنظیم کرده‌اید، اینجا بدهید)
    bridge = RobotBridge("http://127.0.0.1:8000", secret="", default_tf="1h")

    # بررسیِ دسترسی
    if not bridge.ping():
        print("⛔ برنامه در دسترس نیست. مطمئن شوید app.py در حال اجراست.")
        return
    print("وضعیتِ پُل:", json.dumps(bridge.config().get("config", {}),
                                    ensure_ascii=False))

    # ۲) سبکِ ساده — یک سفارشِ خرید
    print("\n— ارسالِ سفارشِ نمونه (سبکِ ساده) —")
    res = bridge.send(symbol="BTC", direction="BUY", volume=0.10,
                      sl=50000, tp=70000, tf="1h", robot_id="EA_Demo")
    print(res)
    print("  تأیید:", res.approved, "| ارسال به MT5:", res.forwarded)
    print("  داخلی_ok:", res.internal_ok, "| AI_ok:", res.ai_ok)
    for r in res.reasons:
        print("   -", r)

    # ۳) سبکِ سازگار با MT5 — جایگزینِ mt5.order_send
    print("\n— ارسال با سبکِ سازگار با MetaTrader5 —")
    mt5_style_request = {
        # "action": mt5.TRADE_ACTION_DEAL,   # در پُل نادیده گرفته می‌شود
        "symbol": "XAUUSD",
        "volume": 0.10,
        "type": 0,               # 0 = ORDER_TYPE_BUY  (1 = SELL)
        "price": 2350.5,
        "sl": 2345.0,
        "tp": 2360.0,
        "magic": 234000,
        "comment": "my ea",
        "tf": "1h",
    }
    result = bridge.order_send(mt5_style_request)
    print(result)
    if result.retcode == TRADE_RETCODE_DONE:
        print("  ✅ به متاتریدر ارسال شد.")
    elif result.retcode == BRIDGE_REJECTED:
        print("  ⛔ توسطِ فیلتر رد شد:", result.comment)
    else:
        print("  ℹ️ وضعیت:", result.retcode, "-", result.comment)


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(message)s")
    _demo()
