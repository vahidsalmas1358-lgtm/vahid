# -*- coding: utf-8 -*-
"""رگرسیونِ تبِ «🛰️ سیگنال‌های ورودی ربات‌ها» (اصلاح‌های ROBOT-TAB-001..004).

بک‌اند (با test_client):
  • default_tf: مقدارِ معتبر ذخیره، خراب رد (حفظِ قبلی)، قالبِ متاتریدر (M15) نرمال.
  • /api/robot/test با secret تنظیم‌شده: بدونِ هدر 401، با هدر 200.
فرانت‌اند (بررسیِ ایستا):
  • منوهای تایم‌فریم شاملِ 1m/5m/10m هستند (قبلاً 5m نبود و ذخیره آن را بی‌صدا 15m می‌کرد).
  • آزمایشِ تب هدرِ X-Robot-Secret می‌فرستد و کشِ کانفیگ بعدِ ذخیره تازه می‌شود.
  • نتیجهٔ فیلترِ زمان‌بندی در پنلِ ارزیابی و جدولِ لاگ نمایش داده می‌شود.
"""
import os as _os_env; _os_env.environ.setdefault("BTC_AGENT_ALLOW_INSECURE_ROBOT", "1")  # محیط تست
import shutil

import app
import robots

PASS = 0
FAIL = 0


def chk(name, cond, detail=""):
    global PASS, FAIL
    if cond:
        PASS += 1
    else:
        FAIL += 1
        print(f"   FAIL  {name} — {str(detail)[:200]}")


shutil.copy("robot_config.json", "/tmp/rtt_robot.bak")
app.app.config["TESTING"] = True
client = app.app.test_client()

print("=" * 70)
print(" رگرسیونِ تبِ سیگنال‌های ورودی ربات‌ها")
print("=" * 70)

# ── بک‌اند: اعتبارسنجیِ default_tf (ROBOT-TAB-004)
robots.save_config({"default_tf": "5m"})
chk("default_tf=5m ذخیره می‌شود", robots.load_config()["default_tf"] == "5m",
    robots.load_config()["default_tf"])
robots.save_config({"default_tf": "13x"})
chk("مقدارِ خراب (13x) رد و مقدارِ قبلی حفظ می‌شود",
    robots.load_config()["default_tf"] == "5m", robots.load_config()["default_tf"])
robots.save_config({"default_tf": "M15"})
chk("قالبِ متاتریدر (M15) به 15m نرمال می‌شود",
    robots.load_config()["default_tf"] == "15m", robots.load_config()["default_tf"])
robots.save_config({"default_tf": "H4"})
chk("H4 → 4h", robots.load_config()["default_tf"] == "4h", robots.load_config()["default_tf"])

# ── بک‌اند: secret برای آزمایشِ تب (ROBOT-TAB-002 سمتِ سرور سختگیر می‌ماند)
robots.save_config({"shared_secret": "rtt-secret", "enabled": True})
r = client.post("/api/robot/test", json={"sym": "BTCUSD", "side": "buy", "lots": 0.01})
chk("آزمایش بدونِ هدر → 401", r.status_code == 401, r.status_code)
r = client.post("/api/robot/test", json={"sym": "BTCUSD", "side": "buy", "lots": 0.01},
                headers={"X-Robot-Secret": "rtt-secret"})
chk("آزمایش با هدرِ درست → 200", r.status_code == 200, r.status_code)
d = r.get_json() or {}
chk("پاسخِ آزمایش test=True (مسیرِ شبیه‌سازی)", d.get("test") is True, d.get("test"))
chk("اگر فوروارد شد حتماً simulated=True (هرگز معاملهٔ واقعی)",
    (not d.get("forwarded")) or d.get("simulated") is True,
    {"forwarded": d.get("forwarded"), "simulated": d.get("simulated")})

# ── فرانت‌اند: بررسیِ ایستا
ui = open("static/index.html", encoding="utf-8").read()
chk("منوی تایم‌فریمِ ارزیابی شاملِ 1m/5m/10m",
    ui.count("'1m','5m','10m','15m','30m','1h','2h','4h','1d','1w'") >= 1, "rb_tf")
chk("فرمِ آزمایش هم شاملِ 5m", ui.count("'','1m','5m','10m'") >= 1, "tb_tf")
chk("آزمایشِ تب هدرِ X-Robot-Secret می‌فرستد", '_hdrs["X-Robot-Secret"]=_sec' in ui, "runRobotTest")
chk("کشِ کانفیگ پس از ذخیره تازه می‌شود", "robotCfgCache=j.data.config" in ui, "saveRobotCfg")
chk("ردیفِ زمان‌بندی در پنلِ ارزیابی", "schedRow" in ui and "زمان‌بندیِ سرور" in ui, "robotEvalHTML")
chk("نشانِ ⏰ مسدودیِ زمان‌بندی", "schedBadge" in ui and "مسدود توسط زمان‌بندی" in ui, "badge")
chk("نشانِ ⏰🛑 در جدولِ لاگ", "⏰🛑" in ui, "loadRobotLog")

# ── تایم‌فریمِ ارزیابیِ پیش‌فرض: وقتی ربات tf نفرستد باید default_tf استفاده شود
import json as _json
import dispatch as _dispatch
shutil.copy("dispatch_config.json", "/tmp/rtt_dispatch.bak")
_dispatch.save_config({"news_filter_enabled": False, "schedule_filter_enabled": False})
robots.save_config({"enabled": True, "auto_forward": False, "filter_mode": "internal",
                    "min_internal_score": 0, "require_direction_match": False,
                    "conflict_guard_enabled": False, "dedupe_window_sec": 0.0,
                    "aggregate_window_sec": 0.0, "shared_secret": "", "default_tf": "30m"})
_CAP = []
_DATA = {"direction": "LONG", "internal_score": 50.0, "total_score": 50.0, "price": 100.0,
         "atr": 1.0, "pair": "X", "interval": "?", "generated_at": "x",
         "plan": {"direction": "LONG", "entry": 100.0, "stop_loss": 99.0,
                  "take_profits": [{"price": 101.0}]},
         "technical": {"supports": [], "resistances": []}}
_real_sig = app._signal_for
app._signal_for = lambda sym, tf, with_ai=False: (_CAP.append(tf) or (_DATA, "BTC", None))


def _tf_used(payload):
    _CAP.clear()
    d = client.post("/api/robot/order", json=payload).get_json() or {}
    return (_CAP[0] if _CAP else None), (d.get("eval") or {}).get("tf")


u, e = _tf_used({"sym": "BTCUSD", "side": "buy", "lots": 0.01})
chk("بدون tf → ارزیابی با default_tf (30m)", u == "30m" and e == "30m", (u, e))
u, e = _tf_used({"sym": "BTCUSD", "side": "buy", "lots": 0.01, "tf": "5m"})
chk("tf خودِ ربات مقدم است (5m)", u == "5m" and e == "5m", (u, e))
u, e = _tf_used({"sym": "BTCUSD", "side": "buy", "lots": 0.01, "timeframe": "M15"})
chk("قالب متاتریدر M15 → 15m", u == "15m" and e == "15m", (u, e))
u, e = _tf_used({"sym": "BTCUSD", "side": "buy", "lots": 0.01, "tf": "13x"})
chk("tf خراب → سقوط به default_tf", u == "30m" and e == "30m", (u, e))
_cfgj = _json.load(open("robot_config.json")); _cfgj["default_tf"] = "junk"
_json.dump(_cfgj, open("robot_config.json", "w"), ensure_ascii=False)
u, e = _tf_used({"sym": "BTCUSD", "side": "buy", "lots": 0.01})
chk("default_tf خرابِ فایل → سقوط امن به 1h", u == "1h" and e == "1h", (u, e))
app._signal_for = _real_sig
shutil.copy("/tmp/rtt_dispatch.bak", "dispatch_config.json")

shutil.copy("/tmp/rtt_robot.bak", "robot_config.json")
print("\n" + "=" * 70)
print(f"  نتیجه: {PASS} پاس · {FAIL} ناموفق")
print("=" * 70)
raise SystemExit(1 if FAIL else 0)
