"""دریافت و ارزیابیِ سفارش‌های ربات‌های متاتریدر ۵.

ربات‌های شما (نوشته‌شده با پایتون) به‌جای ارسالِ مستقیمِ سفارش به متاتریدر، سفارش را
به این برنامه می‌فرستند. برنامه سفارش را دقیق دریافت می‌کند، آن را با «سیگنالِ داخلی»
و «سیگنالِ هوش مصنوعی» امتیازدهی می‌کند و تنها در صورتِ تأییدِ فیلترِ انتخابی
(داخلی، هوش مصنوعی، یا هر دو) عینِ همان مشخصات و مقادیر را به متاتریدر می‌فرستد.

این ماژول فقط کانفیگ/لاگ/نرمال‌سازیِ سفارش را نگه می‌دارد؛ منطقِ ارزیابی و ارسال در
app.py است چون به engine/ai_bridge/mt5_bridge نیاز دارد.
"""
from __future__ import annotations
import os
import json
import threading

CONFIG_PATH = os.path.join(os.path.dirname(__file__), "robot_config.json")
LOG_PATH = os.path.join(os.path.dirname(__file__), "robot_signals.json")

_lock = threading.RLock()
_log_lock = threading.Lock()

VALID_MODES = ("internal", "ai", "both")


def _default_config() -> dict:
    return {
        "enabled": True,               # کلیدِ اصلی: آیا پُلِ ربات‌ها فعال است؟
        "filter_mode": "both",         # internal | ai | both
        "require_direction_match": True,  # جهتِ سیگنال باید با جهتِ سفارشِ ربات یکی باشد
        "min_internal_score": 15.0,    # حداقلِ قدرِمطلقِ امتیازِ داخلی برای تأیید
        "min_ai_score": 15.0,          # حداقلِ قدرِمطلقِ امتیازِ AI برای تأیید
        "auto_forward": True,          # پس از تأیید، خودکار به متاتریدر ارسال شود؟
        "respect_robot_volume": True,  # حجمِ دقیقِ ربات حفظ شود (بدونِ محاسبه‌ی ریسکِ مجدد)
        "default_tf": "1h",            # تایم‌فریمِ ارزیابیِ سیگنال وقتی ربات آن را نفرستد
        "shared_secret": "",           # اگر پر باشد، ربات باید همین توکن را در هدر/بدنه بفرستد
        # --- فیلتر اخبار (جلوگیری از معامله نزدیکِ اخبارِ پرتأثیر) ---
        "news_filter_enabled": True,   # فیلتر اخبار برای سفارش‌های ربات فعال باشد؟
        "news_before_min": 30,         # چند دقیقه قبل از رویداد، ارسال مسدود شود
        "news_after_min": 30,          # چند دقیقه بعد از رویداد، ارسال مسدود شود
        "news_impact": "High",         # حداقلِ تأثیر برای مسدودسازی: High | Medium | Low
        # --- مدیریتِ سیگنال‌های همزمان/تکراری/متضاد (Conflict & Duplicate Guard) ---
        "conflict_guard_enabled": True,   # فعال‌سازیِ داوریِ سیگنال‌های همزمان
        "aggregate_window_sec": 2.0,      # پنجرهٔ جمع‌آوریِ سیگنال‌های همزمان برای انتخابِ بهترین (۰=خاموش)
        "dedupe_window_sec": 60.0,        # تا این مدت پس از ارسال، سیگنالِ هم‌جهتِ تکراری رد شود
        "block_duplicate_open": True,     # اگر پوزیشنِ باز هم‌جهت روی نماد باشد، ارسالِ تکراری رد شود
        "block_opposite_open": True,      # اگر پوزیشنِ باز مخالف روی نماد باشد، سیگنالِ مخالف رد شود (بدونِ هج)
        # اگر متاتریدر متصل باشد ولی خواندنِ پوزیشن‌ها ناموفق شود، محافظِ تکرار/تضاد
        # عملاً دور زده می‌شود (fail-open). با روشن‌کردنِ این گزینه، در چنین حالتی
        # ارسال «محتاطانه» مسدود می‌شود تا از بازشدنِ پوزیشنِ تکراری/متضادِ ناخواسته
        # جلوگیری شود. (پیش‌فرض خاموش تا رفتارِ قبلی حفظ شود.)
        "position_guard_fail_closed": False,
    }


def load_config() -> dict:
    cfg = _default_config()
    if os.path.exists(CONFIG_PATH):
        try:
            with open(CONFIG_PATH, encoding="utf-8") as f:
                cfg.update(json.load(f) or {})
        except Exception:  # noqa
            pass
    if cfg.get("filter_mode") not in VALID_MODES:
        cfg["filter_mode"] = "both"
    return cfg


_VALID_TFS = {"1m", "5m", "10m", "15m", "30m", "1h", "2h", "4h", "1d", "1w"}


def save_config(patch: dict) -> dict:
    cfg = load_config()
    allowed = set(_default_config().keys())   # فقط کلیدهای شناخته‌شده
    for k, v in (patch or {}).items():
        if v is None or k not in allowed:
            continue
        # اصلاح (ROBOT-TAB-004): تایم‌فریمِ پیش‌فرض اعتبارسنجی/نرمال‌سازی می‌شود؛
        # مقدارِ خراب (مثل "13x") ذخیره نمی‌شود و مقدارِ قبلی حفظ می‌ماند.
        if k == "default_tf":
            _tf = normalize_tf(v)
            if _tf not in _VALID_TFS:
                continue
            v = _tf
        cfg[k] = v
    for k in [k for k in cfg if k not in allowed]:
        cfg.pop(k, None)
    # اصلاح (هم‌خانوادهٔ DISP-001): کلیدِ بولی با رشتهٔ "false"/"0"/"off" دیگر True نمی‌شود
    def _as_bool(v):
        if isinstance(v, str):
            return v.strip().lower() not in ("", "0", "false", "no", "off", "none")
        return bool(v)
    for _k, _dv in _default_config().items():
        if isinstance(_dv, bool):
            cfg[_k] = _as_bool(cfg.get(_k, _dv))
    if cfg.get("filter_mode") not in VALID_MODES:
        cfg["filter_mode"] = "both"
    with _lock:
        with open(CONFIG_PATH, "w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False, indent=2)
    return cfg


# ------------------------------------------------------------------------- لاگ
import db  # noqa: E402

_LOG_CHANNEL = "robot"
_LOG_CAP = 500
_log_migrated = False


def _ensure_log_migrated():
    global _log_migrated
    if _log_migrated:
        return
    with _log_lock:
        if _log_migrated:
            return
        try:
            db.migrate_logs_from_json(_LOG_CHANNEL, LOG_PATH, _LOG_CAP)
        except Exception:  # noqa
            pass
        _log_migrated = True


def append_log(entry: dict) -> dict:
    _ensure_log_migrated()
    return db.add_log(_LOG_CHANNEL, entry, cap=_LOG_CAP)


def read_log(limit: int = 200) -> list:
    _ensure_log_migrated()
    return db.get_logs(_LOG_CHANNEL, limit)


def clear_log() -> None:
    _ensure_log_migrated()
    db.clear_logs(_LOG_CHANNEL)


def stats() -> dict:
    """آمارِ کلیِ سفارش‌های دریافتی (برای نمایش در بالای تب).

    نکته: منبعِ لاگ به SQLite منتقل شده است؛ این تابع باید از همان منبعِ
    read_log/append_log بخواند، نه از فایلِ JSONِ بازنشسته‌شده (که پس از
    مهاجرت به .migrated تغییرِ نام می‌یابد و دیگر وجود ندارد).
    """
    # اصلاح (ROBOT-TAB-005): رکوردهای «آزمایشی» (دکمهٔ 🧪 خودِ تب) آمارِ واقعی را
    # آلوده نمی‌کنند؛ جداگانه شمارش می‌شوند تا «ارسال به MT5» فقط ارسالِ واقعی باشد.
    out = {"total": 0, "approved": 0, "rejected": 0, "forwarded": 0, "errors": 0,
           "tests": 0}
    try:
        data = read_log(_LOG_CAP)
    except Exception:  # noqa
        return out
    for r in data:
        if r.get("test"):
            out["tests"] += 1
            continue
        out["total"] += 1
        if r.get("error"):
            out["errors"] += 1
        if r.get("approved"):
            out["approved"] += 1
        else:
            out["rejected"] += 1
        if r.get("forwarded"):
            out["forwarded"] += 1
    return out


# ----------------------------------------------------------- نرمال‌سازیِ سفارش
def _first(d: dict, *keys, default=None):
    for k in keys:
        if k in d and d[k] not in (None, ""):
            return d[k]
    return default


def _to_float(x):
    # اصلاح (ROB-001): bool نباید به عدد تبدیل شود (float(True)==1.0 →
    # volume=true یک لات کامل می‌شد و از validate_order عبور می‌کرد).
    if isinstance(x, bool):
        return None
    try:
        if x is None or x == "":
            return None
        return float(x)
    except Exception:  # noqa
        return None


# نگاشتِ تایم‌فریمِ متاتریدر (M1/M5/H1/…) → قالبِ داخلیِ برنامه (1m/5m/1h/…)
# ربات‌های MQL5 تایم‌فریم را به سبکِ متاتریدر می‌فرستند (مثلاً "M5" یا "H1")؛ اگر نگاشت
# نشوند، در ارزیابی به تایم‌فریمِ پیش‌فرض سقوط می‌کنند و سیگنال روی تایم‌فریمِ اشتباه سنجیده می‌شود.
_MT5_TF_MAP = {
    "M1": "1m", "M5": "5m", "M10": "10m", "M15": "15m", "M30": "30m",
    "H1": "1h", "H2": "2h", "H4": "4h", "D1": "1d", "W1": "1w", "MN1": "1mn",
}


def normalize_tf(val) -> str:
    """تایم‌فریم را به قالبِ داخلی (مثل 5m/1h) استاندارد می‌کند.

    - قالبِ داخلی (5m/1h/…) دست‌نخورده برمی‌گردد.
    - قالبِ متاتریدر (M5/H1/H4/D1/W1/…) به معادلِ داخلی نگاشت می‌شود.
    - مقادیرِ ناشناخته بدونِ تغییر (فقط trim) برمی‌گردند تا لایهٔ بالادست تصمیم بگیرد.
    """
    s = str(val or "").strip()
    if not s:
        return ""
    low = s.lower()
    # قالبِ داخلیِ رایج (5m, 15m, 1h, 4h, 1d, 1w, 10m, 1m)
    if low and (low[-1] in ("m", "h", "d", "w")) and low[:-1].isdigit():
        return low
    up = s.upper()
    if up in _MT5_TF_MAP:
        return _MT5_TF_MAP[up]
    return low


def normalize_direction(val) -> str:
    """جهتِ سفارش را به LONG/SHORT استاندارد می‌کند (پشتیبانی از مترادف‌های رایجِ MT5)."""
    s = str(val).strip().upper()
    if s in ("BUY", "LONG", "0", "BUY_LIMIT", "BUY_STOP", "ORDER_TYPE_BUY", "B"):
        return "LONG"
    if s in ("SELL", "SHORT", "1", "SELL_LIMIT", "SELL_STOP", "ORDER_TYPE_SELL", "S"):
        return "SHORT"
    # اصلاح (ROB-001): جست‌وجوی زیررشته‌ایِ آزاد حذف شد — قبلاً «NOTBUY» خرید و
    # «DONTSELL» فروش تفسیر می‌شد! فقط الگوهای شناخته‌شدهٔ MT5 پذیرفته می‌شوند.
    if s.startswith(("BUY_", "ORDER_TYPE_BUY", "POSITION_TYPE_BUY", "DEAL_TYPE_BUY")) or s == "LONG":
        return "LONG"
    if s.startswith(("SELL_", "ORDER_TYPE_SELL", "POSITION_TYPE_SELL", "DEAL_TYPE_SELL")):
        return "SHORT"
    return "NEUTRAL"


def normalize_order(payload: dict) -> dict:
    """سفارشِ خامِ ربات را به قالبِ استانداردِ داخلی تبدیل می‌کند.

    مترادف‌های پشتیبانی‌شده:
      symbol: symbol/sym/instrument
      direction: direction/type/order_type/side/action/cmd
      volume: volume/vol/lot/lots/size
      entry: entry/price/open_price/entry_price
      sl: sl/stop_loss/stoploss/stop
      tp: tp/take_profit/takeprofit  |  tp1/tp2/tp3  |  take_profits/tps (لیست)
      tf: tf/timeframe/period
      robot_id: robot_id/robot/ea/magic/name/id
      comment: comment/note
    """
    p = payload or {}
    symbol = _first(p, "symbol", "sym", "instrument", "pair", default="")
    direction = normalize_direction(_first(p, "direction", "type", "order_type",
                                           "side", "action", "cmd", default=""))
    volume = _to_float(_first(p, "volume", "vol", "lot", "lots", "size", "quantity"))
    entry = _to_float(_first(p, "entry", "price", "open_price", "entry_price"))
    sl = _to_float(_first(p, "sl", "stop_loss", "stoploss", "stop"))

    # حد سودها: هم لیستِ take_profits/tps و هم tp/tp1/tp2/tp3
    tps = []
    lst = _first(p, "take_profits", "tps", "tp_list")
    if isinstance(lst, (list, tuple)):
        for t in lst:
            v = _to_float(t["price"] if isinstance(t, dict) else t)
            if v is not None:
                tps.append(v)
    single = _to_float(_first(p, "tp", "take_profit", "takeprofit"))
    if single is not None and single not in tps:
        tps.append(single)
    for k in ("tp1", "tp2", "tp3"):
        v = _to_float(p.get(k))
        if v is not None and v not in tps:
            tps.append(v)
    # اصلاح (ROB-002): مقادیرِ غیرمتناهی حذف و سقفِ ۳ حدِ سود اعمال می‌شود تا
    # payloadِ خراب نتواند ده‌ها پله (تقویتِ سفارش) بسازد.
    import math as _math
    tps = [t for t in tps if isinstance(t, (int, float)) and _math.isfinite(t)][:3]

    tf = normalize_tf(_first(p, "tf", "timeframe", "period", default=""))
    robot_id = str(_first(p, "robot_id", "robot", "ea", "magic", "name", "id",
                          default="") or "").strip()
    comment = str(_first(p, "comment", "note", default="") or "").strip()
    # نوعِ سکوی فرستنده: python / mql5 (برای تفکیک در لاگ)
    platform = str(_first(p, "platform", "client", "source_type", "origin",
                          default="") or "").strip().lower()

    return {
        "symbol": str(symbol).strip(),
        "direction": direction,
        "volume": volume,
        "entry": entry,
        "sl": sl,
        "tps": tps,
        "tf": tf,
        "robot_id": robot_id,
        "comment": comment,
        "platform": platform,
    }


def validate_order(order: dict) -> str:
    """اعتبارسنجیِ پایه؛ در صورتِ اشکال، متنِ خطا (فارسی) برمی‌گرداند، وگرنه رشته‌ی خالی."""
    import math as _math
    if not order.get("symbol"):
        return "نماد (symbol) در سفارش موجود نیست."
    if order.get("direction") not in ("LONG", "SHORT"):
        return "جهتِ سفارش (BUY/SELL) نامعتبر یا موجود نیست."
    vol = order.get("volume")
    # اصلاح (ROB-003): NaN مقدارِ truthy است و NaN<=0 هم False — قبلاً حجمِ NaN
    # از اعتبارسنجی عبور می‌کرد. اکنون متناهی‌بودنِ همهٔ اعداد بررسی می‌شود.
    if not isinstance(vol, (int, float)) or not _math.isfinite(vol) or vol <= 0:
        return "حجمِ سفارش (volume/lot) نامعتبر یا موجود نیست."
    for k in ("entry", "sl"):
        v = order.get(k)
        if v is not None and (not isinstance(v, (int, float)) or not _math.isfinite(v)):
            return f"مقدارِ {k} نامعتبر است (NaN/inf)."
    for t in (order.get("tps") or []):
        if not isinstance(t, (int, float)) or not _math.isfinite(t):
            return "حدِ سود (TP) نامعتبر است (NaN/inf)."
    return ""
