"""تشخیص باز/بسته بودن بازارها (به‌ویژه آخر هفته و جمعه) برای هر نماد.

- کریپتو: ۲۴/۷ همیشه باز است.
- فارکس/فلزات/کالا/شاخص (به‌صورت CFD): آخر هفته بسته‌اند. هفته‌ی معاملاتی از
  یکشنبه ۲۱:۰۰ UTC (باز شدن سیدنی) تا جمعه ۲۱:۰۰ UTC است. شنبه کاملاً بسته است.

این ماژول کاملاً محلی و بدون شبکه است؛ فقط بر پایه‌ی ساعت UTC کار می‌کند تا
هم برای نمایش بنر در داشبورد و هم برای جلوگیری از ارسال معامله‌ی واقعی روی
بازارِ بسته استفاده شود.

نکته درباره‌ی DST: باز/بسته‌شدن دقیق FX کمی با تغییر ساعت تابستانی جابه‌جا می‌شود
(۲۰:۰۰ تا ۲۲:۰۰ UTC). ما ۲۱:۰۰ UTC را به‌عنوان یک تقریبِ امن و پایدار انتخاب
کرده‌ایم؛ این برای هشدار کاربر و پرهیز از ارسال در آخر هفته کافی است. تصمیم
نهاییِ اجرا همیشه با خودِ کارگزار است.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone

import symbols as sym

# ساعت باز/بسته‌شدن هفتگی فارکس/CFD بر حسب UTC
_FX_OPEN_WD = 6      # یکشنبه (Mon=0..Sun=6)
_FX_OPEN_HOUR = 21   # ساعت باز شدن در یکشنبه
_FX_CLOSE_WD = 4     # جمعه
_FX_CLOSE_HOUR = 21  # ساعت بسته شدن در جمعه

# کلاس دارایی‌هایی که تابع ساعات بازار سنتی‌اند (آخر هفته تعطیل)
_SESSION_CLASSES = {"forex", "metal", "commodity", "index"}

# اصلاح (MH-001): sym.get برای نمادِ ناشناخته به پروفایلِ پیش‌فرض (BTC/کریپتو)
# برمی‌گردد؛ در نتیجه نمادهای کارگزار با پسوند (XAUUSD.m، EURUSD.r، GOLD و…)
# «کریپتوی ۲۴/۷» تلقی می‌شدند و محافظتِ آخر هفته/جمعه از دست می‌رفت.
# اینجا اول از نگاشتِ کارگزار→داخلی استفاده می‌کنیم و اگر ناشناخته ماند،
# با نشانه‌های نام تصمیم می‌گیریم؛ پیش‌فرضِ محافظه‌کارانه = بازارِ سنتی
# (یعنی آخر هفته بسته) تا معامله روی بازارِ بسته ارسال نشود.
_CRYPTO_HINTS = ("BTC", "XBT", "BITCOIN", "ETH", "ETHEREUM", "SOL", "SOLANA",
                 "BNB", "XRP", "RIPPLE", "DOGE", "ADA", "LTC", "TRX", "DOT",
                 "AVAX", "LINK", "SHIB", "PEPE", "TON", "CRYPTO", "PERP")


def _class_for(symbol: str) -> str:
    """کلاسِ دارایی برای نمادِ داخلی یا نمادِ کارگزار (با پسوند)."""
    s = (symbol or "").strip().upper()
    if s in sym.SYMBOLS:
        return sym.SYMBOLS[s].get("asset_class", "crypto")
    try:  # نگاشتِ کارگزار→داخلی (واردسازیِ تنبل برای پرهیز از وابستگیِ حلقوی)
        import mt5_bridge
        mapped = (mt5_bridge.internal_for_broker(symbol) or "").upper()
        if mapped in sym.SYMBOLS:
            return sym.SYMBOLS[mapped].get("asset_class", "crypto")
    except Exception:  # noqa
        pass
    base = s.split(".")[0].split("_")[0].split("-")[0]
    if any(h in base for h in _CRYPTO_HINTS):
        return "crypto"
    return "forex"  # محافظه‌کارانه: مشمولِ تعطیلیِ آخر هفته


def _fx_is_open(dt: datetime) -> bool:
    """آیا در لحظه‌ی dt (UTC) بازار فارکس/CFD باز است؟"""
    wd, h = dt.weekday(), dt.hour
    if wd == 5:                      # شنبه: کاملاً بسته
        return False
    if wd == _FX_CLOSE_WD and h >= _FX_CLOSE_HOUR:   # جمعه بعد از ۲۱:۰۰
        return False
    if wd == _FX_OPEN_WD and h < _FX_OPEN_HOUR:      # یکشنبه قبل از ۲۱:۰۰
        return False
    return True


def _next_fx_open(dt: datetime) -> datetime:
    """نخستین زمانِ باز شدن بازار پس از dt (وقتی بازار بسته است)."""
    # به ابتدای ساعت گِرد کن و جلو برو تا به بازِ شدن برسیم
    cur = dt.replace(minute=0, second=0, microsecond=0) + timedelta(hours=1)
    for _ in range(0, 24 * 8):       # حداکثر ۸ روز جست‌وجو
        if _fx_is_open(cur):
            return cur
        cur += timedelta(hours=1)
    return dt


def _next_fx_close(dt: datetime) -> datetime:
    """نخستین زمانِ بسته شدن بازار پس از dt (وقتی بازار باز است)."""
    # بسته شدنِ بعدی همان جمعه ۲۱:۰۰ UTC این هفته است
    cur = dt.replace(minute=0, second=0, microsecond=0) + timedelta(hours=1)
    for _ in range(0, 24 * 8):
        if not _fx_is_open(cur):
            return cur
        cur += timedelta(hours=1)
    return dt


def is_open(symbol: str, now: datetime = None) -> bool:
    """آیا بازارِ این نماد اکنون باز است؟ (کریپتو همیشه باز)"""
    ac = _class_for(symbol)
    if ac not in _SESSION_CLASSES:
        return True
    now = now or datetime.now(timezone.utc)
    return _fx_is_open(now)


def status(symbol: str, now: datetime = None) -> dict:
    """وضعیت کاملِ بازارِ نماد برای نمایش و منطق.

    خروجی: {open, asset_class, always_open, next_change_ts, next_change_in_min,
             reason_fa, reason_en}
    """
    now = now or datetime.now(timezone.utc)
    ac = _class_for(symbol)
    if ac not in _SESSION_CLASSES:
        return {
            "open": True, "asset_class": ac, "always_open": True,
            "next_change_ts": None, "next_change_in_min": None,
            "reason_fa": "بازار کریپتو ۲۴ ساعته و ۷ روز هفته باز است.",
            "reason_en": "Crypto market is open 24/7.",
        }

    op = _fx_is_open(now)
    if op:
        nxt = _next_fx_close(now)
        reason_fa = "بازار باز است."
        reason_en = "Market is open."
    else:
        nxt = _next_fx_open(now)
        wd = now.weekday()
        if wd == 4:  # جمعه بعد از بسته‌شدن
            reason_fa = "بازار برای آخر هفته بسته شده است (جمعه). تا یکشنبه شب باز نمی‌شود."
            reason_en = "Market closed for the weekend (Friday). Reopens Sunday evening (UTC)."
        elif wd == 5:
            reason_fa = "امروز شنبه است و بازارهای سنتی تعطیل‌اند."
            reason_en = "It's Saturday — traditional markets are closed."
        else:
            reason_fa = "بازار هنوز باز نشده است (پیش از باز شدنِ یکشنبه‌شب)."
            reason_en = "Market not open yet (before Sunday open)."

    mins = max(0, round((nxt - now).total_seconds() / 60))
    return {
        "open": op, "asset_class": ac, "always_open": False,
        "next_change_ts": nxt.timestamp(),
        "next_change_in_min": mins,
        "reason_fa": reason_fa, "reason_en": reason_en,
    }


if __name__ == "__main__":
    import json
    for s in ["BTC", "EURUSD", "XAU", "SPX"]:
        print(s, json.dumps(status(s), ensure_ascii=False))
