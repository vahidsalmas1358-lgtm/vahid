"""بک‌تست استراتژی روی داده تاریخی.

استراتژی بر پایه امتیاز تکنیکال (همان منطق موتور زنده) است. در هر کندل امتیاز
تکنیکال محاسبه می‌شود؛ اگر از آستانه عبور کند و پوزیشن باز نباشد، معامله باز
می‌شود. ورود = قیمت بسته‌شدن، استاپ = ۱.۵×ATR، هدف = ۳×ATR (معادل TP2 موتور).
سپس روی کندل‌های بعدی بررسی می‌شود که ابتدا استاپ خورده یا هدف.

نکته: تحلیل فاندامنتال و سنتیمنتال چون فقط لحظه‌ای در دسترس‌اند در بک‌تست
تاریخی لحاظ نمی‌شوند و بک‌تست صرفاً بخش تکنیکال را می‌سنجد.
"""
from __future__ import annotations
import numpy as np
import pandas as pd

import indicators as ind
import data_sources as ds


def _dec(price):
    """اعشار پویا برای گِرد کردن قیمت‌ها (فارکس/ین/کریپتو با بزرگی متفاوت).

    به منبعِ حقیقتِ واحدِ indicators.price_decimals واگذار می‌شود تا اعشارِ
    گزارشِ بک‌تست دقیقاً با موتورِ سیگنال و اندیکاتورها هماهنگ باشد
    (پیش‌تر بازهٔ ≥۱۰۰ سه‌رقمی بود و با بقیه ناسازگار می‌شد).
    """
    return ind.price_decimals(price)


def _technical_score_series(df):
    """امتیاز تکنیکال را برای هر کندل به‌صورت برداری محاسبه می‌کند (نرمال به -100..100)."""
    close = df["close"]
    ema20 = ind.ema(close, 20)
    ema50 = ind.ema(close, 50)
    ema200 = ind.ema(close, 200) if len(close) >= 200 else ind.ema(close, min(len(close) - 1, 100))
    rsi = ind.rsi(close, 14)
    _, _, hist = ind.macd(close)
    up, mid, low = ind.bollinger(close)
    k, d = ind.stochastic(df)
    adx_s, plus_di, minus_di = ind.adx(df, 14)
    tenkan, kijun, senkou_a, senkou_b = ind.ichimoku(df)

    score = pd.Series(0.0, index=df.index)

    # روند EMA 20/50
    up_trend = (close > ema50) & (ema20 > ema50)
    dn_trend = (close < ema50) & (ema20 < ema50)
    score += np.where(up_trend, 1.5, np.where(dn_trend, -1.5, 0.0))

    # EMA200
    score += np.where(close > ema200, 0.8, -0.8)

    # RSI
    rsi_dir = np.where(rsi < 30, 1.0, np.where(rsi > 70, -1.0,
                       np.where(rsi >= 50, 1.0, -1.0)))
    score += rsi_dir * 1.0

    # MACD
    score += np.where(hist > 0, 1.0, -1.0)

    # Stochastic
    stoch_dir = np.where(k < 20, 1.0, np.where(k > 80, -1.0,
                         np.where(k > d, 1.0, -1.0)))
    score += stoch_dir * 0.6

    # Bollinger
    boll = np.where(close <= low, 1.0, np.where(close >= up, -1.0, 0.0))
    score += boll * 0.5

    # ADX + DI (قدرت روند)
    adx_dir = np.where(adx_s >= 20, np.where(plus_di > minus_di, 1.0, -1.0), 0.0)
    score += adx_dir * 1.0

    # Ichimoku (ابر کومو)
    cloud_top = pd.concat([senkou_a, senkou_b], axis=1).max(axis=1)
    cloud_bot = pd.concat([senkou_a, senkou_b], axis=1).min(axis=1)
    ich = np.where(close > cloud_top, 1.0, np.where(close < cloud_bot, -1.0, 0.0))
    ich = np.where(np.isnan(cloud_top) | np.isnan(cloud_bot), 0.0, ich)
    score += ich * 1.2

    return (score / 7.6 * 100).clip(-100, 100)


def run_backtest(symbol="BTC", interval="1h", bars=800,
                 threshold=25.0, atr_mult_sl=1.5, atr_mult_tp=3.0,
                 allow_short=True, df=None):
    if df is None:
        df = ds.get_history(symbol, interval, bars)
    df = df.reset_index(drop=True)
    if len(df) < 120:
        raise RuntimeError("داده تاریخی کافی برای بک‌تست موجود نیست")
    return run_backtest_df(df, symbol, interval, threshold=threshold,
                           atr_mult_sl=atr_mult_sl, atr_mult_tp=atr_mult_tp,
                           allow_short=allow_short)


def run_backtest_df(df, symbol="BTC", interval="1h",
                    threshold=25.0, atr_mult_sl=1.5, atr_mult_tp=3.0,
                    allow_short=True, initial_deposit=10000.0, risk_pct=1.0):
    """اجرای بک‌تست روی یک DataFrame از پیش دریافت‌شده (برای بهینه‌سازی سریع).

    initial_deposit: موجودی اولیهٔ حساب (دلار). risk_pct: درصد ریسک روی موجودیِ
    جاری در هر معامله (کامپاند). سود هر معامله = ریسکِ دلاری × R.
    """
    df = df.reset_index(drop=True)
    atr = ind.atr(df, 14).values
    tscore = _technical_score_series(df).values
    high = df["high"].values
    low = df["low"].values
    close = df["close"].values
    times = df["time"].values

    # اصلاح (BACKTEST-001): inf از گاردِ <=0 عبور می‌کرد و ضرایبِ ATR منفی/غیرهانتم
    # اصلاً اعتبارسنجی نمی‌شدند؛ همه با fallback امن مهار می‌شوند.
    import math as _m
    try:
        initial_deposit = float(initial_deposit)
    except Exception:  # noqa
        initial_deposit = 10000.0
    if not _m.isfinite(initial_deposit) or initial_deposit <= 0:
        initial_deposit = 10000.0
    try:
        risk_pct = float(risk_pct)
    except Exception:  # noqa
        risk_pct = 1.0
    if not _m.isfinite(risk_pct) or not (0 < risk_pct <= 100):
        risk_pct = 1.0
    try:
        atr_mult_sl = float(atr_mult_sl)
    except Exception:  # noqa
        atr_mult_sl = 1.5
    if not _m.isfinite(atr_mult_sl) or atr_mult_sl <= 0:
        atr_mult_sl = 1.5
    try:
        atr_mult_tp = float(atr_mult_tp)
    except Exception:  # noqa
        atr_mult_tp = 3.0
    if not _m.isfinite(atr_mult_tp) or atr_mult_tp <= 0:
        atr_mult_tp = 3.0

    warmup = 50
    trades = []
    equity = []           # منحنی سرمایه: [{t, balance, r}]
    cum_r = 0.0
    balance = initial_deposit
    equity.append({"t": int(times[warmup]) if warmup < len(times) else int(times[0]),
                   "balance": round(balance, 2), "r": 0.0})
    i = warmup
    n = len(df)

    while i < n - 1:
        s = tscore[i]
        direction = None
        if s >= threshold:
            direction = "LONG"
        elif s <= -threshold and allow_short:
            direction = "SHORT"

        if direction is None:
            i += 1
            continue

        entry = close[i]
        a = atr[i]
        if not np.isfinite(a) or a <= 0:
            i += 1
            continue

        if direction == "LONG":
            sl = entry - atr_mult_sl * a
            tp = entry + atr_mult_tp * a
        else:
            sl = entry + atr_mult_sl * a
            tp = entry - atr_mult_tp * a

        risk = abs(entry - sl)
        outcome, exit_price, exit_i = None, None, None

        for j in range(i + 1, n):
            hi, lo = high[j], low[j]
            if direction == "LONG":
                hit_sl = lo <= sl
                hit_tp = hi >= tp
            else:
                hit_sl = hi >= sl
                hit_tp = lo <= tp
            if hit_sl and hit_tp:      # هر دو در یک کندل → محافظه‌کارانه: استاپ
                outcome, exit_price, exit_i = "loss", sl, j
                break
            if hit_sl:
                outcome, exit_price, exit_i = "loss", sl, j
                break
            if hit_tp:
                outcome, exit_price, exit_i = "win", tp, j
                break

        if outcome is None:            # تا انتها بسته نشد → با آخرین قیمت خروج
            exit_price, exit_i = close[-1], n - 1
            r_mult = ((exit_price - entry) if direction == "LONG" else (entry - exit_price)) / risk
            outcome = "open_end"
        else:
            r_mult = atr_mult_tp / atr_mult_sl if outcome == "win" else -1.0

        cum_r += r_mult
        # سود/زیانِ دلاری با کامپاند: ریسکِ هر معامله = درصد ریسک × موجودیِ جاری
        risk_amount = balance * (risk_pct / 100.0)
        profit = risk_amount * r_mult
        balance += profit
        pdec = _dec(entry)
        trades.append({
            "dir": direction,
            "entry": round(float(entry), pdec),
            "exit": round(float(exit_price), pdec),
            "sl": round(float(sl), pdec),
            "tp": round(float(tp), pdec),
            "outcome": outcome,
            "r": round(float(r_mult), 2),
            "profit": round(float(profit), 2),
            "balance": round(float(balance), 2),
            "t_in": int(times[i]),
            "t_out": int(times[exit_i]),
        })
        equity.append({"t": int(times[exit_i]), "balance": round(balance, 2),
                       "r": round(cum_r, 2)})

        i = exit_i + 1   # بعد از خروج، دنبال معامله بعدی

    # متریک‌ها
    wins = [t for t in trades if t["r"] > 0]
    losses = [t for t in trades if t["r"] <= 0]
    total = len(trades)
    win_rate = (len(wins) / total * 100) if total else 0
    gross_win = sum(t["r"] for t in wins)
    gross_loss = abs(sum(t["r"] for t in losses))
    profit_factor = (gross_win / gross_loss) if gross_loss > 0 else (gross_win if gross_win else 0)

    # حداکثر افت سرمایه (max drawdown) روی منحنی R
    peak, max_dd = -1e9, 0.0
    for e in equity:
        peak = max(peak, e["r"])
        max_dd = max(max_dd, peak - e["r"])

    # ---- متریک‌های پولی به سبک متاتریدر ۵ ----
    gross_profit_money = sum(t["profit"] for t in wins)
    gross_loss_money = abs(sum(t["profit"] for t in losses))
    net_profit_money = balance - initial_deposit
    profit_factor_money = (gross_profit_money / gross_loss_money) if gross_loss_money > 0 \
        else (gross_profit_money if gross_profit_money else 0.0)
    ret_pct = (net_profit_money / initial_deposit * 100.0) if initial_deposit else 0.0
    expected_payoff = (net_profit_money / total) if total else 0.0

    # افت سرمایهٔ پولی روی منحنی موجودی
    peak_b, max_dd_money, max_dd_pct = -1e18, 0.0, 0.0
    for e in equity:
        peak_b = max(peak_b, e["balance"])
        dd = peak_b - e["balance"]
        if dd > max_dd_money:
            max_dd_money = dd
            max_dd_pct = (dd / peak_b * 100.0) if peak_b > 0 else 0.0

    win_profits = [t["profit"] for t in wins]
    loss_profits = [t["profit"] for t in losses]
    largest_win = max(win_profits) if win_profits else 0.0
    largest_loss = min(loss_profits) if loss_profits else 0.0
    avg_win_money = (sum(win_profits) / len(win_profits)) if win_profits else 0.0
    avg_loss_money = (sum(loss_profits) / len(loss_profits)) if loss_profits else 0.0

    # بیشترین بُردها/باخت‌های متوالی
    max_cons_win = max_cons_loss = 0
    cw = cl = 0
    for t in trades:
        if t["r"] > 0:
            cw += 1
            cl = 0
        else:
            cl += 1
            cw = 0
        max_cons_win = max(max_cons_win, cw)
        max_cons_loss = max(max_cons_loss, cl)

    return {
        "symbol": symbol.upper(),
        "interval": interval,
        "bars_tested": int(n),
        "params": {"threshold": threshold, "sl_atr": atr_mult_sl, "tp_atr": atr_mult_tp,
                   "allow_short": allow_short, "initial_deposit": round(initial_deposit, 2),
                   "risk_pct": risk_pct},
        "total_trades": total,
        "wins": len(wins),
        "losses": len(losses),
        "win_rate": round(win_rate, 1),
        "net_r": round(cum_r, 2),
        "profit_factor": round(profit_factor, 2),
        "avg_win_r": round(np.mean([t["r"] for t in wins]), 2) if wins else 0,
        "avg_loss_r": round(np.mean([t["r"] for t in losses]), 2) if losses else 0,
        "max_drawdown_r": round(max_dd, 2),
        # --- پولی به سبک MT5 ---
        "initial_deposit": round(initial_deposit, 2),
        "final_balance": round(balance, 2),
        "net_profit": round(net_profit_money, 2),
        "return_pct": round(ret_pct, 2),
        "gross_profit": round(gross_profit_money, 2),
        "gross_loss": round(gross_loss_money, 2),
        "profit_factor_money": round(profit_factor_money, 2),
        "expected_payoff": round(expected_payoff, 2),
        "max_drawdown_money": round(max_dd_money, 2),
        "max_drawdown_pct": round(max_dd_pct, 2),
        "largest_win": round(largest_win, 2),
        "largest_loss": round(largest_loss, 2),
        "avg_win_money": round(avg_win_money, 2),
        "avg_loss_money": round(avg_loss_money, 2),
        "max_consecutive_wins": max_cons_win,
        "max_consecutive_losses": max_cons_loss,
        "equity": equity,
        "trades": trades[-40:],   # ۴۰ معامله آخر برای نمایش
        "source": df.attrs.get("source", "?"),
    }


if __name__ == "__main__":
    import json
    print(json.dumps(run_backtest("BTC", "1h"), ensure_ascii=False, indent=2)[:1500])
