//+------------------------------------------------------------------+
//|                                                    SampleEA.mq5  |
//+------------------------------------------------------------------+
#property copyright "User"
#property version   "1.00"
#property strict

input double InpLot = 0.10;
input bool   InpDemoSend = false; // اصلاح (AUD-002): پیش‌فرض امن — این فایل فقط «نمونهٔ آموزشیِ تزریق» است
datetime g_lastBar = 0;

int OnInit()
{
   Print("SampleEA started");
   return(INIT_SUCCEEDED);
}

void OnTick()
{
   // اصلاح (AUD-002): قبلاً با if(true) در «هر تیک» سفارش می‌فرستاد؛ اکنون فقط
   // با فعال‌کردنِ آگاهانهٔ InpDemoSend و حداکثر یک‌بار در هر کندل اجرا می‌شود.
   datetime bar = iTime(_Symbol, PERIOD_CURRENT, 0);
   if(InpDemoSend && bar != g_lastBar)
   {
      g_lastBar = bar;
      MqlTradeRequest req; MqlTradeResult res;
      ZeroMemory(req);
      req.action = TRADE_ACTION_DEAL;
      req.symbol = _Symbol;
      req.volume = InpLot;
      req.type   = ORDER_TYPE_BUY;
      req.price  = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
      bool ok = OrderSend(req, res);
      Print("retcode=", res.retcode);
   }
}
