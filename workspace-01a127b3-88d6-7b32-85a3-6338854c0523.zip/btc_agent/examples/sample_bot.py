# -*- coding: utf-8 -*-
"""نمونهٔ رباتِ پایتونیِ کاربر که مستقیم به متاتریدر سفارش می‌دهد."""
from __future__ import annotations
import time
import MetaTrader5 as mt5

DRY_RUN = True  # اصلاح (AUD-003): پیش‌فرضِ امن — تا وقتی آگاهانه False نشود، سفارشِ واقعی ارسال نمی‌شود

def my_signal():
    return "BUY"

def run():
    if not mt5.initialize():
        raise RuntimeError("اتصال به متاتریدر برقرار نشد")
    while True:
        s = my_signal()
        if s == "BUY":
            req = {"action": mt5.TRADE_ACTION_DEAL, "symbol": "XAUUSD",
                   "volume": 0.1, "type": mt5.ORDER_TYPE_BUY, "price": 2350.0}
            if DRY_RUN:
                print("[DRY-RUN] سفارش ارسال نشد:", req)
            else:
                result = mt5.order_send(req)
                print(result.retcode)
        time.sleep(60)

if __name__ == "__main__":
    run()
