# -*- coding: utf-8 -*-
"""بهینه‌سازی پارامترهای ربات SP2L روی طلا — جست‌وجوی شبکه‌ای روی ۲۰۰ معاملهٔ بازسازی‌شده.

شبکهٔ پارامترها (۳۶ ترکیب):
  SL = {1.0, 1.2, 1.5}×ATR · TP = {1.5, 1.8, 2.4, 3.0}×ATR
  فیلتر ورود = {none، rsi، trend}
    none : فقط حالت EMA20/EMA50 (همان خط پایهٔ قبلی)
    rsi  : BUY فقط وقتی RSI14>52 ، SELL فقط وقتی RSI14<48
    trend: فاصلهٔ |EMA20−EMA50| > 0.25×ATR (روندِ معنادار)
داده‌ی واقعی طلا یک‌بار دریافت و برای همهٔ ترکیب‌ها یکسان استفاده می‌شود
(مقایسهٔ منصفانه). قاعده‌ی سرنوشت همان قبلی است (دوطرفه=باخت، افق ۴۰ کندل).
"""
import json
import sys

sys.path.insert(0, ".")
import data_sources as ds  # noqa: E402

HORIZON = 40
OZ = 1.0
PLAN = [("15m", 60), ("30m", 40), ("1h", 40), ("2h", 30), ("4h", 30)]


def ema(vals, n):
    k = 2.0 / (n + 1)
    out, e = [], None
    for v in vals:
        e = v if e is None else v * k + e * (1 - k)
        out.append(e)
    return out


def atr14(h, l, c):
    trs, out, prev = [], [], None
    for i in range(len(c)):
        tr = h[i] - l[i] if i == 0 else max(h[i] - l[i],
                                            abs(h[i] - c[i - 1]),
                                            abs(l[i] - c[i - 1]))
        trs.append(tr)
        if len(trs) < 14:
            out.append(sum(trs) / len(trs))
        else:
            prev = sum(trs[:14]) / 14 if prev is None else (prev * 13 + tr) / 14
            out.append(prev)
    return out


def rsi14(c):
    out = [50.0]
    ag = al = None
    for i in range(1, len(c)):
        ch = c[i] - c[i - 1]
        g, lo = max(ch, 0.0), max(-ch, 0.0)
        if i <= 14:
            ag = g if ag is None else (ag * (i - 1) + g) / i
            al = lo if al is None else (al * (i - 1) + lo) / i
        else:
            ag = (ag * 13 + g) / 14
            al = (al * 13 + lo) / 14
        out.append(100.0 if al == 0 else 100 - 100 / (1 + ag / al))
    return out


def load_data():
    data = {}
    for tf, cnt in PLAN:
        df = ds.get_candles("XAU", tf, 300)
        d = {
            "h": df["high"].tolist(), "l": df["low"].tolist(),
            "c": df["close"].tolist(), "t": df["time"].tolist(),
            "cnt": cnt, "src": df.attrs.get("source", "?"),
        }
        d["e20"], d["e50"] = ema(d["c"], 20), ema(d["c"], 50)
        d["atr"], d["rsi"] = atr14(d["h"], d["l"], d["c"]), rsi14(d["c"])
        data[tf] = d
    return data


def run(data, sl_m, tp_m, filt):
    trades = []
    for tf, d in data.items():
        h, l, c, t = d["h"], d["l"], d["c"], d["t"]
        e20, e50, a14, rsi = d["e20"], d["e50"], d["atr"], d["rsi"]
        n, cnt = len(c), d["cnt"]
        first, last = 60, n - HORIZON - 1
        step = max(1, (last - first) // cnt)
        made, i = 0, first
        while made < cnt and i <= last:
            atr = a14[i]
            if atr <= 0:
                i += 1
                continue
            direction = "BUY" if e20[i] > e50[i] else "SELL"
            ok = True
            if filt == "rsi":
                ok = (rsi[i] > 52) if direction == "BUY" else (rsi[i] < 48)
            elif filt == "trend":
                ok = abs(e20[i] - e50[i]) > 0.25 * atr
            if not ok:
                i += 1
                continue
            sgn = 1 if direction == "BUY" else -1
            entry = c[i]
            sl = entry - sgn * sl_m * atr
            tp = entry + sgn * tp_m * atr
            outcome, exit_px = "timeout", c[min(i + HORIZON, n - 1)]
            for j in range(i + 1, min(i + HORIZON, n - 1) + 1):
                hit_tp = (h[j] >= tp) if sgn > 0 else (l[j] <= tp)
                hit_sl = (l[j] <= sl) if sgn > 0 else (h[j] >= sl)
                if hit_tp and hit_sl:
                    outcome, exit_px = "both→loss", sl
                    break
                if hit_sl:
                    outcome, exit_px = "loss", sl
                    break
                if hit_tp:
                    outcome, exit_px = "win", tp
                    break
            pnl = (exit_px - entry) * sgn * OZ
            risk = abs(entry - sl) * OZ
            trades.append({"tf": tf, "t": int(t[i]), "dir": direction,
                           "entry": entry, "sl": sl, "tp": tp,
                           "outcome": outcome, "pnl": round(pnl, 2),
                           "r": round(pnl / risk, 3) if risk else 0.0})
            made += 1
            i += step
    return trades


def stats(ts):
    w = [x for x in ts if x["outcome"] == "win"]
    l = [x for x in ts if x["outcome"] in ("loss", "both→loss")]
    dec = len(w) + len(l)
    wr = 100.0 * len(w) / dec if dec else 0.0
    gp = sum(x["pnl"] for x in ts if x["pnl"] > 0)
    gl = sum(-x["pnl"] for x in ts if x["pnl"] < 0)
    pf = (gp / gl) if gl > 0 else float("inf")
    net = sum(x["pnl"] for x in ts)
    rsum = sum(x["r"] for x in ts)
    # افتِ سرمایه روی PnL تجمعی (به ترتیب زمان)
    eq = peak = mdd = 0.0
    for x in sorted(ts, key=lambda z: z["t"]):
        eq += x["pnl"]
        peak = max(peak, eq)
        mdd = max(mdd, peak - eq)
    return {"n": len(ts), "w": len(w), "l": len(l),
            "tm": len(ts) - dec, "wr": wr, "pf": pf,
            "net": net, "r": rsum, "mdd": mdd}


def main():
    data = load_data()
    for tf, d in data.items():
        print(f"  {tf}: {len(d['c'])} کندل (منبع {d['src']})")
    results = []
    for filt in ["none", "rsi", "trend"]:
        for sl_m in [1.0, 1.2, 1.5]:
            for tp_m in [1.5, 1.8, 2.4, 3.0]:
                ts = run(data, sl_m, tp_m, filt)
                s = stats(ts)
                s.update({"sl": sl_m, "tp": tp_m, "filt": filt,
                          "rr": round(tp_m / sl_m, 2)})
                results.append(s)
    results.sort(key=lambda s: -s["net"])
    with open("sp2l_gold_grid.json", "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False)
    print(f"\n{'فیلتر':<6} {'SL':>4} {'TP':>4} {'R:R':>4} {'n':>4} "
          f"{'WR%':>6} {'PF':>5} {'Net$':>9} {'ΣR':>7} {'MDD$':>7}")
    for s in results[:12]:
        pf = "inf" if s["pf"] == float("inf") else f"{s['pf']:.2f}"
        print(f"{s['filt']:<6} {s['sl']:>4} {s['tp']:>4} {s['rr']:>4} "
              f"{s['n']:>4} {s['wr']:>6.1f} {pf:>5} {s['net']:>9.2f} "
              f"{s['r']:>7.1f} {s['mdd']:>7.1f}")
    base = [s for s in results if s["filt"] == "none"
            and s["sl"] == 1.2 and s["tp"] == 1.8][0]
    print(f"\nخط پایه (گزارش قبلی: none/1.2/1.8): WR={base['wr']:.1f}٪ "
          f"Net={base['net']:.2f}$ PF={'inf' if base['pf']==float('inf') else round(base['pf'],2)}")
    best = results[0]
    print(f"بهترین: {best['filt']}/SL{best['sl']}/TP{best['tp']} → "
          f"WR={best['wr']:.1f}٪ Net={best['net']:.2f}$")


if __name__ == "__main__":
    main()
