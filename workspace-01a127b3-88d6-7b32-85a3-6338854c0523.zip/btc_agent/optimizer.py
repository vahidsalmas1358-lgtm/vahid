"""بهینه‌سازی خودکار پارامترهای استراتژی با جست‌وجوی شبکه‌ای (grid search).

روی یک بار داده تاریخی، ترکیب‌های مختلف آستانه ورود، مضرب استاپ و مضرب هدف را
آزمایش کرده و بهترین‌ها را بر اساس معیار انتخابی مرتب می‌کند.
"""
from __future__ import annotations
import data_sources as ds
import backtest as bt

THRESHOLDS = [15, 20, 25, 30, 35]
SL_MULTS = [1.0, 1.5, 2.0]
TP_MULTS = [2.0, 3.0, 4.0]


def optimize(symbol="BTC", interval="1h", bars=800, allow_short=True,
             metric="net_r", min_trades=8, df=None):
    if df is None:
        df = ds.get_history(symbol, interval, bars)
    df = df.reset_index(drop=True)
    if len(df) < 120:
        raise RuntimeError("داده تاریخی کافی برای بهینه‌سازی موجود نیست")

    results = []
    for th in THRESHOLDS:
        for sl in SL_MULTS:
            for tp in TP_MULTS:
                if tp <= sl:      # هدف باید بزرگ‌تر از استاپ باشد
                    continue
                r = bt.run_backtest_df(df, symbol, interval, threshold=th,
                                       atr_mult_sl=sl, atr_mult_tp=tp,
                                       allow_short=allow_short)
                results.append({
                    "threshold": th, "sl_atr": sl, "tp_atr": tp,
                    "trades": int(r["total_trades"]), "win_rate": float(r["win_rate"]),
                    "net_r": float(r["net_r"]), "profit_factor": float(r["profit_factor"]),
                    "max_dd": float(r["max_drawdown_r"]),
                })

    # فقط ترکیب‌هایی با حداقل تعداد معامله معتبرند
    valid = [x for x in results if x["trades"] >= min_trades]
    pool = valid if valid else results

    key_map = {
        "net_r": lambda x: x["net_r"],
        "profit_factor": lambda x: x["profit_factor"],
        "win_rate": lambda x: x["win_rate"],
    }
    # اصلاح (OPT-001): متریکِ ناشناخته به net_r برمی‌گردد ولی قبلاً در پاسخ همان
    # متریکِ درخواستی گزارش می‌شد و UI نتیجه را به‌اشتباه «بهترین X» می‌خواند.
    metric_used = metric if metric in key_map else "net_r"
    keyfn = key_map[metric_used]
    pool.sort(key=keyfn, reverse=True)

    best = pool[0] if pool else None
    return {
        "symbol": symbol.upper(),
        "interval": interval,
        "bars_tested": int(len(df)),
        "metric": metric_used,
        "requested_metric": metric,
        "combinations": len(results),
        "best": best,
        "top": pool[:12],
        "source": df.attrs.get("source", "?"),
    }


if __name__ == "__main__":
    import json
    print(json.dumps(optimize("BTC", "1h", bars=600), ensure_ascii=False, indent=2)[:1200])
