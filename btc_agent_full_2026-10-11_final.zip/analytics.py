"""تحلیلِ عملکردِ سیگنال‌های ثبت‌شده (win-rate، R محقق‌شده، توزیعِ برخورد به تیک‌پروفیت‌ها).

سیگنال‌ها در جدولِ SQLite ذخیره شده‌اند (نقطهٔ ورود، استاپ، سه تیک‌پروفیت، جهت، زمان).
این ماژول هر سیگنالِ دارای پلن (LONG/SHORT) را با دادهٔ قیمتِ «بعد از زمانِ سیگنال»
ارزیابی می‌کند و می‌گوید به کدام سطح رسیده و چند R محقق کرده است.

مدلِ ارزیابی (دقیق و مستند):
  • پوزیشن با همان نسبتِ بستنی مدل می‌شود که موتور/متاتریدر پیشنهاد/اجرا می‌کند
    (۴۰٪ روی TP1، ۳۵٪ روی TP2، ۲۵٪ روی TP3)؛ نه فرضِ ساده‌سازِ «یک‌سومِ مساوی».
  • ریسکِ مبنا = |ورود − استاپ|.  R هر تیک‌پروفیت = (فاصلهٔ آن تا ورود) ÷ ریسک.
  • «برخورد» = عبورِ های/لوِ کندل از سطح (برای LONG: high≥TP یا low≤SL؛ برای SHORT برعکس).
  • اگر در همان کندل هم استاپ و هم تیک‌پروفیت لمس شود و هنوز TP1 قفل نشده باشد،
    محافظه‌کارانه «استاپ اول» فرض می‌شود (بدترین حالت → ضرر).
  • پس از قفل‌شدنِ TP1، استاپ به نقطهٔ سربه‌سر (ورود) منتقل می‌شود؛ لذا سیگنالی که به TP1
    رسیده دیگر نمی‌تواند زیان بدهد (برد قطعی، با R محقق‌شدهٔ حداقلِ سهمِ TP1).
  • R محقق‌شده = مجموعِ (Rِ هر سطحِ لمس‌شده × سهمِ بستنِ همان سطح). ضررِ کامل = −۱٫۰R.

وضعیت‌ها:
  • loss    : استاپ پیش از TP1 (بسته، R=−۱).
  • win     : حداقل TP1 لمس شده (R>0). اگر همهٔ TPها یا استاپِ سربه‌سر خورده = بسته؛ وگرنه «در سود، باز».
  • pending : هنوز نه استاپ نه TP1 (در جریان).
"""
from __future__ import annotations
import time
from bisect import bisect_right
from concurrent.futures import ThreadPoolExecutor

import db
import data_sources as ds
import symbols as sym

# executorِ مشترک برای دریافتِ موازیِ کندلِ گروه‌ها (I/O bound)
_POOL = ThreadPoolExecutor(max_workers=16, thread_name_prefix="perf")


def _r_levels(direction, entry, sl, tps):
    """Rِ هر تیک‌پروفیت را برمی‌گرداند (فهرست)."""
    long = direction == "LONG"
    risk = (entry - sl) if long else (sl - entry)
    if risk <= 0:
        return None, None
    Rs = [((tp - entry) / risk) if long else ((entry - tp) / risk) for tp in tps]
    return risk, Rs


def evaluate(direction, entry, sl, tps, candles):
    """یک سیگنال را روی کندل‌های بعد از آن ارزیابی می‌کند.

    candles: فهرستِ tupleهای (t_ms, open, high, low, close) مرتب‌شده صعودی، فقط بعد از زمانِ سیگنال.
    خروجی: dict شامل status/outcome/reached/R/fully_closed/bars_held/exit_ts.
    """
    tps = [float(t) for t in (tps or []) if t is not None]
    if direction not in ("LONG", "SHORT") or entry is None or sl is None or not tps:
        return {"status": "skip"}
    entry = float(entry); sl = float(sl)
    long = direction == "LONG"
    n = len(tps)

    # --- اعتبارسنجیِ ترتیبِ سطوح (اصلاحِ OP5-AN-BE-ORDER) ---
    # اگر سطوحِ ذخیره‌شده هم‌ترتیب نباشند (مثلاً TP1 بالاتر از TP3 یا استاپ سمتِ
    # اشتباه)، مدلِ ارزیابی نتیجهٔ بی‌معنا تولید می‌کرد؛ چنین سیگنالی «invalid»
    # علامت می‌خورد و در آمار وارد نمی‌شود (به‌جای نتیجهٔ غلط).
    if long:
        ok = sl < entry and all(tps[k] > entry for k in range(n)) and \
             all(tps[k] < tps[k + 1] for k in range(n - 1))
    else:
        ok = sl > entry and all(tps[k] < entry for k in range(n)) and \
             all(tps[k] > tps[k + 1] for k in range(n - 1))
    if not ok:
        return {"status": "invalid", "reason": "ترتیبِ سطوح (SL/TP) با جهتِ معامله نمی‌خواند."}
    risk, Rs = _r_levels(direction, entry, sl, tps)
    if risk is None:
        return {"status": "skip"}

    # سهمِ بستنِ هر تیک‌پروفیت باید با همان نسبتی باشد که متاتریدر *واقعاً اجرا* می‌کند
    # (RV-3-2، بازبینیِ REVIEW_FA): پیش‌تر اینجا عددِ ثابتِ ۴۰/۳۵/۲۵ فرض می‌شد، ولی
    # حالتِ partial با partial_fractions = [0.5, 0.3] اجرا می‌شد و Rِ گزارش‌شده با
    # استراتژیِ واقعی نمی‌خواند. حالا وزن‌ها از «تنظیماتِ واقعیِ اجرا» خوانده می‌شوند
    # و در نبودِ آن به منبعِ واحدِ symbols.TP_CLOSE_PCT برمی‌گردیم.
    fracs = _exec_close_weights(n)

    def realized(reached):
        # مجموعِ Rِ سطوحِ بسته‌شده، وزن‌دار با سهمِ بستنِ هر سطح. باقی‌ماندهٔ پوزیشن پس از
        # انتقال به سربه‌سر با R=۰ خارج می‌شود، پس در جمع نمی‌آید.
        return sum(Rs[k] * fracs[k] for k in range(reached))

    reached = 0
    be = False          # استاپِ سربه‌سر پس از TP1 فعال شده؟
    bars = 0
    for (t, o, h, l, c) in candles:
        bars += 1
        # تیک‌پروفیت‌های تازه لمس‌شده (به‌ترتیب)
        newly = reached
        for k in range(reached, n):
            hit = (h >= tps[k]) if long else (l <= tps[k])
            if hit:
                newly = k + 1
            else:
                break
        stop_level = entry if be else sl
        hit_stop = (l <= stop_level) if long else (h >= stop_level)

        if not be:
            if hit_stop:                              # استاپ پیش از قفل‌شدنِ TP1 → ضرر
                return {"status": "loss", "outcome": "SL", "reached": 0,
                        "R": -1.0, "fully_closed": True, "bars_held": bars, "exit_ts": t}
            if newly >= 1:
                reached = newly
                be = True
                if reached >= n:                      # همهٔ TPها در یک کندل
                    return {"status": "win", "outcome": f"TP{reached}", "reached": reached,
                            "R": realized(reached), "fully_closed": True,
                            "bars_held": bars, "exit_ts": t}
            continue
        else:
            # اصلاحِ OP5-AN-BE-ORDER: پس از فعال‌شدنِ سربه‌سر، ترتیبِ «لمسِ استاپ و
            # تیک‌پروفیتِ جدید در همان کندل» نامعلوم است؛ محافظه‌کارانه ابتدا استاپِ
            # سربه‌سر فرض می‌شود (پوزیشن بسته می‌شود) و TP جدیدی که در همان کندل
            # لمس شده باشد به حساب نمی‌آید. پیش‌تر TP اول شمرده می‌شد (خوش‌بینانه).
            if hit_stop:                              # بازگشت به سربه‌سر → بستنِ باقی‌مانده
                return {"status": "win", "outcome": f"TP{reached}", "reached": reached,
                        "R": realized(reached), "fully_closed": True,
                        "bars_held": bars, "exit_ts": t}
            if newly > reached:
                reached = newly
                if reached >= n:
                    return {"status": "win", "outcome": f"TP{reached}", "reached": reached,
                            "R": realized(reached), "fully_closed": True,
                            "bars_held": bars, "exit_ts": t}
            continue

    # پایانِ داده — هنوز باز
    if reached == 0:
        return {"status": "pending", "outcome": "OPEN", "reached": 0,
                "R": None, "fully_closed": False, "bars_held": bars, "exit_ts": None}
    return {"status": "win", "outcome": f"TP{reached}", "reached": reached,
            "R": realized(reached), "fully_closed": False,   # در سود ولی هنوز باز
            "bars_held": bars, "exit_ts": None}


def _fetch_signals(symbol=None, interval=None, direction=None, days=None):
    sql = ("SELECT ts, symbol, pair, interval, direction, price, score, entry, "
           "stop_loss, take_profits FROM signals WHERE 1=1")
    p = []
    if symbol:
        sql += " AND symbol=?"; p.append(symbol.upper())
    if interval:
        sql += " AND interval=?"; p.append(interval)
    if direction:
        sql += " AND direction=?"; p.append(direction.upper())
    if days:
        sql += " AND ts>=?"; p.append(int(time.time() - days * 86400))
    sql += " ORDER BY ts ASC, id ASC"
    return db.query(sql, p)


def _pack(d):
    times = d["time"].tolist()
    rows = list(zip(times, d["open"].tolist(), d["high"].tolist(),
                    d["low"].tolist(), d["close"].tolist()))
    return times, rows


def _candles_for(symbol, interval, earliest_ts):
    """کندل‌های موردنیاز را برمی‌گرداند (times[], rows[]).

    ابتدا get_candles (یک درخواستِ سریع ~۳۰۰ کندل) امتحان می‌شود؛ اگر بازهٔ لازم را پوشش دهد
    همان استفاده می‌شود. فقط اگر قدیمی‌ترین سیگنالِ گروه عقب‌تر از آن باشد، به get_history
    (تاریخیِ عمیق‌ترِ کندشونده) برمی‌گردیم. → در حالتِ معمول بسیار سریع‌تر.
    """
    need_ms = earliest_ts * 1000
    try:
        d = ds.get_candles(symbol, interval)
    except Exception:  # noqa
        d = None
    if d is not None and len(d) >= 5 and float(d["time"].iloc[0]) <= need_ms:
        return _pack(d)
    try:
        d2 = ds.get_history(symbol, interval)
    except Exception:  # noqa
        d2 = None
    if d2 is not None and len(d2) >= 5:
        return _pack(d2)
    return _pack(d) if (d is not None and len(d) >= 5) else None


def _exec_close_weights(n: int):
    """سهمِ بستنِ پله‌ها بر پایهٔ تنظیماتِ واقعیِ اجرا (RV-3-2: منبعِ واحد).

    - tp_mode = partial → partial_fractions از کانفیگ (+ باقی‌ماندهٔ TPِ آخر)
    - در غیر این صورت → sym.TP_CLOSE_PCT (همان منبعِ engine.build_trade_plan)
    خروجی همیشه n سهمِ نرمال‌شده است که مجموعشان ۱ می‌شود.
    """
    n = max(1, int(n or 1))
    fr = []
    try:
        import mt5_bridge as _mb
        cfg = _mb.load_config()
        if str(cfg.get("tp_mode") or "").lower() == "partial":
            fr = [float(x) for x in (cfg.get("partial_fractions") or []) if float(x) > 0]
            if fr:
                _s = sum(fr)
                fr = fr + [max(0.0, 1.0 - _s)]
    except Exception:  # noqa
        fr = []
    if not fr:
        fr = [float(w) / 100.0 for w in getattr(sym, "TP_CLOSE_PCT", [40.0, 35.0, 25.0])]
    fr = [w for w in fr[:n]]
    if len(fr) < n:
        fr += [fr[-1] if fr else 1.0] * (n - len(fr))
    _s = sum(fr) or 1.0
    return [w / _s for w in fr]


def analyze(symbol=None, interval=None, direction=None, days=None, limit=500):
    """گزارشِ کاملِ عملکرد را می‌سازد: خلاصه + تفکیک بر نماد/جهت/تایم‌فریم + فهرستِ معاملات."""
    import json
    sigs = _fetch_signals(symbol, interval, direction, days)

    # گروه‌بندی بر (symbol, interval) تا کندلِ هر گروه یک‌بار گرفته شود
    groups: dict = {}
    for r in sigs:
        d = r["direction"]
        if d not in ("LONG", "SHORT"):
            continue
        try:
            tps = json.loads(r["take_profits"] or "[]")
        except Exception:  # noqa
            tps = []
        if r["entry"] is None or r["stop_loss"] is None or not tps:
            continue
        groups.setdefault((r["symbol"], r["interval"]), []).append((r, tps))

    # دریافتِ موازیِ کندلِ همهٔ گروه‌ها (فقط نمادهای دارای دادهٔ رایگان)
    cache: dict = {}
    fetch_keys = [(sy, iv) for (sy, iv) in groups if sym.valid(sy)]

    def _fetch(key):
        sy, iv = key
        earliest = min(r["ts"] for (r, _t) in groups[key])
        return key, _candles_for(sy, iv, earliest)

    if fetch_keys:
        for key, cdata in _POOL.map(_fetch, fetch_keys):
            cache[key] = cdata

    trades = []
    for (sy, iv), items in groups.items():
        cdata = cache.get((sy, iv))
        for (r, tps) in items:
            base = {"ts": r["ts"], "symbol": r["symbol"], "pair": r["pair"],
                    "interval": r["interval"], "direction": r["direction"],
                    "entry": r["entry"], "stop_loss": r["stop_loss"],
                    "take_profits": tps, "score": r["score"], "price": r["price"]}
            if not cdata:
                # اصلاح (ANALYTICS-001): نبودِ دادهٔ کندل با پوزیشنِ واقعاً باز قاطی نشود؛
                # status برای سازگاری حفظ شده و پرچم صریحِ data_available اضافه شد.
                base.update({"status": "pending", "outcome": "N/A", "reached": 0,
                             "R": None, "fully_closed": False, "bars_held": 0, "exit_ts": None,
                             "data_available": False})
                trades.append(base)
                continue
            times, rows = cdata
            i = bisect_right(times, r["ts"] * 1000)     # فقط کندل‌های بعد از زمانِ سیگنال
            res = evaluate(r["direction"], r["entry"], r["stop_loss"], tps, rows[i:])
            if res.get("status") in ("skip", "invalid"):
                # سیگنالِ بدونِ سطوحِ معتبر (ترتیبِ اشتباه/ریسکِ صفر) در آمار نمی‌آید
                continue
            base.update(res)
            trades.append(base)

    trades.sort(key=lambda x: x["ts"], reverse=True)

    def agg(items):
        wins = [t for t in items if t["status"] == "win"]
        losses = [t for t in items if t["status"] == "loss"]
        pend = [t for t in items if t["status"] == "pending"]
        inval = [t for t in items if t["status"] == "invalid"]
        decided = len(wins) + len(losses)
        realized = [t["R"] for t in items if t["R"] is not None]
        pos = sum(r for r in realized if r > 0)
        neg = sum(r for r in realized if r < 0)
        n_tp = [0, 0, 0]
        for t in items:
            for k in range(min(t.get("reached", 0), 3)):
                n_tp[k] += 1
        held = [t["bars_held"] for t in items if t["status"] in ("win", "loss") and t["bars_held"]]
        return {
            "n_total": len(items), "n_wins": len(wins), "n_losses": len(losses),
            "n_pending": len(pend), "n_decided": decided,
            "n_invalid": len(inval),
            "win_rate": round(len(wins) / decided * 100, 1) if decided else None,
            "total_R": round(sum(realized), 2) if realized else 0.0,
            "avg_R": round(sum(realized) / len(realized), 3) if realized else None,
            "expectancy": round(sum(realized) / len(realized), 3) if realized else None,
            "profit_factor": (round(pos / abs(neg), 2) if neg else (None if pos == 0 else float("inf"))),
            "tp1_rate": round(n_tp[0] / len(items) * 100, 1) if items else None,
            "tp2_rate": round(n_tp[1] / len(items) * 100, 1) if items else None,
            "tp3_rate": round(n_tp[2] / len(items) * 100, 1) if items else None,
            "avg_bars_held": round(sum(held) / len(held), 1) if held else None,
        }

    def group_by(key):
        out = {}
        for t in trades:
            out.setdefault(t[key], []).append(t)
        res = []
        for k, its in out.items():
            a = agg(its)
            a["key"] = k
            res.append(a)
        res.sort(key=lambda a: (a["total_R"] if a["total_R"] is not None else -999), reverse=True)
        return res

    summary = agg(trades)
    # profit_factor بی‌نهایت را برای JSON قابل‌حمل کن
    if summary["profit_factor"] == float("inf"):
        summary["profit_factor"] = None
    for coll in (summary,):
        pass

    by_symbol = group_by("symbol")
    by_direction = group_by("direction")
    by_tf = group_by("interval")
    for coll in (by_symbol, by_direction, by_tf):
        for a in coll:
            if a["profit_factor"] == float("inf"):
                a["profit_factor"] = None

    return {
        "summary": summary,
        "by_symbol": by_symbol,
        "by_direction": by_direction,
        "by_tf": by_tf,
        "trades": trades[:limit],
        "model": "weighted scale-out 40/35/25 (یا partial_fractionsِ تنظیمات), breakeven after TP1, SL-priority on same-candle",
    }
