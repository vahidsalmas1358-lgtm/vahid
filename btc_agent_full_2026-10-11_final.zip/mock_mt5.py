# -*- coding: utf-8 -*-
"""شبیه‌سازِ کارگزارِ MetaTrader5 برای آزمونِ مسیرهای واقعیِ ارسال/مدیریتِ پوزیشن.

روی لینوکس کتابخانهٔ رسمیِ `MetaTrader5` در دسترس نیست، بنابراین مسیرِ اجرای واقعیِ
`send_order`/`_manage_once`/`_partial_close` هیچ‌گاه اجرا نمی‌شد. این ماژول یک کارگزارِ
مصنوعیِ کامل می‌سازد تا آن کدها با نمادهایی که «رقم اعشار، point، گام لات و حداقل‌فاصلهٔ
استاپِ» متفاوت دارند، واقعاً اجرا و ریاضیاتشان راستی‌آزمایی شود.

این فایل فقط برای تست است و توسط اپلیکیشن import نمی‌شود.
"""
from __future__ import annotations

import math

# ---- ثابت‌های MT5 (مقادیر واقعیِ کتابخانه) ----
TRADE_ACTION_DEAL = 1
TRADE_ACTION_PENDING = 5
TRADE_ACTION_SLTP = 6

ORDER_TYPE_BUY = 0
ORDER_TYPE_SELL = 1
ORDER_TYPE_BUY_LIMIT = 2
ORDER_TYPE_SELL_LIMIT = 3
ORDER_TYPE_BUY_STOP = 4
ORDER_TYPE_SELL_STOP = 5

ORDER_TIME_GTC = 0
ORDER_FILLING_FOK = 0
ORDER_FILLING_IOC = 1
ORDER_FILLING_RETURN = 2

TRADE_RETCODE_DONE = 10009
TRADE_RETCODE_INVALID_STOPS = 10016

TIMEFRAME_M1 = 1
TIMEFRAME_M5 = 5
TIMEFRAME_M10 = 10
TIMEFRAME_M15 = 15
TIMEFRAME_M30 = 30
TIMEFRAME_H1 = 16385
TIMEFRAME_H2 = 16386  # اصلاح (MOCK-TF-001): mt5_bridge برای تاییدیهٔ تایم‌فریمِ بالاتر (مثلاً 15m→2h) لازم دارد
TIMEFRAME_H4 = 16388
TIMEFRAME_D1 = 16408
TIMEFRAME_W1 = 32769
TIMEFRAME_MN1 = 49153
# نام‌های عمومی که mt5_bridge با getattr می‌سازد (TIMEFRAME_M{n}, _H{n} ...)
TIMEFRAME_M = TIMEFRAME_M1
TIMEFRAME_H = TIMEFRAME_H1
TIMEFRAME_D = TIMEFRAME_D1
TIMEFRAME_W = TIMEFRAME_W1
TIMEFRAME_MN = TIMEFRAME_MN1


class _Obj:
    def __init__(self, **kw):
        self.__dict__.update(kw)

    def _asdict(self):
        return dict(self.__dict__)


class Broker:
    """وضعیتِ کارگزارِ مصنوعی: نمادها، قیمت‌ها، پوزیشن‌ها و حساب."""

    def __init__(self, balance=10000.0):
        self.symbols = {}          # name -> dict(profile + price)
        self.positions = {}        # ticket -> _Obj
        self.pending = {}          # ticket -> req (سفارش‌های معلق)
        self._next_ticket = 1000
        self._tick_time = 1_760_000_000   # اصلاح (MOCK-003): زمانِ تیکِ پیش‌رونده
        self.balance = balance
        self.deals = []            # تاریخچهٔ معاملاتِ اجراشده (برای بازرسیِ حجم)
        self.last_err = (0, "OK")

    # --- تعریفِ نماد ---
    def add_symbol(self, name, digits, point, volume_min=0.01, volume_step=0.01,
                   volume_max=100.0, stops_level=0, tick_value=1.0, tick_size=None,
                   price=100.0, spread_points=10, filling_mode=2):
        self.symbols[name] = {
            "name": name, "digits": digits, "point": point,
            "volume_min": volume_min, "volume_step": volume_step,
            "volume_max": volume_max, "trade_stops_level": stops_level,
            "trade_tick_value": tick_value,
            "trade_tick_size": tick_size if tick_size is not None else point,
            "price": price, "spread_points": spread_points,
            "filling_mode": filling_mode, "visible": True,
            "trade_contract_size": 100000.0,
        }

    def set_price(self, name, price):
        self._tick_time += 1   # اصلاح (MOCK-003)
        self.symbols[name]["price"] = price

    # --- API سازگار با MetaTrader5 ---
    def initialize(self, *a, **k):
        return True

    def shutdown(self):
        return True

    def last_error(self):
        return self.last_err

    def account_info(self):
        return _Obj(balance=self.balance, equity=self.balance, margin=0.0,
                    margin_free=self.balance, currency="USD", login=123456,
                    server="MockServer", leverage=100)

    def terminal_info(self):
        return _Obj(connected=True, trade_allowed=True, name="MockTerminal")

    def symbol_info(self, name):
        s = self.symbols.get(name)
        if not s:
            return None
        return _Obj(**s)

    def symbol_info_tick(self, name):
        s = self.symbols.get(name)
        if not s:
            return None
        half = s["spread_points"] * s["point"] / 2.0
        return _Obj(ask=s["price"] + half, bid=s["price"] - half,
                    last=s["price"], time=self._tick_time)

    def symbol_select(self, name, enable=True):
        if name in self.symbols:
            self.symbols[name]["visible"] = enable
            return True
        return False

    def symbols_get(self, group=None):
        return [_Obj(**s) for s in self.symbols.values()]

    def orders_get(self, ticket=None, symbol=None):
        """سفارش‌های معلق (سازگار با MetaTrader5.orders_get)."""
        os_ = list(self.pending.values())
        if ticket is not None:
            os_ = [o for o in os_ if o.ticket == ticket]
        if symbol is not None:
            os_ = [o for o in os_ if o.symbol == symbol]
        return tuple(os_)

    def positions_get(self, ticket=None, symbol=None):
        # قیمتِ جاری را روی پوزیشن‌ها به‌روزرسانی کن
        for p in self.positions.values():
            s = self.symbols.get(p.symbol)
            if s:
                # اصلاح (MOCK-003): BUY با bid بسته می‌شود و SELL با ask؛
                # قبلاً mid-price بدونِ اسپرد گذاشته می‌شد.
                half = s["spread_points"] * s["point"] / 2.0
                p.price_current = (s["price"] - half if p.type == ORDER_TYPE_BUY
                                   else s["price"] + half)
        if ticket is not None:
            p = self.positions.get(ticket)
            return (p,) if p else ()
        if symbol is not None:
            return tuple(p for p in self.positions.values() if p.symbol == symbol)
        return tuple(self.positions.values())

    def _margin_for(self, info, volume, price):
        # margin تقریبی؛ فقط برای order_check
        return volume * price * info["trade_contract_size"] / 100.0 * 0.01

    def order_check(self, req):
        name = req["symbol"]
        s = self.symbols.get(name)
        if not s:
            return _Obj(retcode=10013, comment="Invalid symbol", margin=0.0,
                        balance=self.balance, profit=0.0)
        # اصلاح (MOCK-001): ماک قبلاً هر درخواستی را DONE برمی‌گرداند؛
        # حالا مثل کارگزارِ واقعی حجم و سمتِ SL/TP را اعتبارسنجی می‌کند.
        try:
            vol = float(req.get("volume", 0))
        except (TypeError, ValueError):
            vol = float("nan")
        if not math.isfinite(vol) or vol < s["volume_min"] or vol > s["volume_max"]:
            return _Obj(retcode=10014, comment="Invalid volume", margin=0.0,
                        balance=self.balance, profit=0.0)
        step = s.get("volume_step") or 0.01
        if step > 0 and abs(vol / step - round(vol / step)) > 1e-6:
            return _Obj(retcode=10014, comment="Invalid volume step", margin=0.0,
                        balance=self.balance, profit=0.0)
        # سمتِ درستِ SL/TP نسبت به قیمت (BUY: SL<price<TP — SELL برعکس)
        otype = req.get("type")
        price = float(req.get("price", s["price"]) or s["price"])
        sl = req.get("sl")
        tp = req.get("tp")
        is_buy = otype in (ORDER_TYPE_BUY, ORDER_TYPE_BUY_LIMIT, ORDER_TYPE_BUY_STOP)
        is_sell = otype in (ORDER_TYPE_SELL, ORDER_TYPE_SELL_LIMIT, ORDER_TYPE_SELL_STOP)
        if is_buy or is_sell:
            if sl:
                if (is_buy and float(sl) >= price) or (is_sell and float(sl) <= price):
                    return _Obj(retcode=10016, comment="Invalid stops (SL side)", margin=0.0,
                                balance=self.balance, profit=0.0)
            if tp:
                if (is_buy and float(tp) <= price) or (is_sell and float(tp) >= price):
                    return _Obj(retcode=10016, comment="Invalid stops (TP side)", margin=0.0,
                                balance=self.balance, profit=0.0)
        return _Obj(retcode=TRADE_RETCODE_DONE, comment="Done",
                    margin=self._margin_for(s, vol, price),
                    balance=self.balance, profit=0.0)

    def order_send(self, req):
        action = req.get("action")
        name = req.get("symbol")
        s = self.symbols.get(name)
        if not s:
            self.last_err = (10013, "Invalid symbol")
            return _Obj(retcode=10013, comment="No symbol", order=0, deal=0,
                        price=0.0, volume=0.0)

        if action == TRADE_ACTION_SLTP:
            p = self.positions.get(req.get("position"))
            if not p:
                return _Obj(retcode=10013, comment="pos not found", order=0, deal=0,
                            price=0.0, volume=0.0)
            # اصلاح (MOCK-002): سمتِ SL/TP روی SLTP هم مثل بروکر واقعی بررسی می‌شود.
            _sl, _tp = req.get("sl", p.sl), req.get("tp", p.tp)
            _isb = p.type == ORDER_TYPE_BUY
            if _sl and ((_isb and _sl >= p.price_current) or ((not _isb) and _sl <= p.price_current)):
                return _Obj(retcode=10016, comment="Invalid SL", order=0, deal=0,
                            price=0.0, volume=0.0)
            # اصلاح (MOCK-STOPS-001): مثل بروکر واقعی، SL جدید نباید از price_current
            # کمتر از stops_level فاصله داشته باشد (تلورانس یک پوینت برای گِردشدن).
            _mind = (s.get("trade_stops_level", 0) or 0) * s["point"]
            if _sl and _sl != p.sl and _mind > 0 and                     abs(p.price_current - _sl) < _mind - s["point"] - 1e-12:
                return _Obj(retcode=10016, comment="Invalid stops (too close)", order=0,
                            deal=0, price=0.0, volume=0.0)
            # فقط TPِ «جدید» بررسی می‌شود؛ چون این ماک اجرای TP را شبیه‌سازی نمی‌کند،
            # ممکن است قیمت از TPِ قبلی عبور کرده باشد و نگه‌داشتنِ همان TP نباید رد شود.
            if _tp and _tp != p.tp and ((_isb and _tp <= p.price_current)
                                        or ((not _isb) and _tp >= p.price_current)):
                return _Obj(retcode=10016, comment="Invalid TP", order=0, deal=0,
                            price=0.0, volume=0.0)
            p.sl = _sl
            p.tp = _tp
            return _Obj(retcode=TRADE_RETCODE_DONE, comment="Done", order=p.ticket,
                        deal=0, price=p.price_open, volume=p.volume)

        if action == TRADE_ACTION_DEAL and req.get("position"):
            # بستن/کاهشِ جزئی
            p = self.positions.get(req.get("position"))
            if not p:
                return _Obj(retcode=10013, comment="pos not found", order=0, deal=0,
                            price=0.0, volume=0.0)
            vol = req.get("volume", 0.0)
            # اصلاح (MOCK-002): حجمِ بستنِ نامعتبر/بیش از پوزیشن رد می‌شود.
            try:
                vol = float(vol)
            except (TypeError, ValueError):
                vol = float("nan")
            if not math.isfinite(vol) or vol <= 0 or vol > p.volume + 1e-9:
                return _Obj(retcode=10014, comment="Invalid close volume", order=0,
                            deal=0, price=0.0, volume=0.0)
            dec = _decimals(s["volume_step"])
            p.volume = round(p.volume - vol, dec)
            self.deals.append({"ticket": p.ticket, "symbol": name, "close_volume": vol})
            if p.volume <= 1e-9:
                self.positions.pop(p.ticket, None)
            tk = self._next_ticket
            self._next_ticket += 1
            return _Obj(retcode=TRADE_RETCODE_DONE, comment="Done", order=tk,
                        deal=tk, price=req.get("price", s["price"]), volume=vol)

        if action == TRADE_ACTION_PENDING:
            # اصلاح (MOCK-PENDING-001): قبلاً سفارشِ معلق مثل سفارشِ بازار «فوراً»
            # پوزیشن می‌شد؛ حالا مثل بروکرِ واقعی در فهرستِ سفارش‌های معلق ثبت
            # می‌شود (اعتبارسنجیِ order_check نسبت به قیمتِ خودِ سفارش انجام شده).
            chk = self.order_check(req)
            if getattr(chk, "retcode", None) != TRADE_RETCODE_DONE:
                return _Obj(retcode=chk.retcode, comment=chk.comment, order=0,
                            deal=0, price=0.0, volume=0.0)
            tk = self._next_ticket
            self._next_ticket += 1
            o = _Obj(ticket=tk, symbol=name, type=req.get("type"),
                     volume_initial=round(req.get("volume", 0.0), 8),
                     volume_current=round(req.get("volume", 0.0), 8),
                     price_open=req.get("price", s["price"]),
                     sl=req.get("sl", 0.0), tp=req.get("tp", 0.0),
                     magic=req.get("magic", 0), comment=req.get("comment", ""),
                     time_setup=self._tick_time)
            self.pending[tk] = o
            return _Obj(retcode=TRADE_RETCODE_DONE, comment="Placed", order=tk,
                        deal=0, price=o.price_open, volume=o.volume_current)

        if action == TRADE_ACTION_DEAL:
            # اصلاح (MOCK-002): بازکردن از همان order_check عبور می‌کند تا حجم/سمتِ
            # استاپِ نامعتبر مثل بروکر واقعی رد شود (قبلاً همیشه DONE بود).
            chk = self.order_check(req)
            if getattr(chk, "retcode", None) != TRADE_RETCODE_DONE:
                return _Obj(retcode=chk.retcode, comment=chk.comment, order=0,
                            deal=0, price=0.0, volume=0.0)
            # بازکردنِ پوزیشنِ جدید
            otype = req.get("type")
            is_buy = otype in (ORDER_TYPE_BUY, ORDER_TYPE_BUY_LIMIT, ORDER_TYPE_BUY_STOP)
            tk = self._next_ticket
            self._next_ticket += 1
            p = _Obj(ticket=tk, symbol=name, type=0 if is_buy else 1,
                     volume=round(req.get("volume", 0.0), 8),
                     price_open=req.get("price", s["price"]),
                     sl=req.get("sl", 0.0), tp=req.get("tp", 0.0),
                     price_current=s["price"], profit=0.0,
                     magic=req.get("magic", 0), comment=req.get("comment", ""),
                     time=1_760_000_000)
            self.positions[tk] = p
            self.deals.append({"ticket": tk, "symbol": name,
                               "open_volume": p.volume, "type": p.type})
            return _Obj(retcode=TRADE_RETCODE_DONE, comment="Done", order=tk,
                        deal=tk, price=p.price_open, volume=p.volume)

        return _Obj(retcode=10013, comment="unknown action", order=0, deal=0,
                    price=0.0, volume=0.0)

    def copy_rates_from_pos(self, symbol, timeframe=None, start_pos=0, count=300, *a, **k):
        """اصلاح (MOCK-RATES-001): قبلاً None برمی‌گرداند و تستِ نمادهای «صرفاً
        متاتریدری» (بدونِ نگاشتِ داخلی) ناممکن بود. حالا کندلِ مصنوعیِ «قطعی»
        می‌سازد: random walk با seed ثابت (نام نماد + تایم‌فریم) که دقیقاً به
        قیمتِ فعلیِ نماد ختم می‌شود — سازگار با mt5_bridge.rates (کلیدهای
        time/open/high/low/close/tick_volume)."""
        info = self.symbols.get(symbol)
        if info is None:
            return None
        import random
        tf_min = {TIMEFRAME_M1: 1, TIMEFRAME_M5: 5, TIMEFRAME_M10: 10,
                  TIMEFRAME_M15: 15, TIMEFRAME_M30: 30, TIMEFRAME_H1: 60,
                  TIMEFRAME_H2: 120, TIMEFRAME_H4: 240, TIMEFRAME_D1: 1440,
                  TIMEFRAME_W1: 10080, TIMEFRAME_MN1: 43200}.get(timeframe, 60)
        n = max(2, min(int(count or 300), 2000))
        px = float(info["price"])
        rng = random.Random(f"{symbol}:{tf_min}")
        # گام‌های بازگشتی از قیمتِ فعلی به عقب تا سری دقیقاً به px ختم شود
        closes = [px]
        for _ in range(n - 1):
            closes.append(closes[-1] / (1.0 + rng.uniform(-0.004, 0.004)))
        closes.reverse()
        step = tf_min * 60
        t0 = int(self._tick_time) - (n - 1) * step
        rows = []
        prev = closes[0]
        for i, c in enumerate(closes):
            o = prev
            hi = max(o, c) * (1.0 + abs(rng.uniform(0, 0.0015)))
            lo = min(o, c) * (1.0 - abs(rng.uniform(0, 0.0015)))
            rows.append({"time": t0 + i * step, "open": o, "high": hi,
                         "low": lo, "close": c,
                         "tick_volume": float(rng.randint(100, 5000))})
            prev = c
        return rows

    def copy_rates_range(self, symbol, timeframe=None, date_from=None, date_to=None, *a, **k):
        """اصلاح (MOCK-RATES-002): مثل copy_rates_from_pos ولی برای بازهٔ تاریخ
        (لازم برای تست /api/backtest/mt5 و rates_range)."""
        info = self.symbols.get(symbol)
        if info is None or date_from is None or date_to is None:
            return None
        import datetime as _dt
        def _ts(x):
            if isinstance(x, (int, float)):
                return int(x)
            if isinstance(x, _dt.datetime):
                return int(x.timestamp())
            return None
        t_from, t_to = _ts(date_from), _ts(date_to)
        if t_from is None or t_to is None or t_to <= t_from:
            return None
        tf_min = {TIMEFRAME_M1: 1, TIMEFRAME_M5: 5, TIMEFRAME_M10: 10,
                  TIMEFRAME_M15: 15, TIMEFRAME_M30: 30, TIMEFRAME_H1: 60,
                  TIMEFRAME_H2: 120, TIMEFRAME_H4: 240, TIMEFRAME_D1: 1440,
                  TIMEFRAME_W1: 10080, TIMEFRAME_MN1: 43200}.get(timeframe, 60)
        step = tf_min * 60
        n = min(max((t_to - t_from) // step, 0), 5000)
        if n < 2:
            return None
        rows = self.copy_rates_from_pos(symbol, timeframe, 0, n)
        # زمان‌ها را روی بازهٔ خواسته‌شده بنشان
        for i, r in enumerate(rows):
            r["time"] = t_from + i * step
        return rows


def _decimals(step):
    s = f"{step:.8f}".rstrip("0")
    return len(s.split(".")[1]) if "." in s else 0
