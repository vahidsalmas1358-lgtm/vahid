//+------------------------------------------------------------------+
//|                                          RobotBridge_FullEA.mq5   |
//|   نسخهٔ کاملِ خودبسنده (همه‌چیز در یک فایل — بدونِ نیاز به .mqh)   |
//|                                                                  |
//|   یک Expert Advisorِ کاملِ آمادهٔ کامپایل که:                     |
//|     • یک استراتژیِ نمونه (تقاطعِ EMA سریع/کند) دارد،             |
//|     • به‌جای OrderSendِ مستقیم، هر ورودی را به «برنامهٔ تحلیل»    |
//|       می‌فرستد تا با سیگنالِ داخلی و/یا هوش مصنوعی امتیاز بگیرد،  |
//|     • تنها در صورتِ تأیید، برنامه عیناً همان معامله را به         |
//|       متاتریدر ارسال می‌کند.                                     |
//|                                                                  |
//|   ★★ پیش‌نیازِ حیاتی: اجازهٔ WebRequest ★★                        |
//|   در متاتریدر:  Tools ▸ Options ▸ Expert Advisors ▸             |
//|   «Allow WebRequest for listed URL» را تیک بزنید و آدرسِ برنامه  |
//|   را دقیقاً اضافه کنید، مثلاً:  http://127.0.0.1:8000            |
//|   بدونِ این کار WebRequest خطای 4014 می‌دهد.                      |
//|   (WebRequest در «تسترِ استراتژی» کار نمی‌کند؛ روی چارتِ زنده    |
//|    اجرا کنید.)                                                    |
//+------------------------------------------------------------------+
#property copyright "BTC Agent - Robot Signal Bridge (Full EA)"
#property version   "1.20"
#property strict

#include <Trade/Trade.mqh>   // مدیریتِ پوزیشن (partial/BE/trailing) — OP5-MQL-MANAGE

//==================================================================//
//                         ۱) ورودی‌های EA                           //
//==================================================================//
//--- اتصال به برنامه
input string   InpBridgeURL      = "http://127.0.0.1:8000"; // آدرسِ برنامه
input string   InpSecret         = "";                       // توکنِ امنیتیِ مشترک (در صورتِ تنظیم در تب)
input int      InpTimeoutMs      = 10000;                    // مهلتِ درخواست (میلی‌ثانیه)
input bool     InpUseTestEndpoint= true;  // اصلاح (AUD-001): پیش‌فرضِ امن — برای معاملهٔ واقعی آگاهانه false کنید                    // ارسال به /api/robot/test (فقط آزمایش، بدونِ معاملهٔ واقعی)

//--- تنظیماتِ معامله
input double   InpVolume         = 0.10;   // حجم (لات) — عیناً همین به متاتریدر می‌رود
input long     InpMagic          = 234000; // عددِ مجیک / شناسهٔ ربات
input int      InpSLPips         = 300;    // فاصلهٔ استاپ (پیپ) — ۰ یعنی بدونِ استاپ
input int      InpTP1Pips        = 300;    // حد سودِ ۱ (پیپ)
input int      InpTP2Pips        = 600;    // حد سودِ ۲ (پیپ) — برای حالتِ چندهدفه
input int      InpTP3Pips        = 900;    // حد سودِ ۳ (پیپ) — برای حالتِ چندهدفه
input bool     InpUseMultiTP     = false;  // ارسالِ سه حد سود؟ (در غیر این صورت فقط TP1)

//--- استراتژیِ نمونه (تقاطعِ میانگینِ متحرک)
input int      InpFastMA         = 20;     // دورهٔ EMA سریع
input int      InpSlowMA         = 50;     // دورهٔ EMA کند
input bool     InpOneSignalPerBar= true;   // فقط یک سیگنال در هر کندل
input bool     InpBlockIfInPos   = true;   // اگر پوزیشنِ باز روی این نماد هست، سیگنالِ جدید نفرست
input string   InpTFOverride     = "";     // تایم‌فریمِ ارزیابی (خالی=خودکار از چارت): 15m/1h/4h/1d/1w
input bool     InpUseSessionGate = false;  // گیتِ جمعه/آخرهفته فعال باشد؟
input int      InpFridayCloseHour= 20;     // ساعتِ بستنِ جمعه (وقتِ سرور)
input bool     InpUseBEAndTrail  = false;  // مدیریتِ breakeven/trailing خودکار (بعد از ورودِ واقعی)
input int      InpBE_TrailTriggerPts = 300;// آستانهٔ سود (پوینت) برای فعال‌شدنِ BE/trailing
input int      InpBE_LockPts     = 30;     // قفلِ سود (پوینت) در breakeven
input int      InpTrailPts       = 200;    // فاصلهٔ trailing (پوینت؛ ۰=خاموش)
input int      InpPingEverySec   = 60;     // Pingِ دوره‌ای در تایمر (ثانیه؛ ۰=خاموش)

//==================================================================//
//              ۲) کدهای بازگشتی و ساختارِ نتیجهٔ پُل                 //
//==================================================================//
#define BRIDGE_RETCODE_DONE       10009   // = TRADE_RETCODE_DONE : به متاتریدر ارسال شد
#define BRIDGE_RETCODE_ERROR      20000   // خطای شبکه/سرور/اعتبارسنجی
#define BRIDGE_RETCODE_REJECTED   20001   // توسطِ فیلترِ برنامه رد شد
#define BRIDGE_RETCODE_NOT_SENT   20002   // تأیید شد ولی ارسالِ خودکار خاموش/ناموفق بود
#define BRIDGE_RETCODE_TEST_SIMULATED 20004  // درخواستِ test: فقط شبیه‌سازیِ سرور (معاملهٔ واقعی نیست)

struct BridgeResult
{
   bool     ok;          // آیا درخواست بدونِ خطا پردازش شد؟
   bool     approved;    // آیا فیلترِ برنامه سفارش را تأیید کرد؟
   bool     forwarded;   // آیا واقعاً به متاتریدر فرستاده شد؟
   int      http;        // کدِ HTTP (یا -1 در خطای WebRequest)
   int      retcode;     // یکی از BRIDGE_RETCODE_*
   string   comment;     // توضیح/خطا
   string   raw;         // پاسخِ خامِ JSON
};

//==================================================================//
//   ۲٫۵) توابعِ کمکیِ امن (اصلاحاتِ OP5-MQL-*) — سراسری و قابلِ استفاده  //
//==================================================================//
bool IsFiniteNumber(const double v)
{
   return(MathIsValidNumber(v) && v!=DBL_MAX && v!=-DBL_MAX);
}
bool HeaderValueSafe(const string value)
{
   return(StringFind(value,"\r")<0 && StringFind(value,"\n")<0 &&
          StringFind(value,"\0")<0);
}
bool BaseUrlSafe(const string url,const bool has_secret)
{
   if(url==NULL || url=="") return false;
   bool https=(StringFind(url,"https://")==0);
   bool loop=(StringFind(url,"http://127.0.0.1:")==0 ||
              StringFind(url,"http://localhost:")==0 ||
              StringFind(url,"http://[::1]:")==0 ||
              url=="http://127.0.0.1" || url=="http://localhost" ||
              url=="http://[::1]");
   return(https || (!has_secret && loop));
}
string JsonEscapeStrict(const string s)
{
   string out="";
   for(int i=0;i<StringLen(s);i++)
   {
      ushort c=StringGetCharacter(s,i);
      if(c=='\\') out+="\\\\";
      else if(c=='"') out+="\\\"";
      else if(c=='\b') out+="\\b";
      else if(c=='\f') out+="\\f";
      else if(c=='\n') out+="\\n";
      else if(c=='\r') out+="\\r";
      else if(c=='\t') out+="\\t";
      else if(c<0x20) out+=StringFormat("\\u%04X",(int)c);
      else out+=ShortToString(c);
   }
   return out;
}
string JsonNumber(const double v,const int digits)
{
   if(!IsFiniteNumber(v)) return "";
   int d=MathMax(0,MathMin(16,digits));
   return DoubleToString(v,d);
}
void PrintBridgeOutcome(const string title,const BridgeResult &r,const bool test_mode)
{
   if(test_mode && r.forwarded)
   {
      PrintFormat("[%s] TEST ONLY: simulated=true; no live trade was sent | http=%d | %s",
                  title,r.http,r.comment);
      return;
   }
   if(r.forwarded && r.retcode==BRIDGE_RETCODE_DONE)
      PrintFormat("[%s] LIVE forwarded=true | http=%d | %s",title,r.http,r.comment);
   else
      PrintFormat("[%s] NOT FILLED | approved=%s forwarded=%s http=%d retcode=%d | %s",
                  title,(r.approved?"true":"false"),(r.forwarded?"true":"false"),
                  r.http,r.retcode,r.comment);
}
int VolumeDigits(const string symbol)
{
   double step=SymbolInfoDouble(symbol,SYMBOL_VOLUME_STEP);
   int d=0;
   while(d<8 && MathAbs(step-NormalizeDouble(step,d))>1e-10) d++;
   return d;
}
double NormalizeVolumeDown(const string symbol,const double requested)
{
   double vmin=SymbolInfoDouble(symbol,SYMBOL_VOLUME_MIN);
   double vmax=SymbolInfoDouble(symbol,SYMBOL_VOLUME_MAX);
   double step=SymbolInfoDouble(symbol,SYMBOL_VOLUME_STEP);
   if(vmin<=0.0 || vmax<vmin || step<=0.0 || requested<=0.0) return 0.0;
   double v=MathMin(requested,vmax);
   double units=MathFloor((v+step*1e-9)/step);
   double out=NormalizeDouble(units*step,VolumeDigits(symbol));
   if(out<vmin) return 0.0;
   return MathMin(out,vmax);
}
double NormalizePriceToTick(const string symbol,const double price)
{
   double tick=SymbolInfoDouble(symbol,SYMBOL_TRADE_TICK_SIZE);
   double point=SymbolInfoDouble(symbol,SYMBOL_POINT);
   int digits=(int)SymbolInfoInteger(symbol,SYMBOL_DIGITS);
   if(tick<=0.0) tick=point;
   if(tick<=0.0 || price<=0.0) return 0.0;
   return NormalizeDouble(MathRound(price/tick)*tick,digits);
}
bool ValidateStops(const string symbol,const ENUM_ORDER_TYPE type,
                   const double sl,const double tp)
{
   MqlTick q;
   if(!SymbolInfoTick(symbol,q)) return false;
   double point=SymbolInfoDouble(symbol,SYMBOL_POINT);
   long stops=(long)SymbolInfoInteger(symbol,SYMBOL_TRADE_STOPS_LEVEL);
   long freeze=(long)SymbolInfoInteger(symbol,SYMBOL_TRADE_FREEZE_LEVEL);
   double min_distance=(double)MathMax(stops,freeze)*point;
   bool buy=(type==ORDER_TYPE_BUY);
   double ref=buy?q.ask:q.bid;
   if(sl>0.0 && (buy ? sl>=ref-min_distance : sl<=ref+min_distance)) return false;
   if(tp>0.0 && (buy ? tp<=ref+min_distance : tp>=ref-min_distance)) return false;
   return true;
}
ENUM_ORDER_TYPE_FILLING SelectFilling(const string symbol)
{
   long flags=SymbolInfoInteger(symbol,SYMBOL_FILLING_MODE);
   ENUM_SYMBOL_TRADE_EXECUTION exec=
      (ENUM_SYMBOL_TRADE_EXECUTION)SymbolInfoInteger(symbol,SYMBOL_TRADE_EXEMODE);
   if((flags & SYMBOL_FILLING_IOC)!=0) return ORDER_FILLING_IOC;
   if((flags & SYMBOL_FILLING_FOK)!=0) return ORDER_FILLING_FOK;
   if(exec!=SYMBOL_TRADE_EXECUTION_MARKET) return ORDER_FILLING_RETURN;
   return ORDER_FILLING_FOK;
}
bool SendChecked(MqlTradeRequest &request,MqlTradeResult &result,
                 const int max_requotes=1)
{
   request.type_filling=SelectFilling(request.symbol);
   int tries=0;
   for(;;)
   {
      ZeroMemory(result);
      ResetLastError();
      if(!OrderSend(request,result))
      {
         if(tries++<max_requotes &&
            (result.retcode==TRADE_RETCODE_REQUOTE ||
             result.retcode==TRADE_RETCODE_PRICE_CHANGED))
         {
            MqlTick q;
            if(!SymbolInfoTick(request.symbol,q)) return false;
            request.price=(request.type==ORDER_TYPE_BUY?q.ask:q.bid);
            continue;
         }
         return false;
      }
      if(result.retcode==TRADE_RETCODE_DONE ||
         result.retcode==TRADE_RETCODE_PLACED ||
         result.retcode==TRADE_RETCODE_DONE_PARTIAL)
         return true;
      if((result.retcode==TRADE_RETCODE_REQUOTE ||
          result.retcode==TRADE_RETCODE_PRICE_CHANGED) && tries++<max_requotes)
         continue;
      return false;
   }
}
bool IsFridayCloseOrWeekend(const int friday_close_hour=20,
                            const int friday_close_minute=0,
                            const bool use_trade_server=true)
{
   datetime now=(use_trade_server?TimeTradeServer():TimeCurrent());
   if(now<=0) now=TimeCurrent();
   if(now<=0) return true;
   MqlDateTime dt;
   TimeToStruct(now,dt);
   if(dt.day_of_week==0 || dt.day_of_week==6) return true;
   if(dt.day_of_week!=5) return false;
   int cur=dt.hour*60+dt.min;
   int cut=MathMax(0,MathMin(23,friday_close_hour))*60+
           MathMax(0,MathMin(59,friday_close_minute));
   return(cur>=cut);
}
bool IsSessionAllowed(const int start_hour,const int start_minute,
                      const int end_hour,const int end_minute)
{
   datetime now=TimeTradeServer();
   if(now<=0) now=TimeCurrent();
   if(now<=0 || IsFridayCloseOrWeekend()) return false;
   MqlDateTime dt; TimeToStruct(now,dt);
   int cur=dt.hour*60+dt.min;
   int a=MathMax(0,MathMin(23,start_hour))*60+MathMax(0,MathMin(59,start_minute));
   int b=MathMax(0,MathMin(23,end_hour))*60+MathMax(0,MathMin(59,end_minute));
   if(a==b) return true;
   return(a<b ? cur>=a && cur<b : cur>=a || cur<b);
}
bool HasManagedPosition(const string symbol,const long magic)
{
   ENUM_ACCOUNT_MARGIN_MODE mode=
      (ENUM_ACCOUNT_MARGIN_MODE)AccountInfoInteger(ACCOUNT_MARGIN_MODE);
   for(int i=PositionsTotal()-1;i>=0;i--)
   {
      ulong ticket=PositionGetTicket(i);
      if(ticket==0 || PositionGetString(POSITION_SYMBOL)!=symbol) continue;
      long pm=(long)PositionGetInteger(POSITION_MAGIC);
      if(mode==ACCOUNT_MARGIN_MODE_RETAIL_NETTING ||
         mode==ACCOUNT_MARGIN_MODE_EXCHANGE)
         return true;
      if(pm==magic) return true;
   }
   return false;
}
bool CloseManagedPositions(const string symbol,const long magic,
                           const double close_fraction,const ulong deviation)
{
   CTrade trade;
   trade.SetExpertMagicNumber(magic);
   trade.SetDeviationInPoints(deviation);
   bool all_ok=true;
   for(int i=PositionsTotal()-1;i>=0;i--)
   {
      ulong ticket=PositionGetTicket(i);
      if(ticket==0 || PositionGetString(POSITION_SYMBOL)!=symbol ||
         (long)PositionGetInteger(POSITION_MAGIC)!=magic) continue;
      double current=PositionGetDouble(POSITION_VOLUME);
      double amount=current;
      if(close_fraction>0.0 && close_fraction<1.0)
      {
         amount=NormalizeVolumeDown(symbol,current*close_fraction);
         double left=NormalizeVolumeDown(symbol,current-amount);
         double vmin=SymbolInfoDouble(symbol,SYMBOL_VOLUME_MIN);
         if(amount<=0.0 || (left>0.0 && left<vmin)) amount=current;
      }
      bool ok=trade.PositionClosePartial(ticket,amount,deviation);
      uint rc=trade.ResultRetcode();
      if(!ok || (rc!=TRADE_RETCODE_DONE && rc!=TRADE_RETCODE_DONE_PARTIAL)) all_ok=false;
   }
   return all_ok;
}
void ManageBreakEvenAndTrailing(const string symbol,const long magic,
                                const int trigger_points,const int lock_points,
                                const int trail_points)
{
   MqlTick q; if(!SymbolInfoTick(symbol,q)) return;
   double point=SymbolInfoDouble(symbol,SYMBOL_POINT);
   for(int i=PositionsTotal()-1;i>=0;i--)
   {
      ulong ticket=PositionGetTicket(i);
      if(ticket==0 || PositionGetString(POSITION_SYMBOL)!=symbol ||
         (long)PositionGetInteger(POSITION_MAGIC)!=magic) continue;
      bool buy=PositionGetInteger(POSITION_TYPE)==POSITION_TYPE_BUY;
      double open=PositionGetDouble(POSITION_PRICE_OPEN);
      double old_sl=PositionGetDouble(POSITION_SL);
      double px=buy?q.bid:q.ask;
      double profit_points=(buy?px-open:open-px)/point;
      if(profit_points<trigger_points) continue;
      double candidate=buy?open+lock_points*point:open-lock_points*point;
      if(trail_points>0)
      {
         double trail=buy?px-trail_points*point:px+trail_points*point;
         candidate=buy?MathMax(candidate,trail):MathMin(candidate,trail);
      }
      candidate=NormalizePriceToTick(symbol,candidate);
      if(candidate<=0.0) continue;
      if(old_sl>0.0 && ((buy && candidate<=old_sl) || (!buy && candidate>=old_sl))) continue;
      CTrade trade;
      trade.SetExpertMagicNumber(magic);
      trade.PositionModify(ticket,candidate,PositionGetDouble(POSITION_TP));
   }
}
bool IsNewBar(const string symbol,const ENUM_TIMEFRAMES tf,datetime &last_bar)
{
   datetime t=iTime(symbol,tf,0);
   if(t<=0) return false;
   if(last_bar==0) { last_bar=t; return false; }
   if(t==last_bar) return false;
   last_bar=t;
   return true;
}

//==================================================================//
//                 ۳) کلاسِ پُل (کاملاً تعبیه‌شده)                    //
//==================================================================//
class CRobotBridge
{
private:
   string   m_base_url;
   string   m_secret;
   int      m_timeout;

   string   JsonEscape(const string s) const
   {
      string r=s;
      StringReplace(r,"\\","\\\\");
      StringReplace(r,"\"","\\\"");
      StringReplace(r,"\n","\\n");
      StringReplace(r,"\r","\\r");
      StringReplace(r,"\t","\\t");
      return r;
   }

   string   NumToStr(const double v,const int digits) const
   {
      int d=(digits>=0?digits:8);
      string s=DoubleToString(v,d);
      if(StringFind(s,".")>=0)
      {
         int len=StringLen(s);
         while(len>0 && StringGetCharacter(s,len-1)=='0'){ s=StringSubstr(s,0,len-1); len--; }
         if(len>0 && StringGetCharacter(s,len-1)=='.') s=StringSubstr(s,0,len-1);
      }
      return s;
   }

   bool     JsonGetBool(const string js,const string key,const bool defv=false) const
   {
      int p=StringFind(js,"\""+key+"\"");
      if(p<0) return defv;
      int c=StringFind(js,":",p+StringLen(key)+2);
      if(c<0) return defv;
      string rest=StringSubstr(js,c+1,8);
      StringTrimLeft(rest);
      if(StringFind(rest,"true")==0)  return true;
      if(StringFind(rest,"false")==0) return false;
      return defv;
   }

   string   JsonGetStr(const string js,const string key) const
   {
      int p=StringFind(js,"\""+key+"\"");
      if(p<0) return "";
      int c=StringFind(js,":",p+StringLen(key)+2);
      if(c<0) return "";
      int q1=StringFind(js,"\"",c+1);
      if(q1<0) return "";
      int q2=StringFind(js,"\"",q1+1);
      if(q2<0) return "";
      return StringSubstr(js,q1+1,q2-q1-1);
   }

   bool     Post(const string path,const string body,BridgeResult &out)
   {
      out.ok=false; out.approved=false; out.forwarded=false;
      out.http=-1; out.retcode=BRIDGE_RETCODE_ERROR; out.comment=""; out.raw="";

      // --- امنیت (OP5-MQL-SEC)
      if(!BaseUrlSafe(m_base_url,StringLen(m_secret)>0) || !HeaderValueSafe(m_secret))
      {
         out.comment="Unsafe URL or secret header";
         Print("[RobotBridge] ",out.comment);
         return false;
      }

      string url=m_base_url+path;
      string headers="Content-Type: application/json\r\n";
      if(StringLen(m_secret)>0) headers+="X-Robot-Secret: "+m_secret+"\r\n";

      char data[];
      int len=StringToCharArray(body,data,0,WHOLE_ARRAY,CP_UTF8);
      if(len>0 && data[len-1]==0) ArrayResize(data,len-1);

      char   result[];
      string result_headers;
      ResetLastError();
      int status=WebRequest("POST",url,headers,
                            MathMax(100,MathMin(m_timeout,30000)),
                            data,result,result_headers);

      if(status==-1)
      {
         int err=GetLastError();
         out.http=-1; out.retcode=BRIDGE_RETCODE_ERROR;
         if(err==4014)
            out.comment="خطا 4014: آدرسِ «"+url+"» در فهرستِ WebRequest مجاز نیست. "
                        "از Tools ▸ Options ▸ Expert Advisors اضافه کنید.";
         else
            out.comment="WebRequest ناموفق (خطا "+IntegerToString(err)+"). "
                        "اتصال/آدرس/فعال بودنِ برنامه را بررسی کنید.";
         Print("[RobotBridge] ",out.comment);
         return false;
      }

      string resp=CharArrayToString(result,0,WHOLE_ARRAY,CP_UTF8);
      // --- OP5-MQL-HTTP: پاسخِ غیرِ 2xx خطاست
      if(status<200 || status>=300)
      {
         out.http=status; out.raw=resp; out.retcode=BRIDGE_RETCODE_ERROR;
         out.comment="HTTP error "+IntegerToString(status);
         return false;
      }

      out.http=status; out.raw=resp;
      out.ok        =JsonGetBool(resp,"ok",false);
      out.approved  =JsonGetBool(resp,"approved",false);
      out.forwarded =JsonGetBool(resp,"forwarded",false);

      if(!out.ok)
      {
         out.retcode=BRIDGE_RETCODE_ERROR;
         out.comment=JsonGetStr(resp,"error");
         if(StringLen(out.comment)==0) out.comment="خطای نامشخص (HTTP "+IntegerToString(status)+")";
         return false;
      }
      // --- OP5-MQL-TEST: endpointِ آزمون = شبیه‌سازی (نه معاملهٔ واقعی)
      if(StringFind(path,"/api/robot/test")>=0 && out.forwarded)
      {
         out.retcode=BRIDGE_RETCODE_TEST_SIMULATED;
         out.comment="TEST ONLY: server simulation; no live MT5 trade";
      }
      else if(out.forwarded)
      {
         out.retcode=BRIDGE_RETCODE_DONE;
         out.comment="پاسخِ فوروارد دریافت شد";
      }
      else if(out.approved)
      {
         out.retcode=BRIDGE_RETCODE_NOT_SENT;
         out.comment="تأیید شد ولی به متاتریدر ارسال نشد (ارسالِ خودکار خاموش یا ارسال ناموفق)";
      }
      else
      {
         out.retcode=BRIDGE_RETCODE_REJECTED;
         out.comment="توسطِ فیلترِ برنامه رد شد";
      }
      return out.ok;
   }

public:
   CRobotBridge(void){ m_base_url="http://127.0.0.1:8000"; m_secret=""; m_timeout=10000; }

   void     Init(const string base_url,const string secret="",const int timeout_ms=10000)
   {
      m_base_url=base_url;
      int n=StringLen(m_base_url);
      while(n>0 && StringGetCharacter(m_base_url,n-1)=='/'){ m_base_url=StringSubstr(m_base_url,0,n-1); n--; }
      m_secret=secret;
      m_timeout=(timeout_ms>0?timeout_ms:10000);
   }

   // OP5-MQL-FIREWALL: فقط خرید/فروشِ بازارِ شناخته‌شده؛ بقیه نامعتبرند
   static string DirFromType(const int order_type)
   {
      if(order_type==ORDER_TYPE_BUY)  return "BUY";
      if(order_type==ORDER_TYPE_SELL) return "SELL";
      return "";
   }

   static string TFfromPeriod(const ENUM_TIMEFRAMES period)
   {
      switch(period)
      {
         case PERIOD_M15: return "15m";
         case PERIOD_H1:  return "1h";
         case PERIOD_H4:  return "4h";
         case PERIOD_D1:  return "1d";
         case PERIOD_W1:  return "1w";
         default:         return "1h";
      }
   }

   bool     Ping(void)
   {
      char data[]; char result[]; string response_headers;
      ResetLastError();
      int status=WebRequest("GET",m_base_url+"/health",
                            "Accept: application/json\r\n",
                            MathMax(100,MathMin(m_timeout,30000)),
                            data,result,response_headers);
      if(status!=200)
      {
         PrintFormat("[RobotBridge] health failed status=%d error=%d url=%s",
                     status,GetLastError(),m_base_url+"/health");
         return false;
      }
      return true;
   }

   BridgeResult Send(const string symbol,const string direction,const double volume,
                     const double sl=0.0,const double tp=0.0,const double entry=0.0,
                     const string tf="",const string robot_id="",const string comment="",
                     const long magic=0,const int price_digits=-1,const bool test=false)
   {
      BridgeResult res;
      int pd=(price_digits>=0?price_digits:(int)SymbolInfoInteger(symbol,SYMBOL_DIGITS));
      if(pd<=0) pd=5;
      if(!IsFiniteNumber(volume) || volume<=0.0)
      {
         res.ok=false; res.retcode=BRIDGE_RETCODE_ERROR; res.comment="Invalid volume";
         return res;
      }
      string j="{";
      j+="\"symbol\":\""   +JsonEscapeStrict(symbol)+"\",";
      j+="\"direction\":\""+JsonEscapeStrict(direction)+"\",";
      j+="\"volume\":"     +JsonNumber(volume,2);
      if(sl>0.0 && IsFiniteNumber(sl))    j+=",\"sl\":"    +JsonNumber(sl,pd);
      if(tp>0.0 && IsFiniteNumber(tp))    j+=",\"tp\":"    +JsonNumber(tp,pd);
      if(entry>0.0 && IsFiniteNumber(entry)) j+=",\"entry\":" +JsonNumber(entry,pd);
      if(StringLen(tf)>0)       j+=",\"tf\":\""      +JsonEscapeStrict(tf)+"\"";
      if(StringLen(robot_id)>0) j+=",\"robot_id\":\""+JsonEscapeStrict(robot_id)+"\"";
      if(StringLen(comment)>0)  j+=",\"comment\":\"" +JsonEscapeStrict(comment)+"\"";
      if(magic!=0)              j+=",\"magic\":"     +IntegerToString(magic);
      j+="}";
      Post(test?"/api/robot/test":"/api/robot/order",j,res);
      return res;
   }

   BridgeResult SendMultiTP(const string symbol,const string direction,const double volume,
                            const double sl,const double &tps[],const double entry=0.0,
                            const string tf="",const string robot_id="",const string comment="",
                            const long magic=0,const int price_digits=-1,const bool test=false)
   {
      BridgeResult res;
      int pd=(price_digits>=0?price_digits:(int)SymbolInfoInteger(symbol,SYMBOL_DIGITS));
      if(pd<=0) pd=5;
      if(!IsFiniteNumber(volume) || volume<=0.0)
      {
         res.ok=false; res.retcode=BRIDGE_RETCODE_ERROR; res.comment="Invalid volume";
         return res;
      }
      string j="{";
      j+="\"symbol\":\""   +JsonEscapeStrict(symbol)+"\",";
      j+="\"direction\":\""+JsonEscapeStrict(direction)+"\",";
      j+="\"volume\":"     +JsonNumber(volume,2);
      if(sl>0.0 && IsFiniteNumber(sl)) j+=",\"sl\":"+JsonNumber(sl,pd);
      int cnt=ArraySize(tps);
      if(cnt>0)
      {
         j+=",\"take_profits\":[";
         int written=0;
         for(int i=0;i<cnt;i++)
         {
            if(!IsFiniteNumber(tps[i]) || tps[i]<=0.0) continue;  // صفر/NaN وارد نمی‌شود
            if(written>0) j+=",";
            j+=JsonNumber(tps[i],pd);
            written++;
         }
         j+="]";
      }
      if(entry>0.0 && IsFiniteNumber(entry)) j+=",\"entry\":"+JsonNumber(entry,pd);
      if(StringLen(tf)>0)       j+=",\"tf\":\""      +JsonEscapeStrict(tf)+"\"";
      if(StringLen(robot_id)>0) j+=",\"robot_id\":\""+JsonEscapeStrict(robot_id)+"\"";
      if(StringLen(comment)>0)  j+=",\"comment\":\"" +JsonEscapeStrict(comment)+"\"";
      if(magic!=0)              j+=",\"magic\":"     +IntegerToString(magic);
      j+="}";
      Post(test?"/api/robot/test":"/api/robot/order",j,res);
      return res;
   }

   //--- جایگزینِ مستقیمِ OrderSend
   bool     OrderSendBridge(MqlTradeRequest &request,MqlTradeResult &result,
                            const string tf="",const bool test=false)
   {
      ZeroMemory(result);
      result.retcode=TRADE_RETCODE_INVALID;
      // --- OP5-MQL-FIREWALL: فقط بازارِ جدیدِ BUY/SELL
      if(request.action!=TRADE_ACTION_DEAL ||
         (request.type!=ORDER_TYPE_BUY && request.type!=ORDER_TYPE_SELL) ||
         request.position!=0 || request.order!=0 || request.position_by!=0 ||
         request.stoplimit!=0.0 || request.type_time!=ORDER_TIME_GTC ||
         request.expiration!=0)
      {
         result.comment="RobotBridge supports only new market BUY/SELL orders; "
                        "close, SLTP and pending orders must use native OrderSend";
         Print("[RobotBridge] ",result.comment);
         return false;
      }
      if(request.symbol==NULL || request.symbol=="" || request.volume<=0.0)
      {
         result.comment="Invalid symbol or volume";
         return false;
      }
      string dir=DirFromType((int)request.type);
      if(dir=="")
      {
         result.comment="Unsupported order type";
         return false;
      }
      BridgeResult br=Send(request.symbol,dir,request.volume,request.sl,request.tp,
                           request.price,tf,IntegerToString((long)request.magic),
                           request.comment,(long)request.magic,-1,test);
      result.retcode=(uint)br.retcode;
      result.comment=br.comment;
      result.volume =request.volume;
      result.price  =request.price;
      return (br.forwarded && br.retcode==BRIDGE_RETCODE_DONE);
   }
};

//==================================================================//
//                    ۴) متغیرها و توابعِ کمکیِ EA                   //
//==================================================================//
CRobotBridge  bridge;
int           hFast=INVALID_HANDLE;   // هندلِ EMA سریع
int           hSlow=INVALID_HANDLE;   // هندلِ EMA کند
datetime      g_lastBarTime=0;        // برای تشخیصِ کندلِ جدید
int           g_lastSignal=0;         // آخرین سیگنال روی همین کندل: 0=هیچ،1=خرید،-1=فروش

//--- اندازهٔ یک پیپ بر اساس رقمِ اعشارِ نماد
double PipSize()
{
   int digits=(int)SymbolInfoInteger(_Symbol,SYMBOL_DIGITS);
   double point=SymbolInfoDouble(_Symbol,SYMBOL_POINT);
   return((digits==3 || digits==5) ? point*10.0 : point);
}

//--- آیا پوزیشنِ بازی روی این نماد وجود دارد؟ (netting-aware)
bool HasOpenPosition()
{
   return HasManagedPosition(_Symbol, InpMagic);
}

//--- چاپِ نتیجهٔ پُل در لاگ (با تفکیکِ TEST از LIVE)
void LogResult(const string title,const BridgeResult &r)
{
   PrintBridgeOutcome(title,r,InpUseTestEndpoint);
}

//--- اعتبارسنجیِ ورودی‌ها (OP5-MQL-VALIDATE)
bool ValidateInputs()
{
   if(InpBridgeURL==NULL || InpBridgeURL=="") return false;
   if(!BaseUrlSafe(InpBridgeURL, StringLen(InpSecret)>0)) return false;
   if(InpTimeoutMs<100 || InpTimeoutMs>30000) return false;
   if(InpVolume<=0.0 || NormalizeVolumeDown(_Symbol,InpVolume)<=0.0) return false;
   if(InpFastMA<1 || InpSlowMA<2 || InpFastMA>=InpSlowMA) return false;
   if(InpSLPips<0 || InpTP1Pips<0 || InpTP2Pips<0 || InpTP3Pips<0) return false;
   if(InpMagic<=0) return false;
   if(InpFridayCloseHour<0 || InpFridayCloseHour>23) return false;
   return true;
}

//--- به‌روزرسانیِ وضعیت روی چارت (observability)
void UpdateStatus(const string text)
{
   Comment("RobotBridge FullEA\n",text,
           "\nmode=",(InpUseTestEndpoint?"TEST":"LIVE"),
           " url=",InpBridgeURL,
           " magic=",IntegerToString(InpMagic),
           " fast/slow=",IntegerToString(InpFastMA)+"/"+IntegerToString(InpSlowMA));
}
string g_status_object="RobotBridgeStatus";
void ClearStatus()
{
   Comment("");
   ObjectDelete(0, g_status_object);   // OP5-MQL-24: نمایش/پاک‌سازیِ وضعیت روی چارت
}

//--- ارسالِ یک سیگنال از طریقِ پُل (خرید/فروش) با محاسبهٔ SL/TP از پیپ
void RouteSignal(const string dir)
{
   if(InpUseSessionGate && IsFridayCloseOrWeekend(InpFridayCloseHour))
   {
      Print("Session gate: Friday/weekend — signal skipped");
      return;
   }
   MqlTick q;
   if(!SymbolInfoTick(_Symbol,q) || q.ask<=0.0 || q.bid<=0.0)
   {
      Print("No valid quote; signal skipped");
      return;
   }
   if(InpVolume<=0.0 || InpSLPips<0 || InpTP1Pips<0 || InpTP2Pips<0 || InpTP3Pips<0)
   {
      Print("Invalid volume/SL/TP inputs");
      return;
   }
   double point=SymbolInfoDouble(_Symbol,SYMBOL_POINT);
   double tick=SymbolInfoDouble(_Symbol,SYMBOL_TRADE_TICK_SIZE);
   int dg=(int)SymbolInfoInteger(_Symbol,SYMBOL_DIGITS);
   double unit=(tick>0.0?tick:point);
   double pip=((dg==3 || dg==5) ? point*10.0 : point);
   double ref=(dir=="BUY"?q.ask:q.bid);
   double sl=0.0;
   if(InpSLPips>0) sl=NormalizePriceToTick(_Symbol,ref+(dir=="BUY"?-1:1)*InpSLPips*pip);
   double tp_values[3];
   int n=0;
   int distances[3]={InpTP1Pips,InpTP2Pips,InpTP3Pips};
   for(int i=0;i<3;i++)
   {
      if(distances[i]<=0) continue;
      double tp=NormalizePriceToTick(_Symbol,ref+(dir=="BUY"?1:-1)*distances[i]*pip);
      if(tp<=0.0 || (dir=="BUY" && tp<=ref) || (dir=="SELL" && tp>=ref)) continue;
      if(n==0 || MathAbs(tp-tp_values[n-1])>=unit*0.5) tp_values[n++]=tp;
   }
   if(n==0) { Print("No valid TP"); return; }
   double volume=NormalizeVolumeDown(_Symbol,InpVolume);
   if(volume<=0.0) { Print("Volume is outside symbol limits"); return; }
   if(!ValidateStops(_Symbol,(dir=="BUY"?ORDER_TYPE_BUY:ORDER_TYPE_SELL),sl,tp_values[0]))
   {
      Print("Stops violate broker stops/freeze level; signal skipped");
      return;
   }
   string tf=(StringLen(InpTFOverride)>0?InpTFOverride:
              CRobotBridge::TFfromPeriod((ENUM_TIMEFRAMES)_Period));
   BridgeResult r;
   if(InpUseMultiTP)
      r=bridge.SendMultiTP(_Symbol,dir,volume,sl,tp_values,0.0,tf,
                           "FullEA-"+IntegerToString(InpMagic),"EMA cross "+dir,
                           InpMagic,dg,InpUseTestEndpoint);
   else
      r=bridge.Send(_Symbol,dir,volume,sl,tp_values[0],0.0,tf,
                    "FullEA-"+IntegerToString(InpMagic),"EMA cross "+dir,
                    InpMagic,dg,InpUseTestEndpoint);
   LogResult("Route/"+dir,r);
   UpdateStatus(dir+" retcode="+IntegerToString(r.retcode));
}

//--- صفِ سیگنال (WebRequestِ همگام نباید در مسیرِ تیک اجرا شود)
bool     g_pending_signal=false;
string   g_pending_dir="";
datetime g_lastPing=0;

void QueueSignal(const string dir)
{
   if(g_pending_signal) return;
   g_pending_signal=true;
   g_pending_dir=dir;
}

void OnTimer()
{
   if(g_pending_signal)
   {
      string dir=g_pending_dir;
      g_pending_signal=false;
      g_pending_dir="";
      RouteSignal(dir);
   }
   if(InpUseBEAndTrail)
      ManageBreakEvenAndTrailing(_Symbol,InpMagic,InpBE_TrailTriggerPts,
                                 InpBE_LockPts,InpTrailPts);
   if(InpPingEverySec>0 && TimeCurrent()-g_lastPing>=InpPingEverySec)
   {
      g_lastPing=TimeCurrent();
      if(!bridge.Ping()) UpdateStatus("health check failed");
   }
}

//==================================================================//
//                       ۵) رویدادهای EA                            //
//==================================================================//
int OnInit()
{
   if(!ValidateInputs())
   {
      Print("⛔ ورودی‌های EA نامعتبر است.");
      return(INIT_PARAMETERS_INCORRECT);
   }
   // ساخت هندلِ اندیکاتورها
   hFast=iMA(_Symbol,_Period,InpFastMA,0,MODE_EMA,PRICE_CLOSE);
   hSlow=iMA(_Symbol,_Period,InpSlowMA,0,MODE_EMA,PRICE_CLOSE);
   if(hFast==INVALID_HANDLE || hSlow==INVALID_HANDLE)
   {
      Print("⛔ ساختِ هندلِ میانگینِ متحرک ناموفق بود.");
      return(INIT_FAILED);
   }
   // OP5-MQL-TIMER: WebRequest در تایمر اجرا می‌شود، نه در OnInit/OnTick
   if(!EventSetTimer(1))
   {
      PrintFormat("EventSetTimer failed: %d",GetLastError());
      return INIT_FAILED;
   }
   bridge.Init(InpBridgeURL,InpSecret,InpTimeoutMs);
   UpdateStatus("init");

   PrintFormat("RobotBridge FullEA آماده شد | نماد=%s تایم‌فریم=%s حجم=%.2f مجیک=%d حالت=%s",
               _Symbol,CRobotBridge::TFfromPeriod((ENUM_TIMEFRAMES)_Period),
               InpVolume,(int)InpMagic,(InpUseMultiTP?"MultiTP":"SingleTP"));
   return(INIT_SUCCEEDED);
}

void OnDeinit(const int reason)
{
   EventKillTimer();
   ClearStatus();
   if(hFast!=INVALID_HANDLE) IndicatorRelease(hFast);
   if(hSlow!=INVALID_HANDLE) IndicatorRelease(hSlow);
}

void OnTick()
{
   // فقط روی کندلِ جدید تصمیم بگیر (کاهشِ نویز و درخواستِ اضافه)
   // OP5-MQL-NEWBAR: iTime=0 در شروع ممکن است صفر باشد؛ IsNewBar با retry
   datetime t=iTime(_Symbol,_Period,0);
   if(t<=0) return;
   bool newBar=(t!=g_lastBarTime);
   if(newBar){ g_lastBarTime=t; g_lastSignal=0; }
   if(!newBar && InpOneSignalPerBar) return;

   // خواندنِ EMAها روی کندل‌های بسته‌شده (شیفت ۱ و ۲)
   double fast[], slow[];
   ArraySetAsSeries(fast,true);
   ArraySetAsSeries(slow,true);
   if(CopyBuffer(hFast,0,0,3,fast)<3) return;
   if(CopyBuffer(hSlow,0,0,3,slow)<3) return;

   bool crossUp   =(fast[2]<=slow[2] && fast[1]>slow[1]);   // تقاطعِ صعودی
   bool crossDown =(fast[2]>=slow[2] && fast[1]<slow[1]);   // تقاطعِ نزولی
   if(!crossUp && !crossDown) return;

   // جلوگیری از ارسالِ تکراری روی همان کندل
   if(InpOneSignalPerBar && g_lastSignal!=0) return;

   // در صورتِ تنظیم، اگر پوزیشنِ باز داریم سیگنالِ جدید نفرست
   if(InpBlockIfInPos && HasOpenPosition())
   {
      Print("ℹ️ پوزیشنِ باز روی این نماد هست؛ سیگنالِ جدید ارسال نشد.");
      g_lastSignal=(crossUp?1:-1);
      return;
   }

   if(crossUp){  g_lastSignal=1;  QueueSignal("BUY");  }
   else       {  g_lastSignal=-1; QueueSignal("SELL"); }
}
//+------------------------------------------------------------------+
