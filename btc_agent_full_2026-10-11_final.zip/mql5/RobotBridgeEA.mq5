//+------------------------------------------------------------------+
//|                                               RobotBridgeEA.mq5   |
//|   نمونهٔ Expert Advisor برای استفاده از «پُلِ سیگنالِ ربات‌ها».   |
//|                                                                  |
//|   این EA نشان می‌دهد چگونه به‌جای ارسالِ مستقیمِ سفارش به کارگزار،|
//|   آن را به «برنامهٔ تحلیل» بفرستید تا پس از تأییدِ سیگنالِ داخلی/ |
//|   هوش مصنوعی، عیناً به متاتریدر ارسال شود.                        |
//|                                                                  |
//|   ★ پیش‌نیاز: Tools ▸ Options ▸ Expert Advisors ▸               |
//|     «Allow WebRequest for listed URL» را تیک بزنید و آدرسِ       |
//|     برنامه (مثلاً http://127.0.0.1:8000) را اضافه کنید.          |
//|   ★ WebRequest در «تسترِ استراتژی» کار نمی‌کند؛ روی چارتِ زنده   |
//|     اجرا کنید.                                                    |
//+------------------------------------------------------------------+
#property copyright "BTC Agent"
#property version   "1.10"
#property strict

#include <RobotBridge.mqh>
//  اگر فایلِ .mqh را در پوشهٔ MQL5\Include گذاشته‌اید از < > استفاده کنید،
//  و اگر کنارِ همین EA (در MQL5\Experts) گذاشته‌اید از "RobotBridge.mqh".

//--- ورودی‌ها -------------------------------------------------------
input string InpBridgeURL   = "http://127.0.0.1:8000"; // آدرسِ برنامه
input string InpSecret      = "";                       // توکنِ امنیتیِ مشترک (در صورتِ تنظیم در تب)
input int    InpTimeoutMs   = 10000;                    // مهلتِ درخواست (میلی‌ثانیه)
input double InpVolume      = 0.10;                     // حجمِ نمونه (لات)
input long   InpMagic       = 234000;                   // عددِ مجیک/شناسهٔ ربات
input bool   InpSendTestOnInit = true;                  // هنگامِ راه‌اندازی یک سفارشِ آزمایشی بفرست؟
input bool   InpUseTestEndpoint = true;                 // به /api/robot/test برود؟ (فقط آزمایش)
input bool   InpBlockIfInPos   = true;                  // اگر پوزیشنِ تحتِ مدیریت هست، سفارشِ تازه نفرست
input bool   InpUseSessionGate = false;                 // گیتِ جمعه/آخرهفته فعال باشد؟
input int    InpFridayCloseHour = 20;                   // ساعتِ بستنِ جمعه (وقتِ سرور)
input bool   InpPingOnTimerMs   = 60000;                // فاصلهٔ Ping دوره‌ای (میلی‌ثانیه؛ ۰ = خاموش)

//--- شیءِ سراسریِ پُل + وضعیت
CRobotBridge bridge;
datetime     g_lastPing = 0;
string       g_status_object = "RobotBridgeStatus";

//+------------------------------------------------------------------+
//| اعتبارسنجیِ ورودی‌ها (OP5-MQL-VALIDATE)                          |
//+------------------------------------------------------------------+
bool ValidateInputs()
{
   if(InpBridgeURL==NULL || InpBridgeURL=="") return false;
   if(!BaseUrlSafe(InpBridgeURL, StringLen(InpSecret)>0))
   {
      Print("⛔ آدرسِ پل نامعتبر است (برای secret روی میزبانِ غیرلوکال، HTTPS لازم است).");
      return false;
   }
   if(InpTimeoutMs<100 || InpTimeoutMs>30000) return false;
   if(InpVolume<=0.0 || NormalizeVolumeDown(_Symbol,InpVolume)<=0.0) return false;
   if(InpMagic<=0) return false;
   if(InpFridayCloseHour<0 || InpFridayCloseHour>23) return false;
   return true;
}

//+------------------------------------------------------------------+
//| به‌روزرسانیِ وضعیت روی چارت (observability)                      |
//+------------------------------------------------------------------+
void UpdateStatus(const string text)
{
   Comment("RobotBridge\n", text,
           "\nmode=", (InpUseTestEndpoint ? "TEST" : "LIVE"),
           " url=", InpBridgeURL,
           " magic=", IntegerToString(InpMagic));
}

void ClearStatus()
{
   Comment("");
   ObjectDelete(0, g_status_object);
}

//+------------------------------------------------------------------+
int OnInit()
{
   if(!ValidateInputs())
   {
      Print("⛔ ورودی‌های EA نامعتبر است.");
      return(INIT_PARAMETERS_INCORRECT);
   }
   // OP5-MQL-TIMER: Ping و انقضای وضعیت در تایمر انجام می‌شود، نه در هر OnTick
   // (WebRequestِ همگام تا مهلتش، پردازشِ تیک را بلوکه می‌کند).
   if(!EventSetTimer(1))
   {
      PrintFormat("EventSetTimer failed: %d", GetLastError());
      return INIT_FAILED;
   }
   bridge.Init(InpBridgeURL, InpSecret, InpTimeoutMs);
   UpdateStatus("init");

   if(InpSendTestOnInit)
   {
      // --- نمونهٔ ۱: سبکِ ساده (پیش‌فرض = endpointِ آزمون؛ شبیه‌سازیِ سرور) ---
      string tf = CRobotBridge::TFfromPeriod((ENUM_TIMEFRAMES)_Period);
      BridgeResult r1 = bridge.Send(_Symbol, "BUY", InpVolume,
                                    0.0, 0.0, 0.0,     // sl, tp, entry (۰ = ندارد)
                                    tf, "RobotBridgeEA", "demo buy",
                                    InpMagic, _Digits, InpUseTestEndpoint);
      PrintBridgeOutcome("Send/BUY", r1, InpUseTestEndpoint);

      // --- نمونهٔ ۲: چند حد سود ---
      double tps[3];
      double ask = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
      double pt  = SymbolInfoDouble(_Symbol, SYMBOL_POINT);
      tps[0]=ask+500*pt; tps[1]=ask+1000*pt; tps[2]=ask+1500*pt;
      double sl = ask-500*pt;
      BridgeResult r2 = bridge.SendMultiTP(_Symbol, "BUY", InpVolume, sl, tps,
                                           0.0, tf, "RobotBridgeEA", "demo multi-tp",
                                           InpMagic, _Digits, InpUseTestEndpoint);
      PrintBridgeOutcome("SendMultiTP", r2, InpUseTestEndpoint);

      // --- نمونهٔ ۳: سبکِ سازگار با OrderSend (کمترین تغییر) ---
      MqlTradeRequest req; MqlTradeResult  res;
      ZeroMemory(req);
      req.action = TRADE_ACTION_DEAL;
      req.symbol = _Symbol;
      req.volume = InpVolume;
      req.type   = ORDER_TYPE_BUY;            // 0 = خرید
      req.price  = ask;
      req.sl     = sl;
      req.tp     = tps[0];
      req.magic  = InpMagic;
      req.comment= "demo order_send";

      // قبلاً:  bool ok = OrderSend(req, res);
      bool ok = bridge.OrderSendBridge(req, res, tf, InpUseTestEndpoint);
      PrintFormat("[OrderSendBridge] ok=%s retcode=%d | %s",
                  (ok?"true":"false"), res.retcode, res.comment);
   }

   return(INIT_SUCCEEDED);
}

//+------------------------------------------------------------------+
//| ارسالِ سیگنال — با گاردهای امن (کپی در EAهای واقعی)              |
//+------------------------------------------------------------------+
void RouteSignal(const string dir)
{
   if(InpUseSessionGate && IsFridayCloseOrWeekend(InpFridayCloseHour))
   {
      Print("Session gate: Friday/weekend — signal skipped");
      return;
   }
   if(InpBlockIfInPos && HasManagedPosition(_Symbol, InpMagic))
   {
      Print("Position guard: a managed position already exists");
      return;
   }
   MqlTick q;
   if(!SymbolInfoTick(_Symbol,q) || q.ask<=0.0 || q.bid<=0.0)
   {
      Print("No valid quote; signal skipped");
      return;
   }
   double volume = NormalizeVolumeDown(_Symbol, InpVolume);
   if(volume<=0.0)
   {
      Print("Volume is outside symbol limits");
      return;
   }
   double pt  = SymbolInfoDouble(_Symbol,SYMBOL_POINT);
   double ref = (dir=="BUY" ? q.ask : q.bid);
   double sl  = NormalizePriceToTick(_Symbol, ref + (dir=="BUY"?-1:1)*300*pt);
   double tp  = NormalizePriceToTick(_Symbol, ref + (dir=="BUY"? 1:-1)*600*pt);
   if(!ValidateStops(_Symbol, (dir=="BUY"?ORDER_TYPE_BUY:ORDER_TYPE_SELL), sl, tp))
   {
      Print("Stops violate broker stops/freeze level; signal skipped");
      return;
   }
   string tf = CRobotBridge::TFfromPeriod((ENUM_TIMEFRAMES)_Period);
   BridgeResult r = bridge.Send(_Symbol, dir, volume, sl, tp, 0.0, tf,
                                "RobotBridgeEA", "signal "+dir, InpMagic, _Digits,
                                InpUseTestEndpoint);
   PrintBridgeOutcome("Route/"+dir, r, InpUseTestEndpoint);
   UpdateStatus(dir+" sent; retcode="+IntegerToString(r.retcode));
}

//+------------------------------------------------------------------+
//| صفِ سیگنال برای تایمر (بدونِ WebRequest در مسیرِ تیک)            |
//+------------------------------------------------------------------+
bool     g_pending_signal=false;
string   g_pending_dir="";
datetime g_pending_bar=0;

void QueueSignal(const string dir)
{
   if(g_pending_signal) return;
   g_pending_signal=true;
   g_pending_dir=dir;
   g_pending_bar=iTime(_Symbol,_Period,0);
}

//+------------------------------------------------------------------+
void OnTimer()
{
   // اجرای سیگنالِ صف‌شده (اگر باشد) — سپس Pingِ دوره‌ای
   if(g_pending_signal)
   {
      string dir=g_pending_dir;
      g_pending_signal=false;
      g_pending_dir="";
      RouteSignal(dir);
   }
   if(InpPingOnTimerMs>0 && TimeCurrent()-g_lastPing>=InpPingOnTimerMs/1000)
   {
      g_lastPing=TimeCurrent();
      if(!bridge.Ping())
         UpdateStatus("health check failed");
   }
}

//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
   EventKillTimer();
   ClearStatus();
}

//+------------------------------------------------------------------+
void OnTick()
{
   //---------------------------------------------------------------
   //  الگوی استفاده در ربات‌های واقعیِ شما:
   //    if(MyBuyCondition()) QueueSignal("BUY");
   //  سیگنال در تایمر (بیرون از مسیرِ تیک) ارسال می‌شود تا WebRequestِ
   //  همگام پردازشِ قیمت را بلوکه نکند.
   //---------------------------------------------------------------
}
//+------------------------------------------------------------------+
