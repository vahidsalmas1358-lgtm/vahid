//+------------------------------------------------------------------+
//|                                                  RobotBridge.mqh  |
//|   پُلِ ارسالِ سیگنالِ ربات‌های متاتریدر ۵ به «برنامهٔ تحلیل»       |
//|                                                                  |
//|  به‌جای ارسالِ مستقیمِ سفارش به کارگزار (OrderSend)، سفارش را به   |
//|  برنامه می‌فرستد؛ برنامه آن را با سیگنالِ داخلی و/یا هوش مصنوعی   |
//|  امتیازدهی می‌کند و تنها در صورتِ تأیید، عینِ همان مشخصات را به   |
//|  متاتریدر ارسال می‌کند.                                          |
//|                                                                  |
//|  === پیش‌نیازِ حیاتی: اجازهٔ WebRequest ===                        |
//|  در متاتریدر: Tools ▸ Options ▸ Expert Advisors ▸                |
//|  «Allow WebRequest for listed URL» را تیک بزنید و آدرسِ برنامه   |
//|  را دقیقاً اضافه کنید، مثلاً:  http://127.0.0.1:8000              |
//|  (بدونِ این کار WebRequest خطای 4014 می‌دهد.)                     |
//+------------------------------------------------------------------+
#property copyright "BTC Agent - Robot Signal Bridge"
#property strict

#include <Trade/Trade.mqh>   // برای مدیریتِ پوزیشن (participation/partial/close) — OP5-MQL-MANAGE

//--- کدهای بازگشتی (retcode) که در MqlTradeResult.retcode قرار می‌گیرند
#define BRIDGE_RETCODE_DONE       10009   // = TRADE_RETCODE_DONE : به متاتریدر ارسال شد
#define BRIDGE_RETCODE_ERROR      20000   // خطای شبکه/سرور/اعتبارسنجی
#define BRIDGE_RETCODE_REJECTED   20001   // توسطِ فیلترِ برنامه رد شد
#define BRIDGE_RETCODE_NOT_SENT   20002   // تأیید شد ولی ارسالِ خودکار خاموش/ناموفق بود
#define BRIDGE_RETCODE_TEST_SIMULATED 20004  // درخواستِ test: فقط شبیه‌سازیِ سرور (معاملهٔ واقعی نیست)

//+------------------------------------------------------------------+
//| نتیجهٔ ارسالِ یک سفارش به پُل                                     |
//+------------------------------------------------------------------+
struct BridgeResult
{
   bool     ok;          // آیا درخواست بدونِ خطا پردازش شد؟
   bool     approved;    // آیا فیلترِ برنامه سفارش را تأیید کرد؟
   bool     forwarded;   // آیا واقعاً به متاتریدر فرستاده شد؟
   int      http;        // کدِ وضعیتِ HTTP (یا -1 در خطای WebRequest)
   int      retcode;     // یکی از BRIDGE_RETCODE_*
   string   comment;     // توضیحِ متنی/خطا
   string   raw;         // پاسخِ خامِ JSON (برای عیب‌یابی)
};

//+------------------------------------------------------------------+
//| ===== توابعِ کمکیِ امن و قابلِ تحمل (اصلاحِ OP5-MQL-*) ========== |
//|  این توابع بر پایهٔ اصلاحاتِ ممیزی افزوده شده‌اند:               |
//|   • اعتبارسنجیِ URL/هدر (ضدِ header-injection و HTTPِ بی‌TLS)،   |
//|   • محافظت از NaN/inf در JSON،                                  |
//|   • نرمال‌سازیِ حجم/ریسک و tick/استاپ (SPECS)،                   |
//|   • انتخابِ نوعِ فیلینگِ نماد + ارسالِ کنترل‌شده با requote،      |
//|   • گیتِ جمعه/آخرهفته و سشن به وقتِ سرور،                        |
//|   • مدیریتِ پوزیشنِ netting/hedging-aware.                       |
//+------------------------------------------------------------------+

//--- امنیتِ هدرِ HTTP: CR/LF/NUL در مقدارِ هدر ممنوع است (header injection)
bool HeaderValueSafe(const string value)
{
   return(StringFind(value,"\r")<0 && StringFind(value,"\n")<0 &&
          StringFind(value,"\0")<0);
}

//--- امنیتِ URL: HTTPS همیشه مجاز؛ HTTP فقط برای loopback (بدونِ secret
//--- روی HTTPِ غیرلوکال — خطرِ شنود/بازپخشِ توکن)
bool BaseUrlSafe(const string url, const bool has_secret)
{
   if(url==NULL || url=="") return false;
   bool https=(StringFind(url,"https://")==0);
   bool loop=(StringFind(url,"http://127.0.0.1:")==0 ||
              StringFind(url,"http://localhost:")==0 ||
              StringFind(url,"http://[::1]:")==0 ||
              url=="http://127.0.0.1" || url=="http://localhost" ||
              url=="http://[::1]");
   return(https || (!has_secret && loop));
}

//--- عددِ معتبر برای JSON (NaN/inf را رد می‌کند)
bool IsFiniteNumber(const double v)
{
   return(MathIsValidNumber(v) && v!=DBL_MAX && v!=-DBL_MAX);
}

//--- فرارِ کاملِ رشته برای JSON (شاملِ همهٔ کاراکترهای کنترلی زیرِ 0x20)
string JsonEscapeStrict(const string s)
{
   string out="";
   for(int i=0;i<StringLen(s);i++)
   {
      ushort c=StringGetCharacter(s,i);
      if(c=='\\') out+="\\\\";
      else if(c=='"') out+="\\\"";
      else if(c=='\b') out+="\\b";
      else if(c=='\f') out+="\\f";
      else if(c=='\n') out+="\\n";
      else if(c=='\r') out+="\\r";
      else if(c=='\t') out+="\\t";
      else if(c<0x20) out+=StringFormat("\\u%04X",(int)c);
      else out+=ShortToString(c);
   }
   return out;
}

//--- عددِ JSON؛ برای NaN/inf رشتهٔ خالی برمی‌گرداند (نه «nan»/«inf»)
string JsonNumber(const double v, const int digits)
{
   if(!IsFiniteNumber(v)) return "";
   int d=MathMax(0,MathMin(16,digits));
   return DoubleToString(v,d);
}

//--- چاپِ نتیجه با تفکیکِ صریحِ TEST از LIVE (ضدِ «شبیه‌سازی = معامله»)
void PrintBridgeOutcome(const string title,const BridgeResult &r,const bool test_mode)
{
   if(test_mode && r.forwarded)
   {
      PrintFormat("[%s] TEST ONLY: simulated=true; no live trade was sent | http=%d | %s",
                  title,r.http,r.comment);
      return;
   }
   if(r.forwarded && r.retcode==BRIDGE_RETCODE_DONE)
      PrintFormat("[%s] LIVE forwarded=true | http=%d | %s",title,r.http,r.comment);
   else
      PrintFormat("[%s] NOT FILLED | approved=%s forwarded=%s http=%d retcode=%d | %s",
                  title,(r.approved?"true":"false"),(r.forwarded?"true":"false"),
                  r.http,r.retcode,r.comment);
}

//--- تعدادِ رقم‌های حجمِ نماد (بر اساسِ volume_step)
int VolumeDigits(const string symbol)
{
   double step=SymbolInfoDouble(symbol,SYMBOL_VOLUME_STEP);
   int d=0;
   while(d<8 && MathAbs(step-NormalizeDouble(step,d))>1e-10) d++;
   return d;
}

//--- حجم را به پایین در محدودهٔ نماد نرمال می‌کند (هرگز بالاتر از درخواستِ ریسک)
double NormalizeVolumeDown(const string symbol,const double requested)
{
   double vmin=SymbolInfoDouble(symbol,SYMBOL_VOLUME_MIN);
   double vmax=SymbolInfoDouble(symbol,SYMBOL_VOLUME_MAX);
   double step=SymbolInfoDouble(symbol,SYMBOL_VOLUME_STEP);
   if(vmin<=0.0 || vmax<vmin || step<=0.0 || requested<=0.0) return 0.0;
   double v=MathMin(requested,vmax);
   double units=MathFloor((v+step*1e-9)/step);
   double out=NormalizeDouble(units*step,VolumeDigits(symbol));
   if(out<vmin) return 0.0;
   return MathMin(out,vmax);
}

//--- حجم بر اساسِ درصدِ ریسک از اکوییتی (با OrderCalcProfit/Margin)
double LotByRiskPercent(const string symbol,const ENUM_ORDER_TYPE type,
                        const double risk_percent,const double entry,
                        const double stop_loss)
{
   if(risk_percent<=0.0 || entry<=0.0 || stop_loss<=0.0 || entry==stop_loss)
      return 0.0;
   double equity=AccountInfoDouble(ACCOUNT_EQUITY);
   double risk_money=equity*risk_percent/100.0;
   if(risk_money<=0.0) return 0.0;
   double one_lot_loss=0.0;
   if(!OrderCalcProfit(type,symbol,1.0,entry,stop_loss,one_lot_loss))
      one_lot_loss=0.0;
   one_lot_loss=MathAbs(one_lot_loss);
   if(one_lot_loss<=0.0)
   {
      double tick_value=SymbolInfoDouble(symbol,SYMBOL_TRADE_TICK_VALUE_LOSS);
      if(tick_value<=0.0) tick_value=SymbolInfoDouble(symbol,SYMBOL_TRADE_TICK_VALUE);
      double tick_size=SymbolInfoDouble(symbol,SYMBOL_TRADE_TICK_SIZE);
      if(tick_value<=0.0 || tick_size<=0.0) return 0.0;
      one_lot_loss=MathAbs(entry-stop_loss)/tick_size*tick_value;
   }
   if(one_lot_loss<=0.0) return 0.0;
   double lots=NormalizeVolumeDown(symbol,risk_money/one_lot_loss);
   if(lots<=0.0) return 0.0;   // هرگز به بالا گرد نکن و از بودجهٔ ریسک رد نشو
   double margin=0.0;
   MqlTick tick;
   if(SymbolInfoTick(symbol,tick) &&
      OrderCalcMargin(type,symbol,lots,(type==ORDER_TYPE_BUY?tick.ask:tick.bid),margin) &&
      margin>AccountInfoDouble(ACCOUNT_MARGIN_FREE))
      return 0.0;
   return lots;
}

//--- قیمت را روی شبکهٔ tick نرمال می‌کند (نه فقط digits)
double NormalizePriceToTick(const string symbol,const double price)
{
   double tick=SymbolInfoDouble(symbol,SYMBOL_TRADE_TICK_SIZE);
   double point=SymbolInfoDouble(symbol,SYMBOL_POINT);
   int digits=(int)SymbolInfoInteger(symbol,SYMBOL_DIGITS);
   if(tick<=0.0) tick=point;
   if(tick<=0.0 || price<=0.0) return 0.0;
   return NormalizeDouble(MathRound(price/tick)*tick,digits);
}

//--- اعتبارسنجیِ فاصلهٔ SL/TP نسبت به stops/freeze level بروکر
bool ValidateStops(const string symbol,const ENUM_ORDER_TYPE type,
                   const double sl,const double tp)
{
   MqlTick q;
   if(!SymbolInfoTick(symbol,q)) return false;
   double point=SymbolInfoDouble(symbol,SYMBOL_POINT);
   long stops=(long)SymbolInfoInteger(symbol,SYMBOL_TRADE_STOPS_LEVEL);
   long freeze=(long)SymbolInfoInteger(symbol,SYMBOL_TRADE_FREEZE_LEVEL);
   double min_distance=(double)MathMax(stops,freeze)*point;
   bool buy=(type==ORDER_TYPE_BUY);
   double ref=buy?q.ask:q.bid;
   if(sl>0.0 && (buy ? sl>=ref-min_distance : sl<=ref+min_distance)) return false;
   if(tp>0.0 && (buy ? tp<=ref+min_distance : tp>=ref-min_distance)) return false;
   return true;
}

//--- انتخابِ نوعِ فیلینگِ مجازِ نماد (FOK/IOC/RETURN) — نه enumِ خامِ فلگ‌ها
ENUM_ORDER_TYPE_FILLING SelectFilling(const string symbol)
{
   long flags=SymbolInfoInteger(symbol,SYMBOL_FILLING_MODE);
   ENUM_SYMBOL_TRADE_EXECUTION exec=
      (ENUM_SYMBOL_TRADE_EXECUTION)SymbolInfoInteger(symbol,SYMBOL_TRADE_EXEMODE);
   if((flags & SYMBOL_FILLING_IOC)!=0) return ORDER_FILLING_IOC;
   if((flags & SYMBOL_FILLING_FOK)!=0) return ORDER_FILLING_FOK;
   if(exec!=SYMBOL_TRADE_EXECUTION_MARKET) return ORDER_FILLING_RETURN;
   return ORDER_FILLING_FOK;
}

//--- ارسالِ سفارش با فیلینگِ درست + تلاشِ دوبارهٔ کنترل‌شده روی requote
bool SendChecked(MqlTradeRequest &request,MqlTradeResult &result,
                 const int max_requotes=1)
{
   request.type_filling=SelectFilling(request.symbol);
   int tries=0;
   for(;;)
   {
      ZeroMemory(result);
      ResetLastError();
      if(!OrderSend(request,result))
      {
         if(tries++<max_requotes &&
            (result.retcode==TRADE_RETCODE_REQUOTE ||
             result.retcode==TRADE_RETCODE_PRICE_CHANGED))
         {
            MqlTick q;
            if(!SymbolInfoTick(request.symbol,q)) return false;
            request.price=(request.type==ORDER_TYPE_BUY?q.ask:q.bid);
            continue;
         }
         return false;
      }
      if(result.retcode==TRADE_RETCODE_DONE ||
         result.retcode==TRADE_RETCODE_PLACED ||
         result.retcode==TRADE_RETCODE_DONE_PARTIAL)
         return true;
      if((result.retcode==TRADE_RETCODE_REQUOTE ||
          result.retcode==TRADE_RETCODE_PRICE_CHANGED) && tries++<max_requotes)
         continue;
      return false;
   }
}

//--- گیتِ جمعه/آخرهفته به وقتِ سرورِ معاملاتی (fail-closed اگر ساعت نامعلوم)
bool IsFridayCloseOrWeekend(const int friday_close_hour=20,
                            const int friday_close_minute=0,
                            const bool use_trade_server=true)
{
   datetime now=(use_trade_server?TimeTradeServer():TimeCurrent());
   if(now<=0) now=TimeCurrent();
   if(now<=0) return true;   // ساعت نامعلوم → معامله نکن
   MqlDateTime dt;
   TimeToStruct(now,dt);
   if(dt.day_of_week==0 || dt.day_of_week==6) return true;
   if(dt.day_of_week!=5) return false;
   int cur=dt.hour*60+dt.min;
   int cut=MathMax(0,MathMin(23,friday_close_hour))*60+
           MathMax(0,MathMin(59,friday_close_minute));
   return(cur>=cut);
}

//--- آیا ساعتِ فعلی داخلِ سشنِ مجاز است؟ (با پشتیبانیِ سشنِ شبانه)
bool IsSessionAllowed(const int start_hour,const int start_minute,
                      const int end_hour,const int end_minute)
{
   datetime now=TimeTradeServer();
   if(now<=0) now=TimeCurrent();
   if(now<=0 || IsFridayCloseOrWeekend()) return false;
   MqlDateTime dt; TimeToStruct(now,dt);
   int cur=dt.hour*60+dt.min;
   int a=MathMax(0,MathMin(23,start_hour))*60+MathMax(0,MathMin(59,start_minute));
   int b=MathMax(0,MathMin(23,end_hour))*60+MathMax(0,MathMin(59,end_minute));
   if(a==b) return true;
   return(a<b ? cur>=a && cur<b : cur>=a || cur<b);
}

//--- نگه‌داریِ پوزیشنِ تحتِ مدیریت (netting-aware: در netting کلِ نماد محسوب می‌شود)
bool HasManagedPosition(const string symbol,const long magic)
{
   ENUM_ACCOUNT_MARGIN_MODE mode=
      (ENUM_ACCOUNT_MARGIN_MODE)AccountInfoInteger(ACCOUNT_MARGIN_MODE);
   for(int i=PositionsTotal()-1;i>=0;i--)
   {
      ulong ticket=PositionGetTicket(i);
      if(ticket==0 || PositionGetString(POSITION_SYMBOL)!=symbol) continue;
      long pm=(long)PositionGetInteger(POSITION_MAGIC);
      if(mode==ACCOUNT_MARGIN_MODE_RETAIL_NETTING ||
         mode==ACCOUNT_MARGIN_MODE_EXCHANGE)
         return true;   // در netting جداسازیِ magic ممکن نیست → محتاط باش
      if(pm==magic) return true;
   }
   return false;
}

//--- بستنِ (جزئیِ) پوزیشن‌های تحتِ مدیریت + بررسیِ retcode
bool CloseManagedPositions(const string symbol,const long magic,
                           const double close_fraction,const ulong deviation)
{
   CTrade trade;
   trade.SetExpertMagicNumber(magic);
   trade.SetDeviationInPoints(deviation);
   bool all_ok=true;
   for(int i=PositionsTotal()-1;i>=0;i--)
   {
      ulong ticket=PositionGetTicket(i);
      if(ticket==0 || PositionGetString(POSITION_SYMBOL)!=symbol ||
         (long)PositionGetInteger(POSITION_MAGIC)!=magic) continue;
      double current=PositionGetDouble(POSITION_VOLUME);
      double amount=current;
      if(close_fraction>0.0 && close_fraction<1.0)
      {
         amount=NormalizeVolumeDown(symbol,current*close_fraction);
         double left=NormalizeVolumeDown(symbol,current-amount);
         double vmin=SymbolInfoDouble(symbol,SYMBOL_VOLUME_MIN);
         if(amount<=0.0 || (left>0.0 && left<vmin)) amount=current;
      }
      bool ok=trade.PositionClosePartial(ticket,amount,deviation);
      uint rc=trade.ResultRetcode();
      if(!ok || (rc!=TRADE_RETCODE_DONE && rc!=TRADE_RETCODE_DONE_PARTIAL)) all_ok=false;
   }
   return all_ok;
}

//--- مدیریتِ breakeven/trailing با نرمال‌سازیِ tick و بدونِ عقب‌رفتنِ SL
void ManageBreakEvenAndTrailing(const string symbol,const long magic,
                                const int trigger_points,const int lock_points,
                                const int trail_points)
{
   MqlTick q; if(!SymbolInfoTick(symbol,q)) return;
   double point=SymbolInfoDouble(symbol,SYMBOL_POINT);
   for(int i=PositionsTotal()-1;i>=0;i--)
   {
      ulong ticket=PositionGetTicket(i);
      if(ticket==0 || PositionGetString(POSITION_SYMBOL)!=symbol ||
         (long)PositionGetInteger(POSITION_MAGIC)!=magic) continue;
      bool buy=PositionGetInteger(POSITION_TYPE)==POSITION_TYPE_BUY;
      double open=PositionGetDouble(POSITION_PRICE_OPEN);
      double old_sl=PositionGetDouble(POSITION_SL);
      double px=buy?q.bid:q.ask;
      double profit_points=(buy?px-open:open-px)/point;
      if(profit_points<trigger_points) continue;
      double candidate=buy?open+lock_points*point:open-lock_points*point;
      if(trail_points>0)
      {
         double trail=buy?px-trail_points*point:px+trail_points*point;
         candidate=buy?MathMax(candidate,trail):MathMin(candidate,trail);
      }
      candidate=NormalizePriceToTick(symbol,candidate);
      if(candidate<=0.0) continue;
      if(old_sl>0.0 && ((buy && candidate<=old_sl) || (!buy && candidate>=old_sl))) continue;
      CTrade trade;
      trade.SetExpertMagicNumber(magic);
      trade.PositionModify(ticket,candidate,PositionGetDouble(POSITION_TP));
   }
}

//--- تشخیصِ کندلِ تازه با retry (شروعِ تیک/سینک نبودنِ تایم‌فریم)
bool IsNewBar(const string symbol,const ENUM_TIMEFRAMES tf,datetime &last_bar)
{
   datetime t=iTime(symbol,tf,0);
   if(t<=0) return false;
   if(last_bar==0) { last_bar=t; return false; }
   if(t==last_bar) return false;
   last_bar=t;
   return true;
}

//+------------------------------------------------------------------+
//| کلاسِ کلاینتِ پُل                                                 |
//+------------------------------------------------------------------+
class CRobotBridge
{
private:
   string   m_base_url;      // مثل http://127.0.0.1:8000
   string   m_secret;        // توکنِ امنیتیِ مشترک (اختیاری)
   int      m_timeout;       // مهلتِ درخواست (میلی‌ثانیه)

   //--- ابزارِ JSON --------------------------------------------------
   string   JsonEscape(const string s) const;
   string   NumToStr(const double v, const int digits) const;
   bool     JsonGetBool(const string js, const string key, const bool defv=false) const;
   string   JsonGetStr(const string js, const string key) const;

   //--- ارسالِ HTTP -------------------------------------------------
   bool     Post(const string path, const string body, BridgeResult &out);

public:
            CRobotBridge(void);
   void     Init(const string base_url, const string secret="", const int timeout_ms=10000);

   //--- تبدیلِ نوعِ سفارشِ MT5 به BUY/SELL
   static string DirFromType(const int order_type);
   //--- تبدیلِ دورهٔ نمودار به رشتهٔ تایم‌فریمِ برنامه (15m/1h/4h/1d/1w)
   static string TFfromPeriod(const ENUM_TIMEFRAMES period);

   //--- بررسیِ در دسترس بودنِ برنامه
   bool     Ping(void);

   //--- سبکِ ساده: ارسالِ یک سیگنال/سفارش
   BridgeResult Send(const string symbol,
                     const string direction,    // "BUY" یا "SELL"
                     const double volume,
                     const double sl=0.0,
                     const double tp=0.0,
                     const double entry=0.0,
                     const string tf="",
                     const string robot_id="",
                     const string comment="",
                     const long   magic=0,
                     const int    price_digits=-1,
                     const bool   test=false);

   //--- سبکِ ساده با سه حد سود
   BridgeResult SendMultiTP(const string symbol,
                            const string direction,
                            const double volume,
                            const double sl,
                            const double &tps[],       // آرایهٔ حد سودها
                            const double entry=0.0,
                            const string tf="",
                            const string robot_id="",
                            const string comment="",
                            const long   magic=0,
                            const int    price_digits=-1,
                            const bool   test=false);

   //--- جایگزینِ مستقیمِ OrderSend (کمترین تغییر در EAهای موجود)
   bool     OrderSendBridge(MqlTradeRequest &request,
                            MqlTradeResult &result,
                            const string tf="",
                            const bool   test=false);
};

//+------------------------------------------------------------------+
CRobotBridge::CRobotBridge(void)
{
   m_base_url = "http://127.0.0.1:8000";
   m_secret   = "";
   m_timeout  = 10000;
}

//+------------------------------------------------------------------+
void CRobotBridge::Init(const string base_url, const string secret, const int timeout_ms)
{
   m_base_url = base_url;
   // حذفِ اسلشِ انتهایی
   int n = StringLen(m_base_url);
   while(n>0 && StringGetCharacter(m_base_url, n-1)=='/')
   {
      m_base_url = StringSubstr(m_base_url, 0, n-1);
      n--;
   }
   m_secret  = secret;
   m_timeout = (timeout_ms>0 ? timeout_ms : 10000);
}

//+------------------------------------------------------------------+
//| تبدیلِ ENUM_ORDER_TYPE به BUY/SELL (زوج=خرید، فرد=فروش)          |
//+------------------------------------------------------------------+
string CRobotBridge::DirFromType(const int order_type)
{
   // اصلاحِ OP5-MQL-FIREWALL: فقط خرید/فروشِ بازارِ شناخته‌شده نگاشت می‌شود؛
   // پیش‌تر هر عدد زوج «BUY» و هر فرد «SELL» می‌شد و سفارش‌های pending/close
   // می‌توانستند بی‌صدا به «بازکردنِ معاملهٔ جدید» تبدیل شوند.
   if(order_type==ORDER_TYPE_BUY)  return "BUY";
   if(order_type==ORDER_TYPE_SELL) return "SELL";
   return "";
}

//+------------------------------------------------------------------+
//| تبدیلِ دوره به رشتهٔ تایم‌فریمِ موردِ پذیرشِ برنامه               |
//+------------------------------------------------------------------+
string CRobotBridge::TFfromPeriod(const ENUM_TIMEFRAMES period)
{
   switch(period)
   {
      case PERIOD_M1:  return "1m";
      case PERIOD_M5:  return "5m";
      case PERIOD_M10: return "10m";
      case PERIOD_M15: return "15m";
      case PERIOD_M30: return "30m";
      case PERIOD_H1:  return "1h";
      case PERIOD_H2:  return "2h";
      case PERIOD_H4:  return "4h";
      case PERIOD_D1:  return "1d";
      case PERIOD_W1:  return "1w";
      default:         return "1h";   // پیش‌فرضِ امن (M2/M3/M6/M12/H3/H6/H8/MN1)
   }
}

//+------------------------------------------------------------------+
//| فرارِ کاراکترهای خاصِ رشته برای JSON                              |
//+------------------------------------------------------------------+
string CRobotBridge::JsonEscape(const string s) const
{
   string r = s;
   StringReplace(r, "\\", "\\\\");
   StringReplace(r, "\"", "\\\"");
   StringReplace(r, "\n", "\\n");
   StringReplace(r, "\r", "\\r");
   StringReplace(r, "\t", "\\t");
   return r;
}

//+------------------------------------------------------------------+
//| عدد به رشتهٔ JSON (با حذفِ صفرهای اضافی)                          |
//+------------------------------------------------------------------+
string CRobotBridge::NumToStr(const double v, const int digits) const
{
   int d = (digits>=0 ? digits : 8);
   string s = DoubleToString(v, d);
   // حذفِ صفرهای انتهاییِ اعشار برای تمیزی (اختیاری)
   if(StringFind(s, ".")>=0)
   {
      int len = StringLen(s);
      while(len>0 && StringGetCharacter(s, len-1)=='0'){ s=StringSubstr(s,0,len-1); len--; }
      if(len>0 && StringGetCharacter(s, len-1)=='.'){ s=StringSubstr(s,0,len-1); }
   }
   return s;
}

//+------------------------------------------------------------------+
//| خواندنِ مقدارِ بولین از JSON (اولین رخداد = سطحِ بالا)            |
//+------------------------------------------------------------------+
bool CRobotBridge::JsonGetBool(const string js, const string key, const bool defv) const
{
   int p = StringFind(js, "\""+key+"\"");
   if(p<0) return defv;
   int c = StringFind(js, ":", p+StringLen(key)+2);
   if(c<0) return defv;
   string rest = StringSubstr(js, c+1, 8);
   StringTrimLeft(rest);
   if(StringFind(rest, "true")==0)  return true;
   if(StringFind(rest, "false")==0) return false;
   return defv;
}

//+------------------------------------------------------------------+
//| خواندنِ مقدارِ رشته‌ای از JSON (ساده، برای فیلدِ error)           |
//+------------------------------------------------------------------+
string CRobotBridge::JsonGetStr(const string js, const string key) const
{
   int p = StringFind(js, "\""+key+"\"");
   if(p<0) return "";
   int c = StringFind(js, ":", p+StringLen(key)+2);
   if(c<0) return "";
   int q1 = StringFind(js, "\"", c+1);
   if(q1<0) return "";
   int q2 = StringFind(js, "\"", q1+1);
   if(q2<0) return "";
   return StringSubstr(js, q1+1, q2-q1-1);
}

//+------------------------------------------------------------------+
//| ارسالِ POST به برنامه و پُر کردنِ BridgeResult                    |
//+------------------------------------------------------------------+
bool CRobotBridge::Post(const string path, const string body, BridgeResult &out)
{
   out.ok=false; out.approved=false; out.forwarded=false;
   out.http=-1; out.retcode=BRIDGE_RETCODE_ERROR; out.comment=""; out.raw="";

   // --- امنیت (OP5-MQL-SEC): URL و secret قبل از هر ارسالی اعتبارسنجی می‌شوند
   if(!BaseUrlSafe(m_base_url,StringLen(m_secret)>0) || !HeaderValueSafe(m_secret))
   {
      out.comment="Unsafe URL or secret header";
      Print("[RobotBridge] ",out.comment);
      return false;
   }

   string url = m_base_url + path;
   string headers = "Content-Type: application/json\r\n";
   if(StringLen(m_secret)>0)
      headers += "X-Robot-Secret: " + m_secret + "\r\n";

   char data[];
   int len = StringToCharArray(body, data, 0, WHOLE_ARRAY, CP_UTF8);
   if(len>0 && data[len-1]==0) ArrayResize(data, len-1);

   char     result[];
   string   result_headers;
   ResetLastError();
   int status = WebRequest("POST", url, headers,
                           MathMax(100,MathMin(m_timeout,30000)),
                           data, result, result_headers);

   if(status==-1)
   {
      int err = GetLastError();
      out.http=-1;
      out.retcode=BRIDGE_RETCODE_ERROR;
      if(err==4014)
         out.comment = "خطا 4014: آدرسِ «"+url+"» در فهرستِ WebRequestِ متاتریدر مجاز نیست. "
                       "از Tools ▸ Options ▸ Expert Advisors آن را اضافه کنید.";
      else
         out.comment = "WebRequest ناموفق (خطا "+IntegerToString(err)+"). "
                       "اتصال/آدرس/فعال بودنِ برنامه را بررسی کنید.";
      Print("[RobotBridge] ", out.comment);
      return false;
   }

   // --- OP5-MQL-HTTP: هر پاسخِ غیرِ 2xx خطاست (قبلاً فقط بدنه parse می‌شد و
   // --- یک صفحهٔ خطای HTML می‌توانست «رشتهٔ خالی» و نتیجهٔ مبهم بدهد)
   string resp = CharArrayToString(result, 0, WHOLE_ARRAY, CP_UTF8);
   if(status<200 || status>=300)
   {
      out.http=status;
      out.raw=resp;
      out.retcode=BRIDGE_RETCODE_ERROR;
      out.comment="HTTP error "+IntegerToString(status);
      return false;
   }

   out.http = status;
   out.raw  = resp;
   out.ok        = JsonGetBool(resp, "ok", false);
   out.approved  = JsonGetBool(resp, "approved", false);
   out.forwarded = JsonGetBool(resp, "forwarded", false);

   if(!out.ok)
   {
      out.retcode = BRIDGE_RETCODE_ERROR;
      out.comment = JsonGetStr(resp, "error");
      if(StringLen(out.comment)==0) out.comment = "خطای نامشخص (HTTP "+IntegerToString(status)+")";
      return false;
   }

   // --- OP5-MQL-TEST: endpointِ آزمون فقط «شبیه‌سازی» است؛ نباید موفقیتِ معامله
   // --- گزارش شود. کدِ مخصوصِ شبیه‌سازی برگردانده می‌شود تا caller هوشیار باشد.
   if(StringFind(path, "/api/robot/test") >= 0 && out.forwarded)
   {
      out.retcode = BRIDGE_RETCODE_TEST_SIMULATED;
      out.comment = "TEST ONLY: server simulation; no live MT5 trade";
   }
   else if(out.forwarded)
   {
      out.retcode = BRIDGE_RETCODE_DONE;
      out.comment = "پاسخِ فوروارد دریافت شد";
   }
   else if(out.approved)
   {
      out.retcode = BRIDGE_RETCODE_NOT_SENT;
      out.comment = "تأیید شد ولی به متاتریدر ارسال نشد (ارسالِ خودکار خاموش یا ارسال ناموفق)";
   }
   else
   {
      out.retcode = BRIDGE_RETCODE_REJECTED;
      out.comment = "توسطِ فیلترِ برنامه رد شد";
   }
   return true;
}

//+------------------------------------------------------------------+
//| بررسیِ در دسترس بودنِ برنامه (GET /health)                        |
//+------------------------------------------------------------------+
bool CRobotBridge::Ping(void)
{
   // OP5-MQL-PING: خطا/کد/آدرس گزارش می‌شود (قبلاً فقط bool بدونِ هیچ توضیحی)
   char data[]; char result[]; string response_headers;
   ResetLastError();
   int status=WebRequest("GET",m_base_url+"/health",
                         "Accept: application/json\r\n",
                         MathMax(100,MathMin(m_timeout,30000)),
                         data,result,response_headers);
   if(status!=200)
   {
      PrintFormat("[RobotBridge] health failed status=%d error=%d url=%s",
                  status,GetLastError(),m_base_url+"/health");
      return false;
   }
   return true;
}

//+------------------------------------------------------------------+
//| سبکِ ساده: ارسالِ یک سیگنال                                      |
//+------------------------------------------------------------------+
BridgeResult CRobotBridge::Send(const string symbol, const string direction,
                                const double volume, const double sl, const double tp,
                                const double entry, const string tf,
                                const string robot_id, const string comment,
                                const long magic, const int price_digits, const bool test)
{
   BridgeResult res;
   int pd = (price_digits>=0 ? price_digits
             : (int)SymbolInfoInteger(symbol, SYMBOL_DIGITS));
   if(pd<=0) pd = 5;

   // OP5-MQL-JSON: فرارِ سخت‌گیرانه (کنترل‌کاراکترها) + عددِ محدود (بدونِ NaN/inf)
   if(!IsFiniteNumber(volume) || volume<=0.0)
   {
      res.ok=false; res.retcode=BRIDGE_RETCODE_ERROR; res.comment="Invalid volume";
      return res;
   }
   string j = "{";
   j += "\"platform\":\"mql5\",";     // نوعِ سکو برای تفکیک در لاگِ سرور
   j += "\"symbol\":\""    + JsonEscapeStrict(symbol) + "\",";
   j += "\"direction\":\"" + JsonEscapeStrict(direction) + "\",";
   j += "\"volume\":"      + JsonNumber(volume, 2);
   if(sl>0.0 && IsFiniteNumber(sl))       j += ",\"sl\":"    + JsonNumber(sl, pd);
   if(tp>0.0 && IsFiniteNumber(tp))       j += ",\"tp\":"    + JsonNumber(tp, pd);
   if(entry>0.0 && IsFiniteNumber(entry)) j += ",\"entry\":" + JsonNumber(entry, pd);
   if(StringLen(tf)>0)       j += ",\"tf\":\""       + JsonEscapeStrict(tf) + "\"";
   if(StringLen(robot_id)>0) j += ",\"robot_id\":\"" + JsonEscapeStrict(robot_id) + "\"";
   if(StringLen(comment)>0)  j += ",\"comment\":\""  + JsonEscapeStrict(comment) + "\"";
   if(magic!=0)              j += ",\"magic\":"      + IntegerToString(magic);
   j += "}";

   Post(test ? "/api/robot/test" : "/api/robot/order", j, res);
   return res;
}

//+------------------------------------------------------------------+
//| سبکِ ساده با چند حد سود                                          |
//+------------------------------------------------------------------+
BridgeResult CRobotBridge::SendMultiTP(const string symbol, const string direction,
                                       const double volume, const double sl,
                                       const double &tps[], const double entry,
                                       const string tf, const string robot_id,
                                       const string comment, const long magic,
                                       const int price_digits, const bool test)
{
   BridgeResult res;
   int pd = (price_digits>=0 ? price_digits
             : (int)SymbolInfoInteger(symbol, SYMBOL_DIGITS));
   if(pd<=0) pd = 5;

   if(!IsFiniteNumber(volume) || volume<=0.0)
   {
      res.ok=false; res.retcode=BRIDGE_RETCODE_ERROR; res.comment="Invalid volume";
      return res;
   }
   string j = "{";
   j += "\"platform\":\"mql5\",";     // نوعِ سکو برای تفکیک در لاگِ سرور
   j += "\"symbol\":\""    + JsonEscapeStrict(symbol) + "\",";
   j += "\"direction\":\"" + JsonEscapeStrict(direction) + "\",";
   j += "\"volume\":"      + JsonNumber(volume, 2);
   if(sl>0.0 && IsFiniteNumber(sl)) j += ",\"sl\":" + JsonNumber(sl, pd);

   int cnt = ArraySize(tps);
   if(cnt>0)
   {
      j += ",\"take_profits\":[";
      int written=0;
      for(int i=0;i<cnt;i++)
      {
         if(!IsFiniteNumber(tps[i]) || tps[i]<=0.0) continue;   // صفر/NaN به آرایه نمی‌رود
         if(written>0) j += ",";
         j += JsonNumber(tps[i], pd);
         written++;
      }
      j += "]";
   }
   if(entry>0.0 && IsFiniteNumber(entry)) j += ",\"entry\":" + JsonNumber(entry, pd);
   if(StringLen(tf)>0)       j += ",\"tf\":\""       + JsonEscapeStrict(tf) + "\"";
   if(StringLen(robot_id)>0) j += ",\"robot_id\":\"" + JsonEscapeStrict(robot_id) + "\"";
   if(StringLen(comment)>0)  j += ",\"comment\":\""  + JsonEscapeStrict(comment) + "\"";
   if(magic!=0)              j += ",\"magic\":"      + IntegerToString(magic);
   j += "}";

   Post(test ? "/api/robot/test" : "/api/robot/order", j, res);
   return res;
}

//+------------------------------------------------------------------+
//| جایگزینِ مستقیمِ OrderSend                                        |
//|  در EAِ خود، «OrderSend(req,res)» را با                          |
//|  «bridge.OrderSendBridge(req,res)» عوض کنید.                     |
//|  خروجی: true اگر واقعاً به متاتریدر ارسال شده باشد؛              |
//|  result.retcode == 10009 (TRADE_RETCODE_DONE) در حالتِ موفق.     |
//+------------------------------------------------------------------+
bool CRobotBridge::OrderSendBridge(MqlTradeRequest &request, MqlTradeResult &result,
                                   const string tf, const bool test)
{
   ZeroMemory(result);
   result.retcode = TRADE_RETCODE_INVALID;

   // --- OP5-MQL-FIREWALL — «فقط بازارِ جدیدِ BUY/SELL» ---
   // پل فقط یک «بازکردنِ بازارِ تازه» را می‌فهمد؛ close/SLTP/pending هرگز نباید
   // بی‌صدا به معاملهٔ جدید تبدیل شوند (بدترین نوعِ تغییرِ معنای سفارش).
   if(request.action != TRADE_ACTION_DEAL ||
      (request.type != ORDER_TYPE_BUY && request.type != ORDER_TYPE_SELL) ||
      request.position != 0 || request.order != 0 || request.position_by != 0 ||
      request.stoplimit != 0.0 || request.type_time != ORDER_TIME_GTC ||
      request.expiration != 0)
   {
      result.comment = "RobotBridge supports only new market BUY/SELL orders; "
                       "close, SLTP and pending orders must use native OrderSend";
      Print("[RobotBridge] ", result.comment);
      return false;
   }
   if(request.symbol == NULL || request.symbol == "" || request.volume <= 0.0)
   {
      result.comment = "Invalid symbol or volume";
      Print("[RobotBridge] ", result.comment);
      return false;
   }

   string dir = DirFromType((int)request.type);
   if(dir == "")
   {
      result.comment = "Unsupported order type";
      return false;
   }

   BridgeResult br = Send(request.symbol, dir, request.volume,
                          request.sl, request.tp, request.price,
                          tf, IntegerToString(request.magic),
                          request.comment, (long)request.magic, -1, test);

   result.retcode = (uint)br.retcode;   // 10009 فقط در موفقیتِ واقعیِ فوروارد
   result.comment = br.comment;
   result.volume  = request.volume;
   result.price   = request.price;
   // صرفاً forwarded کافی نیست: در حالتِ test، کدِ شبیه‌سازی برگردانده می‌شود
   // و این تابع false می‌ماند تا caller آن را «موفقیتِ معامله» تلقی نکند.
   return (br.forwarded && br.retcode == BRIDGE_RETCODE_DONE);
}
//+------------------------------------------------------------------+
