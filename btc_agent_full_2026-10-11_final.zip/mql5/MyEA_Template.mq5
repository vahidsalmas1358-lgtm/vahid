//+------------------------------------------------------------------+
//|                                              MyEA_Template.mq5    |
//|   قالبِ آمادهٔ «اکسپرتِ خودِ شما» برای ارسالِ سیگنال به برنامه     |
//|                                                                  |
//|   شما فقط دو تابعِ زیر را با منطقِ خودتان پر می‌کنید:             |
//|        MyBuySignal()  → true اگر الان باید بخرید                 |
//|        MySellSignal() → true اگر الان باید بفروشید              |
//|   بقیهٔ کار (ساختِ سفارش، ارسال به برنامه، خواندنِ پاسخ) آماده است.|
//|                                                                  |
//|   ★ پیش‌نیازِ حیاتی: Tools ▸ Options ▸ Expert Advisors ▸        |
//|     «Allow WebRequest for listed URL» را تیک بزنید و آدرسِ       |
//|     برنامه را اضافه کنید (مثلاً http://127.0.0.1:8000).          |
//|   ★ دکمهٔ «Algo Trading» روشن باشد. WebRequest در تسترِ استراتژی  |
//|     کار نمی‌کند؛ روی چارتِ زنده اجرا کنید.                        |
//+------------------------------------------------------------------+
#property copyright "My EA - sends signals to BTC Agent"
#property version   "1.20"
#property strict

//  از کتابخانهٔ آمادهٔ همین پروژه استفاده می‌کنیم تا کدِ شبکه ننویسید.
//  RobotBridge.mqh را در پوشهٔ  MQL5\Include\  بگذارید (یا کنارِ همین EA و
//  آنگاه به‌جای < > از "RobotBridge.mqh" استفاده کنید).
#include <RobotBridge.mqh>

//==================================================================//
//                         ۱) ورودی‌ها                              //
//==================================================================//
input string InpBridgeURL   = "http://127.0.0.1:8000"; // آدرسِ برنامه
input string InpSecret      = "";                       // توکنِ مشترک (اگر تنظیم کرده‌اید)
input int    InpTimeoutMs   = 10000;                    // مهلتِ درخواست
input double InpVolume      = 0.10;                     // حجم (لات)
input long   InpMagic       = 555001;                   // شناسهٔ ربات
input int    InpSLPips      = 300;                      // فاصلهٔ استاپ (پیپ) — ۰ = بدونِ استاپ
input int    InpTP1Pips     = 300;                      // TP1 (پیپ)
input int    InpTP2Pips     = 600;                      // TP2 (پیپ)
input int    InpTP3Pips     = 900;                      // TP3 (پیپ)
input bool   InpUseMultiTP  = true;                     // سه حد سود بفرست؟ (وگرنه فقط TP1)
input bool   InpOnePerBar   = true;                     // فقط یک سیگنال در هر کندل
input bool   InpUseTestEndpoint = true;                 // true = فقط آزمایش (بدونِ معاملهٔ واقعی)
input bool   InpUseSessionGate = false;                 // گیتِ جمعه/آخرهفته فعال باشد؟
input int    InpFridayCloseHour= 20;                    // ساعتِ بستنِ جمعه (وقتِ سرور)
input int    InpPingEverySec   = 60;                    // Pingِ دوره‌ای در تایمر (ثانیه؛ ۰=خاموش)

//==================================================================//
//                     ۲) شیءِ پُل و متغیرها                         //
//==================================================================//
CRobotBridge bridge;
datetime     g_lastBar = 0;
bool         g_pending_signal = false;
string       g_pending_dir    = "";
datetime     g_lastPing       = 0;

//==================================================================//
//         ۳) ★★★ منطقِ استراتژیِ شما اینجاست ★★★                   //
//   فقط این دو تابع را با شرط‌های خودتان پر کنید. true یعنی سیگنال. //
//==================================================================//
bool MyBuySignal()
{
   //  ── نمونه (شبه‌کد) — حذف و منطقِ خودتان را بنویسید: ──────────────
   //   double ma_fast[], ma_slow[];  // مقادیرِ اندیکاتورِ خودتان
   //   ...
   //   return (ma_fast[1] > ma_slow[1] && ma_fast[2] <= ma_slow[2]); // تقاطعِ صعودی
   //  ────────────────────────────────────────────────────────────────
   return false;   // پیش‌فرض: بدونِ سیگنالِ خرید. (این را عوض کنید.)
}

bool MySellSignal()
{
   //  نمونه:
   //   return (ma_fast[1] < ma_slow[1] && ma_fast[2] >= ma_slow[2]); // تقاطعِ نزولی
   return false;   // پیش‌فرض: بدونِ سیگنالِ فروش. (این را عوض کنید.)
}

//==================================================================//
//             ۴) موتورِ آماده — نیازی به تغییر نیست               //
//==================================================================//
double PipSize()
{
   int digits = (int)SymbolInfoInteger(_Symbol, SYMBOL_DIGITS);
   double point = SymbolInfoDouble(_Symbol, SYMBOL_POINT);
   return((digits==3 || digits==5) ? point*10.0 : point);
}

//  یک سیگنال را می‌سازد و از طریقِ پُل به برنامه می‌فرستد
//  OP5-MQL-ROUTE: نسخهٔ اعتبارسنجی‌شده — quote/tick، حجم، حد ضرر/سود و گیتِ جمعه
void RouteSignal(const string dir)   // dir = "BUY" یا "SELL"
{
   if(InpUseSessionGate && IsFridayCloseOrWeekend(InpFridayCloseHour))
   {
      Print("Session gate: Friday/weekend — signal skipped");
      return;
   }
   MqlTick q;
   if(!SymbolInfoTick(_Symbol,q) || q.ask<=0.0 || q.bid<=0.0)
   {
      Print("No valid quote; signal skipped");
      return;
   }
   if(InpVolume<=0.0 || InpSLPips<0 || InpTP1Pips<0 || InpTP2Pips<0 || InpTP3Pips<0)
   {
      Print("Invalid volume/SL/TP inputs");
      return;
   }
   string tf = CRobotBridge::TFfromPeriod((ENUM_TIMEFRAMES)_Period);
   int    dg  = (int)SymbolInfoInteger(_Symbol, SYMBOL_DIGITS);
   double point=SymbolInfoDouble(_Symbol,SYMBOL_POINT);
   double pip = ((dg==3 || dg==5) ? point*10.0 : point);
   double ref = (dir=="BUY" ? q.ask : q.bid);
   double sl  = 0.0;
   if(InpSLPips>0)
      sl = NormalizePriceToTick(_Symbol, ref + (dir=="BUY"? -1 : 1)*InpSLPips*pip);

   double tps[3];
   int    n = 0;
   int    distances[3] = {InpTP1Pips, InpTP2Pips, InpTP3Pips};
   double tick = SymbolInfoDouble(_Symbol,SYMBOL_TRADE_TICK_SIZE);
   double unit = (tick>0.0 ? tick : point);
   for(int i=0;i<3;i++)
   {
      if(distances[i]<=0) continue;
      double tp = NormalizePriceToTick(_Symbol, ref + (dir=="BUY"?1:-1)*distances[i]*pip);
      if(tp<=0.0 || (dir=="BUY" && tp<=ref) || (dir=="SELL" && tp>=ref)) continue;
      if(n>0 && MathAbs(tp-tps[n-1]) < unit*0.5) continue;   // حذفِ TPهای تکراری
      tps[n++]=tp;
   }
   if(n==0){ Print("No valid TP; signal skipped"); return; }

   double volume = NormalizeVolumeDown(_Symbol, InpVolume);
   if(volume<=0.0){ Print("Volume is outside symbol limits"); return; }
   if(!ValidateStops(_Symbol,(dir=="BUY"?ORDER_TYPE_BUY:ORDER_TYPE_SELL),sl,tps[0]))
   {
      Print("Stops violate broker stops/freeze level; signal skipped");
      return;
   }

   BridgeResult r;
   if(InpUseMultiTP)
      r = bridge.SendMultiTP(_Symbol, dir, volume, sl, tps, 0.0, tf,
                             "MyEA-"+IntegerToString(InpMagic), "my signal "+dir,
                             InpMagic, dg, InpUseTestEndpoint);
   else
      r = bridge.Send(_Symbol, dir, volume, sl, tps[0], 0.0, tf,
                      "MyEA-"+IntegerToString(InpMagic), "my signal "+dir,
                      InpMagic, dg, InpUseTestEndpoint);

   PrintBridgeOutcome("MyEA/"+dir, r, InpUseTestEndpoint);
   if(InpUseTestEndpoint && r.forwarded)
      Print("   ➜ TEST ONLY: شبیه‌سازیِ سرور — معاملهٔ واقعی ارسال نشد.");
   else if(r.retcode==BRIDGE_RETCODE_DONE)
      Print("   ➜ پس از تأییدِ برنامه به متاتریدر ارسال شد.");
   else if(r.retcode==BRIDGE_RETCODE_REJECTED)
      Print("   ⛔ برنامه سیگنال را رد کرد.");
   UpdateStatus(dir+" retcode="+IntegerToString(r.retcode));
}

//--- صفِ سیگنال: WebRequestِ همگام نباید در مسیرِ تیک اجرا شود
void QueueSignal(const string dir)
{
   if(g_pending_signal) return;
   g_pending_signal=true;
   g_pending_dir=dir;
}

//--- اعتبارسنجیِ ورودی‌ها (OP5-MQL-20)
bool ValidateInputs()
{
   if(InpBridgeURL==NULL || InpBridgeURL=="") return false;
   if(!BaseUrlSafe(InpBridgeURL, StringLen(InpSecret)>0)) return false;
   if(InpTimeoutMs<100 || InpTimeoutMs>30000) return false;
   if(InpVolume<=0.0 || NormalizeVolumeDown(_Symbol,InpVolume)<=0.0) return false;
   if(InpSLPips<0 || InpTP1Pips<0 || InpTP2Pips<0 || InpTP3Pips<0) return false;
   if(InpMagic<=0) return false;
   if(InpFridayCloseHour<0 || InpFridayCloseHour>23) return false;
   return true;
}

//--- وضعیت روی چارت (observability — OP5-MQL-24)
void UpdateStatus(const string text)
{
   Comment("MyEA Template\n", text,
           "\nmode=", (InpUseTestEndpoint?"TEST":"LIVE"),
           " url=", InpBridgeURL,
           " magic=", IntegerToString(InpMagic));
}
void ClearStatus()
{
   Comment("");
   ObjectDelete(0, "MyEAStatus");
}

//==================================================================//
//                       ۵) رویدادهای EA                            //
//==================================================================//
int OnInit()
{
   if(!ValidateInputs())
   {
      Print("⛔ Invalid EA inputs");
      return(INIT_PARAMETERS_INCORRECT);
   }
   // OP5-MQL-TIMER: ارسال در OnTimer انجام می‌شود تا WebRequestِ همگام تیک‌ها را قفل نکند
   if(!EventSetTimer(1))
   {
      PrintFormat("EventSetTimer failed: %d", GetLastError());
      return(INIT_FAILED);
   }
   bridge.Init(InpBridgeURL, InpSecret, InpTimeoutMs);
   PrintFormat("MyEA آماده شد | نماد=%s حجم=%.2f مجیک=%d حالتِ آزمایش=%s",
               _Symbol, InpVolume, (int)InpMagic, (InpUseTestEndpoint?"true":"false"));
   UpdateStatus("init");
   return(INIT_SUCCEEDED);
}

void OnDeinit(const int reason)
{
   EventKillTimer();
   ClearStatus();
}

void OnTimer()
{
   if(g_pending_signal)
   {
      string dir = g_pending_dir;
      g_pending_signal = false;
      g_pending_dir = "";
      RouteSignal(dir);
   }
   if(InpPingEverySec>0 && TimeCurrent()-g_lastPing >= InpPingEverySec)
   {
      g_lastPing = TimeCurrent();
      if(!bridge.Ping())
         UpdateStatus("health check failed");
   }
}

void OnTick()
{
   // فقط روی کندلِ جدید تصمیم بگیر (اختیاری ولی توصیه‌شده) — OP5-MQL-25: IsNewBar
   if(!IsNewBar(_Symbol, (ENUM_TIMEFRAMES)_Period, g_lastBar))
   {
      if(InpOnePerBar) return;
   }

   // ← منطقِ شما فراخوانی می‌شود:
   if(MyBuySignal())       QueueSignal("BUY");
   else if(MySellSignal()) QueueSignal("SELL");
}
//+------------------------------------------------------------------+
