"""فیلتر اخبار / تقویم اقتصادی (منبع رایگان و بدون کلید: Forex Factory).

این ماژول تقویم هفتگی رویدادهای اقتصادی را می‌گیرد و امکان «فیلتر اخبار» را می‌دهد:
یعنی در بازه‌ی نزدیک به رویدادهای پرتأثیر (مثل FOMC، CPI، NFP) از باز کردن معامله
جلوگیری شود تا از نوسان شدید و اسپردِ بالا دوری کنیم.

منبع: https://nfs.faireconomy.media/ff_calendar_thisweek.json  (رایگان، بدون API key)
فیلدها: title, country (کد ارز مثل USD/EUR), date (ISO با آفست), impact (High/Medium/Low/Holiday), forecast, previous
"""
from __future__ import annotations

import os
import json
import time
import threading
from datetime import datetime, timezone

import requests

CAL_URL = "https://nfs.faireconomy.media/ff_calendar_thisweek.json"
_HEADERS = {"User-Agent": "Mozilla/5.0 (MultiMarketAgent NewsFilter)"}
_CACHE_FILE = os.path.join(os.path.dirname(__file__), "news_cache.json")

_cache = {"data": None, "ts": 0, "error": None}
_lock = threading.Lock()
_TTL = 1800  # ۳۰ دقیقه کش


def _load_disk():
    """بارگذاری کش از دیسک (برای مقاومت در برابر ری‌استارت و محدودیت نرخ 429)."""
    if _cache["data"] is not None:
        return
    try:
        if os.path.exists(_CACHE_FILE):
            with open(_CACHE_FILE, encoding="utf-8") as f:
                d = json.load(f)
            _cache.update(data=d.get("events"), ts=d.get("ts", 0))
    except Exception:  # noqa
        pass


def _save_disk(events):
    # OP5-CORE-10: نوشتنِ اتمیک (temp+fsync+os.replace) تا کرش/قطعی وسطِ نوشتن،
    # فایلِ کش را خراب نکند.
    try:
        import jsonutil
        jsonutil.atomic_write_json(_CACHE_FILE, {"events": events, "ts": time.time()},
                                   indent=None)
    except Exception:  # noqa
        pass

IMPACT_RANK = {"holiday": 0, "low": 1, "medium": 2, "high": 3}

# ───────────────────────── تقویمِ خودِ متاتریدر ۵ (منبعِ ترجیحی) ─────────────────────────
# کتابخانهٔ پایتونِ MetaTrader5 تابعِ تقویم ندارد؛ توابعِ تقویم (CalendarValueHistory و…)
# فقط در MQL5 داخلِ خودِ ترمینال هستند. پس یک سرویسِ MQL5 (CalendarExport.mq5) تقویم را
# در یک فایلِ JSON در پوشهٔ Common\Files می‌ریزد و اینجا آن را می‌خوانیم و به منبعِ اصلی
# تبدیل می‌کنیم. اگر فایل نبود/کهنه بود، به منابعِ رایگان (Forex Factory/TradingView) برمی‌گردیم.
_MT5_CAL_MAX_AGE = 3 * 3600  # فایلِ قدیمی‌تر از ۳ ساعت «کهنه» تلقی می‌شود (ولی باز هم استفاده می‌شود)


def _mt5_calendar_candidates():
    """مسیرهای محتملِ فایلِ تقویمِ متاتریدر را برمی‌گرداند (به ترتیبِ اولویت)."""
    cands = []
    env = os.environ.get("MT5_CALENDAR_FILE")
    if env:
        cands.append(env)
    appdata = os.environ.get("APPDATA")
    if appdata:  # مسیرِ استانداردِ Common\Files روی ویندوز
        cands.append(os.path.join(appdata, "MetaQuotes", "Terminal",
                                  "Common", "Files", "mt5_calendar.json"))
    # نسخهٔ محلی (کپیِ دستی یا برای تست)
    cands.append(os.path.join(os.path.dirname(__file__), "mt5_calendar.json"))
    return cands


def _mt5_calendar_path():
    for p in _mt5_calendar_candidates():
        try:
            if p and os.path.exists(p):
                return p
        except Exception:  # noqa
            pass
    return None


def _fetch_mt5_calendar():
    """تقویم را از فایلِ نوشته‌شده توسطِ سرویسِ MQL5 می‌خواند.

    خروجی: {events, generated, stale, path} یا None اگر فایلی نبود/خراب بود.
    فیلدِ داخلیِ «country» همان کدِ ارز است (USD/EUR/…) تا با بقیهٔ کد سازگار بماند.
    """
    path = _mt5_calendar_path()
    if not path:
        return None
    try:
        with open(path, encoding="utf-8-sig") as f:
            d = json.load(f)
    except Exception:  # noqa
        return None
    raw = d.get("events") or []
    events = []
    for e in raw:
        try:
            ts = e.get("ts")
            _meta = {}
            if ts is None:
                dt = _parse_dt(e.get("date", ""), _meta)
                ts = dt.timestamp() if dt else None
            if ts is None:
                continue
            imp = (e.get("impact") or "").strip()
            rank = e.get("impact_rank")
            if rank is None:
                rank = IMPACT_RANK.get(imp.lower(), 0)
            ccy = (e.get("currency") or e.get("country") or "").upper()
            events.append({
                "title": e.get("title", "") or "",
                "country": ccy,
                "impact": imp or {3: "High", 2: "Medium", 1: "Low", 0: "Holiday"}.get(rank, ""),
                "impact_rank": int(rank),
                "forecast": e.get("forecast", "") or "",
                "previous": e.get("previous", "") or "",
                "actual": e.get("actual", "") or "",
                "date": e.get("date") or datetime.fromtimestamp(ts, timezone.utc).isoformat(),
                "ts": float(ts),
            })
        except Exception:  # noqa
            continue
    if not events:
        return None
    events.sort(key=lambda x: x["ts"])
    # تازگیِ فایل: از فیلدِ generated_ts یا زمانِ آخرین تغییرِ فایل
    gen = d.get("generated_ts")
    if gen is None:
        try:
            gen = os.path.getmtime(path)
        except Exception:  # noqa
            gen = None
    stale = bool(gen is not None and (time.time() - float(gen)) > _MT5_CAL_MAX_AGE)
    return {"events": events, "generated": gen, "stale": stale, "path": path}

# نگاشت نماد داخلی → ارزهای مرتبط (کدهای کشور در تقویم)
SYMBOL_CCY = {
    "EURUSD": ["EUR", "USD"], "GBPUSD": ["GBP", "USD"], "USDJPY": ["USD", "JPY"],
    "XAU": ["USD"], "XAG": ["USD"], "HG": ["USD"], "WTI": ["USD"], "NG": ["USD"],
    "SPX": ["USD"], "NASDAQ": ["USD"],
    # کریپتو بیشتر تحت‌تأثیر رویدادهای پرتأثیر دلار (FOMC/CPI/NFP) است
    "BTC": ["USD"], "ETH": ["USD"], "SOL": ["USD"], "BNB": ["USD"],
    "XRP": ["USD"], "DOGE": ["USD"],
}


def currencies_for(symbol: str) -> list:
    """ارزهای مرتبط با یک نماد را برمی‌گرداند (برای فیلترِ اخبار).

    نکته‌ی مهم: علاوه بر کلیدهای داخلی (XAU/EURUSD/…)، نمادهای کارگزار با پسوند
    (مثلاً EURUSDm یا EURUSD.r) نیز باید درست نگاشت شوند؛ وگرنه ارزِ دومِ جفت
    (مثلاً EUR در EURUSD) از قلم می‌افتد و اخبارِ آن ارز نمی‌تواند معامله را مسدود کند.
    پس اگر تطبیقِ مستقیم نشد، نماد را از راهِ نگاشتِ کارگزار→داخلی نرمال می‌کنیم.
    """
    s = (symbol or "").upper()
    if s in SYMBOL_CCY:
        return SYMBOL_CCY[s]
    # تلاش برای نرمال‌سازیِ نمادِ کارگزار (با پسوند) به کلیدِ داخلی
    try:
        import mt5_bridge  # واردسازیِ تنبل برای پرهیز از وابستگیِ حلقوی
        mapped = (mt5_bridge.internal_for_broker(symbol) or "").upper()
        if mapped in SYMBOL_CCY:
            return SYMBOL_CCY[mapped]
    except Exception:  # noqa
        pass
    # OP5-NEWS-06: برای جفت‌های فارکسیِ ۶حرفیِ ناشناخته (مثل GBPJPY) هر دو ارز
    # جدا می‌شوند؛ پیش‌تر فقط ["USD"] برمی‌گشت و اخبارِ JPY/GBP هرگز معامله را
    # مسدود نمی‌کرد. اگر هم ناشناخته ماند و هم ۶حرفی نبود → fallback محافظه‌کارانه.
    core = s.split(".")[0].split("_")[0].split("-")[0]
    if len(core) == 6 and core.isalpha():
        return [core[:3], core[3:]]
    return ["USD"]


def _parse_dt(s: str, meta: dict | None = None):
    """تبدیل تاریخ ISO (با آفست) به datetime آگاه از منطقه‌ی زمانی (UTC).

    OP5-NEWS-04: اگر فید تاریخِ «بدونِ آفست» بدهد، فرضِ UTC می‌کنیم ولی این
    عدم‌قطعیت را در meta['ts_uncertain'] علامت می‌زنیم تا مصرف‌کننده بداند زمانِ
    رویداد ممکن است چند ساعت جابه‌جا باشد (فیدهای محلی مثل ForexFactory).
    """
    try:
        dt = datetime.fromisoformat(s)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
            if meta is not None:
                meta["ts_uncertain"] = True
        return dt.astimezone(timezone.utc)
    except Exception:  # noqa
        return None


# نگاشت کد کشورِ TradingView → کد ارز
_TV_CCY = {"US": "USD", "EU": "EUR", "GB": "GBP", "JP": "JPY", "AU": "AUD",
           "CA": "CAD", "CH": "CHF", "NZ": "NZD", "CN": "CNY", "DE": "EUR", "FR": "EUR"}
_TV_URL = "https://economic-calendar.tradingview.com/events"
_TV_HEADERS = {"User-Agent": "Mozilla/5.0", "Origin": "https://www.tradingview.com"}


def _fetch_tradingview():
    """منبع پشتیبان: تقویم اقتصادی رایگان TradingView (بدون کلید)."""
    from datetime import timedelta
    now = datetime.now(timezone.utc)
    frm = (now - timedelta(days=1)).strftime("%Y-%m-%dT00:00:00.000Z")
    to = (now + timedelta(days=8)).strftime("%Y-%m-%dT00:00:00.000Z")
    params = {"from": frm, "to": to,
              "countries": "US,EU,GB,JP,AU,CA,CH,NZ,CN"}
    r = requests.get(_TV_URL, params=params, headers=_TV_HEADERS, timeout=15)
    r.raise_for_status()
    raw = r.json().get("result", [])
    imp_map = {1: ("High", 3), 0: ("Medium", 2), -1: ("Low", 1)}
    events = []
    for e in raw:
        _meta = {}
        dt = _parse_dt(e.get("date", ""), _meta)
        if dt is None:
            continue
        imp, rank = imp_map.get(e.get("importance"), ("Low", 1))
        events.append({
            "title": e.get("title", ""),
            "country": _TV_CCY.get(e.get("country", ""), e.get("country", "")),
            "impact": imp, "impact_rank": rank,
            "forecast": e.get("forecast") if e.get("forecast") is not None else "",
            "previous": e.get("previous") if e.get("previous") is not None else "",
            "date": dt.isoformat(), "ts": dt.timestamp(),
            "ts_uncertain": bool(_meta.get("ts_uncertain")),   # OP5-NEWS-04
        })
    events.sort(key=lambda x: x["ts"])
    return events


def _fetch_forexfactory():
    """منبع اصلی: تقویم این‌هفته‌ی Forex Factory (رایگان، بدون کلید)."""
    r = requests.get(CAL_URL, headers=_HEADERS, timeout=15)
    r.raise_for_status()
    raw = r.json()
    events = []
    for e in raw:
        _meta = {}
        dt = _parse_dt(e.get("date", ""), _meta)
        if dt is None:
            continue
        events.append({
            "title": e.get("title", ""),
            "country": (e.get("country") or "").upper(),
            "impact": e.get("impact", ""),
            "impact_rank": IMPACT_RANK.get((e.get("impact") or "").lower(), 0),
            "forecast": e.get("forecast", ""),
            "previous": e.get("previous", ""),
            "date": dt.isoformat(),
            "ts": dt.timestamp(),
            "ts_uncertain": bool(_meta.get("ts_uncertain")),   # OP5-NEWS-04
        })
    return events


def _merge_events(*lists):
    """ادغام رویدادهای چند منبع با حذف تکراری‌ها (بر پایه‌ی ارز/عنوان/زمان)."""
    seen = {}
    for lst in lists:
        for e in lst or []:
            if e.get("ts") is None:
                continue
            # OP5-NEWS-16: هم‌زمانی تا دقتِ ۵ دقیقه (منابعِ رایگان ممکن است تا چند
            # دقیقه اختلاف داشته باشند و رویدادِ یکسان دوبار شمرده شود).
            _title = " ".join((e.get("title", "") or "").split()).lower()
            key = (e.get("country", ""), _title, round(float(e["ts"]) / 300))
            old = seen.get(key)
            if old is None:
                seen[key] = e
            else:
                # اصلاح (NEWS-001): ادغامِ فیلدبه‌فیلد — قبلاً کلِ رکورد جایگزین می‌شد
                # و اگر یک منبع forecast و دیگری previous داشت، یکی دور ریخته می‌شد.
                for f in ("forecast", "previous", "actual", "impact"):
                    if not old.get(f) and e.get(f):
                        old[f] = e[f]
    out = list(seen.values())
    out.sort(key=lambda x: x["ts"])
    return out


def _fetch_online(force: bool = False) -> dict:
    """منبعِ آنلاینِ رایگان: ترکیبِ Forex Factory + TradingView (با کش TTL و دیسک)."""
    with _lock:
        _load_disk()
        now = time.time()
        if not force and _cache["data"] is not None and now - _cache["ts"] < _TTL:
            return {"ok": True, "events": _cache["data"], "cached": True,
                    "source": "forexfactory+tradingview"}

        ff, tv, errs = [], [], []
        try:
            ff = _fetch_forexfactory()
        except Exception as ex:  # noqa
            errs.append(f"forexfactory: {ex}")
        try:
            tv = _fetch_tradingview()
        except Exception as ex:  # noqa
            errs.append(f"tradingview: {ex}")

        merged = _merge_events(ff, tv)
        if merged:
            src = "+".join(s for s, lst in (("forexfactory", ff), ("tradingview", tv)) if lst)
            _cache.update(data=merged, ts=now, error=("; ".join(errs) or None))
            _save_disk(merged)
            return {"ok": True, "events": merged, "cached": False,
                    "source": src, "error": ("; ".join(errs) or None)}

        # هیچ منبعِ آنلاینی موفق نشد → سرو کش (حتی قدیمی) وگرنه خطا
        _cache["error"] = "; ".join(errs) or "unknown"
        if _cache["data"] is not None:
            return {"ok": True, "events": _cache["data"], "cached": True,
                    "stale": True, "source": "forexfactory+tradingview",
                    "error": _cache["error"]}
        return {"ok": False, "events": [], "source": "free", "error": _cache["error"]}


_MT5_NO_FILE_MSG = ("فایلِ تقویمِ متاتریدر یافت نشد یا خالی است. "
                    "سرویسِ CalendarExport را روی ویندوز اجرا کنید (راهنما در mt5_files).")


def _norm_source(source: str) -> str:
    s = (source or "both").lower().strip()
    if s in ("forexfactory", "forex", "free", "online", "ff"):
        return "ff"
    if s in ("mt5", "metatrader", "metatrader5"):
        return "mt5"
    return "both"


def fetch(force: bool = False, source: str = "both") -> dict:
    """گرفتن تقویم با انتخابِ منبع.

    source:
      • "ff"   → فقط منابعِ آنلاینِ رایگان (Forex Factory + TradingView)
      • "mt5"  → فقط تقویمِ خودِ متاتریدر ۵ (فایلِ سرویسِ CalendarExport)
      • "both" → ادغامِ هر دو (پیش‌فرض)
    خروجی: {ok, events, source, ...}.
    """
    source = _norm_source(source)

    mt5c = _fetch_mt5_calendar() if source in ("mt5", "both") else None
    mt5_events = mt5c["events"] if (mt5c and mt5c.get("events")) else []

    online = _fetch_online(force) if source in ("ff", "both") else None
    online_events = online["events"] if (online and online.get("ok")) else []

    # ── فقط متاتریدر ──
    if source == "mt5":
        if mt5_events:
            return {"ok": True, "events": mt5_events, "cached": False, "source": "mt5",
                    "mt5_generated": mt5c.get("generated"), "stale": mt5c.get("stale")}
        return {"ok": False, "events": [], "source": "mt5", "error": _MT5_NO_FILE_MSG}

    # ── فقط فارکس‌فکتوری/آنلاین ──
    if source == "ff":
        if online and online.get("ok"):
            return {"ok": True, "events": online_events,
                    "source": online.get("source", "free"),
                    "cached": online.get("cached"), "stale": online.get("stale"),
                    "error": online.get("error")}
        return {"ok": False, "events": [], "source": "free",
                "error": (online or {}).get("error")}

    # ── هر دو (ادغام) ──
    merged = _merge_events(mt5_events, online_events)
    if merged:
        srcs = []
        if mt5_events:
            srcs.append("mt5")
        if online_events:
            srcs.append(online.get("source", "free") if online else "free")
        return {"ok": True, "events": merged, "source": "+".join(srcs) or "none",
                "mt5_generated": (mt5c or {}).get("generated"),
                "stale": bool((mt5c or {}).get("stale") or (online or {}).get("stale")),
                "error": (online or {}).get("error")}

    # هیچ‌کدام داده نداد
    errs = []
    if not mt5_events:
        errs.append("mt5: " + _MT5_NO_FILE_MSG)
    if online and online.get("error"):
        errs.append(str(online["error"]))
    return {"ok": False, "events": [], "source": "none",
            "error": "; ".join(errs) or "داده‌ای از هیچ منبعی دریافت نشد."}



def calendar(min_impact: str = "Low", currencies: list = None,
             hours_ahead: int = 168, hours_back: int = 6,
             source: str = "both") -> dict:
    """فهرست رویدادها با فیلتر تأثیر/ارز/بازه‌ی زمانی و انتخابِ منبع."""
    res = fetch(source=source)
    if not res.get("ok"):
        return {"ok": False, "error": res.get("error"), "events": [],
                "source": res.get("source", _norm_source(source))}
    min_rank = IMPACT_RANK.get(min_impact.lower(), 1)
    now = time.time()
    lo, hi = now - hours_back * 3600, now + hours_ahead * 3600
    ccy = set(c.upper() for c in currencies) if currencies else None
    out = []
    for e in res["events"]:
        if e["impact_rank"] < min_rank:
            continue
        if ccy and e["country"] not in ccy:
            continue
        if not (lo <= e["ts"] <= hi):
            continue
        out.append(e)
    return {"ok": True, "events": out, "count": len(out),
            "cached": res.get("cached"), "stale": res.get("stale"),
            "source": res.get("source", "free"),
            "mt5_generated": res.get("mt5_generated")}


def is_blocked(symbol: str, before_min: int = 30, after_min: int = 30,
               min_impact: str = "High", source: str = "both") -> dict:
    """آیا اکنون به‌خاطر یک رویداد پرتأثیرِ نزدیک، معامله‌ی این نماد باید مسدود شود؟

    خروجی: {blocked: bool, event: {...}|None, window: {...}}
    source: منبعِ تقویم برای فیلتر (ff/mt5/both).
    """
    res = fetch(source=source)
    if not res.get("ok"):
        # اگر تقویم در دسترس نیست، مسدود نمی‌کنیم (fail-open) اما هشدار می‌دهیم
        return {"blocked": False, "event": None, "error": res.get("error"),
                "note": "تقویم اخبار در دسترس نیست؛ فیلتر اعمال نشد."}
    min_rank = IMPACT_RANK.get(min_impact.lower(), 3)
    ccy = set(currencies_for(symbol))
    now = time.time()
    nearest = None
    for e in res["events"]:
        if e["impact_rank"] < min_rank:
            continue
        if e["country"] not in ccy:
            continue
        start = e["ts"] - before_min * 60
        end = e["ts"] + after_min * 60
        if start <= now <= end:
            return {"blocked": True, "event": e,
                    "mins_to_event": round((e["ts"] - now) / 60, 1),
                    "window": {"before_min": before_min, "after_min": after_min,
                               "min_impact": min_impact}}
        # نزدیک‌ترین رویداد آینده برای اطلاع‌رسانی
        if e["ts"] >= now and (nearest is None or e["ts"] < nearest["ts"]):
            nearest = e
    return {"blocked": False, "event": None, "next_event": nearest,
            "next_in_min": round((nearest["ts"] - now) / 60, 1) if nearest else None}
