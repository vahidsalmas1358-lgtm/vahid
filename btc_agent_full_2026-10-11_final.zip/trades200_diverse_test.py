# -*- coding: utf-8 -*-
"""۲۰۰ معاملهٔ خرید/فروش با سناریوهای متنوع روی نمادهایی با مقیاسِ قیمتیِ متفاوت.

پوشش:
  • طلا (XAU~۴هزار)، نقره (XAG~۵۰)، بیت‌کوین (~۸۴هزار)، اتریوم، سولانا، دوج (~۰٫۱)،
    جفت‌ارزها (EURUSD~۱٫۱، USDJPY~۱۵۰)، شاخص‌ها (SPX/NASDAQ)، نفت/مس.
  • فاز A: کیفیتِ پلنِ سیگنالِ زنده (اعشارِ درست، ۳ حدسود، ترتیب، سمتِ استاپ، RR).
  • فاز B (۱۲۰ معامله): /api/robot/test با ۵ سناریو × ۲ جهت × ۱۲ نماد.
  • فاز C (۴۰ معامله): /api/mt5/send با dry_run (جهتِ اجباری + پلنِ معکوس).
  • فاز D (۴۰ معامله): /api/robot/order واقعی (بدونِ MT5 → باید مودبانه مدیریت شود).

پیش‌نیاز: سرور روی 127.0.0.1:8000 در حالِ اجرا باشد.
"""
import json
import urllib.request
import urllib.error

BASE = "http://127.0.0.1:8000"
PASS = 0
FAIL = 0
TRADES = 0
FAILS = []


def check(name, cond, detail=""):
    global PASS, FAIL
    if cond:
        PASS += 1
    else:
        FAIL += 1
        FAILS.append(f"{name} — {detail}")
        print(f"  ❌ {name} — {detail}")


def get(u, timeout=60):
    with urllib.request.urlopen(BASE + u, timeout=timeout) as r:
        return r.status, json.loads(r.read().decode())


def post(u, payload, timeout=60):
    data = json.dumps(payload).encode()
    rq = urllib.request.Request(BASE + u, data, {"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(rq, timeout=timeout) as r:
            return r.status, json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        try:
            return e.code, json.loads(e.read().decode())
        except Exception:  # noqa
            return e.code, {}


def expected_dec(p):
    p = abs(float(p))
    if p >= 100:
        return 2
    if p >= 1:
        return 4
    if p >= 0.01:
        return 5
    return 8


SYMBOLS = ["XAU", "XAG", "BTC", "ETH", "SOL", "DOGE",
           "EURUSD", "GBPUSD", "USDJPY", "SPX", "NASDAQ", "WTI"]

# ---------------------------------------------------------------- setup
_, robot_cfg0 = get("/api/robot/config")
robot_cfg0 = (robot_cfg0.get("data") or {}).get("config") or robot_cfg0.get("data") or {}
KEEP_ROBOT = {k: robot_cfg0.get(k) for k in (
    "enabled", "filter_mode", "min_internal_score", "require_direction_match",
    "news_filter_enabled", "conflict_guard_enabled", "aggregate_window_sec",
    "dedupe_window_sec", "block_duplicate_open", "block_opposite_open", "auto_forward")}
post("/api/robot/config", {
    "enabled": True, "filter_mode": "internal", "min_internal_score": 0,
    "require_direction_match": False, "news_filter_enabled": False,
    "conflict_guard_enabled": False, "aggregate_window_sec": 0,
    "dedupe_window_sec": 0, "block_duplicate_open": False,
    "block_opposite_open": False, "auto_forward": True})

# قیمتِ زنده و پلنِ هر نماد (فاز A) — یک‌بار برای استفادهٔ فازهای بعدی
live = {}
print("فاز A — کیفیتِ پلنِ سیگنالِ زنده (دادهٔ واقعی):")
for s in SYMBOLS:
    st, d = get(f"/api/signal?symbol={s}&tf=1h&ai=0")
    check(f"A/{s}/http", st == 200 and d.get("ok"), f"status={st} err={d.get('error')}")
    dd = d.get("data") or {}
    price = dd.get("price")
    plan = dd.get("plan") or {}
    live[s] = {"price": price, "plan": plan, "dir": dd.get("direction")}
    check(f"A/{s}/price", isinstance(price, (int, float)) and price > 0, f"price={price}")
    if not plan or plan.get("direction") in (None, "NEUTRAL"):
        # بازارِ خنثی پلن ندارد — قابلِ قبول؛ ولی اگر پلن هست باید کامل باشد
        continue
    e, sl = plan.get("entry"), plan.get("stop_loss")
    tps = [t.get("price") for t in (plan.get("take_profits") or [])]
    dec = expected_dec(price)
    check(f"A/{s}/tp3", len(tps) == 3, f"tps={tps}")
    check(f"A/{s}/fields", e is not None and sl is not None, f"entry={e} sl={sl}")
    if e is None or sl is None or len(tps) != 3:
        continue
    long = plan["direction"] == "LONG"
    ordered = (tps[0] < tps[1] < tps[2]) if long else (tps[0] > tps[1] > tps[2])
    check(f"A/{s}/tp_order", ordered, f"dir={plan['direction']} tps={tps}")
    side_ok = (sl < e < tps[0]) if long else (tps[0] < e < sl)
    check(f"A/{s}/sl_side", side_ok, f"sl={sl} entry={e} tp1={tps[0]}")
    # اعشار: مقادیر باید با قاعدهٔ اعشارِ برنامه گِرد شده باشند
    for label, v in (("entry", e), ("sl", sl), ("tp1", tps[0]), ("tp3", tps[2])):
        check(f"A/{s}/dec_{label}", abs(v - round(v, dec)) < 1e-12, f"{label}={v} dec={dec}")
    # سطوح نباید روی هم بیفتند (فروپاشیِ اعشار مثل EURUSD→1.1)
    check(f"A/{s}/distinct", len({e, sl, *tps}) == 5, f"levels={[e, sl] + tps}")
    check(f"A/{s}/entry_sane", abs(e - price) / price < 0.2, f"entry={e} price={price}")
    rr = [t.get("rr") for t in plan.get("take_profits") or []]
    if all(isinstance(x, (int, float)) for x in rr):
        check(f"A/{s}/rr_inc", rr[0] > 0 and rr[0] <= rr[1] <= rr[2], f"rr={rr}")

# ---------------------------------------------------------------- فاز B
print("فاز B — ۱۲۰ سفارشِ ربات (/api/robot/test)، ۵ سناریو × ۲ جهت × ۱۲ نماد:")
for s in SYMBOLS:
    p = live[s]["price"] or 100.0
    dec = expected_dec(p)

    def lv(frac):  # سطحِ قیمتی نسبت به قیمتِ زنده
        return round(p * (1 + frac), dec)

    scen = [
        # (توضیح، بدنهٔ اضافه برای BUY، بدنهٔ اضافه برای SELL)
        ("full", {"sl": lv(-0.01), "take_profits": [lv(0.01), lv(0.02), lv(0.03)], "tf": "1h"},
                 {"sl": lv(0.01), "take_profits": [lv(-0.01), lv(-0.02), lv(-0.03)], "tf": "1h"}),
        ("bare", {"tf": "30m"}, {"tf": "30m"}),
        ("single_tp_M15", {"tp": lv(0.015), "tf": "M15"}, {"tp": lv(-0.015), "tf": "M15"}),
        ("entry_magic_2h", {"entry": lv(0.001), "magic": 777, "comment": "سناریو ۴ 💹", "tf": "2h"},
                           {"entry": lv(-0.001), "magic": 778, "comment": "سناریو ۴ 💹", "tf": "2h"}),
        ("bigvol_lower", {"volume": 50, "tf": "1d"}, {"volume": 50, "tf": "1d"}),
    ]
    for name, extra_b, extra_s in scen:
        for direction, extra in (("buy", extra_b), ("SELL", extra_s),):
            body = {"symbol": s, "direction": direction, "volume": extra.get("volume", 0.1),
                    "robot_id": f"diverse_{name}", "platform": "python"}
            body.update(extra)
            st, d = post("/api/robot/test", body)
            TRADES += 1
            tag = f"B/{s}/{name}/{direction}"
            check(f"{tag}/http", st == 200 and d.get("ok") is True,
                  f"status={st} err={d.get('error')}")
            ev = (d.get("eval") or (d.get("data") or {}).get("eval")) or {}
            # اصلاح (AUD-007): «or True» حذف شد — این اَسرت قبلاً همیشه قبول می‌شد.
            check(f"{tag}/eval_dir", ev.get("order_direction") in ("LONG", "SHORT", None),
                  f"order_direction={ev.get('order_direction')!r}")
            internal = ev.get("internal") or {}
            check(f"{tag}/eval_price", isinstance(internal.get("price"), (int, float))
                  and internal.get("price") > 0, f"internal={internal}")
            appr = d.get("approved", (d.get("data") or {}).get("approved"))
            check(f"{tag}/approved_bool", isinstance(appr, bool), f"approved={appr!r}")
            # با min_score=0 و بدونِ direction-match، سفارشِ سالم باید تأیید شود
            check(f"{tag}/approved_true", appr is True,
                  f"reasons={ev.get('reasons')}")

# ---------------------------------------------------------------- فاز C
print("فاز C — ۴۰ ارسالِ مستقیم (/api/mt5/send، dry_run، جهتِ اجباری):")
for s in SYMBOLS[:10]:
    for direction in ("LONG", "SHORT"):
        for tf in ("1h", "30m", "2h"):
            if tf in ("30m", "2h") and s not in ("XAU", "BTC", "EURUSD", "SPX", "USDJPY"):
                continue  # ۴۰تا شود: ۱۰×۲×۱ + ۵×۲×۲
            st, d = post("/api/mt5/send", {"symbol": s, "tf": tf, "direction": direction,
                                           "volume": 0.2, "dry_run": True})
            TRADES += 1
            tag = f"C/{s}/{direction}/{tf}"
            check(f"{tag}/http", st == 200 and d.get("ok") is True,
                  f"status={st} err={str(d.get('error'))[:70]}")
            dd = d.get("data") or {}
            planned = dd.get("planned") or {}
            check(f"{tag}/has_plan", bool(planned), f"keys={list(dd)[:8]}")
            e, sl = planned.get("entry"), planned.get("sl")
            tps = planned.get("tps") or []
            check(f"{tag}/vol_echo", planned.get("volume") == 0.2,
                  f"volume={planned.get('volume')}")
            if e is not None and sl is not None and len(tps) == 3:
                long = direction == "LONG"
                check(f"{tag}/plan_side",
                      (sl < e < tps[0]) if long else (tps[0] < e < sl),
                      f"sl={sl} e={e} tp1={tps[0]}")
                ordered = (tps[0] < tps[1] < tps[2]) if long else (tps[0] > tps[1] > tps[2])
                check(f"{tag}/tp_order", ordered, f"tps={tps}")
                dec = expected_dec(live[s]["price"] or e)
                check(f"{tag}/plan_dec", abs(e - round(e, dec)) < 1e-12, f"e={e} dec={dec}")
                check(f"{tag}/distinct", len({e, sl, *tps}) == 5,
                      f"levels={[e, sl] + list(tps)}")

# ---------------------------------------------------------------- فاز D
print("فاز D — ۴۰ سفارشِ واقعیِ ربات (/api/robot/order، بدونِ MT5 → مدیریتِ مودبانه):")
for s in SYMBOLS[:10]:
    p = live[s]["price"] or 100.0
    dec = expected_dec(p)
    for direction, sgn in (("BUY", 1), ("SELL", -1)):
        for k, variant in enumerate((
            {"sl": round(p * (1 - sgn * 0.012), dec),
             "take_profits": [round(p * (1 + sgn * 0.01 * i), dec) for i in (1, 2, 3)]},
            {"tf": "M30", "type": 0 if sgn > 0 else 1},   # سبکِ MT5: type به‌جای direction
        )):
            body = {"symbol": s, "volume": 0.05, "robot_id": "diverse_real",
                    "platform": "mql5"}
            if "type" not in variant:
                body["direction"] = direction
            body.update(variant)
            st, d = post("/api/robot/order", body)
            TRADES += 1
            tag = f"D/{s}/{direction}/v{k}"
            check(f"{tag}/http", st == 200 and d.get("ok") is True,
                  f"status={st} err={str(d.get('error'))[:70]}")
            appr = d.get("approved", (d.get("data") or {}).get("approved"))
            fwd = d.get("forwarded", (d.get("data") or {}).get("forwarded"))
            check(f"{tag}/approved", appr is True, f"approved={appr!r}")
            # بدونِ اتصالِ MT5، یا forward=False با پیامِ روشن یا شبیه‌سازِ mock پاسخ می‌دهد
            check(f"{tag}/fwd_bool", isinstance(fwd, bool) or fwd is None, f"fwd={fwd!r}")

# ---------------------------------------------------------------- teardown
post("/api/robot/config", KEEP_ROBOT)
print("\n" + "=" * 66)
print(f"  معاملات: {TRADES} · نتیجه: {PASS} پاس · {FAIL} ناموفق")
if FAILS:
    print("  خطاها:")
    for f in FAILS[:30]:
        print("   -", f)
print("=" * 66)
