"""زمان‌بندیِ فعال/غیرفعال بودنِ کلِ برنامه بر اساسِ «ساعتِ سرورِ کارگزار».

کاربر می‌تواند تا دو بازهٔ کاری در شبانه‌روز تعریف کند (شروعِ۱/پایانِ۱ و
شروعِ۲/پایانِ۲)، روزهای هفته را انتخاب کند و (اختیاری) یک timezone بدهد.

- `windows` عیناً «دقیقهٔ روز» است؛ بازهٔ شب‌گذر (۲۲:۰۰→۰۶:۰۰) پشتیبانی می‌شود.
- `days` لیستِ روزهای مجاز است (0=دوشنبه … 6=یکشنبه، مطابقِ datetime.weekday()).
- op5-sched-002: `on == off` بازهٔ صفر است و نادیده گرفته می‌شود (نه «۲۴ ساعت»).
- op5-sched-003: خطای parse در فایلِ config نباید کلیدها را خراب کند؛ مقادیر
  نامعتبر به «خالی» برمی‌گردند و config قدیمی هم سازگار می‌ماند.
"""
from __future__ import annotations

import os
import json
import threading
from zoneinfo import ZoneInfo

CONFIG_PATH = os.path.join(os.path.dirname(__file__), "schedule_config.json")
_lock = threading.RLock()
KEYS = ("on1", "off1", "on2", "off2")


def _default_config() -> dict:
    return {"enabled": False, "timezone": "broker", "days": [0, 1, 2, 3, 4],
            "on1": "", "off1": "", "on2": "", "off2": ""}


def to_minutes(v):
    """«HH:MM» یا دیکشنری {h,m} را به دقیقهٔ روز (0..1439) تبدیل می‌کند، وگرنه None."""
    if v is None or v == "":
        return None
    try:
        if isinstance(v, dict):
            h = int(v.get("h", v.get("hour")))
            m = int(v.get("m", v.get("min", v.get("minute"))))
        else:
            p = str(v).strip().split(":", 1)
            h = int(p[0])
            m = int(p[1]) if len(p) == 2 else 0
    except (TypeError, ValueError):
        return None
    return h * 60 + m if 0 <= h <= 23 and 0 <= m <= 59 else None


def _norm_hhmm(v) -> str:
    """ورودی را به قالبِ استانداردِ "HH:MM" تبدیل می‌کند؛ نامعتبر → رشتهٔ خالی."""
    x = to_minutes(v)
    return "" if x is None else f"{x // 60:02d}:{x % 60:02d}"


def _norm_days(v):
    try:
        return sorted({int(x) for x in v if 0 <= int(x) <= 6})
    except (TypeError, ValueError):
        return [0, 1, 2, 3, 4]


def load_config() -> dict:
    cfg = _default_config()
    try:
        with open(CONFIG_PATH, encoding="utf-8") as f:
            saved = json.load(f)
        if isinstance(saved, dict):
            cfg.update(saved)
    except (OSError, ValueError, TypeError):
        pass
    for k in KEYS:
        cfg[k] = _norm_hhmm(cfg.get(k))
    cfg["days"] = _norm_days(cfg.get("days", [0, 1, 2, 3, 4]))
    cfg["enabled"] = bool(cfg.get("enabled"))
    if not isinstance(cfg.get("timezone"), str) or not cfg.get("timezone").strip():
        cfg["timezone"] = "broker"
    return cfg


def save_config(patch: dict) -> dict:
    cfg = load_config()
    for k, v in (patch or {}).items():
        if k == "enabled":
            cfg[k] = (v.strip().lower() not in ("", "0", "false", "no", "off", "none")
                      if isinstance(v, str) else bool(v))
        elif k in KEYS:
            cfg[k] = _norm_hhmm(v)
        elif k == "days":
            cfg[k] = _norm_days(v)
        elif k == "timezone" and isinstance(v, str) and v.strip():
            v2 = v.strip()
            if v2 != "broker":
                try:  # فقط منطقه‌های معتبر (در غیر این صورت به «بروکر» برمی‌گردیم)
                    ZoneInfo(v2)
                except Exception:  # noqa
                    v2 = "broker"
            cfg[k] = v2
    with _lock:
        # OP5-CORE-10: نوشتنِ اتمیک
        import jsonutil
        jsonutil.atomic_write_json(CONFIG_PATH, cfg)
    return cfg


def _window_active(minute: int, on_min, off_min) -> bool:
    """آیا دقیقهٔ فعلی در بازهٔ [on, off) است؟ (پشتیبانی از بازهٔ شب‌گذر)"""
    if on_min is None or off_min is None or on_min == off_min:
        return False
    if on_min < off_min:
        return on_min <= minute < off_min
    return minute >= on_min or minute < off_min


def is_active(minute_of_day: int, cfg: dict = None, weekday: int = None) -> dict:
    """آیا برنامه در «این دقیقهٔ روز» (ساعتِ سرور) باید فعال باشد؟

    خروجی: {enabled, active, matched (1|2|None), windows, has_windows, reason}
    weekday (0=دوشنبه..6=یکشنبه) اگر داده شود، در فیلترِ روزهای هفته لحاظ می‌شود.
    """
    c = cfg or load_config()
    windows = []
    for n in (1, 2):
        on = to_minutes(c.get(f"on{n}"))
        off = to_minutes(c.get(f"off{n}"))
        if on is not None and off is not None and on != off:
            windows.append((on, off))

    if not c.get("enabled"):
        return {"enabled": False, "active": True, "matched": None,
                "windows": windows, "has_windows": bool(windows),
                "reason": "زمان‌بندی غیرفعال است (برنامه همیشه فعال)."}

    if weekday is not None and int(weekday) not in c.get("days", [0, 1, 2, 3, 4]):
        return {"enabled": True, "active": False, "matched": None,
                "windows": windows, "has_windows": bool(windows),
                "reason": "امروز در روزهای مجازِ زمان‌بندی نیست."}

    if not windows:
        return {"enabled": True, "active": True, "matched": None,
                "windows": windows, "has_windows": False,
                "reason": "زمان‌بندی فعال است اما هیچ بازهٔ معتبری تعریف نشده."}

    m = int(minute_of_day) % 1440
    hit = None
    for i, (on, off) in enumerate(windows, 1):
        if _window_active(m, on, off):
            hit = i
            break
    return {"enabled": True, "active": hit is not None, "matched": hit,
            "windows": windows, "has_windows": True,
            "reason": (f"داخلِ بازهٔ کاریِ {hit}." if hit
                       else "خارج از بازه‌های کاریِ تعریف‌شده — ارسالِ معامله متوقف است.")}


def minute_of_day(now, tz: str | None = None):
    """(دقیقهٔ روز, weekday) از یک datetimeِ aware؛ با tz اختیاری (غیر از broker)."""
    if now.tzinfo is None:
        raise ValueError("aware datetime required")
    if tz and tz != "broker":
        now = now.astimezone(ZoneInfo(tz))
    return now.hour * 60 + now.minute, now.weekday()
