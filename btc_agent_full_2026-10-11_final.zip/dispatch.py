"""پیکربندیِ «روشِ ارسالِ سیگنال به متاتریدر ۵».

سیگنال‌هایی که خودِ برنامه تولید می‌کند، به یکی از سه روشِ زیر برای ارسال به
متاتریدر تصمیم‌گیری می‌شوند (کاربر یکی را فعال می‌کند):

  internal → فقط تحلیل‌گرِ داخلیِ برنامه
  ai       → فقط تحلیل/سیگنالِ مدلِ هوش مصنوعی
  both     → رأی‌گیری: هر دو (داخلی + هوش مصنوعی) باید هم‌جهت و معتبر باشند

نکتهٔ مهم: صرف‌نظر از روشِ انتخابی، سیگنال باید از «فیلترِ اخبار» (در صورتِ
دسترسی) و «فیلترِ زمان‌بندیِ ساعاتِ کارِ سرور» هم عبور کند. این فیلترها هم
اینجا نگهداری می‌شوند و در app.py هنگامِ ارسال اعمال می‌گردند.

این تنظیمات فقط مربوط به سیگنال‌های تولیدیِ خودِ برنامه است؛ روشِ صدورِ مجوز برای
سیگنال‌های دریافتی از ربات‌ها/اکسپرت‌ها در robots.py نگهداری می‌شود (و از همین تب
ویرایش می‌شود).
"""
from __future__ import annotations

import os
import json
import threading

import jsonutil

CONFIG_PATH = os.path.join(os.path.dirname(__file__), "dispatch_config.json")
_lock = threading.RLock()

VALID_SOURCES = ("internal", "ai", "both")
VALID_IMPACT = ("High", "Medium", "Low")
VALID_NEWS_SOURCES = ("ff", "mt5", "both")


def _default_config() -> dict:
    return {
        # --- سیگنال‌های تولیدیِ خودِ برنامه ---
        "program_enabled": False,        # ارسالِ خودکارِ سیگنال‌های برنامه به متاتریدر
        "program_source": "internal",    # internal | ai | both  (بندهای ۱،۲،۳)
        "program_min_internal": 15.0,    # حداقلِ قدرِمطلقِ امتیازِ داخلیِ لازم
        "program_min_ai": 15.0,          # حداقلِ قدرِمطلقِ امتیازِ AI لازم
        # --- اصلاح (AUTOPILOT-001): زمان‌بندِ سمتِ سرور — ارسالِ خودکار دیگر به
        # بازبودنِ مرورگر/داشبورد یا کلیکِ «تحلیل اکنون» وابسته نیست ---
        "program_autorun": True,          # حلقهٔ خودکارِ سمتِ سرور (وقتی program_enabled روشن است)
        "program_symbols": ["BTC"],      # نمادهایی که سرور خودش تحلیل/ارسال می‌کند
        "program_tf": "15m",             # تایم‌فریمِ تحلیلِ خودکار
        "program_every_sec": 60,          # بازهٔ اجرا (ثانیه، حداقل ۱۵)
        # --- اصلاح (PROG-GUARD-001): گاردِ پوزیشنِ باز برای ارسالِ خودکارِ برنامه ---
        "program_block_duplicate_open": True,   # پوزیشنِ بازِ هم‌جهت → ارسالِ تکراری ممنوع
        "program_block_opposite_open": True,    # پوزیشنِ بازِ مخالف → هجِ همزمان ممنوع
        # اصلاح (REVERSE-001): رفتار هنگامِ سیگنالِ مخالفِ پوزیشنِ باز:
        #   reverse = بستنِ پوزیشنِ مخالف و بازکردنِ معاملهٔ جدید (پیش‌فرض — دستورالعملِ کاربر)
        #   close   = فقط بستنِ پوزیشنِ مخالف (بدونِ معاملهٔ جدید)
        #   block   = نگه‌داشتنِ پوزیشن و ردِ سیگنالِ مخالف
        "program_opposite_action": "reverse",
        # --- فیلترهای مشترک (روی همهٔ ارسال‌ها اعمال می‌شوند) ---
        "news_filter_enabled": True,     # فیلترِ اخبار (اگر در دسترس باشد)
        "news_source": "both",           # منبعِ تقویم: ff (فارکس‌فکتوری) | mt5 | both
        "news_impact": "High",           # حداقلِ تأثیرِ خبر برای مسدودسازی
        "news_before_min": 30,
        "news_after_min": 30,
        # OP5-CORE-17: پیش‌فرضِ محافظه‌کارانه = fail-closed؛ اگر تقویمِ اخبار در
        # دسترس نباشد، معاملهٔ واقعی مسدود می‌شود (برای محیطِ آزمایشی می‌توانید
        # آگاهانه False کنید). پیش‌تر پیش‌فرض fail-open بود و محافظِ اخبار عملاً
        # در سه مسیر (برنامه/ربات/بریج) بی‌اثر می‌شد.
        "news_fail_closed": True,
        "schedule_filter_enabled": True,  # فیلترِ زمان‌بندیِ ساعاتِ کارِ سرور
        # اگر ساعتِ سرورِ کارگزار در دسترس نباشد: False = fail-open (اجازه، با هشدار)،
        # True = fail-closed (تا وقتی ساعت معلوم نشود، ارسال متوقف است).
        "schedule_fail_closed": False,
    }


def load_config() -> dict:
    cfg = _default_config()
    if os.path.exists(CONFIG_PATH):
        try:
            with open(CONFIG_PATH, encoding="utf-8") as f:
                cfg.update(json.load(f) or {})
        except Exception:  # noqa
            pass
    return cfg


def save_config(patch: dict) -> dict:
    cfg = load_config()
    allowed = set(_default_config().keys())   # فقط کلیدهای شناخته‌شده ذخیره شوند
    for k, v in (patch or {}).items():
        if k in allowed:
            cfg[k] = v
    # کلیدهای ناشناخته‌ای که قبلاً (پیش از این محدودسازی) واردِ فایل شده‌اند حذف شوند
    for k in [k for k in cfg if k not in allowed]:
        cfg.pop(k, None)

    # ---- اعتبارسنجی/محدودسازی ----
    if cfg.get("program_source") not in VALID_SOURCES:
        cfg["program_source"] = "internal"
    if cfg.get("news_impact") not in VALID_IMPACT:
        cfg["news_impact"] = "High"
    if cfg.get("news_source") not in VALID_NEWS_SOURCES:
        cfg["news_source"] = "both"
    # اصلاح (AUTOPILOT-001): اعتبارسنجی تنظیماتِ حلقهٔ خودکارِ سمتِ سرور
    _vtf = {"1m", "5m", "10m", "15m", "30m", "1h", "2h", "4h", "1d"}
    if cfg.get("program_tf") not in _vtf:
        cfg["program_tf"] = "15m"
    try:
        cfg["program_every_sec"] = max(15, int(float(cfg.get("program_every_sec", 60) or 60)))
    except Exception:  # noqa
        cfg["program_every_sec"] = 60
    _syms = cfg.get("program_symbols")
    if not isinstance(_syms, list):
        _syms = []
    cfg["program_symbols"] = [str(x).strip() for x in _syms if str(x).strip()][:12]
    cfg["program_autorun"] = bool(cfg.get("program_autorun", True))
    cfg["program_block_duplicate_open"] = bool(cfg.get("program_block_duplicate_open", True))
    if cfg.get("program_opposite_action") not in ("reverse", "close", "block"):
        cfg["program_opposite_action"] = "reverse"
    cfg["program_block_opposite_open"] = bool(cfg.get("program_block_opposite_open", True))

    def _clampf(key, default, lo, hi):
        try:
            cfg[key] = max(lo, min(hi, float(cfg.get(key, default))))
        except Exception:  # noqa
            cfg[key] = default

    _clampf("program_min_internal", 15.0, 0.0, 100.0)
    _clampf("program_min_ai", 15.0, 0.0, 100.0)

    def _clampi(key, default, lo, hi):
        try:
            cfg[key] = max(lo, min(hi, int(float(cfg.get(key, default)))))
        except Exception:  # noqa
            cfg[key] = default

    _clampi("news_before_min", 30, 0, 1440)
    _clampi("news_after_min", 30, 0, 1440)

    def _as_bool(v):
        # اصلاح (DISP-001): رشته‌ی "false"/"0"/"off" قبلاً با bool() به True تبدیل می‌شد.
        if isinstance(v, str):
            return v.strip().lower() not in ("", "0", "false", "no", "off", "none")
        return bool(v)

    # OP5-CORE-11: همهٔ کلیدهای بولیِ کنترلی (نه فقط سه کلید) با همان قاعده
    # نرمال می‌شوند؛ پیش‌تر program_autorun / *_block_* / *_fail_closed با
    # bool(value) ذخیره می‌شدند و رشتهٔ "false" آن‌ها را True می‌کرد.
    _BOOL_KEYS = (
        "program_enabled", "program_autorun",
        "program_block_duplicate_open", "program_block_opposite_open",
        "news_filter_enabled", "news_fail_closed",
        "schedule_filter_enabled", "schedule_fail_closed",
    )
    for key in _BOOL_KEYS:
        cfg[key] = _as_bool(cfg.get(key, _default_config().get(key, False)))

    with _lock:
        # OP5-CORE-10: نوشتنِ اتمیک
        jsonutil.atomic_write_json(CONFIG_PATH, cfg)
    return cfg


def source_label(source: str, lang: str = "fa") -> str:
    fa = {"internal": "تحلیل‌گر داخلی", "ai": "هوش مصنوعی",
          "both": "رأی‌گیری داخلی + هوش مصنوعی"}
    en = {"internal": "Internal analyzer", "ai": "AI model",
          "both": "Vote: internal + AI"}
    return (fa if lang == "fa" else en).get(source, source)
