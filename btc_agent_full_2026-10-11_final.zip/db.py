"""لایهٔ ماندگاریِ SQLite (حالتِ WAL) — پشتوانهٔ مشترکِ تاریخچهٔ سیگنال‌ها و لاگ‌ها.

چرا SQLite؟ نوشتن O(1) و اتمیک است (به‌جای بازنویسیِ کاملِ فایلِ JSON در هر بار)،
خواندنِ ایندکس‌دار سریع است، حجمِ دیسک جمع‌وجورتر است و مقیاس‌پذیر است.
خواندنِ «داغ» همچنان در ماژول‌های بالادست از کشِ RAM انجام می‌شود؛ این لایه فقط
ماندگاریِ سریع و امن را فراهم می‌کند.

طراحی:
  • یک اتصالِ مشترکِ thread-safe (check_same_thread=False) که با یک RLock سریالایز می‌شود.
  • WAL + synchronous=NORMAL + busy_timeout → نوشتنِ سریع و امن در برابرِ کرشِ برنامه،
    و خواندن/نوشتنِ هم‌زمانِ بی‌دردسر.
  • رابطِ بیرونی (history.record/get_all/clear و *_log) بدونِ تغییر می‌ماند؛ فقط پشتوانه عوض می‌شود.
"""
from __future__ import annotations
import os
import json
import time
import sqlite3
import threading

DB_PATH = os.path.join(os.path.dirname(__file__), "agent.db")

_lock = threading.RLock()
_conn: sqlite3.Connection | None = None


def _init(conn: sqlite3.Connection) -> None:
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    conn.execute("PRAGMA busy_timeout=5000")
    conn.execute("PRAGMA temp_store=MEMORY")
    # سقفِ اندازهٔ فایلِ WAL پس از checkpoint (بایت). بدونِ این، در اجرای
    # طولانی‌مدت (VPS) فایلِ agent.db-wal می‌تواند چند برابرِ خودِ دیتابیس شود.
    conn.execute("PRAGMA journal_size_limit=4194304")   # ~4MB
    try:
        conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")  # جمع‌کردنِ WALِ انباشتهٔ قبلی
    except Exception:  # noqa
        pass
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS signals(
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            ts           INTEGER,
            skey         TEXT,
            symbol       TEXT,
            pair         TEXT,
            interval     TEXT,
            direction    TEXT,
            price        REAL,
            score        REAL,
            entry        REAL,
            stop_loss    REAL,
            take_profits TEXT,
            generated_at TEXT
        );
        CREATE INDEX IF NOT EXISTS ix_sig_symbol ON signals(symbol, id);
        CREATE INDEX IF NOT EXISTS ix_sig_key    ON signals(skey, id);

        CREATE TABLE IF NOT EXISTS logs(
            id       INTEGER PRIMARY KEY AUTOINCREMENT,
            channel  TEXT,
            ts       REAL,
            data     TEXT
        );
        CREATE INDEX IF NOT EXISTS ix_log_channel ON logs(channel, id);
        """
    )
    conn.commit()


def conn() -> sqlite3.Connection:
    """اتصالِ مشترک (تنبل‌ساز)."""
    global _conn
    if _conn is None:
        with _lock:
            if _conn is None:
                c = sqlite3.connect(DB_PATH, check_same_thread=False, timeout=5.0)
                c.row_factory = sqlite3.Row
                _init(c)
                _conn = c
    return _conn


def execute(sql: str, params=()):
    with _lock:
        c = conn()
        cur = c.execute(sql, params)
        c.commit()
        return cur


def query(sql: str, params=()):
    with _lock:
        return conn().execute(sql, params).fetchall()


# ----------------------------------------------------------------- سیگنال‌ها
SIGNALS_CAP = 5000        # نگه‌داریِ تاریخِ بسیار بیشتر از قبل (JSON فقط ۳۰۰ بود)
_TRIM_EVERY = 200         # هرس فقط هر N درج (نه هر بار) → نوشتنِ سریع‌تر
_sig_writes = 0


def add_signal(rec: dict) -> None:
    global _sig_writes
    with _lock:
        c = conn()
        c.execute(
            """INSERT INTO signals(ts, skey, symbol, pair, interval, direction,
                                   price, score, entry, stop_loss, take_profits, generated_at)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",
            (rec.get("ts"), rec.get("key"), rec.get("symbol"), rec.get("pair"),
             rec.get("interval"), rec.get("direction"), rec.get("price"), rec.get("score"),
             rec.get("entry"), rec.get("stop_loss"),
             json.dumps(rec.get("take_profits", []), ensure_ascii=False),
             rec.get("generated_at")),
        )
        _sig_writes += 1
        if _sig_writes % _TRIM_EVERY == 0:     # هرسِ دوره‌ای به‌جای هر درج
            c.execute(
                """DELETE FROM signals WHERE id NOT IN
                   (SELECT id FROM signals ORDER BY id DESC LIMIT ?)""",
                (SIGNALS_CAP,),
            )
        c.commit()


def _sig_row_to_dict(r: sqlite3.Row) -> dict:
    try:
        tps = json.loads(r["take_profits"] or "[]")
    except Exception:  # noqa
        tps = []
    return {
        "ts": r["ts"], "key": r["skey"], "symbol": r["symbol"], "pair": r["pair"],
        "interval": r["interval"], "direction": r["direction"], "price": r["price"],
        "score": r["score"], "entry": r["entry"], "stop_loss": r["stop_loss"],
        "take_profits": tps, "generated_at": r["generated_at"],
    }


def get_signals(symbol=None, limit=100) -> list:
    """جدیدترین سیگنال‌ها (newest-first) — اختیاراً فقط یک نماد."""
    if symbol:
        rows = query(
            "SELECT * FROM signals WHERE symbol=? ORDER BY id DESC LIMIT ?",
            (symbol.upper(), limit),
        )
    else:
        rows = query("SELECT * FROM signals ORDER BY id DESC LIMIT ?", (limit,))
    return [_sig_row_to_dict(r) for r in rows]


def last_signal_direction(skey: str):
    rows = query(
        "SELECT direction FROM signals WHERE skey=? ORDER BY id DESC LIMIT 1", (skey,)
    )
    return rows[0]["direction"] if rows else None


def count_signals() -> int:
    return query("SELECT COUNT(*) AS n FROM signals")[0]["n"]


def clear_signals() -> None:
    execute("DELETE FROM signals")


def add_signals_bulk(recs: list) -> None:
    if not recs:
        return
    # اصلاح (DB-001): درجِ انبوه (مهاجرت JSON) نباید از SIGNALS_CAP عبور کند.
    recs = list(recs)[-SIGNALS_CAP:]
    with _lock:
        c = conn()
        c.executemany(
            """INSERT INTO signals(ts, skey, symbol, pair, interval, direction,
                                   price, score, entry, stop_loss, take_profits, generated_at)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",
            [(r.get("ts"), r.get("key"), r.get("symbol"), r.get("pair"), r.get("interval"),
              r.get("direction"), r.get("price"), r.get("score"), r.get("entry"),
              r.get("stop_loss"), json.dumps(r.get("take_profits", []), ensure_ascii=False),
              r.get("generated_at")) for r in recs],
        )
        c.commit()


# ----------------------------------------------------------------- لاگ‌ها
_log_writes: dict = {}


def add_log(channel: str, entry: dict, cap: int = 500) -> dict:
    """یک ردیفِ لاگ درج می‌کند (با مهرِ زمان) و کانال را دوره‌ای تا سقف هرس می‌کند."""
    rec = {"ts": time.time(), **entry}
    with _lock:
        c = conn()
        c.execute(
            "INSERT INTO logs(channel, ts, data) VALUES(?,?,?)",
            (channel, rec["ts"], json.dumps(rec, ensure_ascii=False)),
        )
        n = _log_writes.get(channel, 0) + 1
        _log_writes[channel] = n
        if n % _TRIM_EVERY == 0:               # هرسِ دوره‌ای به‌جای هر درج
            c.execute(
                """DELETE FROM logs WHERE channel=? AND id NOT IN
                   (SELECT id FROM logs WHERE channel=? ORDER BY id DESC LIMIT ?)""",
                (channel, channel, cap),
            )
        c.commit()
    return rec


def get_logs(channel: str, limit: int = 200) -> list:
    """جدیدترین لاگ‌های یک کانال (newest-first)."""
    rows = query(
        "SELECT data FROM logs WHERE channel=? ORDER BY id DESC LIMIT ?",
        (channel, limit),
    )
    out = []
    for r in rows:
        try:
            out.append(json.loads(r["data"]))
        except Exception:  # noqa
            pass
    return out


def count_logs(channel: str) -> int:
    return query("SELECT COUNT(*) AS n FROM logs WHERE channel=?", (channel,))[0]["n"]


def clear_logs(channel: str) -> None:
    execute("DELETE FROM logs WHERE channel=?", (channel,))


# ----------------------------------------------------------------- مهاجرتِ یک‌باره از JSON
def _retire_json(path: str) -> None:
    """فایلِ JSONِ قدیمی را پس از مهاجرتِ موفق به .migrated تغییرِ نام می‌دهد
    تا دیگر (مثلاً پس از پاک‌کردنِ تاریخچه) دوباره وارد نشود؛ دادهٔ اصلی هم گم نمی‌شود."""
    try:
        if os.path.exists(path):
            os.replace(path, path + ".migrated")
    except Exception:  # noqa
        pass


def migrate_signals_from_json(path: str) -> int:
    """اگر جدولِ signals خالی است، رکوردهای فایلِ JSONِ قدیمی را وارد می‌کند (دقیقاً یک‌بار)."""
    with _lock:
        if not os.path.exists(path):
            return 0
        if count_signals() > 0:
            _retire_json(path)      # قبلاً مهاجرت شده؛ فایل را بازنشسته کن
            return 0
        try:
            with open(path, encoding="utf-8") as f:
                items = json.load(f)
        except Exception:  # noqa
            return 0
        if not isinstance(items, list) or not items:
            _retire_json(path)
            return 0
        add_signals_bulk(items)
        _retire_json(path)
        return len(items)


def migrate_logs_from_json(channel: str, path: str, cap: int = 500) -> int:
    """اگر کانالِ لاگ خالی است، فایلِ JSONِ قدیمی را وارد می‌کند (دقیقاً یک‌بار)."""
    with _lock:
        if not os.path.exists(path):
            return 0
        if count_logs(channel) > 0:
            _retire_json(path)
            return 0
        try:
            with open(path, encoding="utf-8") as f:
                items = json.load(f)
        except Exception:  # noqa
            return 0
        if not isinstance(items, list) or not items:
            _retire_json(path)
            return 0
        items = items[-cap:]
        c = conn()
        c.executemany(
            "INSERT INTO logs(channel, ts, data) VALUES(?,?,?)",
            [(channel, (it.get("ts") if isinstance(it, dict) else None),
              json.dumps(it, ensure_ascii=False)) for it in items],
        )
        c.commit()
        _retire_json(path)
        return len(items)
