@echo off
REM ============================================================================
REM  install_autostart_vps.bat  --  اجرای خودکارِ برنامه هنگامِ ورود به VPS
REM  یک Task در Windows Task Scheduler می‌سازد تا پس از هر ورود (logon) به VPS،
REM  برنامه به‌صورتِ خودکار اجرا شود. (متاتریدر ۵ هم به نشستِ لاگین‌شده نیاز دارد،
REM  پس تریگرِ ورود مناسب‌ترین حالت برای VPS ویندوز است.)
REM
REM  اجرا با دسترسیِ Administrator (روی فایل راست‌کلیک ^> Run as administrator).
REM  برای حذف:  schtasks /Delete /TN "BTC_Agent_Dashboard" /F
REM ============================================================================
setlocal
cd /d "%~dp0"

set TASKNAME=BTC_Agent_Dashboard
set RUNCMD="%~dp0run_vps.bat"

echo.
echo ساختِ Taskِ اجرای خودکار: %TASKNAME%
echo دستورِ اجرا: %RUNCMD%
echo.

schtasks /Create /TN "%TASKNAME%" /TR %RUNCMD% /SC ONLOGON /RL HIGHEST /F
if errorlevel 1 (
    echo [X] ساختِ Task ناموفق بود. مطمئن شوید این فایل را با دسترسیِ Administrator اجرا کرده‌اید.
    pause
    exit /b 1
)

echo.
echo ============================================================
echo   انجام شد. از این پس با هر ورود به VPS، برنامه خودکار اجرا می‌شود.
echo   اجرای فوریِ همین حالا:   schtasks /Run /TN "%TASKNAME%"
echo   توقف/حذفِ اجرای خودکار:  schtasks /Delete /TN "%TASKNAME%" /F
echo ============================================================
pause
endlocal
