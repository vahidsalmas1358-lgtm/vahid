# -*- coding: utf-8 -*-
"""رگرسیونِ کیفیتِ تحلیلِ فاندامنتال/سنتیمنتال (پاسخ به «به درستی انجام نمی‌شود»).

۱) صحتِ معناییِ سنتیمنت (علامت/مقیاس):
   • DXY: دلارِ قوی → منفی برای طلا/EURUSD (k=-1) و مثبت برای USDJPY (k=+1).
   • VIX: نوسانِ پایین/کاهشی → مثبتِ سهام؛ بالا → منفی.
   • FNG: طمع → امتیازِ منفیِ کنترین؛ ترس → مثبت.
۲) FUND-MACRO-001: فاندامنتالِ غیرکریپتو علاوه بر مومنتومِ قیمت، «رویدادهای کلانِ
   پیش‌رو» (تقویمِ اقتصادیِ رایگان) را هم دارد — با ارزهای درستِ هر نماد.
۳) کریپتو دست‌نخورده (CoinGecko + FNG).
"""
import time

import data_sources as ds
import engine

PASS = 0
FAIL = 0


def chk(name, cond, detail=""):
    global PASS, FAIL
    if cond:
        PASS += 1
    else:
        FAIL += 1
        print(f"   FAIL  {name} — {str(detail)[:200]}")


print("=" * 72)
print(" کیفیتِ فاندامنتال/سنتیمنتال: علامت‌ها، مقیاس‌ها و رویدادهای کلان")
print("=" * 72)

# ── ۱) DXY: جهت‌داریِ درست با k (بدونِ شبکه — ورودیِ کنترل‌شده)
mkdxy = lambda k, chg: {"ok": True, "kind": "dxy", "value": 50, "classification": "",
                        "dxy": 100.0, "dxy_chg_5d": chg, "bull": chg * k, "dxy_k": k}
a = engine.analyze_sentiment(mkdxy(-1, +2.0))   # دلار قوی، طلا/یورو
chk("DXY k=-1: دلارِ قوی → امتیازِ منفی", a["score"] < 0, a["score"])
a = engine.analyze_sentiment(mkdxy(+1, +2.0))   # دلار قوی، USDJPY
chk("DXY k=+1: دلارِ قوی → امتیازِ مثبت", a["score"] > 0, a["score"])
a = engine.analyze_sentiment(mkdxy(-1, -2.0))   # دلار ضعیف، طلا
chk("DXY k=-1: دلارِ ضعیف → مثبت", a["score"] > 0, a["score"])
chk("DXY: برچسبِ ردیف‌ها (شاخص دلار + تغییر ۵ روزه)",
    [x["name"] for x in a["signals"]] == ["شاخص دلار (DXY)", "تغییر ۵ روزه دلار"],
    [x["name"] for x in a["signals"]])

# ── VIX
mkvix = lambda val, chg: {"ok": True, "kind": "vix", "value": val, "classification": "",
                          "vix": 15.0, "vix_chg_5d": chg}
chk("VIX آرام/کاهشی → مثبتِ سهام", engine.analyze_sentiment(mkvix(63, -3.0))["score"] > 0, "")
chk("VIX بالا/افزایشی → منفیِ سهام", engine.analyze_sentiment(mkvix(30, +8.0))["score"] < 0, "")

# ── FNG (کنترین)
mkfng = lambda v: {"ok": True, "kind": "fng", "value": v, "classification": "x", "history": [v]}
chk("FNG طمع (۸۰) → منفیِ کنترین", engine.analyze_sentiment(mkfng(80))["score"] < 0, "")
chk("FNG ترس (۲۰) → مثبتِ کنترین", engine.analyze_sentiment(mkfng(20))["score"] > 0, "")

# ── نگاشتِ مقیاسِ خامِ ارائه‌دهنده‌ها (با ورودیِ کنترل‌شده، بدونِ شبکه)
import pandas as pd
_real_chart = ds._yahoo_chart
try:
    ds._yahoo_chart = lambda *a, **k: pd.DataFrame(
        {"close": [20, 19, 18, 17, 16, 15, 12.0]})
    v = ds._vix_sentiment()
    chk("VIX خام ۱۲ → value≈۷۰ (آرامش) و classification مثبت",
        v["value"] == 70 and "مثبت" in v["classification"], v)
finally:
    ds._yahoo_chart = _real_chart

# ── ۲) FUND-MACRO-001 با تقویمِ ماک (قطعی)
import news as news_mod
_real_fetch = news_mod.fetch
now = time.time()
news_mod.fetch = lambda force=False, source="both": {"ok": True, "events": [
    {"title": "CPI YoY", "country": "USD", "impact": "High", "impact_rank": 3, "ts": now + 5 * 3600},
    {"title": "Fed Speech", "country": "USD", "impact": "Medium", "impact_rank": 2, "ts": now + 2 * 3600},
    {"title": "ECB Rate", "country": "EUR", "impact": "High", "impact_rank": 3, "ts": now + 30 * 3600},
    {"title": "Old Event", "country": "USD", "impact": "High", "impact_rank": 3, "ts": now - 3600},
    {"title": "Low thing", "country": "USD", "impact": "Low", "impact_rank": 1, "ts": now + 3 * 3600},
    {"title": "Far CPI", "country": "USD", "impact": "High", "impact_rank": 3, "ts": now + 100 * 3600},
]}
try:
    for key in ("fund:XAU", "fund:EURUSD", "fund:USDJPY"):
        try:
            ds._cache.pop(key, None)
        except Exception:  # noqa
            pass
    f = ds.get_fundamentals("XAU")
    ev = f.get("macro_events") or []
    chk("طلا: فقط ارزِ USD", f.get("macro_currencies") == ["USD"], f.get("macro_currencies"))
    chk("طلا: رویدادهای معتبر (High اول، بدونِ گذشته/کم‌اثر/دور)",
        [e["title"] for e in ev] == ["CPI YoY", "Fed Speech"], [e["title"] for e in ev])
    a = engine.analyze_fundamental(f)
    rows = [x for x in a["signals"] if "رویداد کلان" in x["name"]]
    chk("طلا: ردیف‌های 📅 در تحلیلِ فاندامنتال", len(rows) == 2
        and rows[0]["value"] == "CPI YoY" and "ساعت دیگر" in rows[0]["note"], rows[:1])

    f = ds.get_fundamentals("EURUSD")
    chk("EURUSD: هر دو ارزِ جفت (EUR+USD)", f.get("macro_currencies") == ["EUR", "USD"],
        f.get("macro_currencies"))
    chk("EURUSD: رویدادِ EUR هم آمده", any(e["country"] == "EUR" for e in f.get("macro_events") or []),
        f.get("macro_events"))
    f = ds.get_fundamentals("USDJPY")
    chk("USDJPY: ارزها USD+JPY", f.get("macro_currencies") == ["USD", "JPY"],
        f.get("macro_currencies"))
finally:
    news_mod.fetch = _real_fetch

# ── ۳) کریپتو: بدونِ رویدادِ کلان (رفتارِ قبلی) و FNG برقرار
fb = ds.get_fundamentals("BTC")
chk("BTC: ساختارِ کریپتو دست‌نخورده (بدونِ macro_events)", "macro_events" not in fb, list(fb)[:6])
sb = ds.get_sentiment("BTC")
chk("BTC: سنتیمنت FNG", sb.get("kind") == "fng" and sb.get("ok") is True, sb.get("kind"))

print("\n" + "=" * 72)
print(f"  نتیجه: {PASS} پاس · {FAIL} ناموفق")
print("=" * 72)
raise SystemExit(1 if FAIL else 0)
