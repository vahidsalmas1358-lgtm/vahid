# -*- coding: utf-8 -*-
"""آزمونِ «صداقتِ لاگِ ارسال» — بازتولیدِ سناریوی گزارش‌شدهٔ کاربر:

«مدل هوش مصنوعی وصل، روشِ ارسال = تأییدِ دوگانه، در لاگ ثبت شد که معاملهٔ SHORT
اتریوم به متاتریدر ارسال شد — ولی در MT5 معامله‌ای باز نشده بود.»

ریشه‌ها و رفتارِ درستِ موردِانتظار پس از اصلاح (DISP-TRUTH-001..004):
  ۱) MT5 در دسترس نیست (کتابخانه/اتصال) → ارسالِ خودکار «شبیه‌سازی» می‌شود؛ باید
     با سطحِ warn و متنِ صریح «معامله‌ای در متاتریدر باز نشد» لاگ شود، تیکتی ادعا
     نشود و جهتِ ارسال هم ثبت نشود (تا بعدِ وصل‌شدن دوباره تلاش شود).
  ۲) ارسالِ واقعیِ موفق → لاگِ success همراه با «تیکت‌ها=[…]» و پوزیشنِ واقعی.
  ۳) ارسالِ واقعیِ ناموفق (مثلاً AutoTrading خاموش = retcode 10027) → لاگِ error با
     راهنمای فارسیِ علت؛ جهت ثبت نشود تا چرخهٔ بعد دوباره تلاش کند.
  ۴) execution=pending → لاگِ success ولی با توضیحِ «سفارشِ معلق؛ پوزیشن تا رسیدنِ
     قیمت باز نمی‌شود».
  ۵) مسیرِ ربات: فورواردِ شبیه‌سازی‌شده باید در رکورد/پاسخ simulated=True و دلیلِ
     هشدار داشته باشد.
  ۶) ارسالِ دستی /api/mt5/send بدونِ dry_run وقتی MT5 نیست → لاگِ warn «شبیه‌سازی».
"""
import os as _os_env; _os_env.environ.setdefault("BTC_AGENT_ALLOW_INSECURE_ROBOT", "1")  # محیط تست
import shutil

import app
import robots
import dispatch
import server_log
import mock_mt5
import mt5_bridge as mb
import market_hours as mh

PASS = 0
FAIL = 0


def chk(name, cond, detail=""):
    global PASS, FAIL
    if cond:
        PASS += 1
    else:
        FAIL += 1
        print(f"   FAIL  {name} — {str(detail)[:220]}")


# ───────────────────────── محیطِ آزمون ─────────────────────────
for i, f in enumerate(("mt5_config.json", "dispatch_config.json", "robot_config.json")):
    shutil.copy(f, f"/tmp/dtt_{i}.bak")

app.app.config["TESTING"] = True
client = app.app.test_client()
_real_status = mh.status
mh.status = lambda s, now=None: {"open": True, "state": "open", "reason": "",
                                 "asset_class": "crypto", "always_open": True}

# سیگنالِ ساختگیِ کاملِ ETH SHORT (مطابقِ قراردادِ data در /api/signal)
PRICE = 2650.0
DATA = {
    "symbol": "ETH", "direction": "SHORT", "internal_score": -42.0,
    "total_score": -42.0, "price": PRICE, "atr": 12.0,
    "plan": {"direction": "SHORT", "entry": PRICE,
             "stop_loss": PRICE + 15.0, "risk_per_unit": 15.0,
             "take_profits": [{"price": PRICE - 15.0, "label": "TP1", "rr": 1.0, "close_pct": 40},
                              {"price": PRICE - 27.0, "label": "TP2", "rr": 1.8, "close_pct": 30},
                              {"price": PRICE - 40.0, "label": "TP3", "rr": 2.67, "close_pct": 30}]},
    "technical": {"supports": [PRICE - 20, PRICE - 40], "resistances": [PRICE + 20, PRICE + 40],
                  "fibonacci": None, "conf_supports": [], "conf_resistances": []},
}

dispatch.save_config({"program_enabled": True, "program_source": "internal",
                      "program_min_internal": 15, "program_min_ai": 15,
                      "news_filter_enabled": False, "schedule_filter_enabled": False})
mb.save_config({"market_hours_guard": False, "news_filter_enabled": False,
                "max_daily_trades": 0, "max_daily_risk_pct": 0,
                "allowed_symbols": [], "manage_positions": False,
                "risk_mode": "fixed", "default_volume": 0.1,
                "tp_mode": "split", "execution": "market", "magic": 532025,
                "symbol_map": {"ETH": "ETHUSD"}})


def last_mt5out():
    rows = [r for r in server_log.get(limit=1000) if r.get("cat") == "mt5_out"]
    return rows[-1] if rows else {}


def fresh_key():
    app._last_dispatch_dir.clear()


def dispatch_once():
    app._program_auto_dispatch(DATA, "ETH", "15m", broker="ETHUSD")


print("=" * 72)
print(" آزمونِ صداقتِ لاگِ ارسال (بازتولیدِ «لاگ می‌گوید ارسال شد، MT5 خالی است»)")
print("=" * 72)

# ───────── سناریو ۱: بازتولیدِ عینِ مشکلِ کاربر — MT5 در دسترس نیست ─────────
print("\n── ۱) MT5 در دسترس نیست → قبلاً لاگِ «موفق» می‌خورد؛ حالا هشدارِ شفاف ──")
mb.MT5_AVAILABLE = False
mb.mt5 = None
server_log.clear()
fresh_key()
dispatch_once()
e = last_mt5out()
chk("لاگ ثبت شده", bool(e), "هیچ رکوردی نیست")
chk("سطحِ لاگ warn است نه success", e.get("level") == "warn", e.get("level"))
chk("متن صریحاً می‌گوید معامله‌ای باز نشد",
    "شبیه‌سازی" in e.get("msg", "") and "باز نشد" in e.get("msg", ""), e.get("msg"))
chk("هیچ تیکتی ادعا نشده", "تیکت" not in (e.get("msg", "") + e.get("detail", "")), e.get("detail"))
chk("راهنمای رفع (ویندوز/MetaTrader5) در جزئیات هست",
    "MetaTrader5" in e.get("detail", "") or "ویندوز" in e.get("detail", ""), e.get("detail"))
chk("جهت ثبت نشده (تلاشِ مجدد ممکن بماند)", not app._last_dispatch_dir,
    dict(app._last_dispatch_dir))

# ───────── سناریو ۲: ارسالِ واقعیِ موفق با بروکرِ شبیه‌سازی‌شده ─────────
print("\n── ۲) ارسالِ واقعیِ موفق → لاگِ success + تیکت‌ها + پوزیشنِ واقعی ──")
b = mock_mt5.Broker(balance=100000)
b.add_symbol("ETHUSD", digits=2, point=0.01, volume_min=0.01, volume_step=0.01,
             stops_level=10, tick_value=1.0, tick_size=0.01, price=PRICE)
for k in dir(mock_mt5):
    if k.isupper():
        setattr(b, k, getattr(mock_mt5, k))
mb.mt5 = b
mb.MT5_AVAILABLE = True
mb._conn.update(connected=True, error=None, since=1.0)
server_log.clear()
fresh_key()
dispatch_once()
e = last_mt5out()
chk("سطحِ لاگ success", e.get("level") == "success", e.get("level"))
chk("تیکت‌ها در لاگ آمده", "تیکت‌ها=" in e.get("detail", ""), e.get("detail"))
chk("پوزیشنِ واقعی باز شده (۳ لگِ split)", len(b.positions) == 3, len(b.positions))
chk("جهت ثبت شده (جلوگیری از تکرار)",
    app._last_dispatch_dir.get("ETHUSD:15m") == "SHORT", dict(app._last_dispatch_dir))
sum_v = round(sum(p.volume for p in b.positions.values()), 8)
chk("مجموعِ حجمِ لگ‌ها = حجمِ کانفیگ", abs(sum_v - 0.1) < 1e-9, sum_v)
for p in b.positions.values():
    chk(f"لگ {p.ticket}: SHORT با SL/TP سمتِ درست",
        p.type == 1 and p.sl > p.price_open and (p.tp == 0 or p.tp < p.price_open),
        f"sl={p.sl} tp={p.tp} open={p.price_open}")
b.positions.clear(); mb._pos_state.clear(); mb._partial_plans.clear()

# تکرارِ همان جهت → نباید دوباره ارسال شود
server_log.clear()
dispatch_once()
chk("سیگنالِ هم‌جهتِ تکراری دوباره ارسال نمی‌شود",
    not last_mt5out() and len(b.positions) == 0,
    f"log={last_mt5out().get('msg')} pos={len(b.positions)}")

# ───────── سناریو ۳: AutoTrading خاموش (retcode 10027) ─────────
print("\n── ۳) ترمینال AutoTrading خاموش → لاگِ error با راهنمای فارسی ──")
_orig_send = b.order_send
b.order_send = lambda req: mock_mt5._Obj(retcode=10027, comment="AutoTrading disabled by client",
                                         order=0, deal=0, price=0.0, volume=0.0)
server_log.clear()
fresh_key()
dispatch_once()
e = last_mt5out()
chk("سطحِ لاگ error", e.get("level") == "error", e.get("level"))
chk("راهنمای «Algo Trading را روشن کنید» در لاگ هست",
    "Algo Trading" in e.get("detail", "") or "AutoTrading" in e.get("detail", ""), e.get("detail"))
chk("retcode 10027 در لاگ هست", "10027" in e.get("detail", ""), e.get("detail"))
chk("جهت ثبت نشده (تلاشِ مجدد ممکن)", not app._last_dispatch_dir, dict(app._last_dispatch_dir))
chk("پوزیشنی باز نشده", len(b.positions) == 0, len(b.positions))
b.order_send = _orig_send

# ───────── سناریو ۴: execution=pending → توضیحِ صریح در لاگ ─────────
print("\n── ۴) سفارشِ معلق → لاگ می‌گوید پوزیشن هنوز باز نشده ──")
mb.save_config({"execution": "pending"})
server_log.clear()
fresh_key()
dispatch_once()
e = last_mt5out()
chk("ارسالِ معلق موفق", e.get("level") == "success", f"{e.get('level')} {e.get('detail')}")
chk("توضیحِ «سفارشِ معلق … باز نمی‌شود» در لاگ هست", "معلق" in e.get("detail", ""), e.get("detail"))
chk("سفارش در صفِ معلق است، نه پوزیشن", len(b.pending) >= 1 and len(b.positions) == 0,
    f"pending={len(b.pending)} pos={len(b.positions)}")
b.pending.clear()
mb.save_config({"execution": "market"})

# ───────── سناریو ۵: مسیرِ ربات — فورواردِ شبیه‌سازی‌شده آشکار شود ─────────
print("\n── ۵) ربات: MT5 قطع → forwarded ولی simulated=True + دلیلِ هشدار ──")
mb.MT5_AVAILABLE = False
mb.mt5 = None
robots.save_config({"enabled": True, "auto_forward": True, "filter_mode": "internal",
                    "min_internal_score": 15, "conflict_guard_enabled": False,
                    "dedupe_window_sec": 0.0, "aggregate_window_sec": 0.0,
                    "block_duplicate_open": False, "block_opposite_open": False,
                    "shared_secret": ""})
dispatch.save_config({"news_filter_enabled": False, "schedule_filter_enabled": False})
_real_sig = app._signal_for
app._signal_for = lambda sym, tf, with_ai=False: (DATA, "ETH", "ETHUSD")
r = client.post("/api/robot/order", json={"sym": "ETHUSD", "side": "sell", "lots": 0.05,
                                          "robot": "truth-bot"})
app._signal_for = _real_sig
d = r.get_json() or {}
chk("ربات: پاسخ ۲۰۰ و forwarded", r.status_code == 200 and d.get("forwarded") is True,
    f"st={r.status_code} fwd={d.get('forwarded')}")
chk("ربات: simulated=True (قبلاً False بود)", d.get("simulated") is True, d.get("simulated"))
reasons = " ".join(((d.get("eval") or {}).get("reasons")) or [])
chk("ربات: دلیلِ هشدار «معامله‌ای باز نشده» در eval", "باز نشده" in reasons, reasons[:150])
rb_logs = [x for x in server_log.get(limit=200) if x.get("cat") == "robot"]
chk("ربات: هشدارِ warn در لاگِ سرور", any(x.get("level") == "warn" and "شبیه‌سازی" in x.get("msg", "")
                                          for x in rb_logs), [x.get("msg") for x in rb_logs][-2:])

# ───────── سناریو ۶: ارسالِ دستی بدونِ dry_run وقتی MT5 نیست ─────────
print("\n── ۶) ارسالِ دستی: درخواستِ واقعی ولی MT5 نیست → warn «شبیه‌سازی» ──")
server_log.clear()
r = client.post("/api/mt5/send", json={"symbol": "ETH", "tf": "15m",
                                       "direction": "SHORT", "volume": 0.1})
e = last_mt5out()
chk("پاسخ ۲۰۰ (پیش‌نمایش)", r.status_code == 200, r.status_code)
chk("لاگ warn با متنِ صریح", e.get("level") == "warn" and "باز نشد" in e.get("msg", ""),
    f"{e.get('level')} {e.get('msg')}")
chk("علتِ شبیه‌سازی در جزئیات", "علت=" in e.get("detail", ""), e.get("detail"))

# ───────── بازگردانی ─────────
mh.status = _real_status
for i, f in enumerate(("mt5_config.json", "dispatch_config.json", "robot_config.json")):
    shutil.copy(f"/tmp/dtt_{i}.bak", f)

print("\n" + "=" * 72)
print(f"  نتیجه: {PASS} پاس · {FAIL} ناموفق")
print("=" * 72)
raise SystemExit(1 if FAIL else 0)
