# -*- coding: utf-8 -*-
"""تستِ سناریوی واقعی (end-to-end) با payloadهای دقیقِ دو رباتِ کاربر.

این تست به سرورِ زندهٔ (http://127.0.0.1:8000) وصل می‌شود و دقیقاً همان چیزی را
می‌فرستد که دو رباتِ واقعیِ کاربر می‌فرستند:

  • SP2L_Advanced_Bot  (رباتِ پایتون)  → XAUUSD، تک‌TP، magic=8، robot_id=SP2L_Advanced
  • SmartGoldScalperPro (اکسپرتِ MQL5) → platform=mql5، XAUUSD، آرایهٔ take_profits

هر سناریو در حالت‌های internal / ai / both آزموده می‌شود و کلِ زنجیره
(نگاشتِ نماد → نرمال‌سازی → اعتبارسنجی → ارزیابی → ارسالِ dry-run) بررسی می‌گردد.

اجرا:  python3 scenario_realbots_test.py
"""
import os as _os_env; _os_env.environ.setdefault("BTC_AGENT_ALLOW_INSECURE_ROBOT", "1")  # محیط تست
import sys
import requests

BASE = "http://127.0.0.1:8000"
PASS = 0
FAIL = 0


def check(name, cond, detail=""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"  \033[32mPASS\033[0m  {name}")
    else:
        FAIL += 1
        print(f"  \033[31mFAIL\033[0m  {name}   {detail}")


def set_mode(mode, match=False, min_i=0, min_a=0, conflict_guard=False):
    """پیکربندیِ پُلِ ربات برای یک سناریو."""
    requests.post(f"{BASE}/api/robot/config", json={
        "enabled": True, "filter_mode": mode,
        "require_direction_match": match,
        "min_internal_score": min_i, "min_ai_score": min_a,
        "auto_forward": True, "respect_robot_volume": True,
        "conflict_guard_enabled": conflict_guard,
        "shared_secret": "",
        # تایم‌فریمِ پیش‌فرض را با همان تایم‌فریمی که «جهتِ هم‌سو» از آن گرفته می‌شود
        # (internal_dir → 5m) یکی می‌کنیم تا رباتی که tf نمی‌فرستد (SP2L) هم روی
        # همان تایم‌فریم ارزیابی شود و آزمونِ هم‌سویی به اختلافِ تایم‌فریم حساس نباشد.
        "default_tf": "5m",
    }, timeout=10)


def post_robot(payload, test=True):
    url = f"{BASE}/api/robot/{'test' if test else 'order'}"
    return requests.post(url, json=payload, timeout=30).json()


def internal_dir(symbol="XAUUSD", tf="5m"):
    r = requests.get(f"{BASE}/api/signal", params={"symbol": symbol, "tf": tf}, timeout=30).json()
    d = r.get("data", r)
    return d.get("direction"), d


# ---- payloadهای دقیقِ دو رباتِ کاربر -----------------------------------------
def sp2l_payload(direction="BUY", entry=3900.0, sl=3890.0, tp=3910.0):
    """عینِ آنچه SP2L_Advanced_Bot.bridge.py با bridge.send(...) می‌فرستد."""
    return {
        "symbol": "XAUUSD", "direction": direction, "volume": 0.01,
        "entry": entry, "sl": sl, "tp": tp,        # ← تک‌TP (نه لیست)
        "magic": 8, "robot_id": "SP2L_Advanced",
        "comment": "SP2L Advanced Trader", "platform": "python",
    }


def sgs_payload(direction="BUY", entry=3900.0, sl=3890.0, tps=(3910.0, 3920.0, 3930.0)):
    """عینِ آنچه SmartGoldScalperPro (RobotBridge.mqh SendMultiTP) می‌فرستد."""
    return {
        "platform": "mql5", "symbol": "XAUUSD", "direction": direction,
        "volume": 0.01, "sl": sl, "take_profits": list(tps),   # ← آرایهٔ TP
        "entry": entry, "tf": "M5", "robot_id": "SmartGoldScalperPro", "magic": 20250929,
    }


def main():
    print("=" * 64)
    print(" تستِ سناریوی واقعیِ دو رباتِ کاربر روی طلا (XAUUSD) — end-to-end")
    print("=" * 64)

    # سلامتِ سرور + جهتِ زندهٔ طلا
    try:
        idir, _ = internal_dir()
    except Exception as e:  # noqa
        print("سرور در دسترس نیست:", e)
        sys.exit(2)
    print(f"\nجهتِ زندهٔ تحلیلِ داخلیِ طلا (XAUUSD/5m): {idir}")
    aligned = "BUY" if idir == "LONG" else "SELL" if idir == "SHORT" else "BUY"
    opposite = "SELL" if aligned == "BUY" else "BUY"

    # ---------------------------------------------------------------- [۱]
    print("\n[۱] نگاشتِ نماد و نرمال‌سازیِ payloadِ هر دو ربات")
    set_mode("internal", match=False, min_i=0)
    r_sp = post_robot(sp2l_payload(aligned), test=True)
    r_sg = post_robot(sgs_payload(aligned), test=True)
    o_sp = r_sp.get("order", {})
    o_sg = r_sg.get("order", {})
    check("SP2L: نماد XAUUSD شناسایی شد", o_sp.get("symbol") == "XAUUSD", o_sp)
    check("SP2L: تک‌TP به لیستِ یک‌عضوی نرمال شد", o_sp.get("tps") == [3910.0], o_sp)
    check("SP2L: حجمِ 0.01 و جهت درست", o_sp.get("volume") == 0.01 and o_sp.get("direction") in ("LONG", "SHORT"), o_sp)
    check("EA(SGS): platform=mql5 و ۳ TP در آرایه", o_sg.get("tps") == [3910.0, 3920.0, 3930.0], o_sg)
    check("EA(SGS): robot_id حفظ شد", o_sg.get("robot_id") == "SmartGoldScalperPro", o_sg)
    ev_sp = r_sp.get("eval", {})
    check("هر دو به نمادِ داخلیِ XAU نگاشت شدند (تحلیلِ داخلی ساخته شد)",
          isinstance(ev_sp.get("internal"), dict) and "error" not in ev_sp.get("internal", {}), ev_sp.get("internal"))

    # ---------------------------------------------------------------- [۲]
    print("\n[۲] حالتِ internal — جهتِ هم‌سو با تحلیلِ داخلی (باید تأیید و شبیه‌سازی شود)")
    if idir in ("LONG", "SHORT"):
        set_mode("internal", match=True, min_i=0)
        r1 = post_robot(sp2l_payload(aligned), test=True)
        r2 = post_robot(sgs_payload(aligned), test=True)
        check("SP2L internal هم‌سو: تأیید شد", r1.get("approved") is True, r1.get("eval", {}).get("reasons"))
        check("SP2L internal هم‌سو: شبیه‌سازی شد (dry-run)", r1.get("simulated") is True, r1)
        check("EA(SGS) internal هم‌سو: تأیید و شبیه‌سازی", r2.get("approved") is True and r2.get("simulated") is True, r2)
        # جهتِ مخالف با require_match → باید رد شود
        set_mode("internal", match=True, min_i=0)
        r3 = post_robot(sp2l_payload(opposite), test=True)
        check("SP2L internal مخالف + الزامِ تطبیق: رد شد", r3.get("approved") is False, r3.get("eval", {}).get("reasons"))
    else:
        print("  (طلا اکنون خنثی است؛ تستِ جهت‌دار رد می‌شود — رفتارِ درست: خنثی معامله نمی‌سازد)")
        set_mode("internal", match=True, min_i=0)
        r0 = post_robot(sp2l_payload("BUY"), test=True)
        check("SP2L internal در بازارِ خنثی: تأیید نشد (درست)", r0.get("approved") is False, r0)

    # ---------------------------------------------------------------- [۳]
    print("\n[۳] حالت‌های ai و both وقتی هوش مصنوعی پیکربندی نشده (باید امن رد شوند)")
    set_mode("ai", match=False, min_a=0)
    r_ai = post_robot(sp2l_payload(aligned), test=True)
    check("ai بدونِ کلیدِ AI: تأیید نشد (رفتارِ امن)", r_ai.get("approved") is False, r_ai.get("eval", {}))
    check("ai: ارسال/شبیه‌سازی رخ نداد", not r_ai.get("forwarded"), r_ai)
    set_mode("both", match=False, min_i=0, min_a=0)
    r_both = post_robot(sgs_payload(aligned), test=True)
    check("both بدونِ کلیدِ AI: تأیید نشد (رفتارِ امن)", r_both.get("approved") is False, r_both.get("eval", {}))

    # ---------------------------------------------------------------- [۴]
    print("\n[۴] اعتبارسنجی — سیگنال‌های ناقصِ رایجِ اکسپرت‌ها باید تمیز رد شوند")
    set_mode("internal", match=False, min_i=0)
    no_vol = requests.post(f"{BASE}/api/robot/order",
                           json={"symbol": "XAUUSD", "direction": "BUY", "platform": "mql5"}, timeout=15)
    check("سفارشِ بدونِ حجم → HTTP 400", no_vol.status_code == 400, no_vol.status_code)
    bad_dir = requests.post(f"{BASE}/api/robot/order",
                            json={"symbol": "XAUUSD", "direction": "HOLD", "volume": 0.01}, timeout=15)
    check("جهتِ نامعتبر (HOLD) → HTTP 400", bad_dir.status_code == 400, bad_dir.status_code)
    no_sym = requests.post(f"{BASE}/api/robot/order",
                           json={"direction": "BUY", "volume": 0.01}, timeout=15)
    check("سفارشِ بدونِ نماد → HTTP 400", no_sym.status_code == 400, no_sym.status_code)

    # ---------------------------------------------------------------- [۵]
    print("\n[۵] ایمنیِ دکمهٔ «آزمایش» در برابرِ وب‌هوکِ واقعی (با payloadِ همان ربات)")
    set_mode("internal", match=False, min_i=0)
    rt = post_robot(sp2l_payload(aligned), test=True)      # /api/robot/test
    ro = post_robot(sp2l_payload(aligned), test=False)     # /api/robot/order
    check("آزمایش: simulated=True (هیچ معاملهٔ واقعی)", rt.get("simulated") is True, rt)
    # اصلاح (DISP-TRUTH): روی سیستمِ بدونِ MT5، فورواردِ «واقعی» هم ناگزیر فقط
    # شبیه‌سازی است و پاسخ باید صادقانه simulated=True + دلیلِ هشدار بدهد؛ قبلاً
    # simulated=False گزارش می‌شد و کاربر فکر می‌کرد معامله در متاتریدر باز شده.
    _sim_env = bool(((ro.get("forward") or {}).get("simulated"))
                    or ((ro.get("forward") or {}).get("dry_run")))
    if _sim_env:
        _rs = " ".join(((ro.get("eval") or {}).get("reasons")) or [])
        check("واقعی (بدونِ MT5): simulated=True صادقانه + دلیلِ هشدار",
              ro.get("simulated") is True and "باز نشده" in _rs, ro.get("simulated"))
    else:
        check("واقعی: simulated=False (معاملهٔ واقعی ثبت شد)", ro.get("simulated") is False, ro)

    # ---------------------------------------------------------------- [۶]
    print("\n[۶] زنجیرهٔ کاملِ تأیید→ارسال (dry-run) روی یک نمادِ زندهٔ جهت‌دار")
    # مستقل از اینکه طلا الان خنثی است، یک نمادِ جهت‌دار پیدا می‌کنیم تا مسیرِ
    # «تأیید و شبیه‌سازیِ ارسال» و «ردِّ جهتِ مخالف» واقعاً اجرا شود.
    scan = ["BTC", "ETH", "SOL", "WTI", "EURUSD", "GBPUSD", "USDJPY", "SPX", "NASDAQ", "XAU"]
    picked, pdir = None, None
    for s in scan:
        try:
            d, _ = internal_dir(s, "15m")
        except Exception:  # noqa
            continue
        if d in ("LONG", "SHORT"):
            picked, pdir = s, d
            break
    if not picked:
        print("  (هیچ نمادی اکنون جهت‌دار نیست؛ این بخش رد شد)")
    else:
        al = "BUY" if pdir == "LONG" else "SELL"
        op = "SELL" if al == "BUY" else "BUY"
        print(f"  نمادِ انتخاب‌شده: {picked} ({pdir}) — سفارشِ هم‌سو={al} · مخالف={op}")
        # پُلِ ربات با payloadِ سبکِ SP2L روی این نماد (تک‌TP)
        # نکتهٔ مهم: tf باید همان تایم‌فریمِ انتخابِ نماد (15m) باشد؛ وگرنه پل
        # روی default_tf ارزیابی می‌کند که ممکن است آنجا سیگنال خنثی باشد و
        # سفارش به‌درستی رد شود (شکستِ کاذبِ تست، نه باگِ برنامه).
        base = {"symbol": picked, "volume": 0.01, "sl": 1.0, "tp": 999999.0, "tf": "15m",
                "magic": 8, "robot_id": "SP2L_Advanced", "platform": "python"}
        set_mode("internal", match=True, min_i=0)
        ra = post_robot({**base, "direction": al}, test=True)
        check(f"{picked} internal هم‌سو ({al}): تأیید شد",
              ra.get("approved") is True, ra.get("eval", {}).get("reasons"))
        check(f"{picked} internal هم‌سو: شبیه‌سازیِ ارسال انجام شد (forwarded dry-run)",
              ra.get("forwarded") is True and ra.get("simulated") is True, ra)
        fr = ra.get("forward", {}) or {}
        check(f"{picked}: نقشهٔ ارسال‌شده جهتِ درست و dry_run دارد",
              fr.get("direction") == pdir and fr.get("dry_run") is True, fr)
        set_mode("internal", match=True, min_i=0)
        ro2 = post_robot({**base, "direction": op}, test=True)
        check(f"{picked} internal مخالف ({op}) + الزامِ تطبیق: رد شد",
              ro2.get("approved") is False and not ro2.get("forwarded"), ro2.get("eval", {}).get("reasons"))

    # پاک‌سازیِ لاگِ ناشی از تست + بازگرداندنِ پیکربندیِ امن
    requests.delete(f"{BASE}/api/robot/log", timeout=10)
    requests.post(f"{BASE}/api/robot/config", json={
        "filter_mode": "both", "require_direction_match": True,
        "min_internal_score": 15, "min_ai_score": 15,
        "auto_forward": True, "conflict_guard_enabled": True, "enabled": True,
    }, timeout=10)

    print("\n" + "=" * 64)
    print(f"  نتیجه: {PASS} پاس · {FAIL} ناموفق")
    print("=" * 64)
    sys.exit(1 if FAIL else 0)


if __name__ == "__main__":
    main()
