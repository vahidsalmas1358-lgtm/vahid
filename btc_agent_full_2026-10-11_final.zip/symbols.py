"""پیکربندی نمادهای پشتیبانی‌شده و نگاشت آن‌ها به هر منبع داده.

asset_class:
  - "crypto" : داده از OKX/Coinbase/Kraken + CoinGecko + Fear&Greed
  - "metal"  : داده از Yahoo Finance (فیوچرز) + سنتیمنت مبتنی بر شاخص دلار (DXY)
"""

# ── RV-3-2 (بازبینیِ REVIEW_FA): منبعِ واحدِ «درصدِ بستنِ پلهها» ──────────────
# پیش‌تر سه سیستمِ درصدِ جدا وجود داشت: engine (close_pct = 40/35/25)،
# partial_fractions پیش‌فرضِ پل (50/30) و مدلِ analytics. حالا همه از همین دو
# عدد می‌آیند تا Rِ محقق‌شدهٔ گزارش‌ها با استراتژیِ اجراشده یکی باشد.
TP_CLOSE_PCT = [40.0, 35.0, 25.0]              # درصدِ بستنِ TP1/TP2/TP3
PARTIAL_FRACTIONS = [round(x / 100.0, 2)       # معادلِ همان درصدها برای حالتِ partial
                     for x in TP_CLOSE_PCT[:2]]   # → [0.4, 0.35] (۲۵٪ باقی‌مانده تا TP3)

SYMBOLS = {
    "BTC": {"name": "بیت‌کوین", "pair": "BTC/USDT", "asset_class": "crypto",
            "okx": "BTC-USDT", "coinbase": "BTC-USD", "kraken": "XBTUSD", "cg": "bitcoin"},
    "ETH": {"name": "اتریوم", "pair": "ETH/USDT", "asset_class": "crypto",
            "okx": "ETH-USDT", "coinbase": "ETH-USD", "kraken": "ETHUSD", "cg": "ethereum"},
    "SOL": {"name": "سولانا", "pair": "SOL/USDT", "asset_class": "crypto",
            "okx": "SOL-USDT", "coinbase": "SOL-USD", "kraken": "SOLUSD", "cg": "solana"},
    "BNB": {"name": "بی‌ان‌بی", "pair": "BNB/USDT", "asset_class": "crypto",
            "okx": "BNB-USDT", "coinbase": None, "kraken": None, "cg": "binancecoin"},
    "XRP": {"name": "ریپل", "pair": "XRP/USDT", "asset_class": "crypto",
            "okx": "XRP-USDT", "coinbase": "XRP-USD", "kraken": "XRPUSD", "cg": "ripple"},
    "DOGE": {"name": "دوج‌کوین", "pair": "DOGE/USDT", "asset_class": "crypto",
             "okx": "DOGE-USDT", "coinbase": "DOGE-USD", "kraken": "XDGUSD", "cg": "dogecoin"},
    "XAU": {"name": "طلا", "pair": "XAU/USD", "asset_class": "metal",
            "yahoo": "GC=F", "sentiment": "dxy", "dxy_k": -1},
    "XAG": {"name": "نقره", "pair": "XAG/USD", "asset_class": "metal",
            "yahoo": "SI=F", "sentiment": "dxy", "dxy_k": -1},
    "HG": {"name": "مس", "pair": "Copper/USD", "asset_class": "commodity",
           "yahoo": "HG=F", "sentiment": "dxy", "dxy_k": -1},
    "WTI": {"name": "نفت خام (WTI)", "pair": "WTI/USD", "asset_class": "commodity",
            "yahoo": "CL=F", "sentiment": "dxy", "dxy_k": -1},
    "NG": {"name": "گاز طبیعی", "pair": "NatGas/USD", "asset_class": "commodity",
           "yahoo": "NG=F", "sentiment": "dxy", "dxy_k": -1},
    "SPX": {"name": "شاخص S&P 500", "pair": "S&P 500", "asset_class": "index",
            "yahoo": "^GSPC", "sentiment": "vix"},
    "NASDAQ": {"name": "شاخص نزدک", "pair": "NASDAQ", "asset_class": "index",
               "yahoo": "^IXIC", "sentiment": "vix"},
    "EURUSD": {"name": "یورو / دلار", "pair": "EUR/USD", "asset_class": "forex",
               "yahoo": "EURUSD=X", "sentiment": "dxy", "dxy_k": -1},
    "GBPUSD": {"name": "پوند / دلار", "pair": "GBP/USD", "asset_class": "forex",
               "yahoo": "GBPUSD=X", "sentiment": "dxy", "dxy_k": -1},
    "USDJPY": {"name": "دلار / ین", "pair": "USD/JPY", "asset_class": "forex",
               "yahoo": "USDJPY=X", "sentiment": "dxy", "dxy_k": 1},
}

# منابع مرجع سنتیمنت
DXY_SYMBOL = "DX-Y.NYB"   # شاخص دلار آمریکا
VIX_SYMBOL = "^VIX"       # شاخص نوسان بازار سهام


def is_crypto(symbol: str) -> bool:
    return get(symbol).get("asset_class") == "crypto"

DEFAULT = "BTC"


def get(symbol: str) -> dict:
    """پیکربندیِ نماد را برمی‌گرداند و برای نمادِ ناشناس **خطای صریح** می‌دهد.

    اصلاحِ OP5-SYM-STRICT: پیش‌تر `symbols.get("FOOBAR")` بی‌صدا پیکربندیِ BTC را
    برمی‌گرداند؛ یعنی یک اشتباهِ تایپی در نماد می‌توانست به تحلیل/معاملهٔ بیت‌کوین
    تبدیل شود. اکنون نمادِ ناشناس KeyError می‌دهد و مسیرهای رابط باید با
    `resolve()` آن را به پیامِ روشن تبدیل کنند.
    """
    return resolve(symbol, raise_on_missing=True)


def resolve(symbol: str, raise_on_missing: bool = False):
    """پیکربندیِ نماد یا None (بدونِ fallbackِ پنهان به BTC)."""
    key = str(symbol or "").strip().upper()
    if key in SYMBOLS:
        return SYMBOLS[key]
    if raise_on_missing:
        raise KeyError(f"نمادِ پشتیبانی‌نشده: {symbol!r}")
    return None


def valid(symbol: str) -> bool:
    return symbol.upper() in SYMBOLS


def asset_class(symbol: str) -> str:
    return get(symbol).get("asset_class", "crypto")
