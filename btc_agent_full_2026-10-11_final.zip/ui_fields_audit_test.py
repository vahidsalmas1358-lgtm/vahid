# -*- coding: utf-8 -*-
"""ممیزی تک‌به‌تکِ تب‌ها/منوها/قسمت‌ها/فیلدهای برنامه.

  A) یکپارچگیِ UI: هر ارجاعِ $("#id") در جاوااسکریپت باید تعریفِ id داشته باشد
     (فیلد/دکمهٔ شکسته پس از ویرایش‌ها) + هر کلیدِ t('…') در هر دو دیکشنریِ fa/en.
  B) راندتریپِ فیلدهای تنظیماتِ هر تب: مقدارِ آزمایشی POST → GET همان مقدار →
     بازگردانی (ذخیره‌ای که اعمال نشود همین‌جا لو می‌رود).
  C) پیمایشِ همهٔ مسیرهای GETِ برنامه: هیچ‌کدام نباید 500 بدهند.
"""
import os as _os_env; _os_env.environ.setdefault("BTC_AGENT_ALLOW_INSECURE_ROBOT", "1")  # محیط تست
import re
import shutil

import app

PASS = 0
FAIL = 0


def chk(name, cond, detail=""):
    global PASS, FAIL
    if cond:
        PASS += 1
    else:
        FAIL += 1
        print(f"   FAIL  {name} — {str(detail)[:220]}")


CFGS = ("mt5_config.json", "dispatch_config.json", "robot_config.json",
        "alerts_config.json", "ai_config.json", "schedule_config.json")
for i, f in enumerate(CFGS):
    try:
        shutil.copy(f, f"/tmp/ufa_{i}.bak")
    except FileNotFoundError:
        pass

app.app.config["TESTING"] = True
client = app.app.test_client()
UI = open("static/index.html", encoding="utf-8").read()

print("=" * 74)
print(" ممیزی تک‌به‌تک: یکپارچگیِ UI · راندتریپِ فیلدها · پیمایشِ مسیرها")
print("=" * 74)

# ═══ A) یکپارچگیِ UI
refs = set(re.findall(r'\$\(["\']#([A-Za-z_][\w-]*)["\']\)', UI))
defs = set(re.findall(r'id=["\']([A-Za-z_][\w-]*)["\']', UI))
defs |= set(re.findall(r'id=\\"([A-Za-z_][\w-]*)\\"', UI))
missing = sorted(refs - defs)
chk(f"A1: هر {len(refs)} ارجاعِ $(#id) تعریف دارد", not missing, missing[:8])

tkeys = set(re.findall(r"\bt\(['\"](\w+)['\"]\)", UI))
m = re.search(r"const I18N=\{\s*fa:\{(.*?)\},\s*en:\{(.*?)\}\s*\};", UI, re.S)
fa_keys = set(re.findall(r"(\w+)\s*:", m.group(1)))
en_keys = set(re.findall(r"(\w+)\s*:", m.group(2)))
miss_fa = sorted(k for k in tkeys if k not in fa_keys)
miss_en = sorted(k for k in tkeys if k not in en_keys)
chk(f"A2: هر {len(tkeys)} کلیدِ t() در دیکشنریِ fa", not miss_fa, miss_fa[:8])
chk(f"A3: هر {len(tkeys)} کلیدِ t() در دیکشنریِ en", not miss_en, miss_en[:8])
chk("A4: دکمه‌های هر ۱۸ تب", UI.count('data-view=') >= 18, UI.count('data-view='))

# ═══ B) راندتریپِ فیلدهای تنظیماتِ هر تب (API پشتِ فیلدها)
def rt(name, get_url, post_url, patch, path=("data",), restore=None):
    """POST patch → GET → همهٔ کلیدها برابر؛ سپس restore."""
    r = client.post(post_url, json=patch)
    ok = r.status_code == 200
    r2 = client.get(get_url)
    d = r2.get_json() or {}
    for p in path:
        d = (d or {}).get(p) or {}
    if "config" in d and isinstance(d.get("config"), dict):
        d = d["config"]
    bad = {k: (d.get(k), v) for k, v in patch.items() if d.get(k) != v}
    chk(f"B: {name}", ok and not bad, bad or r.status_code)
    if restore:
        client.post(post_url, json=restore)


# — تب متاتریدر (فیلدهای معامله/مدیریت)
rt("متاتریدر: حجم/حالتِ TP/ریسک/اسلیپیج", "/api/mt5/config", "/api/mt5/config",
   {"default_volume": 0.07, "tp_mode": "partial", "risk_mode": "risk_pct",
    "risk_pct": 1.3, "deviation": 37},
   restore={"default_volume": 0.01, "tp_mode": "split", "risk_mode": "fixed",
            "risk_pct": 1.0, "deviation": 20})
rt("متاتریدر: منیجر (بریک‌ایون/تریلینگ/پارشیال)", "/api/mt5/config", "/api/mt5/config",
   {"breakeven_r": 1.4, "breakeven_buffer_pts": 9, "trailing_points": 410,
    "manage_interval": 7},
   restore={"breakeven_r": 1.0, "breakeven_buffer_pts": 5, "trailing_points": 300,
            "manage_interval": 5})
rt("متاتریدر: گاردها (سقفِ معاملات/ریسکِ روزانه/ساعاتِ بازار)", "/api/mt5/config", "/api/mt5/config",
   {"max_daily_trades": 11, "max_daily_risk_pct": 3.5, "market_hours_guard": False},
   restore={"max_daily_trades": 0, "max_daily_risk_pct": 0, "market_hours_guard": True})

# — تب روشِ ارسال (برنامه + خودکارِ سمتِ سرور + گاردها + اخبار/زمان‌بندی)
rt("روش ارسال: منبع/آستانه‌ها", "/api/dispatch/config", "/api/dispatch/config",
   {"program_source": "both", "program_min_internal": 22.0, "program_min_ai": 33.0},
   restore={"program_source": "internal", "program_min_internal": 15.0,
            "program_min_ai": 15.0})
rt("روش ارسال: خودکارِ سمتِ سرور (نمادها/tf/بازه)", "/api/dispatch/config", "/api/dispatch/config",
   {"program_autorun": False, "program_symbols": ["XAU@1h", "BTC"],
    "program_tf": "30m", "program_every_sec": 45},
   restore={"program_autorun": True, "program_symbols": ["BTC"],
            "program_tf": "15m", "program_every_sec": 60})
rt("روش ارسال: گاردِ تکرار/مخالف + رفتارِ معکوس", "/api/dispatch/config", "/api/dispatch/config",
   {"program_block_duplicate_open": False, "program_block_opposite_open": False,
    "program_opposite_action": "close"},
   restore={"program_block_duplicate_open": True, "program_block_opposite_open": True,
            "program_opposite_action": "reverse"})
rt("روش ارسال: فیلترِ اخبار", "/api/dispatch/config", "/api/dispatch/config",
   {"news_filter_enabled": False, "news_impact": "Medium", "news_before_min": 17,
    "news_after_min": 23, "news_source": "ff"},
   restore={"news_filter_enabled": True, "news_impact": "High", "news_before_min": 30,
            "news_after_min": 30, "news_source": "both"})

# — تب ربات‌ها
rt("ربات‌ها: tf پیش‌فرض/حفظِ حجم/داوری", "/api/robot/config", "/api/robot/config",
   {"default_tf": "30m", "respect_robot_volume": False, "dedupe_window_sec": 45.0,
    "aggregate_window_sec": 1.5},
   restore={"default_tf": "5m", "respect_robot_volume": True, "dedupe_window_sec": 60.0,
            "aggregate_window_sec": 2.0})

# — تب هوش مصنوعی
rt("هوش مصنوعی: مدل/دما/توکن/پروکسی/وزن", "/api/ai/config", "/api/ai/config",
   {"model": "test-model-x", "temperature": 0.4, "max_tokens": 777,
    "proxy": "http://127.0.0.1:9999", "signal_weight": 0.45, "use_in_signal": True},
   restore={"model": "gpt-4o-mini", "temperature": 0.7, "max_tokens": 512,
            "proxy": "", "signal_weight": 0.30, "use_in_signal": False})

# — تب هشدارها (تلگرام/ایمیل/خودکار)
r = client.post("/api/alerts/config", json={"telegram": {"enabled": True, "chat_id": "123"},
                                            "auto_alert": True})
d = ((client.get("/api/alerts/config").get_json() or {}).get("data")) or {}
chk("B: هشدارها: تلگرام/خودکار", r.status_code == 200
    and (d.get("telegram") or {}).get("enabled") is True
    and (d.get("telegram") or {}).get("chat_id") == "123" and d.get("auto_alert") is True, d)
client.post("/api/alerts/config", json={"telegram": {"enabled": False, "chat_id": ""},
                                        "auto_alert": False})

# — تب ساعاتِ کار سرور
r = client.post("/api/schedule/config", json={"enabled": True, "on1": "08:00", "off1": "17:00"})
d = ((client.get("/api/schedule/config").get_json() or {}).get("data") or {}).get("config") or {}
chk("B: ساعاتِ کار: بازهٔ ۱", r.status_code == 200 and d.get("enabled") is True
    and d.get("on1") == "08:00" and d.get("off1") == "17:00", d)
client.post("/api/schedule/config", json={"enabled": False, "on1": "", "off1": ""})

# ═══ C) پیمایشِ همهٔ مسیرهای GET — هیچ 500ای مجاز نیست
HEAVY_SKIP = {"/api/optimize", "/api/backtest", "/api/backtest/mt5", "/api/ai/ask_stream"}
PARAMS = {"/api/signal": "?symbol=BTC&tf=15m&ai=0", "/api/mtf": "?symbol=BTC",
          "/api/compare": "?symbols=BTC,ETH", "/api/scan": "?tf=15m",
          "/api/news/check": "?symbol=XAU", "/api/mt5/resolve": "?symbol=BTC",
          "/api/mt5/data/load": "?name=none"}
n_ok = 0
bad_routes = []
for rule in app.app.url_map.iter_rules():
    if "GET" not in rule.methods or "<" in rule.rule or rule.rule.startswith("/static"):
        continue
    if rule.rule in HEAVY_SKIP:
        continue
    url = rule.rule + PARAMS.get(rule.rule, "")
    try:
        resp = client.get(url)
        if resp.status_code >= 500:
            bad_routes.append((rule.rule, resp.status_code))
        else:
            n_ok += 1
    except Exception as e:  # noqa
        bad_routes.append((rule.rule, str(e)[:60]))
chk(f"C: هر {n_ok + len(bad_routes)} مسیرِ GET بدونِ 500", not bad_routes, bad_routes[:6])

for i, f in enumerate(CFGS):
    try:
        shutil.copy(f"/tmp/ufa_{i}.bak", f)
    except FileNotFoundError:
        pass

print("\n" + "=" * 74)
print(f"  نتیجه: {PASS} پاس · {FAIL} ناموفق")
print("=" * 74)
raise SystemExit(1 if FAIL else 0)
