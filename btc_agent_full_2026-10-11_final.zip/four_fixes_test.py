# -*- coding: utf-8 -*-
"""رگرسیونِ چهار اصلاحِ درخواستیِ کاربر:

  ۱) TP-RUNNER-001: پس از TP1، حدهای TP2/TP3 دیگر نادیده گرفته نمی‌شوند —
     لگِ آخر همیشه هدفِ نهایی را می‌گیرد (۱لگ→TP3، ۲لگ→TP1+TP3، ۳لگ→کامل).
  ۲) MT5-FUNDSENT-001: برای نمادهای متاتریدریِ دارای معادلِ داخلی، فاندامنتال/
     سنتیمنت از منابعِ رایگان واکشی و با وزنِ استاندارد ترکیب می‌شود.
  ۳) AUTOPILOT-001: ارسالِ خودکارِ سمتِ سرور — بدونِ بازبودنِ داشبورد/مرورگر.
  ۴) WL-TF-001: تایم‌فریمِ مخصوصِ هر نماد در واچ‌لیست (SYM@TF).
"""
import os as _os_env; _os_env.environ.setdefault("BTC_AGENT_ALLOW_INSECURE_ROBOT", "1")  # محیط تست
import shutil
import time
import random

import app
import dispatch
import engine
import mock_mt5
import mt5_bridge as mb
import market_hours as mh

PASS = 0
FAIL = 0


def chk(name, cond, detail=""):
    global PASS, FAIL
    if cond:
        PASS += 1
    else:
        FAIL += 1
        print(f"   FAIL  {name} — {str(detail)[:220]}")


for i, f in enumerate(("mt5_config.json", "dispatch_config.json")):
    shutil.copy(f, f"/tmp/ff_{i}.bak")
app.app.config["TESTING"] = True
client = app.app.test_client()

print("=" * 72)
print(" رگرسیونِ چهار اصلاحِ کلی (TP-RUNNER · MT5-FUNDSENT · AUTOPILOT · WL-TF)")
print("=" * 72)

# ═══ ۱) TP-RUNNER-001
print("\n── ۱) لگِ آخر همیشه هدفِ نهایی ──")
b = mock_mt5.Broker(balance=100000)
b.add_symbol("X", digits=2, point=0.01, volume_min=0.01, volume_step=0.01, price=100.0)
info = b.symbol_info("X")
tps = [101.0, 102.0, 103.0]
chk("۱ لگ (حجمِ حداقلی) → TP3", mb._legs(0.01, tps, "split", info) == [(0.01, 103.0)],
    mb._legs(0.01, tps, "split", info))
chk("۲ لگ → TP1 و TP3", [t for _, t in mb._legs(0.02, tps, "split", info)] == [101.0, 103.0],
    mb._legs(0.02, tps, "split", info))
chk("۳ لگ → TP1,TP2,TP3", [t for _, t in mb._legs(0.03, tps, "split", info)] == tps, "")
chk("جمعِ حجم حفظ می‌شود", abs(sum(v for v, _ in mb._legs(0.25, tps, "split", info)) - 0.25) < 1e-9, "")
chk("single دست‌نخورده (TP1)", mb._legs(0.05, tps, "single", info) == [(0.05, 101.0)], "")

# partial: پوزیشن با TP نهایی
for k in dir(mock_mt5):
    if k.isupper():
        setattr(b, k, getattr(mock_mt5, k))
mb.mt5 = b
mb.MT5_AVAILABLE = True
mb._conn.update(connected=True, error=None, since=1.0)
_mh = mh.status
mh.status = lambda s, now=None: {"open": True, "state": "open", "reason": ""}
mb.save_config({"market_hours_guard": False, "news_filter_enabled": False,
                "max_daily_trades": 0, "max_daily_risk_pct": 0, "allowed_symbols": [],
                "manage_positions": False, "risk_mode": "fixed", "tp_mode": "partial",
                "execution": "market", "symbol_map": {"XTEST": "X"}})
r = mb.send_order("XTEST", "LONG",
                  {"entry": 100.0, "stop_loss": 99.0,
                   "take_profits": [{"price": p} for p in tps]}, volume=0.2)
mb.stop_manager()
p0 = list(b.positions.values())[0]
chk("partial: TP پوزیشن = هدفِ نهایی (TP3)", abs(p0.tp - 103.0) < 1e-9, p0.tp)
b.positions.clear()
mb._pos_state.clear()
mb._partial_plans.clear()

# ═══ ۲) MT5-FUNDSENT-001
print("\n── ۲) فاندامنتال/سنتیمنت برای نمادهای متاتریدری ──")
now = int(time.time())
random.seed(11)
rows = []
px = 4000.0
for i in range(120):
    o = px
    px += random.uniform(-8, 8)
    rows.append({"time": now - (120 - i) * 900, "open": o, "high": max(o, px) + 3,
                 "low": min(o, px) - 3, "close": px, "volume": 100 + i})
d = engine.build_signal_from_rows("XAUUSD.m", "15m", rows, source="MT5", digits=2)
chk("طلایِ بروکری: سنتیمنت موجود (DXY)", d["sentiment"].get("available") is True
    and d["sentiment"].get("kind") == "dxy", d["sentiment"].get("kind"))
chk("طلایِ بروکری: وزن‌ها ترکیبی (تکنیکال<1)", d["weights"].get("technical", 1.0) < 1.0,
    d["weights"])
d2 = engine.build_signal_from_rows("WEIRDSYM.q", "15m", rows, source="MT5", digits=2)
chk("نمادِ بدونِ معادل: همان رفتارِ قبلی (فقط تکنیکال)",
    d2["weights"].get("technical") == 1.0 and not d2["fundamental"].get("available"),
    d2["weights"])

# ═══ ۳) AUTOPILOT-001
print("\n── ۳) ارسالِ خودکارِ سمتِ سرور (بدونِ مرورگر) ──")
DATA = {"symbol": "ETH", "pair": "ETH/USDT", "interval": "15m", "price": 2650.0,
        "generated_at": "x", "direction": "SHORT", "internal_score": -45.0,
        "total_score": -45.0, "confidence": 60.0, "atr": 10.0,
        "technical": {"supports": [], "resistances": []},
        "plan": {"direction": "SHORT", "entry": 2650.0, "stop_loss": 2664.0,
                 "take_profits": [{"price": 2636.0}, {"price": 2624.0}, {"price": 2610.0}]}}
SENT = []
_real_sig = app._signal_for
_real_send = app.mt5_bridge.send_order
app._signal_for = lambda s, tf, with_ai=False, **k: (dict(DATA), "ETH", "ETHUSD.z")
app.mt5_bridge.send_order = lambda *a, **k: (SENT.append((a[0], a[1])) or
                                             {"ok": True, "tickets": [1], "execution": "market"})
dispatch.save_config({"program_enabled": True, "program_autorun": True,
                      "program_symbols": ["ETHUSD.z"], "program_tf": "15m",
                      "program_every_sec": 20, "program_source": "internal",
                      "program_min_internal": 15,
                      "news_filter_enabled": False, "schedule_filter_enabled": False})
app._last_dispatch_dir.clear()
res = app._program_autorun_once()
chk("یک دورِ خودکار اجرا شد (بدونِ هیچ درخواستِ مرورگر)", res.get("ran") is True, res)
chk("سفارش به متاتریدر ارسال شد", len(SENT) == 1 and SENT[0][1] == "SHORT", SENT)
res = app._program_autorun_once()
chk("دورِ بعد: جهتِ تکراری دوباره ارسال نمی‌شود", len(SENT) == 1, SENT)
dispatch.save_config({"program_enabled": False})
app._last_dispatch_dir.clear()
res = app._program_autorun_once()
chk("با خاموش‌بودنِ ارسالِ خودکار، هیچ اجرایی نیست", res.get("ran") is False and len(SENT) == 1, res)
# اعتبارسنجی کانفیگ
cfgd = dispatch.save_config({"program_every_sec": 3, "program_tf": "13x",
                             "program_symbols": ["A", "", "B"] + [str(i) for i in range(20)]})
chk("اعتبارسنجی: every≥15، tf→15m، سقف ۱۲ نماد",
    cfgd["program_every_sec"] >= 15 and cfgd["program_tf"] == "15m"
    and len(cfgd["program_symbols"]) <= 12 and "" not in cfgd["program_symbols"], 
    {k: cfgd[k] for k in ("program_every_sec", "program_tf")})
chk("زمان‌بند در راه‌اندازیِ برنامه وصل است",
    "_start_program_autorun()" in open("app.py", encoding="utf-8").read(), "")

# ── AUTOPILOT-002: ارسالِ خودکارِ «همهٔ» نمادهای واچ‌لیست + tf مخصوصِ هر نماد
CAPRUN = []
app._signal_for = lambda s, tf, with_ai=False, **k: (CAPRUN.append((s, tf)) or (dict(DATA), "ETH", "ETHUSD.z"))
app.mt5_bridge.send_order = lambda *a, **k: {"ok": True, "tickets": [9], "execution": "market"}
dispatch.save_config({"program_enabled": True, "program_autorun": True,
                      "program_symbols": ["ETHUSD.z@5m", "XAUUSD.m@1h", "BTC"],
                      "program_tf": "15m", "program_min_internal": 15,
                      "program_block_duplicate_open": False,
                      "program_block_opposite_open": False,
                      "news_filter_enabled": False, "schedule_filter_enabled": False})
app._last_dispatch_dir.clear()
res2 = app._program_autorun_once()
chk("اتوران: هر ۳ نمادِ فهرست تحلیل شدند", len(CAPRUN) == 3, CAPRUN)
chk("اتوران: tf مخصوصِ هر نماد اعمال شد",
    dict(CAPRUN).get("ETHUSD.z") == "5m" and dict(CAPRUN).get("XAUUSD.m") == "1h"
    and dict(CAPRUN).get("BTC") == "15m", CAPRUN)
app._signal_for = _real_sig
app.mt5_bridge.send_order = _real_send
ui_a2 = open("static/index.html", encoding="utf-8").read()
chk("UI: سوئیچِ همگام‌سازیِ واچ‌لیست با ارسالِ خودکار", 'id="wlAutoDisp"' in ui_a2
    and "function wlSyncAutorun" in ui_a2, "")
chk("UI: همگام‌سازی با tf مخصوص (SYM@TF) و فراخوانی از wlSaveCfg",
    "`${c}@${WL.tfmap[c]}`" in ui_a2 and "wlSyncAutorun();}" in ui_a2, "")
app._signal_for = _real_sig
app.mt5_bridge.send_order = _real_send

# ═══ ۴) WL-TF-001
print("\n── ۴) تایم‌فریمِ مخصوصِ هر نماد (SYM@TF) ──")
CAPTF = {}


def _sig_cap(s, tf, with_ai=False, **k):
    CAPTF[s] = tf
    d = dict(DATA)
    d["symbol"] = s
    d["chart"] = {"candles": [{"t": 1, "o": 1, "h": 1, "l": 1, "c": 1, "v": 1}] * 40,
                  "ema20": [1] * 40, "ema50": [1] * 40}
    d["symbol_name"] = s
    d["technical"] = {"score": 10, "supports": [], "resistances": [], "source": "t"}
    d["fundamental"] = {"score": 0, "available": False}
    d["sentiment"] = {"score": 0, "available": False}
    d["plan"] = dict(DATA["plan"])
    d["weights"] = {"technical": 1.0}
    d["internal_score"] = 10
    return d, s, None


app._signal_for = _sig_cap
r = client.get("/api/compare?symbols=BTC@5m,ETH,XAU@1h&tf=15m")
rows2 = ((r.get_json() or {}).get("data") or {}).get("rows") or []
tfmap = {x.get("symbol"): x.get("tf") for x in rows2 if x}
chk("BTC@5m → تحلیل با 5m", CAPTF.get("BTC") == "5m" and tfmap.get("BTC") == "5m",
    (CAPTF.get("BTC"), tfmap.get("BTC")))
chk("ETH بدونِ پسوند → تایم‌فریمِ عمومی (15m)", CAPTF.get("ETH") == "15m", CAPTF.get("ETH"))
chk("XAU@1h → تحلیل با 1h", CAPTF.get("XAU") == "1h" and tfmap.get("XAU") == "1h",
    (CAPTF.get("XAU"), tfmap.get("XAU")))
r = client.get("/api/compare?symbols=BTC@13x&tf=15m")
chk("تایم‌فریمِ خرابِ پسوند → سقوط به عمومی", CAPTF.get("BTC") == "15m", CAPTF.get("BTC"))
app._signal_for = _real_sig

ui = open("static/index.html", encoding="utf-8").read()
chk("UI: منوی tf روی هر چیپ", 'data-tfsel=' in ui and "تایم‌فریمِ مخصوصِ این نماد" in ui, "")
chk("UI: ارسالِ SYM@TF به سرور", '`${c}@${W.tfmap[c]}`' in ui, "")
chk("UI: بازکردنِ کارت با tf مخصوص", '(W.tfmap&&W.tfmap[symbol])||W.tf' in ui, "")
chk("UI: نمایش tf روی کارت", "${r.tf?` · <b>${esc(r.tf)}</b>`:''}" in ui, "")
chk("UI: تنظیماتِ autorun در تبِ روش ارسال", 'id="dp_autorun"' in ui and 'id="dp_autosyms"' in ui, "")

mh.status = _mh
for i, f in enumerate(("mt5_config.json", "dispatch_config.json")):
    shutil.copy(f"/tmp/ff_{i}.bak", f)
print("\n" + "=" * 72)
print(f"  نتیجه: {PASS} پاس · {FAIL} ناموفق")
print("=" * 72)
raise SystemExit(1 if FAIL else 0)
