# -*- coding: utf-8 -*-
"""رگرسیونِ دکمهٔ «🤝 باز کردن این معامله در متاتریدر ۵» (MT5-DUP-001 + UI-BTN-001).

شکایتِ کاربر: «یا معامله باز نمی‌شود یا دو معامله باز می‌شود.»

ریشه‌ها:
  ۱) دو معامله: دوبار-کلیک/هم‌زمانیِ حالتِ خودکار؛ نه UI قفل داشت، نه سرور گاردِ
     پوزیشنِ بازِ هم‌جهت برای /api/mt5/send.
  ۲) باز نمی‌شود (ولی UI می‌گفت ✅): وقتی MT5 متصل نبود پاسخِ شبیه‌سازی ok=true بود
     و پیامِ «معامله باز شد» نمایش داده می‌شد.

پس از اصلاح:
  • ارسالِ دومِ هم‌جهت → 409 با پیامِ روشن + تیکتِ پوزیشنِ موجود.
  • allow_duplicate=true → بازکردنِ عمدیِ معاملهٔ دوم همچنان ممکن.
  • جهتِ مخالف/نمادِ دیگر/پیش‌نمایش → بدونِ مزاحمتِ گارد.
  • شبیه‌سازیِ اجباری در UI با هشدارِ «معامله‌ای باز نشد» نشان داده می‌شود (چکِ ایستا).
"""
import os as _os_env; _os_env.environ.setdefault("BTC_AGENT_ALLOW_INSECURE_ROBOT", "1")  # محیط تست
import shutil

import app
import mock_mt5
import mt5_bridge as mb
import market_hours as mh

PASS = 0
FAIL = 0


def chk(name, cond, detail=""):
    global PASS, FAIL
    if cond:
        PASS += 1
    else:
        FAIL += 1
        print(f"   FAIL  {name} — {str(detail)[:220]}")


shutil.copy("mt5_config.json", "/tmp/btn_mt5.bak")
app.app.config["TESTING"] = True
client = app.app.test_client()
_real_mh = mh.status
mh.status = lambda s, now=None: {"open": True, "state": "open", "reason": ""}

# بروکرِ شبیه‌سازی‌شده
b = mock_mt5.Broker(balance=100000)
b.add_symbol("ETHUSD", digits=2, point=0.01, volume_min=0.01, volume_step=0.01,
             stops_level=10, tick_value=1.0, tick_size=0.01, price=2650.0)
for k in dir(mock_mt5):
    if k.isupper():
        setattr(b, k, getattr(mock_mt5, k))
mb.mt5 = b
mb.MT5_AVAILABLE = True
mb._conn.update(connected=True, error=None, since=1.0)
mb.save_config({"market_hours_guard": False, "news_filter_enabled": False,
                "max_daily_trades": 0, "max_daily_risk_pct": 0, "allowed_symbols": [],
                "manage_positions": False, "risk_mode": "fixed", "tp_mode": "single",
                "execution": "market", "default_volume": 0.1, "magic": 532025,
                "symbol_map": {"ETH": "ETHUSD"}})

DATA = {"symbol": "ETH", "pair": "ETH/USDT", "interval": "15m", "price": 2650.0,
        "generated_at": "x", "data_source": "mock", "direction": "SHORT",
        "internal_score": -40.0, "total_score": -40.0, "confidence": 60.0, "atr": 10.0,
        "market": {"open": True}, "technical": {"supports": [], "resistances": []},
        "fundamental": {}, "sentiment": {},
        "plan": {"direction": "SHORT", "entry": 2650.0, "stop_loss": 2664.0, "rr": 2.0,
                 "take_profits": [{"price": 2636.0}, {"price": 2624.0}, {"price": 2610.0}]}}
_real_sig = app._signal_for
app._signal_for = lambda sym, tf, with_ai=False: (DATA, "ETH", None)

print("=" * 70)
print(" دکمهٔ «باز کردن این معامله در متاتریدر ۵» — ضدتکرار + صداقت")
print("=" * 70)


def send(body):
    r = client.post("/api/mt5/send", json=body)
    return r.status_code, (r.get_json() or {})


# ➊ ارسالِ اول: باید دقیقاً یک پوزیشن باز شود
st, d = send({"symbol": "ETH", "tf": "15m", "direction": "SHORT"})
res = d.get("data") or {}
chk("ارسالِ اول موفق", st == 200 and res.get("ok") is True, f"st={st} {str(d)[:100]}")
chk("دقیقاً یک پوزیشن باز شد", len(b.positions) == 1, len(b.positions))
chk("تیکت در پاسخ هست", bool(res.get("tickets")), res.get("tickets"))
tk1 = (res.get("tickets") or [None])[0]

# ➋ شبیه‌سازیِ دوبار-کلیک/ارسالِ هم‌زمانِ خودکار: ارسالِ دومِ هم‌جهت → 409
st, d = send({"symbol": "ETH", "tf": "15m", "direction": "SHORT"})
chk("ارسالِ تکراریِ هم‌جهت → 409", st == 409 and d.get("ok") is False, f"st={st}")
chk("پاسخ پرچمِ duplicate و تیکتِ موجود دارد",
    (d.get("duplicate") is True) and d.get("ticket") == tk1, d)
chk("پیامِ روشنِ فارسی", "از قبل باز است" in (d.get("error") or ""), d.get("error"))
chk("هیچ پوزیشنِ دومی باز نشد", len(b.positions) == 1, len(b.positions))

# ➌ بازکردنِ عمدیِ معاملهٔ دوم با allow_duplicate
st, d = send({"symbol": "ETH", "tf": "15m", "direction": "SHORT", "allow_duplicate": True})
chk("allow_duplicate=true → معاملهٔ دومِ عمدی باز می‌شود",
    st == 200 and len(b.positions) == 2, f"st={st} pos={len(b.positions)}")
# پاک‌سازی معاملهٔ دوم
for t in list(b.positions):
    if t != tk1:
        b.positions.pop(t)

# ➍ اصلاح (PROG-GUARD-001): جهتِ مخالف هم مسدود است (ضدِ هجِ ناخواسته) + override عمدی
st, d = send({"symbol": "ETH", "tf": "15m", "direction": "LONG"})
chk("جهتِ مخالف → 409 ضدِ هج", st == 409 and (d or {}).get("opposite") is True
    and len(b.positions) == 1, f"st={st} pos={len(b.positions)}")
st, d = send({"symbol": "ETH", "tf": "15m", "direction": "LONG", "allow_opposite": True})
chk("هجِ عمدی با allow_opposite ممکن", st == 200 and len(b.positions) == 2,
    f"st={st} pos={len(b.positions)}")

# ➎ پیش‌نمایش (dry_run) هرگز گارد/معامله ندارد
n0 = len(b.positions)
st, d = send({"symbol": "ETH", "tf": "15m", "direction": "SHORT", "dry_run": True})
chk("dry_run آزاد و بدونِ معاملهٔ جدید", st == 200 and len(b.positions) == n0,
    f"st={st} pos={len(b.positions)}")

# ➏ پس از بسته‌شدنِ پوزیشن، ارسالِ مجدد آزاد است
b.positions.clear()
mb._pos_state.clear()
mb._partial_plans.clear()
st, d = send({"symbol": "ETH", "tf": "15m", "direction": "SHORT"})
chk("بعد از بستنِ پوزیشن، ارسالِ دوباره آزاد", st == 200 and len(b.positions) == 1,
    f"st={st} pos={len(b.positions)}")
b.positions.clear()

# ➐ صداقتِ UI (چکِ ایستا): قفلِ دوبار-کلیک + هشدارِ شبیه‌سازی + نمایشِ تیکت
ui = open("static/index.html", encoding="utf-8").read()
chk("UI: قفلِ ضدِ دوبار-کلیک", "if(btn&&btn.disabled)return;" in ui and "btn.disabled=true" in ui, "")
chk("UI: هشدارِ «فقط شبیه‌سازی شد — معامله‌ای باز نشد»", "فقط شبیه‌سازی شد — معامله‌ای در متاتریدر باز نشد" in ui, "")
chk("UI: نمایشِ تیکت پس از بازشدنِ واقعی", "تیکت: " in ui and "r.tickets" in ui, "")
chk("UI: حالتِ خودکار هم صادق است", "خودکار: فقط شبیه‌سازی شد" in ui, "")

mh.status = _real_mh
app._signal_for = _real_sig
shutil.copy("/tmp/btn_mt5.bak", "mt5_config.json")

print("\n" + "=" * 70)
print(f"  نتیجه: {PASS} پاس · {FAIL} ناموفق")
print("=" * 70)
raise SystemExit(1 if FAIL else 0)
