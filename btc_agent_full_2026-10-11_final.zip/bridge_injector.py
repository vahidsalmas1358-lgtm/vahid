# -*- coding: utf-8 -*-
"""
bridge_injector.py  —  «تزریق‌گرِ خودکارِ کدِ اتصال»
====================================================

این برنامه فایلِ رباتِ پایتونی (.py) یا اکسپرتِ متاتریدر (.mq5/.mqh) شما را می‌گیرد و
کدهای لازم را «خودکار» داخلش وارد می‌کند تا به‌جای بازکردنِ مستقیمِ معامله، سیگنال را
به «برنامهٔ تحلیل» بفرستد (برنامه پس از تأییدِ سیگنالِ داخلی/هوش مصنوعی، عیناً به
متاتریدر ارسال می‌کند).

طراحی‌شده برای حالتی که «همه‌چیز روی یک کامپیوتر» است (اتصالِ localhost).

چه کاری انجام می‌دهد؟
  • پایتون:
      - ایمپورتِ کلاینتِ پُل را اضافه می‌کند (RobotBridge)
      - یک شیءِ  bridge = RobotBridge(URL, secret=...)  می‌سازد
      - همهٔ فراخوانی‌های  mt5.order_send(...)  را به  bridge.order_send(...)  تبدیل می‌کند
  • متاتریدر (MQL5):
      - #include <RobotBridge.mqh>  و ورودی‌های آدرس/توکن/تایم‌اوت را اضافه می‌کند
      - یک شیءِ سراسریِ  CRobotBridge bridge;  می‌سازد و در OnInit مقداردهی می‌کند
      - همهٔ فراخوانی‌های  OrderSend(req,res)  را به  bridge.OrderSendBridge(req,res)  تبدیل می‌کند

ایمن و شفاف:
  • فایلِ اصلی را دست نمی‌زند مگر با  --in-place  (که آن‌وقت هم یک نسخهٔ .bak می‌سازد)
  • به‌صورتِ پیش‌فرض خروجی را در فایلِ جدا (نام + .bridge.py/.mq5) می‌نویسد
  • --dry-run  فقط گزارش و «تفاوتِ» تغییرات را چاپ می‌کند، چیزی نمی‌نویسد
  • اگر قبلاً تزریق شده باشد، دوباره تزریق نمی‌کند (نشانهٔ BRIDGE-INJECTED)
  • جاهایی که نیاز به دخالتِ دستی دارند با TODO علامت می‌خورند

نمونهٔ استفاده:
  python bridge_injector.py my_bot.py
  python bridge_injector.py MyEA.mq5 --url http://127.0.0.1:8000 --secret TOKEN
  python bridge_injector.py ./robots_folder --recursive
  python bridge_injector.py my_bot.py --dry-run
  python bridge_injector.py my_bot.py --in-place
"""

from __future__ import annotations

import os
import re
from urllib.parse import urlsplit
import ast
import argparse
import difflib
from typing import Dict, List, Optional, Tuple

MARKER = "BRIDGE-INJECTED"
DEFAULT_URL = "http://127.0.0.1:8000"


# ═════════════════════════════════════════════════════════════════════════════
#  جایگزینیِ امن: فقط روی «کدِ واقعی»، نه داخلِ کامنت‌ها و رشته‌ها
# ═════════════════════════════════════════════════════════════════════════════

def _split_code_segments(src: str, lang: str) -> List[Tuple[str, bool]]:
    """منبع را به قطعاتِ (متن، آیا_کد_است) می‌شکند.

    قطعاتِ رشته‌ای و کامنت با is_code=False علامت می‌خورند تا جایگزینی رویشان
    اعمال نشود (رفعِ باگِ خراب‌کردنِ متنِ کامنت‌ها/رشته‌ها).
    """
    segs: List[Tuple[str, bool]] = []
    buf: List[str] = []
    i, n = 0, len(src)

    def flush():
        if buf:
            segs.append(("".join(buf), True))
            buf.clear()

    if lang == "python":
        while i < n:
            c = src[i]
            if c == "#":                                   # کامنتِ تک‌خطی
                flush()
                j = i
                while j < n and src[j] != "\n":
                    j += 1
                segs.append((src[i:j], False))
                i = j
            elif c in "\"'":                               # رشته
                flush()
                triple = src[i:i + 3] in ('"""', "'''")
                if triple:
                    q = src[i:i + 3]
                    end = src.find(q, i + 3)
                    j = (end + 3) if end != -1 else n
                else:
                    j = i + 1
                    while j < n:
                        if src[j] == "\\":
                            j += 2
                            continue
                        if src[j] == c or src[j] == "\n":
                            j += 1 if src[j] == c else 0
                            break
                        j += 1
                segs.append((src[i:j], False))
                i = j
            else:
                buf.append(c)
                i += 1
        flush()
    else:  # mql5 / زبان‌های C-مانند
        while i < n:
            two = src[i:i + 2]
            c = src[i]
            if two == "//":                                # کامنتِ خطی
                flush()
                j = i
                while j < n and src[j] != "\n":
                    j += 1
                segs.append((src[i:j], False))
                i = j
            elif two == "/*":                              # کامنتِ بلوکی
                flush()
                end = src.find("*/", i + 2)
                j = (end + 2) if end != -1 else n
                segs.append((src[i:j], False))
                i = j
            elif c == "\"" or c == "'":                    # رشته/کاراکتر
                flush()
                j = i + 1
                while j < n:
                    if src[j] == "\\":
                        j += 2
                        continue
                    if src[j] == c:
                        j += 1
                        break
                    j += 1
                segs.append((src[i:j], False))
                i = j
            else:
                buf.append(c)
                i += 1
        flush()
    return segs


def _sub_code_only(src: str, pattern: "re.Pattern", repl: str,
                   lang: str) -> Tuple[str, int]:
    """regex را فقط روی قطعاتِ کد اعمال می‌کند (نه کامنت/رشته)."""
    out: List[str] = []
    total = 0
    for text, is_code in _split_code_segments(src, lang):
        if is_code:
            new, cnt = pattern.subn(repl, text)
            total += cnt
            out.append(new)
        else:
            out.append(text)
    return "".join(out), total


# ═════════════════════════════════════════════════════════════════════════════
#  پایتون
# ═════════════════════════════════════════════════════════════════════════════

def _py_insertion_index(lines: List[str]) -> int:
    """اندیسِ خطی که باید بلوکِ تزریق را قبل از آن درج کنیم را می‌یابد (OP5-INJ-05).

    با ast.parse تعیین می‌شود: بعد از docstringِ ماژول و «همهٔ» importهای
    `from __future__` — حتی اگر چندخطی و داخلِ پرانتز باشند. پیاده‌سازیِ قبلی
    خط‌محور بود و در `from __future__ import (\n    annotations,\n)` بلوک را
    وسطِ پرانتز می‌گذاشت → SyntaxError.
    """
    text = "\n".join(lines)
    try:
        tree = ast.parse(text)
    except SyntaxError:
        return 0
    end = 0
    body = tree.body
    i = 0
    if body and isinstance(body[0], ast.Expr) and isinstance(
            getattr(body[0], "value", None), ast.Constant) and \
            isinstance(body[0].value.value, str):
        end = body[0].end_lineno or body[0].lineno
        i = 1
    while i < len(body):
        n = body[i]
        if isinstance(n, ast.ImportFrom) and n.module == "__future__":
            end = max(end, n.end_lineno or n.lineno)
            i += 1
            continue
        if isinstance(n, ast.Expr) and isinstance(getattr(n, "value", None), ast.Constant) \
                and isinstance(n.value.value, str) and end == 0:
            end = n.end_lineno or n.lineno
        break
    return end


# OP5-INJ-05: ساختِ رشتهٔ امن برای درج در کدِ MQL5 (URL/secret با کوته/بک‌اسلش/
# خطِ نو نباید literal را بشکند یا کد تزریق کند).
def _mql_string_literal(value: str) -> str:
    s = str(value)
    s = s.replace("\\", "\\\\").replace('"', '\\"')
    s = s.replace("\r", "\\r").replace("\n", "\\n").replace("\t", "\\t")
    return '"' + s + '"'


# OP5-INJ-04: اعتبارسنجیِ آدرس/توکن پیش از تولیدِ کد (سرور و کلاینت هر دو).
def _validate_base_url(base_url: str, secret: str) -> str:
    u = urlsplit(str(base_url or ""))
    if u.scheme not in {"http", "https"} or not u.netloc:
        raise ValueError("base_url must be an absolute http(s) URL")
    host = (u.hostname or "").lower()
    if secret and u.scheme != "https" and host not in {"127.0.0.1", "localhost", "::1"}:
        raise ValueError("secret requires HTTPS except loopback")
    if any(c in secret for c in ("\r", "\n", "\x00")):
        raise ValueError("secret contains forbidden header characters")
    return str(base_url).rstrip("/")


# ─────────────────────────────────────────────────────────────────────────────
#  تشخیص و اتصالِ خودکارِ «لایه‌های اجرای سفارش» (فراتر از mt5.order_send)
#
#  بعضی ربات‌ها مستقیم mt5.order_send نمی‌زنند و از یک تابعِ واسط استفاده می‌کنند
#  (مثلِ Meta.run(...) در آموزش‌های رایج). این بخش با تحلیلِ AST آن فراخوانی‌ها را
#  می‌یابد، آرگومان‌ها را به پارامترهای bridge.send نگاشت می‌کند، و فراخوانیِ اصلی
#  را (به‌صورتِ کامنت‌شده، برای بازگشتِ آسان) با bridge.send جایگزین می‌کند.
# ─────────────────────────────────────────────────────────────────────────────

# نام‌هایی که معمولاً «اجرای سفارش» هستند (برای گزارشِ راهنما وقتی نگاشتِ خودکار نداریم)
_EXEC_HINT_NAMES = {
    "run", "buy", "sell", "open_trade", "open_position", "opentrade",
    "send_order", "sendorder", "place_order", "placeorder", "market_order",
    "entry", "execute", "trade", "position_open", "positionopen",
}


def _call_dotted_name(func: ast.AST) -> str:
    """نامِ نقطه‌دارِ تابعِ فراخوانی‌شده را برمی‌گرداند (مثل 'Meta.run')."""
    parts: List[str] = []
    node = func
    while isinstance(node, ast.Attribute):
        parts.append(node.attr)
        node = node.value
    if isinstance(node, ast.Name):
        parts.append(node.id)
    elif isinstance(node, ast.Call):
        parts.append("()")
    else:
        return ""
    return ".".join(reversed(parts))


def _seg(src: str, node: ast.AST) -> str:
    """متنِ منبعِ یک گرهٔ AST (بدونِ فاصله‌های اضافی)."""
    s = ast.get_source_segment(src, node) or ""
    return " ".join(s.split())


def _adapter_meta_run(call: ast.Call, src: str) -> Optional[Dict[str, str]]:
    """نگاشتِ Meta.run(symbol, buy, sell, lot, tp, sl, magic, ...) → bridge.send.

    امضای رایجِ این لایهٔ اجرا (آموزش‌های متاتریدرِ پایتونی):
        Meta.run(symbol, buy, sell, lot, tp, sl, magic, stopLossPure=...)
    آرگومان‌های positional به این ترتیب نگاشت می‌شوند:
        0=symbol  1=buy(bool)  2=sell(bool)  3=lot  4=tp  5=sl  6=magic
    """
    a = call.args
    if len(a) < 6:
        return None
    kv: Dict[str, str] = {
        "symbol": _seg(src, a[0]),
        "direction": f'("BUY" if {_seg(src, a[1])} else "SELL")',
        "volume": _seg(src, a[3]),
        "sl": _seg(src, a[5]),
        "tp": _seg(src, a[4]),
    }
    if len(a) >= 7:
        kv["magic"] = _seg(src, a[6])
    return kv


# رجیستریِ آداپترها: نامِ فراخوانی → تابعِ نگاشت. برای پشتیبانی از لایه‌های دیگر
# کافی است یک آداپترِ جدید اینجا اضافه شود.
EXEC_ADAPTERS = {
    "Meta.run": _adapter_meta_run,
    "meta.run": _adapter_meta_run,
}

# ارتقا (INJ-ADV): نگاشتِ نام‌های رایجِ کیورد-آرگومان‌ها در فریم‌ورک‌های مختلف
_KW_SYMBOL = ("symbol", "sym", "pair", "ticker", "instrument", "asset")
_KW_VOLUME = ("volume", "vol", "lot", "lots", "qty", "quantity", "size", "amount")
_KW_SL     = ("sl", "stop_loss", "stoploss", "stop")
_KW_TP     = ("tp", "take_profit", "takeprofit", "target", "tp1")
_KW_ENTRY  = ("entry", "price", "entry_price", "open_price", "limit_price")
_KW_DIR    = ("direction", "side", "dir", "order_type", "action", "type", "cmd")
_KW_MAGIC  = ("magic", "magic_number", "magicnumber")

_BUYISH  = ("buy", "long")
_SELLISH = ("sell", "short")


def _adapter_kwargs(call: ast.Call, src: str, dotted: str) -> Optional[Dict[str, str]]:
    """آداپترِ عمومی برای توابعِ اجرای سفارش با کیورد-آرگومان‌های متعارف.

    برای ربات‌های پیشرفته‌تری که لایهٔ اجرای خودشان را دارند؛ مثل:
        place_order(symbol="XAUUSD", side="BUY", lot=0.1, sl=..., tp=...)
        broker.open_trade(pair=sym, direction=d, size=lots, stop=sl, target=tp)
        executor.buy(symbol=s, qty=0.2, stop_loss=sl)        ← جهت از نامِ تابع
    فقط وقتی وصل می‌کند که نماد + حجم + جهت قابل‌استخراج باشند؛ وگرنه None.
    """
    kws = {k.arg: k.value for k in call.keywords if k.arg}
    def pick(names):
        for nm in names:
            if nm in kws:
                return _seg(src, kws[nm])
        return None
    sym = pick(_KW_SYMBOL)
    vol = pick(_KW_VOLUME)
    if not sym or not vol:
        return None
    # جهت: از نامِ تابع (buy/sell/long/short) یا از کیوردِ جهت
    last = dotted.split(".")[-1].lower() if dotted else ""
    direction = None
    if any(t in last for t in _BUYISH) and not any(t in last for t in _SELLISH):
        direction = '"BUY"'
    elif any(t in last for t in _SELLISH) and not any(t in last for t in _BUYISH):
        direction = '"SELL"'
    else:
        d = pick(_KW_DIR)
        if d is not None:
            direction = d            # bridge.send خودش BUY/SELL/enum را coerce می‌کند
    if direction is None:
        return None
    kv: Dict[str, str] = {"symbol": sym, "direction": direction, "volume": vol}
    for key, names in (("sl", _KW_SL), ("tp", _KW_TP),
                       ("entry", _KW_ENTRY), ("magic", _KW_MAGIC)):
        v = pick(names)
        if v is not None:
            kv[key] = v
    return kv

# ترتیبِ چاپِ پارامترها در bridge.send تولیدشده
_SEND_ORDER = ["symbol", "direction", "volume", "entry", "sl", "tp", "magic", "robot_id"]


def _indent_of(line: str) -> str:
    return line[:len(line) - len(line.lstrip())]


def _build_send_block(indent: str, kv: Dict[str, str],
                      original_lines: List[str], dotted: str) -> List[str]:
    """بلوکِ جایگزینِ bridge.send + مدیریتِ نتیجه + کامنتِ نسخهٔ اصلی را می‌سازد."""
    out = [f"{indent}# --- {MARKER}: «{dotted}» خودکار به bridge.send وصل شد ---",
           f"{indent}_bridge_res = bridge.send("]
    for k in _SEND_ORDER:
        if k in kv:
            out.append(f"{indent}    {k}={kv[k]},")
    out += [
        f"{indent})",
        f"{indent}if _bridge_res.forwarded:",
        f'{indent}    print("Bridge: به متاتریدر ارسال شد \u2705 -", _bridge_res.comment)',
        f"{indent}elif _bridge_res.approved:",
        f'{indent}    print("Bridge: تایید شد ولی ارسال نشد -", _bridge_res.comment)',
        f"{indent}else:",
        f'{indent}    print("Bridge: رد شد \u26d4 -", _bridge_res.comment)',
        f"{indent}# --- نسخهٔ اصلیِ اجرای مستقیم (غیرفعال‌شده؛ برای بازگشت از کامنت خارج کنید): ---",
    ]
    for ol in original_lines:
        out.append(f"{indent}# " + ol.rstrip())
    out.append(f"{indent}# --- پایانِ {MARKER} ---")
    return out


def _rewrite_exec_calls(src: str) -> Tuple[str, List[str], int]:
    """فراخوانی‌های لایهٔ اجرا (مثلِ Meta.run) را به bridge.send تبدیل می‌کند.

    خروجی: (کدِ جدید، گزارش، تعدادِ اتصالِ خودکار).
    """
    try:
        tree = ast.parse(src)
    except SyntaxError:
        return src, [], 0

    lines = src.splitlines()
    edits: List[Tuple[int, int, List[str]]] = []
    report: List[str] = []
    hints: List[str] = []
    wired = 0

    def _stmt_call(node):
        """اگر statement یک فراخوانیِ قابل‌سیم‌کشی باشد → (call, target_var|None, awaited)."""
        # ارتقا (INJ-ADV): علاوه بر Expr، حالت‌های «x = call(...)» و «await call(...)»
        # هم پشتیبانی می‌شوند (ربات‌های پیشرفته نتیجه را نگه می‌دارند یا async هستند).
        val, target = None, None
        if isinstance(node, ast.Expr):
            val = node.value
        elif isinstance(node, ast.Assign) and len(node.targets) == 1 \
                and isinstance(node.targets[0], ast.Name):
            val, target = node.value, node.targets[0].id
        else:
            return None
        awaited = False
        if isinstance(val, ast.Await):
            val, awaited = val.value, True
        if not isinstance(val, ast.Call):
            return None
        return val, target, awaited

    for node in ast.walk(tree):
        info = _stmt_call(node)
        if info is None:
            # فراخوانیِ اجرای سفارش در «خودِ شرط» یا مقدارِ return که خودکار
            # قابل‌تبدیل نیست → فقط راهنما. (نکته: فقط عبارتِ شرط اسکن می‌شود،
            # نه بدنهٔ if — statementهای بدنه جداگانه و خودکار وصل می‌شوند.)
            _cond_exprs = ()
            if isinstance(node, (ast.If, ast.While)):
                _cond_exprs = (node.test,)
            elif isinstance(node, ast.Return) and node.value is not None:
                _cond_exprs = (node.value,)
            for _ce in _cond_exprs:
                for sub in ast.walk(_ce):
                    if isinstance(sub, ast.Call):
                        d = _call_dotted_name(sub.func)
                        lastn = d.split(".")[-1].lower() if d else ""
                        if (d in EXEC_ADAPTERS or lastn in _EXEC_HINT_NAMES) and d not in (
                                "mt5.order_send", "bridge.order_send", "bridge.send"):
                            hints.append(f"{d}() (خط {sub.lineno} — داخلِ شرط/return؛ دستی وصل کنید)")
            continue
        call, target, awaited = info
        dotted = _call_dotted_name(call.func)
        adapter = EXEC_ADAPTERS.get(dotted)
        kv = adapter(call, src) if adapter else None
        if kv is None:
            # آداپترِ عمومیِ کیورد-آرگومان برای لایه‌های اجرای ناشناخته
            last = dotted.split(".")[-1].lower() if dotted else ""
            if last in _EXEC_HINT_NAMES and dotted not in (
                    "mt5.order_send", "bridge.order_send", "bridge.send"):
                kv = _adapter_kwargs(call, src, dotted)
                if kv is None:
                    hints.append(f"{dotted}() (خط {node.lineno})")
                    continue
            else:
                continue
        start = node.lineno
        end = getattr(node, "end_lineno", node.lineno)
        indent = _indent_of(lines[start - 1])
        original = lines[start - 1:end]
        block = _build_send_block(indent, kv, original, dotted)
        if target:
            # نتیجهٔ پل در متغیرِ خودِ ربات هم گذاشته می‌شود تا کدِ پایین‌دست نشکند
            _close = block.index(f"{indent})")
            block.insert(_close + 1,
                         f"{indent}{target} = _bridge_res  "
                         f"# {MARKER}: نتیجهٔ پل (BridgeResult: ok/retcode/comment/forwarded)")
        if awaited:
            block.insert(1, f"{indent}# توجه: فراخوانیِ اصلی async بود؛ bridge.send همگام (sync) است.")
        edits.append((start, end, block))
        wired += 1

    # اعمالِ ویرایش‌ها از پایین به بالا تا شماره‌خط‌ها به‌هم نریزد
    for start, end, block in sorted(edits, key=lambda e: e[0], reverse=True):
        lines[start - 1:end] = block

    if wired:
        report.append(f"\u2705 {wired} فراخوانیِ لایهٔ اجرا (مثلِ Meta.run) خودکار به "
                      "bridge.send وصل شد (نسخهٔ اصلی به‌صورتِ کامنت نگه داشته شد). "
                      "توجه: چون این توابع «قیمتِ ورود» جدا نمی‌گیرند، سفارش به‌صورتِ "
                      "بازار ارسال می‌شود؛ اگر ورودِ قیمتی می‌خواهید entry=... را اضافه کنید.")
    if hints:
        uniq = list(dict.fromkeys(hints))
        report.append("\u2139\ufe0f کاندیدهای احتمالیِ اجرای سفارش که خودکار وصل نشدند "
                      "(در صورتِ نیاز دستی به bridge.send وصل کنید): " + "، ".join(uniq[:12]))

    return "\n".join(lines), report, wired


def patch_python(src: str, url: str, secret: str) -> Tuple[str, List[str]]:
    """کدِ پایتون را تزریق می‌کند. خروجی: (کدِ جدید، گزارش)."""
    report: List[str] = []
    if MARKER in src:
        report.append("قبلاً تزریق شده — بدونِ تغییر رد شد.")
        return src, report

    cls = "RobotBridge"
    mod = "robot_client_example"

    # تشخیصِ نامِ مستعارِ MetaTrader5
    aliases = re.findall(r'^\s*import\s+MetaTrader5\s+as\s+(\w+)', src, re.M)
    if re.search(r'^\s*import\s+MetaTrader5\s*$', src, re.M):
        aliases.append("MetaTrader5")
    aliases = list(dict.fromkeys(aliases)) or ["mt5"]

    # جایگزینیِ order_send
    total = 0
    new_src = src
    for al in aliases:
        pat = re.compile(r'(?<![\w.])' + re.escape(al) + r'\.order_send\s*\(')
        new_src, cnt = _sub_code_only(new_src, pat, "bridge.order_send(", "python")
        if cnt:
            report.append(f"جایگزین شد: {al}.order_send( → bridge.order_send(  ({cnt} مورد)")
        total += cnt
    # from MetaTrader5 import order_send  →  فراخوانیِ مستقیمِ order_send(
    if re.search(r'from\s+MetaTrader5\s+import\s+[^\n]*\border_send\b(?!\s+as\b)', new_src):
        pat = re.compile(r'(?<![\w.])order_send\s*\(')
        new_src, cnt = _sub_code_only(new_src, pat, "bridge.order_send(", "python")
        if cnt:
            report.append(f"جایگزین شد: order_send( → bridge.order_send(  ({cnt} مورد)")
        total += cnt
    # اصلاح (INJ-003): from MetaTrader5 import order_send as osend → osend( هم پل می‌شود؛
    # قبلاً فراخوانیِ مستعار مستقیم به MT5 می‌رفت و گزارشِ injector گمراه‌کننده بود.
    for _alias in re.findall(
            r'from\s+MetaTrader5\s+import\s+[^\n]*\border_send\s+as\s+(\w+)', new_src):
        pat = re.compile(r'(?<![\w.])' + re.escape(_alias) + r'\s*\(')
        new_src, cnt = _sub_code_only(new_src, pat, "bridge.order_send(", "python")
        if cnt:
            report.append(f"جایگزین شد: {_alias}( → bridge.order_send(  ({cnt} مورد)")
        total += cnt
    # ارتقا (INJ-ADV): from MetaTrader5 import *  →  order_send( برهنه هم باید پل شود
    if re.search(r'^\s*from\s+MetaTrader5\s+import\s+\*', new_src, re.M):
        pat = re.compile(r'(?<![\w.])order_send\s*\(')
        new_src, cnt = _sub_code_only(new_src, pat, "bridge.order_send(", "python")
        if cnt:
            report.append(f"جایگزین شد (import *): order_send( → bridge.order_send(  ({cnt} مورد)")
        total += cnt

    # ارتقا (INJ-ADV): اگر order_send به‌صورتِ «ارجاع» (callback/partial) پاس داده شده
    # باشد، regex بالا آن را نمی‌گیرد — به‌جای تغییرِ پنهان، هشدارِ شفاف می‌دهیم.
    try:
        _tree = ast.parse(src)
        _callfuncs = {id(n.func) for n in ast.walk(_tree) if isinstance(n, ast.Call)}
        _refs = []
        for _n in ast.walk(_tree):
            if isinstance(_n, ast.Attribute) and _n.attr == "order_send" \
                    and isinstance(_n.value, ast.Name) and _n.value.id in aliases \
                    and id(_n) not in _callfuncs:
                _refs.append(_n.lineno)
        if _refs:
            report.append("⚠️ ارجاعِ مستقیم به order_send (بدونِ فراخوانی — مثلاً به‌عنوانِ "
                          "callback/partial) در خط(های) "
                          + "، ".join(str(x) for x in _refs[:8])
                          + " یافت شد؛ این‌ها خودکار پل نمی‌شوند. به‌جایش "
                          "bridge.order_send را پاس بدهید.")
    except SyntaxError:
        pass

    # اتصالِ خودکارِ لایه‌های اجرای سفارش (مثلِ Meta.run) از طریقِ تحلیلِ AST
    new_src, exec_report, exec_wired = _rewrite_exec_calls(new_src)
    report += exec_report
    total += exec_wired

    # ساختِ بلوکِ تزریق
    # اصلاح (INJ-001): url/secret با repr درج می‌شوند تا کوتیشن/بک‌اسلش/خطِ نو در
    # ورودی، SyntaxError یا تزریقِ کد در فایلِ خروجی نسازد.
    # OP5-INJ-04: توکنِ غیرخالی در سورس نوشته نمی‌شود؛ از متغیرِ محیطی خوانده
    # می‌شود (و اگر نبود، همان مقدارِ داده‌شده به‌عنوانِ پیش‌فرض می‌ماند).
    if secret:
        block = [
            f"# --- {MARKER}: اتصالِ خودکار به «برنامهٔ تحلیل» (توسطِ bridge_injector) ---",
            "import os",
            f"from {mod} import {cls}",
            f"bridge = {cls}({str(url)!r}, "
            f"secret=os.environ.get(\"BTC_AGENT_ROBOT_SECRET\") or {str(secret)!r})",
        ]
    else:
        block = [
            f"# --- {MARKER}: اتصالِ خودکار به «برنامهٔ تحلیل» (توسطِ bridge_injector) ---",
            f"from {mod} import {cls}",
            f"bridge = {cls}({str(url)!r}, secret='')",
        ]
    if total == 0:
        block += [
            "# TODO: در این فایل فراخوانیِ mt5.order_send پیدا نشد.",
            "#       هرجا می‌خواهید سیگنال بفرستید، این را صدا بزنید:",
            '#   res = bridge.send(symbol="XAUUSD", direction="BUY", volume=0.10,',
            '#                     sl=..., take_profits=[...], tf="1h")',
            "#   if res.forwarded: ...  # به متاتریدر ارسال شد",
        ]
        report.append("⚠️ هیچ mt5.order_send یافت نشد؛ فقط ایمپورت/شیءِ bridge اضافه شد + راهنمای دستی (TODO).")
    block += [f"# --- پایانِ {MARKER} ---", ""]

    lines = new_src.splitlines(keepends=False)
    idx = _py_insertion_index(lines)
    lines[idx:idx] = block
    out = "\n".join(lines)
    if src.endswith("\n") and not out.endswith("\n"):
        out += "\n"

    report.insert(0, f"ایمپورت اضافه شد: from {mod} import {cls}")
    report.insert(1, f'شیء ساخته شد: bridge = {cls}("{url}", '
                     + ('secret از متغیرِ محیطی BTC_AGENT_ROBOT_SECRET/مقدارِ ورودی")'
                        if secret else 'secret="")'))
    if secret:
        report.insert(2, "🔐 توکن در سورس نوشته نشد؛ از متغیرِ محیطی "
                         "BTC_AGENT_ROBOT_SECRET خوانده می‌شود (مقدارِ ورودی فقط fallback است).")
    return out, report


# ═════════════════════════════════════════════════════════════════════════════
#  متاتریدر (MQL5)
# ═════════════════════════════════════════════════════════════════════════════

# ─────────────────────────────────────────────────────────────────────────────
#  ارتقا (INJ-ADV): اتصالِ خودکارِ CTrade — ربات‌های پیشرفتهٔ MQL5 به‌جای OrderSendِ
#  خام از کلاسِ استانداردِ CTrade استفاده می‌کنند (trade.Buy/Sell/PositionOpen/
#  BuyStop/...). این بخش نمونه‌های CTrade را پیدا می‌کند، آرگومان‌ها را طبقِ امضای
#  رسمیِ CTrade نگاشت می‌کند و فراخوانی را «درجا» (حتی داخلِ شرطِ if) با یک تابعِ
#  boolِ کمکی BridgeCTOrder جایگزین می‌کند؛ بنابراین ساختارِ کنترل‌جریانِ ربات حفظ
#  می‌شود.
# ─────────────────────────────────────────────────────────────────────────────

_CT_HELPER_NAME = "BridgeCTOrder"
_CT_HELPER_LINES = [
    "// تابعِ کمکیِ پل برای فراخوانی‌های CTrade — خروجی true یعنی به متاتریدر ارسال شد",
    "bool %s(const string symbol,const string dir,const double volume," % _CT_HELPER_NAME,
    "        const double sl=0.0,const double tp=0.0,const double entry=0.0,",
    "        const string comment=\"\")",
    "{",
    "   string _sym = symbol;",
    "   if(_sym==NULL || _sym==\"\") _sym = _Symbol;",
    "   BridgeResult _r = bridge.Send(_sym, dir, volume, sl, tp, entry,",
    "                                 CRobotBridge::TFfromPeriod((ENUM_TIMEFRAMES)_Period),",
    "                                 \"\", comment);",
    "   return(_r.forwarded);",
    "}",
]


def _code_mask(src: str, lang: str) -> List[bool]:
    """برای هر کاراکترِ منبع مشخص می‌کند که «کدِ واقعی» است یا کامنت/رشته."""
    mask: List[bool] = []
    for text, is_code in _split_code_segments(src, lang):
        mask.extend([is_code] * len(text))
    return mask


def _find_ctrade_instances(src: str, mask: List[bool]) -> List[str]:
    """نام‌های نمونه‌های CTrade را می‌یابد: CTrade trade; / CTrade *t = ... / پارامترها."""
    names: List[str] = []
    for m in re.finditer(r'\bCTrade\s*[*&]?\s*([A-Za-z_]\w*)\s*(?=[;=,)])', src):
        if mask[m.start()]:
            names.append(m.group(1))
    return list(dict.fromkeys(names))


def _scan_balanced(src: str, mask: List[bool], open_idx: int) -> int:
    """اندیسِ پرانتزِ بستهٔ متناظر را برمی‌گرداند (فقط پرانتزهای داخلِ «کد» شمرده می‌شوند)."""
    depth = 0
    for i in range(open_idx, len(src)):
        if not mask[i]:
            continue
        c = src[i]
        if c == "(":
            depth += 1
        elif c == ")":
            depth -= 1
            if depth == 0:
                return i
    return -1


def _split_args(src: str, mask: List[bool], start: int, end: int) -> List[str]:
    """آرگومان‌های بینِ start..end را روی کاماهای سطحِ بالا می‌شکند (ماسک‌آگاه)."""
    args: List[str] = []
    depth, last = 0, start
    for i in range(start, end):
        if not mask[i]:
            continue
        c = src[i]
        if c in "([{":
            depth += 1
        elif c in ")]}":
            depth -= 1
        elif c == "," and depth == 0:
            args.append(src[last:i].strip())
            last = i + 1
    tail = src[last:end].strip()
    if tail or args:
        args.append(tail)
    return args


def _ct_direction_from_type(expr: str) -> str:
    """جهتِ PositionOpen از آرگومانِ order_type — لیترال یا عبارتِ زمانِ اجرا."""
    if "ORDER_TYPE_BUY" in expr and "ORDER_TYPE_SELL" not in expr:
        return '"BUY"'
    if "ORDER_TYPE_SELL" in expr and "ORDER_TYPE_BUY" not in expr:
        return '"SELL"'
    return '((%s)==ORDER_TYPE_BUY?"BUY":"SELL")' % expr


def _ct_map_call(method: str, args: List[str]) -> Optional[Dict[str, str]]:
    """نگاشتِ آرگومان‌های متدهای CTrade به پارامترهای BridgeCTOrder (OP5-INJ-06).

    نکتهٔ مهم: قیمتِ صریح حذف نمی‌شود و سفارش‌های pending هرگز خودکار تبدیل
    نمی‌شوند؛ پل فقط سفارشِ بازارِ BUY/SELL را می‌شناسد و ندارد نوع/انقضا.
    """
    def A(i: int, default: str = "") -> str:
        v = args[i].strip() if i < len(args) else ""
        return v if v else default
    if method in ("Buy", "Sell"):
        # Buy(volume [,symbol [,price ,sl ,tp [,comment]]])
        if not A(0):
            return None
        return {"symbol": A(1, "_Symbol"), "dir": '"%s"' % method.upper(),
                "volume": A(0), "sl": A(3, "0.0"), "tp": A(4, "0.0"),
                "entry": A(2, "0.0"), "comment": A(5)}
    if method == "PositionOpen":
        # PositionOpen(symbol ,order_type ,volume ,price ,sl ,tp [,comment])
        if len(args) < 4 or not A(0) or not A(1) or not A(2):
            return None
        return {"symbol": A(0), "dir": _ct_direction_from_type(A(1)),
                "volume": A(2), "entry": A(3, "0.0"),
                "sl": A(4, "0.0"), "tp": A(5, "0.0"), "comment": A(6)}
    # A bridge with no order_type/type_time/expiration cannot safely represent pending.
    if method in ("BuyStop", "BuyLimit", "SellStop", "SellLimit"):
        return None
    return None


_CT_METHODS = ("BuyStop", "BuyLimit", "SellStop", "SellLimit",
               "PositionOpen", "Buy", "Sell")


def _rewrite_ctrade_calls(src: str, report: List[str]) -> Tuple[str, int]:
    """فراخوانی‌های CTrade را با BridgeCTOrder(...) جایگزین می‌کند. → (کد, تعداد)."""
    mask = _code_mask(src, "mql5")
    names = _find_ctrade_instances(src, mask)
    if not names:
        return src, 0
    pat = re.compile(
        r'(?<![\w.])(%s)\s*\.\s*(%s)\s*\(' % (
            "|".join(re.escape(n) for n in names), "|".join(_CT_METHODS)))
    edits: List[Tuple[int, int, str]] = []   # (start, end_exclusive, replacement)
    notes: List[str] = []
    pending_notes: List[str] = []
    _PENDING_METHODS = ("BuyStop", "BuyLimit", "SellStop", "SellLimit")
    for m in pat.finditer(src):
        if not mask[m.start()]:
            continue
        open_idx = m.end() - 1
        close_idx = _scan_balanced(src, mask, open_idx)
        if close_idx < 0:
            continue
        method = m.group(2)
        args = _split_args(src, mask, open_idx + 1, close_idx)
        kv = _ct_map_call(method, args)
        if kv is None:
            _line = src.count(chr(10), 0, m.start()) + 1
            if method in _PENDING_METHODS:
                # OP5-INJ-06: پندینگ عمداً تبدیل نمی‌شود (پل نوع/انقضا ندارد).
                pending_notes.append(f"{m.group(1)}.{method} (خط {_line})")
            else:
                notes.append(f"{m.group(1)}.{method} (خط {_line}) — آرگومان‌ها ناکافی؛ دستی وصل کنید")
            continue
        parts = [kv["symbol"], kv["dir"], kv["volume"], kv["sl"], kv["tp"], kv["entry"]]
        if kv.get("comment"):
            parts.append(kv["comment"])
        repl = "%s(%s)" % (_CT_HELPER_NAME, ", ".join(parts))
        edits.append((m.start(), close_idx + 1, repl))
    if not edits:
        if pending_notes:
            report.append("⚠️ سفارش‌های پندینگ عمداً تبدیل نشدند (پل فقط بازارِ BUY/SELL را "
                          "پشتیبانی می‌کند؛ با خودِ OrderSend بفرستید): "
                          + " · ".join(pending_notes[:6]))
        if notes:
            report.append("ℹ️ CTrade: " + " · ".join(notes[:6]))
        return src, 0
    out = src
    for start, end, repl in sorted(edits, key=lambda e: e[0], reverse=True):
        out = out[:start] + repl + out[end:]
    report.append(f"✅ {len(edits)} فراخوانیِ بازارِ CTrade (Buy/Sell/PositionOpen) خودکار به "
                  f"{_CT_HELPER_NAME}(...) → bridge.Send وصل شد. "
                  "خروجیِ bool حفظ شد (true = ارسال به متاتریدر)؛ قیمتِ صریحِ فراخوانی "
                  "(در صورتِ وجود) به‌عنوانِ entry منتقل می‌شود.")
    if pending_notes:
        report.append("⚠️ سفارش‌های پندینگ عمداً تبدیل نشدند (پل فقط بازارِ BUY/SELL را "
                      "پشتیبانی می‌کند؛ با خودِ OrderSend بفرستید): "
                      + " · ".join(pending_notes[:6]))
    if notes:
        report.append("ℹ️ CTrade (وصل‌نشده): " + " · ".join(notes[:6]))
    return out, len(edits)


def _count_ctrade(src: str) -> int:
    """شمارشِ فراخوانی‌های احتمالیِ CTrade — فقط در کد (نه کامنت/رشته)."""
    warn_patterns = [r'\.Buy\s*\(', r'\.Sell\s*\(', r'\bPositionOpen\s*\(']
    hits = 0
    for text, is_code in _split_code_segments(src, "mql5"):
        if is_code:
            for p in warn_patterns:
                hits += len(re.findall(p, text))
    return hits


def _ctrade_warning() -> str:
    return ("⚠️ %d فراخوانیِ شبیهِ CTrade (Buy/Sell/PositionOpen) باقی ماند که خودکار وصل "
            "نشد (مثلاً نمونهٔ CTrade در فایلِ دیگری اعلان شده یا کلاسِ سفارشی است). "
            "برای هر ورود، به‌جای آن این را صدا بزنید:\n"
            "        bridge.Send(_Symbol,\"BUY\",volume, sl, tp, 0, "
            "CRobotBridge::TFfromPeriod((ENUM_TIMEFRAMES)_Period));\n"
            "        (برای فروش \"SELL\"). راهنما در HOW_TO_CONNECT_YOUR_BOT.md")


def _insert_ct_helper(out: str, cls: str, added_in_block: bool) -> str:
    """هلپرِ BridgeCTOrder را «بعد از» اعلانِ bridge درج می‌کند (الزامِ declaration-before-use)."""
    lines = out.splitlines(keepends=False)
    decl_re = re.compile(r'\b%s\s+bridge\s*;' % cls)
    idx = -1
    for i, ln in enumerate(lines):
        if decl_re.search(ln):
            idx = i
            break
    if idx < 0:  # نباید رخ دهد؛ محافظه‌کارانه انتهای فایل
        return out + "\n" + "\n".join(_CT_HELPER_LINES) + "\n"
    lines[idx + 1:idx + 1] = [""] + _CT_HELPER_LINES
    return "\n".join(lines)


def _patch_mqh_include(out: str, url: str, secret: str, inc: str, cls: str,
                       cnt: int, ctrade_hits: int,
                       report: List[str],
                       need_ct_helper: bool = False) -> Tuple[str, List[str]]:
    """مسیرِ فایل‌های include (.mqh): بدونِ OnInit و بدونِ input، داخلِ include-guard.

    (رفعِ باگ: افزودنِ OnInit به include باعثِ «تابع تکراری» در EA می‌شد؛ و درجِ
     اعلان‌ها بیرونِ guard باعثِ «تعریفِ تکراری» هنگامِ include چندگانه می‌شد.)
    """
    lines = out.splitlines(keepends=False)

    # یافتنِ محلِ درج: داخلِ include-guard، بعد از خطِ #define
    ins_at, guard = 0, False
    for i, ln in enumerate(lines):
        if ln.strip().startswith("#ifndef"):
            for j in range(i + 1, len(lines)):
                if lines[j].strip().startswith("#define"):
                    ins_at, guard = j + 1, True
                    break
            break
    if not guard:  # بدونِ guard → بعد از کامنت‌های ابتدایی و خطوطِ خالی
        k = 0
        while k < len(lines) and (lines[k].strip().startswith("//") or lines[k].strip() == ""):
            k += 1
        ins_at = k

    header = [f"//--- {MARKER}: اتصالِ خودکار (فایلِ include) ---"]
    if f"#include <{inc}>" not in out:
        header.append(f'#include <{inc}>')
        report.append(f"include اضافه شد: #include <{inc}>")
    else:
        report.append(f"include از قبل بود: <{inc}>")

    decls: List[str] = []
    if re.search(r'\b%s\s+bridge\s*;' % cls, out) is None:
        decls.append("%s bridge;   // شیءِ پُل (سراسری)" % cls)
        report.append(f"شیءِ سراسری اضافه شد: {cls} bridge;")
    if "void BridgeInit(" not in out:
        decls.append('void BridgeInit() { bridge.Init(%s, %s, 10000); }'
                     '  // این را در OnInit در EA صدا بزنید'
                     % (_mql_string_literal(url), _mql_string_literal(secret)))
        report.append("تابعِ BridgeInit() اضافه شد.")
    # ارتقا (INJ-ADV): هلپرِ CTrade — اگر اعلانِ bridge همین حالا به بلوک اضافه شده،
    # هلپر هم در ادامهٔ همان بلوک می‌آید؛ وگرنه بعد از اعلانِ موجود درج می‌شود.
    _helper_in_block = False
    if need_ct_helper:
        if any("bridge;" in d for d in decls):
            decls += _CT_HELPER_LINES
            _helper_in_block = True
        report.append(f"تابعِ کمکیِ bool {_CT_HELPER_NAME}(...) اضافه شد.")

    block = header + decls + [f"//--- پایانِ {MARKER} ---", ""]
    lines[ins_at:ins_at] = block
    out = "\n".join(lines)

    if need_ct_helper and not _helper_in_block:
        out = _insert_ct_helper(out, cls, added_in_block=False)

    report.append("ℹ️ چون این فایلِ include (.mqh) است، برای پرهیز از «تعریفِ تکراری» "
                  "نه OnInit اضافه شد و نه ورودیِ input؛ فقط کافی است در OnInit در EA اصلی، "
                  "یک بار BridgeInit(); را صدا بزنید.")
    if cnt == 0 and ctrade_hits == 0:
        report.append("⚠️ هیچ OrderSend/CTrade یافت نشد؛ فقط زیرساختِ پُل اضافه شد. "
                      "هرجا سیگنال دارید bridge.Send(...) را صدا بزنید.")
    return out, report


def patch_mql5(src: str, url: str, secret: str,
               is_include: bool = False) -> Tuple[str, List[str]]:
    """کدِ MQL5 را تزریق می‌کند. خروجی: (کدِ جدید، گزارش).

    is_include=True برای فایل‌های .mqh (بدونِ OnInit/input، داخلِ include-guard).
    """
    report: List[str] = []
    if MARKER in src:
        report.append("قبلاً تزریق شده — بدونِ تغییر رد شد.")
        return src, report

    inc = "RobotBridge.mqh"
    cls = "CRobotBridge"
    out = src

    # ۱) جایگزینیِ OrderSend( → bridge.OrderSendBridge(  (فقط در کد، نه کامنت/رشته)
    # اصلاح (INJ-002): تعریفِ wrapper مثل «bool OrderSend(...)» نباید بازنویسی شود؛
    # فقط فراخوانی‌ها. اگر توکنِ قبلی یک نوعِ بازگشتی باشد، declaration است.
    pat = re.compile(r'(?<![\w.])OrderSend\s*\(')
    _decl_re = re.compile(
        r'(?:\b(?:bool|int|uint|long|ulong|void|double|float|string|datetime|color'
        r'|char|uchar|short|ushort)\s+(?:[A-Za-z_]\w*::)?)$')
    def _sub_mql_calls(text):
        def repl(m):
            prefix = text[:m.start()].rstrip()
            if _decl_re.search(prefix + " "):
                return m.group(0)          # declaration — دست نزن
            return "bridge.OrderSendBridge("
        return pat.subn(repl, text)
    _parts = []
    cnt = 0
    for _text, _is_code in _split_code_segments(out, "mql5"):
        if not _is_code:
            _parts.append(_text)
            continue
        _rep, _c = _sub_mql_calls(_text)
        _parts.append(_rep)
        cnt += _c
    out = "".join(_parts)
    if cnt:
        report.append(f"جایگزین شد: OrderSend( → bridge.OrderSendBridge(  ({cnt} مورد)")

    # OP5-INJ-06: OrderSendAsync دست‌نخورده می‌ماند. پل، APIِ همگام دارد و تبدیلِ
    # خودکارِ async به sync می‌تواند ترتیب/زمان‌بندیِ ربات را عوض کند؛ پس به‌جای
    # جابه‌جایی، هشدار می‌دهیم.
    _async_hits = len(re.findall(r'(?<![\w.])OrderSendAsync\s*\(', out))
    if _async_hits:
        report.append(f"⚠️ {_async_hits} فراخوانی OrderSendAsync دست‌نخورده ماند "
                      "(پاسخِ پل همگام است؛ برای پل‌کردن، خودتان bridge.OrderSendBridge را صدا بزنید).")
    # ارتقا (INJ-ADV): اتصالِ خودکارِ CTrade (trade.Buy/Sell/PositionOpen/پندینگ‌ها)
    out, ct_wired = _rewrite_ctrade_calls(out, report)
    cnt += ct_wired
    need_ct_helper = ct_wired > 0 and (_CT_HELPER_NAME + "(") in out \
        and ("bool " + _CT_HELPER_NAME + "(") not in out

    # ۲) هشدار برای CTrade / سایر روش‌ها (شمارشِ کد-محور، روی خروجیِ وصل‌شده)
    ctrade_hits = _count_ctrade(out)
    if ctrade_hits:
        report.append(_ctrade_warning() % ctrade_hits)

    # ── مسیرِ فایل‌های include (.mqh) ──
    if is_include:
        return _patch_mqh_include(out, url, secret, inc, cls, cnt, ctrade_hits, report,
                                  need_ct_helper=need_ct_helper)

    # ── مسیرِ اکسپرت (.mq5) ──
    # ۳) درجِ include بعد از آخرین #property (یا اولِ فایل)
    lines = out.splitlines(keepends=False)
    prop_idx, inc_idx = -1, -1
    for i, ln in enumerate(lines):
        s = ln.strip()
        if s.startswith("#property"):
            prop_idx = i
        if s.startswith(f"#include <{inc}>"):
            inc_idx = i
    header = [f"//--- {MARKER}: اتصالِ خودکار به «برنامهٔ تحلیل» (توسطِ bridge_injector) ---",
              f'#include <{inc}>']
    if inc_idx >= 0:
        header = [f"//--- {MARKER} ---"]
        report.append(f"include از قبل بود: <{inc}>")
    else:
        report.append(f"include اضافه شد: #include <{inc}>")
    # اعلان‌ها باید بعد از include بیایند (رفعِ باگ: استفاده از CRobotBridge پیش از include)
    if inc_idx >= 0:
        ins_at = inc_idx + 1
    elif prop_idx >= 0:
        ins_at = prop_idx + 1
    else:
        ins_at = 0

    # ۴) ورودی‌ها + شیءِ سراسری (اگر نبودند)
    decls: List[str] = []
    if "InpBridgeURL" not in out:
        decls += [
            'input string InpBridgeURL = %s; // آدرسِ برنامه' % _mql_string_literal(url),
            'input string InpSecret    = %s; // توکنِ مشترک' % _mql_string_literal(secret),
            "input int    InpTimeoutMs = 10000;   // مهلتِ درخواست (ms)",
        ]
        report.append("ورودی‌های InpBridgeURL/InpSecret/InpTimeoutMs اضافه شد.")
    else:
        report.append("ورودی‌های Inp* از قبل بودند — دوباره اضافه نشد.")
    _bridge_decl_added = False
    if re.search(r'\b%s\s+bridge\s*;' % cls, out) is None:
        decls += ["%s bridge;   // شیءِ پُل" % cls]
        _bridge_decl_added = True
        report.append(f"شیءِ سراسری اضافه شد: {cls} bridge;")

    block = header + decls + [f"//--- پایانِ {MARKER} ---", ""]
    lines[ins_at:ins_at] = block
    out = "\n".join(lines)

    # ارتقا (INJ-ADV): هلپرِ BridgeCTOrder — باید «بعد از» اعلانِ bridge بیاید
    if need_ct_helper:
        out = _insert_ct_helper(out, cls, added_in_block=_bridge_decl_added)
        report.append(f"تابعِ کمکیِ bool {_CT_HELPER_NAME}(...) اضافه شد.")

    # ۵) درجِ bridge.Init(...) در ابتدای OnInit
    init_call = "bridge.Init(InpBridgeURL, InpSecret, InpTimeoutMs);"
    if "bridge.Init(" not in out:
        m = re.search(r'(int\s+OnInit\s*\([^)]*\)\s*\{)', out)
        if m:
            insert_pos = m.end()
            out = out[:insert_pos] + "\n   " + init_call + "\n" + out[insert_pos:]
            report.append("bridge.Init(...) در ابتدای OnInit درج شد.")
        elif re.search(r'\bOnInit\b', out):
            # OnInit هست ولی الگویش تشخیص داده نشد → OnInit تکراری نساز (رفعِ باگ)
            report.append("⚠️ به‌نظر EA شما OnInit دارد ولی الگوی آن خودکار تشخیص داده نشد. "
                          "برای جلوگیری از OnInit تکراری، چیزی اضافه نشد؛ لطفاً این خط را "
                          "دستی در ابتدای OnInit خود بگذارید:\n        " + init_call)
        else:
            # واقعاً OnInit ندارد → یک OnInit اضافه می‌کنیم
            oninit = ("\n//--- %s: OnInit افزوده‌شده ---\n"
                      "int OnInit()\n{\n   %s\n   if(bridge.Ping()) Print(\"BridgeInit: اتصال برقرار است.\");\n"
                      "   else Print(\"BridgeInit: اتصال/WebRequest را بررسی کنید.\");\n"
                      "   return(INIT_SUCCEEDED);\n}\n" % (MARKER, init_call))
            out += oninit
            report.append("⚠️ OnInit وجود نداشت؛ یک OnInit با bridge.Init(...) اضافه شد.")

    if cnt == 0 and ctrade_hits == 0:
        report.append("⚠️ هیچ فراخوانیِ OrderSend یا CTrade یافت نشد؛ فقط زیرساختِ پُل اضافه شد. "
                      "هرجا سیگنال دارید bridge.Send(...) را صدا بزنید (نگاه کنید به HOW_TO_CONNECT_YOUR_BOT.md).")
    return out, report


# ═════════════════════════════════════════════════════════════════════════════
#  رابطِ مشترک (برای CLI و داشبورد)
# ═════════════════════════════════════════════════════════════════════════════

def patch_source(filename: str, src: str, url: str, secret: str) -> Tuple[str, List[str], str]:
    """بر اساسِ پسوندِ نام، منبع را تزریق می‌کند.

    خروجی: (کدِ جدید، گزارش، نوعِ زبان: 'python'|'mql5').
    در صورتِ پسوندِ پشتیبانی‌نشده، ValueError.
    """
    ext = os.path.splitext(filename)[1].lower()
    # OP5-INJ-04: اعتبارسنجیِ آدرس/توکن پیش از تولیدِ کد (تزریقِ CR/LF در هدر یا
    # ارسالِ secret روی HTTPِ غیرلوکال باید رد شود).
    try:
        url = _validate_base_url(url, secret)
    except ValueError as exc:
        raise ValueError(f"آدرس/توکنِ نامعتبر: {exc}") from exc
    # حفظِ BOM (U+FEFF): برخی ویرایشگرها/متاادیتور فایل را با BOM ذخیره می‌کنند.
    # BOM فقط در ابتدای فایل معتبر است؛ اگر آن را جدا نکنیم، کدِ تزریق‌شده جلوی BOM
    # می‌نشیند و BOM به وسطِ فایل می‌رود → SyntaxError در پایتون. جدا می‌کنیم و در
    # انتها دوباره به ابتدای خروجی می‌چسبانیم.
    bom = ""
    if src[:1] == "\ufeff":
        bom = "\ufeff"
        src = src[1:]
    # حفظِ سبکِ پایان‌خط: اگر ورودی CRLF بود، خروجی هم CRLF بماند (کامپایل را خراب
    # نمی‌کند ولی سبکِ اصلیِ فایلِ کاربر را نگه می‌دارد و diff را تمیز می‌کند).
    crlf = ("\r\n" in src)
    src_norm = src.replace("\r\n", "\n") if crlf else src

    if ext == ".py":
        # اصلاح (INJ-SYNTAX-001): اگر فایلِ کاربر از اول خطای نحوی داشته باشد،
        # تزریق بی‌فایده است و ok:true گمراه‌کننده می‌شود؛ بدونِ تغییر برگردان و
        # دلیل را با شمارهٔ خط گزارش کن.
        try:
            ast.parse(src_norm)
        except SyntaxError as e:
            rep = [f"❌ تزریق انجام نشد: فایلِ پایتونِ شما از قبل خطای نحوی دارد "
                   f"(خط {e.lineno}: {e.msg}). ابتدا فایل را اصلاح کنید و دوباره تلاش کنید."]
            out = (bom + (src_norm.replace("\n", "\r\n") if crlf else src_norm))
            return out, rep, "python"
        new, rep = patch_python(src_norm, url, secret)
        lang = "python"
    elif ext in (".mq5", ".mqh"):
        # اصلاح (INJ-SYNTAX-002): توازنِ آکولادها در بخشِ کد (خارج از رشته/کامنت)
        # را بسنجیم؛ MQL5 را نمی‌توان کامل پارس کرد، پس فقط هشدارِ شفاف می‌دهیم.
        _code = "".join(t for t, isc in _split_code_segments(src_norm, "mql5") if isc)
        _depth = 0
        _unbal = False
        for _ch in _code:
            if _ch == "{":
                _depth += 1
            elif _ch == "}":
                _depth -= 1
                if _depth < 0:
                    _unbal = True
                    break
        if _depth != 0:
            _unbal = True
        new, rep = patch_mql5(src_norm, url, secret, is_include=(ext == ".mqh"))
        if _unbal:
            rep.insert(0, "⚠️ آکولادهای { } فایلِ شما (خارج از رشته/کامنت) متوازن نیستند؛ "
                          "احتمالاً فایل ناقص است و در MetaEditor کامپایل نمی‌شود. "
                          "تزریق انجام شد ولی قبل از کامپایل، فایلِ اصلی را بررسی کنید.")
        lang = "mql5"
    else:
        raise ValueError(f"پسوندِ پشتیبانی‌نشده: {ext} (فقط .py/.mq5/.mqh)")

    if crlf:
        new = new.replace("\n", "\r\n")
    if bom:
        new = bom + new
    return new, rep, lang


def make_diff(path: str, old: str, new: str, limit: int = 400) -> str:
    diff = difflib.unified_diff(old.splitlines(), new.splitlines(),
                                fromfile=path, tofile=path + " (patched)", lineterm="")
    return "\n".join(list(diff)[:limit])


# ═════════════════════════════════════════════════════════════════════════════
#  هستهٔ اجرا (CLI)
# ═════════════════════════════════════════════════════════════════════════════

def _out_path(path: str) -> str:
    base, ext = os.path.splitext(path)
    return f"{base}.bridge{ext}"


def process_file(path: str, url: str, secret: str,
                 in_place: bool, dry_run: bool) -> bool:
    ext = os.path.splitext(path)[1].lower()
    if ext not in (".py", ".mq5", ".mqh"):
        print(f"⏭️  رد شد (پسوندِ پشتیبانی‌نشده): {path}")
        return False

    with open(path, encoding="utf-8") as f:
        src = f.read()

    try:
        new_src, report, lang = patch_source(path, src, url, secret)
    except ValueError as exc:
        print(f"❌ تزریق انجام نشد: {exc}")
        return False
    changed = (new_src != src)

    print("\n" + "═" * 70)
    print(f"📄 {path}   [{'پایتون' if lang=='python' else 'MQL5'}]")
    print("─" * 70)
    for r in report:
        print("  •", r)
    if not changed:
        print("  (تغییری اعمال نشد)")
        return False

    if dry_run:
        print("\n  --- تفاوت (dry-run؛ چیزی نوشته نشد) ---")
        for d in make_diff(path, src, new_src, 120).splitlines():
            print("   " + d)
        return True

    if in_place:
        bak = path + ".bak"
        if not os.path.exists(bak):
            with open(bak, "w", encoding="utf-8") as f:
                f.write(src)
            print(f"  💾 پشتیبان: {bak}")
        target = path
    else:
        target = _out_path(path)

    with open(target, "w", encoding="utf-8") as f:
        f.write(new_src)
    print(f"  ✅ نوشته شد: {target}")
    return True


def gather(paths: List[str], recursive: bool) -> List[str]:
    out: List[str] = []
    for p in paths:
        if os.path.isdir(p):
            found: List[str] = []
            if recursive:
                for root, _dirs, files in os.walk(p):
                    for fn in files:
                        if fn.lower().endswith((".py", ".mq5", ".mqh")):
                            found.append(os.path.join(root, fn))
            else:
                for fn in sorted(os.listdir(p)):
                    fp = os.path.join(p, fn)
                    if os.path.isfile(fp) and fn.lower().endswith((".py", ".mq5", ".mqh")):
                        found.append(fp)
            # هنگامِ پیمایشِ پوشه، خروجی‌های خودمان و این اسکریپت را نادیده بگیر
            out += [f for f in found
                    if ".bridge." not in os.path.basename(f)
                    and os.path.basename(f) != os.path.basename(__file__)]
        elif os.path.isfile(p):
            out.append(p)   # فایلِ صریح همیشه پردازش می‌شود
        else:
            print(f"⚠️ یافت نشد: {p}")
    return out


def main(argv: List[str] | None = None) -> int:
    ap = argparse.ArgumentParser(
        description="تزریق‌گرِ خودکارِ کدِ اتصالِ ربات/اکسپرت به «برنامهٔ تحلیل» (اتصالِ محلی).")
    ap.add_argument("paths", nargs="+", help="فایل یا پوشهٔ ربات‌ها (.py/.mq5/.mqh)")
    ap.add_argument("--url", default=DEFAULT_URL, help="آدرسِ برنامه (پیش‌فرض: %(default)s)")
    ap.add_argument("--secret", default="", help="توکنِ مشترک (در صورتِ تنظیم در تب)")
    ap.add_argument("--in-place", action="store_true",
                    help="ویرایشِ خودِ فایل (با ساختِ نسخهٔ .bak)")
    ap.add_argument("--dry-run", action="store_true",
                    help="فقط گزارش و تفاوت؛ چیزی نوشته نشود")
    ap.add_argument("--recursive", action="store_true",
                    help="پیمایشِ زیرپوشه‌ها هنگامِ دادنِ پوشه")
    args = ap.parse_args(argv)

    files = gather(args.paths, args.recursive)
    if not files:
        print("هیچ فایلِ قابلِ‌پردازش (.py/.mq5/.mqh) یافت نشد.")
        return 1

    print(f"🔧 {len(files)} فایل برای پردازش | url={args.url} | "
          f"{'dry-run' if args.dry_run else ('in-place' if args.in_place else 'خروجیِ جدا (.bridge)')}")
    n_changed = 0
    for fp in files:
        try:
            if process_file(fp, args.url, args.secret, args.in_place, args.dry_run):
                n_changed += 1
        except Exception as exc:  # noqa
            print(f"  ❌ خطا در {fp}: {exc}")

    print("\n" + "═" * 70)
    print(f"پایان. {n_changed} فایل تغییر کرد (از {len(files)}).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
