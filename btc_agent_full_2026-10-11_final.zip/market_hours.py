"""تشخیص باز/بسته بودن بازارها با پشتیبانیِ کاملِ DST و تعطیلات (OP5-MH-DST).

- کریپتو: ۲۴/۷ همیشه باز است (override بروکر محفوظ است).
- فارکس/فلز/کالا/شاخص (CFD): ساعاتِ «محلیِ نیویورک» ملاک است؛ نه یک ساعتِ ثابتِ UTC.
  فارکس: یکشنبه ۱۷:۰۰ نیویورک باز می‌شود و جمعه ۱۷:۰۰ نیویورک بسته می‌شود
  (زمستان ۲۲:۰۰ UTC و تابستان ۲۱:۰۰ UTC — اختلافِ DST خودبه‌خود لحاظ می‌شود).
- فلز/کالا: پنجشنبه/جمعهٔ ۱۷:۰۰–۱۸:۰۰ نیویورک break روزانه دارند.
- شاخص (CFD): ملاک سشنِ CFDِ بروکر است، نه فقط ۰۹:۳۰–۱۶:۰۰ سهام؛ فقط آخر هفته،
  تعطیلاتِ آمریکا، بریکِ ۱۷:۰۰–۱۸:۰۰ نیویورک و روزهای «بسته‌شدنِ زودتر» (۱۳:۰۰
  نیویورک، مثلِ شبِ کریسمس/July-3) بسته می‌شود تا تریدِ سالمِ پیش‌ازبازار بلاک نشود.
- اختلافِ ساعتِ کارگزار: اگر ساعتِ سرورِ بروکر با UTC اختلاف داشته باشد (مثلاً
  GMT+2/+3 در بسیاری از بروکرها)، این ماژول با «ساعتِ نیویورکِ DST-aware» کار
  می‌کند؛ app.py زمانِ بروکر را برای زمان‌بندیِ برنامه و mt5_bridge ساعتِ زنده را
  برای تشخیصِ کهنه‌بودن به کار می‌برد.

مرجع‌ها: سشنِ بروکرِ واقعی همیشه مقدم است؛ این ماژول تقریبِ محافظه‌کارانه و
DST-aware می‌دهد تا معاملهٔ واقعی روی بازارِ بسته ارسال نشود.
"""
from __future__ import annotations

from datetime import date, datetime, time, timedelta, timezone
from zoneinfo import ZoneInfo

import symbols as sym

NY = ZoneInfo("America/New_York")

_SESSION_CLASSES = {"forex", "metal", "commodity", "index"}

_CRYPTO_HINTS = ("BTC", "XBT", "BITCOIN", "ETH", "ETHEREUM", "SOL", "SOLANA",
                 "BNB", "XRP", "RIPPLE", "DOGE", "ADA", "LTC", "TRX", "DOT",
                 "AVAX", "LINK", "SHIB", "PEPE", "TON", "CRYPTO", "PERP")


def _as_utc(now: datetime | None) -> datetime:
    if now is None:
        return datetime.now(timezone.utc)
    if now.tzinfo is None:
        # OP5-MH-DST: ورودیِ naive خطرناک است؛ محافظه‌کارانه UTC فرض می‌شود
        return now.replace(tzinfo=timezone.utc)
    return now.astimezone(timezone.utc)


def _nth_weekday(year, month, weekday, n):
    d = date(year, month, 1)
    return d + timedelta(days=(weekday - d.weekday()) % 7 + 7 * (n - 1))


def _last_weekday(year, month, weekday):
    d = (date(year + 1, 1, 1) - timedelta(days=1) if month == 12
         else date(year, month + 1, 1) - timedelta(days=1))
    return d - timedelta(days=(d.weekday() - weekday) % 7)


def _observed(d):
    return (d - timedelta(days=1) if d.weekday() == 5
            else d + timedelta(days=1) if d.weekday() == 6 else d)


def _good_friday(year):
    a = year % 19
    b = year // 100
    c = year % 100
    d = b // 4
    e = b % 4
    f = (b + 8) // 25
    g = (b - f + 1) // 3
    h = (19 * a + b - d - g + 15) % 30
    i = c // 4
    k = c % 4
    l = (32 + 2 * e + 2 * i - h - k) % 7
    m = (a + 11 * h + 22 * l) // 451
    month = (h + l - 7 * m + 114) // 31
    day = (h + l - 7 * m + 114) % 31 + 1
    return date(year, month, day) - timedelta(days=2)


def us_holidays(year):
    """تعطیلاتِ بازارِ آمریکا (NYSE/CME-style) برای سالِ میلادی."""
    return {
        _observed(date(year, 1, 1)),        # New Year
        _nth_weekday(year, 1, 0, 3),        # MLK
        _nth_weekday(year, 2, 0, 3),        # Presidents' Day
        _good_friday(year),                 # Good Friday
        _last_weekday(year, 5, 0),          # Memorial Day
        _observed(date(year, 6, 19)),       # Juneteenth
        _observed(date(year, 7, 4)),        # July 4
        _nth_weekday(year, 9, 0, 1),        # Labor Day
        _nth_weekday(year, 11, 3, 4),       # Thanksgiving
        _observed(date(year, 12, 25)),      # Christmas
    }


def us_early_closes(year):
    """روزهای بسته‌شدنِ زودترِ شاخص‌ها (۱۳:۰۰ نیویورک)."""
    return {
        _observed(date(year, 7, 4)),
        _nth_weekday(year, 11, 3, 4) + timedelta(days=1),   # Black Friday
        date(year, 12, 24),
    }


def _class_for(symbol: str) -> str:
    """کلاسِ دارایی برای نمادِ داخلی یا نمادِ کارگزار (با پسوند)."""
    s = (symbol or "").strip().upper()
    if s in sym.SYMBOLS:
        return sym.SYMBOLS[s].get("asset_class", "crypto")
    try:  # نگاشتِ کارگزار→داخلی (واردسازیِ تنبل برای پرهیز از وابستگیِ حلقوی)
        import mt5_bridge
        mapped = (mt5_bridge.internal_for_broker(symbol) or "").upper()
        if mapped in sym.SYMBOLS:
            return sym.SYMBOLS[mapped].get("asset_class", "crypto")
    except Exception:  # noqa
        pass
    base = s.split(".")[0].split("_")[0].split("-")[0]
    return "crypto" if any(h in base for h in _CRYPTO_HINTS) else "forex"


def _is_open_local(ac: str, local: datetime) -> bool:
    """باز بودن بر اساس ساعتِ محلیِ نیویورک (DST-aware)."""
    wd = local.weekday()
    t = local.time().replace(tzinfo=None)
    d = local.date()
    if ac == "crypto":
        return True
    if wd == 5:                                  # شنبه
        return False
    if ac != "forex" and d in us_holidays(d.year):
        # شاخص/فلز/کالا در تعطیلاتِ رسمیِ آمریکا بسته‌اند؛ فارکسِ نقدی فقط ۱ ژانویه و
        # ۲۵ دسامبر تعطیل است (بقیهٔ تعطیلات را CME معامله می‌کند) — برای پرهیز از
        # بلاکِ اشتباهیِ ترید در روزهایی مثل Labor Day، فارکس خارج از این دو مورد باز
        # در نظر گرفته می‌شود.
        return False
    if ac == "forex" and (d.month, d.day) in {(1, 1), (12, 25)}:
        return False
    if ac == "forex":
        if wd == 6:                              # یکشنبه
            return t >= time(17, 0)
        if wd == 4:                              # جمعه
            return t < time(17, 0)
        return True
    if ac in {"metal", "commodity"}:
        # RV-1-7: فلز/کالا هم در روزهای بستنِ زودهنگام (۲۴ دسامبر/جمعهٔ سیاه)
        # ساعتِ ۱۳:۰۰ نیویورک تعطیل می‌شوند؛ پیش‌تر فقط شاخص‌ها این را رعایت می‌کردند.
        end = time(13, 0) if d in us_early_closes(d.year) else time(17, 0)
        if wd == 6:
            return t >= time(18, 0)
        if wd == 4 and t >= end:
            return False
        if t >= end:
            return False
        return not (time(17, 0) <= t < time(18, 0))   # break روزانه
    if ac == "index":
        # OP5-MH-IDX: CFDِ شاخص در بروکرهای MT5 تقریباً ۲۴ساعته است (پیش/پس‌ازبازار هم
        # معامله می‌شود)؛ پس ملاک، سشنِ CFD است نه فقط ۰۹:۳۰–۱۶:۰۰. فقط آخر هفته،
        # تعطیلاتِ آمریکا، بریکِ روزانهٔ ۱۷:۰۰–۱۸:۰۰ نیویورک و بسته‌شدنِ زودتر (۱۳:۰۰)
        # بسته می‌شود — تا هم تریدِ سالمِ پیش‌ازبازار بلاک نشود و هم روزِ تعطیل.
        end = time(13, 0) if d in us_early_closes(d.year) else time(17, 0)
        if wd == 6:
            return t >= time(18, 0)
        if wd == 4 and t >= end:
            return False
        if wd <= 4:
            if t >= end:
                return False
            return not (time(17, 0) <= t < time(18, 0))
    return False


def is_open(symbol: str, now: datetime | None = None) -> bool:
    """آیا بازارِ این نماد اکنون باز است؟ (کریپتو ۲۴/۷)"""
    u = _as_utc(now)
    ac = _class_for(symbol)
    if ac not in _SESSION_CLASSES:
        return True
    return _is_open_local(ac, u.astimezone(NY))


def _next_transition(symbol: str, now: datetime) -> datetime:
    """نخستین دقیقه‌ای که وضعیتِ باز/بسته بودن عوض می‌شود."""
    base = is_open(symbol, now)
    cur = now.replace(second=0, microsecond=0) + timedelta(minutes=1)
    for _ in range(10 * 24 * 60):
        if is_open(symbol, cur) != base:
            return cur
        cur += timedelta(minutes=1)
    return cur


def minutes_to_close(symbol: str, now: datetime | None = None):
    """۰ اگر بسته باشد، دقیقه تا بسته‌شدنِ سشن، و None برای نمادهای ۲۴/۷."""
    u = _as_utc(now)
    ac = _class_for(symbol)
    if ac not in _SESSION_CLASSES:
        return None
    if not is_open(symbol, u):
        return 0
    return max(0, int((_next_transition(symbol, u) - u).total_seconds() // 60))


def status(symbol: str, now: datetime | None = None) -> dict:
    """وضعیت کاملِ بازارِ نماد برای نمایش و منطق (سازگار با نسخهٔ قبلی)."""
    u = _as_utc(now)
    ac = _class_for(symbol)
    if ac not in _SESSION_CLASSES:
        return {
            "open": True, "asset_class": ac, "always_open": True,
            "next_change_ts": None, "next_change_in_min": None,
            "minutes_to_close": None,
            "reason_fa": "کریپتو ۲۴/۷ باز است؛ سشنِ CFDِ بروکر ممکن است متفاوت باشد.",
            "reason_en": "Crypto is treated as 24/7; broker CFD session may override it.",
            "timezone": NY.key,
        }

    op = is_open(symbol, u)
    nxt = _next_transition(symbol, u)
    local = u.astimezone(NY)
    wd = local.weekday()
    if op:
        reason_fa = "بازار باز است."
        reason_en = "Market is open."
    elif local.date() in us_holidays(local.year):
        reason_fa = "امروز تعطیلاتِ رسمیِ بازارِ آمریکا است؛ بازار بسته است."
        reason_en = "US market holiday — closed."
    elif wd == 5:
        reason_fa = "امروز شنبه است و بازارهای سنتی تعطیل‌اند."
        reason_en = "It's Saturday — traditional markets are closed."
    elif wd == 4 and local.time() >= time(17, 0):
        reason_fa = "بازار برای آخر هفته بسته شده است (جمعه ۱۷:۰۰ نیویورک)."
        reason_en = "Market closed for the weekend (Friday 17:00 New York)."
    elif wd == 6:
        _open_at = "۱۸:۰۰" if ac in {"metal", "commodity", "index"} else "۱۷:۰۰"
        reason_fa = f"یکشنبه است و بازار هنوز باز نشده است ({_open_at} نیویورک باز می‌شود)."
        reason_en = f"Sunday — market not open yet (opens Sunday at {_open_at.replace('۱۸:۰۰','18:00').replace('۱۷:۰۰','17:00')} New York)."
    else:
        reason_fa = "بازار در این سشن/تعطیلی بسته است."
        reason_en = "Market is closed for this session/holiday."

    return {
        "open": op, "asset_class": ac, "always_open": False,
        "next_change_ts": nxt.timestamp(),
        "next_change_in_min": max(0, int((nxt - u).total_seconds() // 60)),
        "minutes_to_close": minutes_to_close(symbol, u),
        "reason_fa": reason_fa, "reason_en": reason_en,
        "timezone": NY.key, "local_time": local.isoformat(),
        "holiday": local.date() in us_holidays(local.year),
    }


# ─────────────────────────────────────────────────────────────────────────────
#  محافظتِ نزدیکِ بسته‌شدن (OP5-MH-CUTOFF): جلوگیری از ورود در دقایقِ آخر و
#  بستنِ خودکار پیش از پایانِ سشن/آخر هفته. این توابع بی‌طرفِ بروکر‌اند و فقط
#  با ساعاتِ همین ماژول کار می‌کنند؛ سرویسِ پس‌زمینه می‌تواند آن‌ها را زمان‌بندی کند.
# ─────────────────────────────────────────────────────────────────────────────

# RV-1-7: پنجرهٔ «رول‌اوورِ» روزانهٔ نیویورک (۱۶:۵۵–۱۷:۱۰) — در این دقایق بروکرهای
# زیادی اسپرد را باز می‌کنند و کیفیتِ اجرا افت می‌کند؛ ورودِ تازه مسدود می‌شود.
ROLLOVER_START = time(16, 55)
ROLLOVER_END = time(17, 10)


def is_rollover(symbol: str, now: datetime | None = None) -> bool:
    """آیا الان در پنجرهٔ رول‌اوورِ روزانه‌ی نیویورک هستیم؟ (کریپتو مستثناست)"""
    if _class_for(symbol) == "crypto":
        return False
    local = _as_utc(now).astimezone(NY)
    if local.weekday() == 5:            # شنبه بازار بسته است
        return False
    t = local.time().replace(tzinfo=None)
    return ROLLOVER_START <= t < ROLLOVER_END


def should_block_new_entry(symbol: str, now: datetime | None = None,
                           cutoff_min: int = 30, rollover_min: int = 15):
    """(block, reason) — آیا ورودِ تازه در این نماد مجاز نیست؟ (محافظه‌کارانه)"""
    if not is_open(symbol, now):
        return True, "market closed"
    left = minutes_to_close(symbol, now)
    if left is not None and left <= max(0, int(cutoff_min)):
        return True, f"session closes in {left} min"
    # RV-1-7: در پنجرهٔ رول‌اوور (و N دقیقه پیش از آن) ورودِ تازه ممنوع است.
    try:
        _rm = max(0, int(rollover_min))
    except (TypeError, ValueError):
        _rm = 15
    if is_rollover(symbol, now):
        return True, "rollover window (spread widening)"
    if _rm > 0:
        local = _as_utc(now).astimezone(NY)
        _t = local.time().replace(tzinfo=None)
        _start_dt = local.replace(hour=ROLLOVER_START.hour, minute=ROLLOVER_START.minute,
                                  second=0, microsecond=0)
        _mins_to = (_start_dt - local).total_seconds() / 60.0
        if 0 <= _mins_to <= _rm and local.weekday() != 5:
            return True, f"rollover in {int(_mins_to)} min (spread widening)"
    return False, ""


# RV-1-8 (بازبینیِ ۲۰۲۶-۱۰-۱۱): تفکیکِ «بسته‌شدنِ آخر هفته/تعطیلات» از «بریکِ
# روزانه». پیش‌تر فقط ورودِ جدید در بازارِ بسته مسدود می‌شد و پوزیشن‌ها/سفارش‌های
# معلق از جمعه ۱۷:۰۰ نیویورک تا یکشنبه باز می‌ماندند (ریسکِ گپِ آخر هفته).
def close_kind(symbol: str, now: datetime | None = None, span_hours: int = 8) -> dict:
    """نوعِ بسته‌شدنِ *بعدیِ* نماد: weekend | holiday | long_close | daily_break | none.

    اگر بازار پس از بسته‌شدن تا `span_hours` ساعت باز نشود، بسته‌شدن «طولانی»
    تلقی می‌شود (آخر هفته/تعطیلات) و نه بریکِ روزانه.
    """
    u = _as_utc(now)
    out = {"kind": "none", "minutes_to_close": None, "close_at": None}
    ac = _class_for(symbol)
    if ac not in _SESSION_CLASSES:          # کریپتو ۲۴/۷
        return out
    left = minutes_to_close(symbol, u)
    out["minutes_to_close"] = left
    if left is None:
        return out
    if left <= 0:
        out["kind"] = "closed"
        return out
    close_at = u + timedelta(minutes=int(left))
    out["close_at"] = close_at
    reopened = False
    for h in range(1, max(1, int(span_hours)) + 1):
        if is_open(symbol, close_at + timedelta(hours=h)):
            reopened = True
            break
    if reopened:
        out["kind"] = "daily_break"
        return out
    local = close_at.astimezone(NY)
    if local.weekday() in (4, 6):           # جمعه‌شب / یکشنبه‌شب
        out["kind"] = "weekend"
    elif local.date() in us_holidays(local.year) or local.date() in us_early_closes(local.year):
        out["kind"] = "holiday"
    else:
        out["kind"] = "long_close"
    return out


def due_symbols(symbols_list, now: datetime | None = None, cutoff_min: int = 30):
    """نمادهایی که سشن‌شان تا ≤ cutoff دقیقهٔ دیگر تمام می‌شود (یا همین حالا بسته‌اند)."""
    due = []
    for s in symbols_list or []:
        left = minutes_to_close(s, now)
        if left is not None and (not is_open(s, now) or left <= max(0, int(cutoff_min))):
            due.append(s)
    return due


def close_before_session_end(mt5_bridge, symbols_list, now: datetime | None = None,
                            cutoff_min: int = 30, magic_only: bool = True,
                            symbols_override=None, cancel_pending: bool = False):
    """پوزیشن‌های بازِ نمادهایی که سشن‌شان تمام می‌شود را می‌بندد (OP5-MH-CLOSE).

    فقط پوزیشن‌های همان نمادهای «در آستانهٔ پایان» بسته می‌شوند؛ پوزیشن‌های ۲۴/۷
    (کریپتو) دست‌نخورده می‌مانند — بستنِ همه‌چیز پشتِ سرِ تعطیلیِ فارکس درست نیست.
    """
    # RV-1-8: فهرستِ صریحِ نمادها (گاردِ آخر هفته/تعطیلات) بر محاسبهٔ خودکار مقدم است.
    due = ([str(x).upper() for x in (symbols_override or [])]
           if symbols_override else due_symbols(symbols_list, now=now, cutoff_min=cutoff_min))
    if not due:
        return {"ok": True, "due": [], "closed": [], "errors": []}
    if not hasattr(mt5_bridge, "positions") or not hasattr(mt5_bridge, "close_position"):
        # مسیرِ جانشین: پُلِ ساده‌ای که فقط close_all دارد
        r = mt5_bridge.close_all(magic_only=magic_only)
        results = r.get("results") or []
        closed = [x.get("ticket") for x in results if x.get("ok")]
        errors = [f"{x.get('ticket')}: {x.get('error') or 'close failed'}"
                  for x in results if not x.get("ok")]
        return {"ok": bool(r.get("ok")), "due": due, "closed": closed, "errors": errors}

    pres = mt5_bridge.positions(magic_only=magic_only)
    if not pres.get("ok"):
        return {"ok": False, "due": due, "closed": [], "errors": ["position state unavailable"],
                "error": pres.get("error")}
    due_set = {str(x).upper() for x in due}
    closed, errors = [], []
    for pos in (pres.get("positions") or []):
        bsym = str(pos.get("symbol") or "").upper()
        try:
            internal = (mt5_bridge.internal_for_broker(bsym) or bsym).upper()
        except Exception:  # noqa
            internal = bsym
        if internal not in due_set and bsym not in due_set:
            continue
        res = mt5_bridge.close_position(int(pos["ticket"]))
        if res.get("ok"):
            closed.append(pos.get("ticket"))
        else:
            errors.append(f"{pos.get('ticket')}: {res.get('error') or 'close failed'}")
    # RV-1-8: سفارش‌های معلقِ همان نمادها هم باید برداشته شوند؛ معلقی که پس از
    # بسته‌شدنِ آخر هفته/تعطیلات فعال شود دقیقاً همان ریسکِ گپ را می‌سازد.
    cancelled = []
    if cancel_pending and hasattr(mt5_bridge, "pending_orders"):
        try:
            po = mt5_bridge.pending_orders(magic_only=magic_only)
            for od in (po.get("orders") or []):
                osym = str(od.get("symbol") or "").upper()
                try:
                    ointernal = (mt5_bridge.internal_for_broker(osym) or osym).upper()
                except Exception:  # noqa
                    ointernal = osym
                if ointernal not in due_set and osym not in due_set:
                    continue
                rc = mt5_bridge.cancel_order(int(od["ticket"]))
                if rc.get("ok"):
                    cancelled.append(od.get("ticket"))
                else:
                    errors.append(f"{od.get('ticket')}: {rc.get('error') or 'cancel failed'}")
        except Exception as e:  # noqa
            errors.append(f"pending sweep: {e}")
    return {"ok": not errors, "due": due, "closed": closed,
            "cancelled": cancelled, "errors": errors}


if __name__ == "__main__":
    import json
    for s in ["BTC", "EURUSD", "XAU", "SPX"]:
        print(s, json.dumps(status(s), ensure_ascii=False))
