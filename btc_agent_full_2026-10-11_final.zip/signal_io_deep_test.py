# -*- coding: utf-8 -*-
"""تستِ عمیقِ «دریافت و ارسالِ سیگنال‌های معاملاتی» روی سرورِ زنده.

بخش دریافت (receive):
  • /api/signal برای ۱۰ نماد × ۲ تایم‌فریم + تایم‌فریم‌های اضافه، با اعتبارسنجیِ
    عمیقِ ساختار: قیمت/ATR/جهت/اطمینان/نقشه (ورود، دقیقاً ۳ حدِ سود، حد ضرر،
    ترتیب و سمتِ درست در LONG و SHORT، RR صعودی و سازگار با فرمول)، کندل‌ها و
    EMAها، سطوحِ حمایت/مقاومت نسبت به قیمت، وضعیتِ بازار (کریپتو ۲۴/۷ در برابرِ
    بسته‌بودنِ آخرِ هفتهٔ غیرکریپتو — امروز واقعی)، احساسات و فاندامنتال.
  • خطاها: نمادِ ناشناخته، تایم‌فریمِ نامعتبر.
  • کَش: فراخوانِ دوم باید سریع باشد.
  • /api/scan و /api/mtf و /api/compare.

بخش ارسال (send):
  • /api/mt5/send به‌صورتِ dry_run (پیش‌نمایشِ واقعی لگ‌ها): split=۳ لگ، single=۱ لگ،
    سمت/گِردشدنِ SL/TP در هر دو جهت، جمعِ حجمِ لگ‌ها.
  • مسیرِ ربات /api/robot/order: payload با مترادف‌ها (side/lots/tp1..)، نرمال‌سازی،
    داوری، فیلتر اخبار/زمان‌بندی، جلوگیری از تکرار (dedupe)، و payloadهای خراب (400).
  • احرازِ هویت ربات: secret درست/غلط (401) و بازگردانی تنظیمات.
"""
import os as _os_env; _os_env.environ.setdefault("BTC_AGENT_ALLOW_INSECURE_ROBOT", "1")  # محیط تست
import json
import math
import time
import datetime as dt

import requests

BASE = "http://localhost:8000"
PASS = 0
FAIL = 0
FAILURES = []


def chk(name, cond, detail=""):
    global PASS, FAIL
    if cond:
        PASS += 1
    else:
        FAIL += 1
        FAILURES.append({"name": name, "detail": str(detail)[:300]})
        print(f"   FAIL  {name} — {detail}")


def get(path, **params):
    r = requests.get(BASE + path, params=params, timeout=120)
    try:
        return r.status_code, r.json()
    except Exception:
        return r.status_code, {"_raw": r.text[:200]}


def post(path, body, headers=None):
    r = requests.post(BASE + path, json=body, headers=headers or {}, timeout=120)
    try:
        return r.status_code, r.json()
    except Exception:
        return r.status_code, {"_raw": r.text[:200]}


CRYPTO = {"BTC", "ETH", "SOL"}
SYMBOLS = ["BTC", "ETH", "SOL", "XAU", "XAG", "EURUSD", "GBPUSD", "USDJPY", "SPX", "NASDAQ"]
TFS = ["15m", "1h"]
EXTRA = [("BTC", "5m"), ("XAU", "4h")]

# امروزِ واقعی شنبه است؟ (برای چکِ بسته‌بودنِ بازارهای غیرکریپتو از مسیرِ دریافت)
NOW = dt.datetime.now(dt.timezone.utc)
IS_WEEKEND = NOW.weekday() in (5, 6)  # شنبه/یکشنبه

print("=" * 72)
print(" تستِ عمیقِ دریافت و ارسالِ سیگنال‌های معاملاتی (سرورِ زنده، دادهٔ واقعی)")
print(f"   اکنونِ UTC: {NOW:%Y-%m-%d %H:%M} · آخرِ هفته={IS_WEEKEND}")
print("=" * 72)

# ────────────────────────── بخش ۱: دریافتِ سیگنال ──────────────────────────
print("\n── ۱) دریافتِ سیگنال: اعتبارسنجیِ عمیقِ ساختار برای همهٔ نمادها ──")
SIGNALS = {}
for sym in SYMBOLS:
    for tf in TFS + [e[1] for e in EXTRA if e[0] == sym]:
        tag = f"{sym}/{tf}"
        st, d = get("/api/signal", symbol=sym, tf=tf, ai=0)
        chk(f"{tag}: پاسخ ۲۰۰", st == 200, st)
        data = (d or {}).get("data") or {}
        if not data:
            chk(f"{tag}: بدنهٔ data موجود", False, str(d)[:120])
            continue
        SIGNALS[(sym, tf)] = data
        price = data.get("price")
        chk(f"{tag}: قیمت معتبر", isinstance(price, (int, float)) and math.isfinite(price) and price > 0, price)
        chk(f"{tag}: منبعِ داده ثبت شده", bool(data.get("data_source")), data.get("data_source"))
        chk(f"{tag}: interval انعکاسِ tf", data.get("interval") == tf, data.get("interval"))
        atr = data.get("atr")
        chk(f"{tag}: ATR مثبت", isinstance(atr, (int, float)) and atr > 0, atr)
        direction = data.get("direction")
        chk(f"{tag}: جهت معتبر", direction in ("LONG", "SHORT", "NEUTRAL"), direction)
        conf = data.get("confidence")
        chk(f"{tag}: اطمینان ۰..۱۰۰", isinstance(conf, (int, float)) and 0 <= conf <= 100, conf)
        sc = data.get("internal_score")
        chk(f"{tag}: امتیاز متناهی", isinstance(sc, (int, float)) and math.isfinite(sc), sc)
        if direction in ("LONG", "SHORT") and isinstance(sc, (int, float)):
            chk(f"{tag}: علامتِ امتیاز با جهت سازگار",
                (sc > 0) == (direction == "LONG") or abs(sc) < 1e-9, f"{direction} score={sc}")

        # ── نقشهٔ معامله: ورود، دقیقاً ۳ حدِ سود، حد ضرر، سمت/ترتیب/RR
        plan = data.get("plan") or {}
        chk(f"{tag}: جهتِ نقشه = جهتِ سیگنال", plan.get("direction") == direction,
            f"{plan.get('direction')} vs {direction}")
        entry, sl = plan.get("entry"), plan.get("stop_loss")
        tps = plan.get("take_profits") or []
        chk(f"{tag}: ورود معتبر و نزدیکِ قیمت",
            isinstance(entry, (int, float)) and entry > 0 and abs(entry - price) / price < 0.08,
            f"entry={entry} price={price}")
        if direction == "NEUTRAL":
            # طراحیِ عمدی: در محدودهٔ خنثی نقشهٔ ورود صادر نمی‌شود (توصیهٔ صبر)
            chk(f"{tag}: NEUTRAL بدونِ نقشهٔ ورود (sl/tp خالی + یادداشت)",
                not tps and plan.get("stop_loss") in (None, 0) and bool(plan.get("note")),
                f"tps={len(tps)} sl={plan.get('stop_loss')}")
            continue
        chk(f"{tag}: دقیقاً ۳ حدِ سود", len(tps) == 3, len(tps))
        if len(tps) == 3 and isinstance(entry, (int, float)) and isinstance(sl, (int, float)):
            prices = [t.get("price") for t in tps]
            labels = [t.get("label") for t in tps]
            rrs = [t.get("rr") for t in tps]
            closes = [t.get("close_pct") for t in tps]
            chk(f"{tag}: برچسب‌های TP1..TP3", labels == ["TP1", "TP2", "TP3"], labels)
            chk(f"{tag}: close_pct معتبر و جمع ≤۱۰۰",
                all(isinstance(c, (int, float)) and 0 < c <= 100 for c in closes)
                and sum(closes) <= 100 + 1e-9, closes)
            risk = abs(entry - sl)
            chk(f"{tag}: ریسکِ واحد مثبت و برابرِ |entry−sl|",
                risk > 0 and abs((plan.get("risk_per_unit") or 0) - risk) <= max(risk * 0.02, 1e-9),
                f"risk={risk} vs {plan.get('risk_per_unit')}")
            if direction == "LONG":
                chk(f"{tag}: LONG: sl<entry<tp1<tp2<tp3",
                    sl < entry < prices[0] < prices[1] < prices[2],
                    f"sl={sl} e={entry} tps={prices}")
            elif direction == "SHORT":
                chk(f"{tag}: SHORT: tp3<tp2<tp1<entry<sl",
                    prices[2] < prices[1] < prices[0] < entry < sl,
                    f"sl={sl} e={entry} tps={prices}")
            chk(f"{tag}: RR صعودی", rrs[0] < rrs[1] < rrs[2], rrs)
            for i in range(3):
                want = abs(prices[i] - entry) / risk if risk > 0 else 0
                chk(f"{tag}: RR TP{i+1} با فرمول سازگار",
                    isinstance(rrs[i], (int, float)) and abs(rrs[i] - want) <= max(0.12 * want, 0.06),
                    f"rr={rrs[i]} محاسبه={round(want,3)}")

        # ── کندل‌ها و EMAها
        chart = data.get("chart") or {}
        cnd = chart.get("candles") or []
        chk(f"{tag}: ≥۵۰ کندل", len(cnd) >= 50, len(cnd))
        if cnd:
            last = cnd[-1]
            chk(f"{tag}: کندلِ آخر سازگار (h≥o,c≥l)",
                last["h"] >= max(last["o"], last["c"]) - 1e-9
                and last["l"] <= min(last["o"], last["c"]) + 1e-9, last)
            chk(f"{tag}: قیمتِ سیگنال ≈ بستهٔ کندلِ آخر",
                abs(last["c"] - price) / price < 0.03, f"{last['c']} vs {price}")
        for k in ("ema20", "ema50"):
            arr = chart.get(k) or []
            chk(f"{tag}: طولِ {k} = طولِ کندل‌ها", len(arr) == len(cnd), f"{len(arr)} vs {len(cnd)}")

        # ── سطوح: حمایت‌ها زیرِ قیمت و مقاومت‌ها بالای قیمت (با تلورانس)
        tech = data.get("technical") or {}
        sups = tech.get("conf_supports") or []
        ress = tech.get("conf_resistances") or []
        chk(f"{tag}: حمایت‌ها ≤ قیمت", all(s <= price * 1.002 for s in sups), sups[:4])
        chk(f"{tag}: مقاومت‌ها ≥ قیمت", all(r >= price * 0.998 for r in ress), ress[:4])

        # ── وضعیتِ بازار (گاردِ MH-001 از سمتِ دریافت — با زمانِ واقعیِ الان)
        mkt = data.get("market") or {}
        if sym in CRYPTO:
            chk(f"{tag}: کریپتو ۲۴/۷ باز", mkt.get("open") is True and mkt.get("always_open") is True, mkt)
        elif IS_WEEKEND:
            chk(f"{tag}: غیرکریپتو در آخرِ هفته بسته", mkt.get("open") is False,
                f"open={mkt.get('open')} class={mkt.get('asset_class')}")
        # ── احساسات/فاندامنتال حاضر
        chk(f"{tag}: بلوکِ احساسات موجود", isinstance(data.get("sentiment"), dict), type(data.get("sentiment")))
        chk(f"{tag}: بلوکِ فاندامنتال موجود", isinstance(data.get("fundamental"), dict), type(data.get("fundamental")))

# خطاها
print("\n── ۲) دریافت: ورودی‌های نامعتبر ──")
st, d = get("/api/signal", symbol="NOSUCH", tf="15m", ai=0)
chk("نمادِ ناشناخته رد می‌شود", st != 200 or not (d or {}).get("ok", True), f"st={st} {str(d)[:100]}")
st, d = get("/api/signal", symbol="BTC", tf="13x", ai=0)
ok_tf = (st != 200) or (not (d or {}).get("ok", True)) or (((d or {}).get("data") or {}).get("interval") in ("15m", "1h", "5m", "30m", "4h", "1d"))
chk("تایم‌فریمِ نامعتبر رد یا به پیش‌فرضِ امن نگاشت می‌شود", ok_tf, f"st={st} interval={((d or {}).get('data') or {}).get('interval')}")

# کش
print("\n── ۳) دریافت: کَش و تازگی ──")
t0 = time.time()
st, _ = get("/api/signal", symbol="BTC", tf="15m", ai=0)
dt1 = time.time() - t0
chk("فراخوانِ دومِ کش‌شده سریع است (<2s)", st == 200 and dt1 < 2.0, f"{dt1:.2f}s")

# scan / mtf / compare
print("\n── ۴) دریافت: scan / mtf / compare ──")
st, d = get("/api/scan", tf="15m")
sd = ((d or {}).get("data") or {})
rows = (sd.get("longs") or []) + (sd.get("shorts") or [])
chk("scan پاسخ ۲۰۰", st == 200, st)
chk("scan چند نماد پویش کرده", (sd.get("count") or 0) >= 5 and not sd.get("errors"),
    f"count={sd.get('count')} errors={sd.get('errors')}")
chk("scan ردیفِ قابلِ معامله دارد", isinstance(rows, list) and len(rows) >= 1, len(rows))
for r0 in rows:
    okrow = (r0.get("direction") in ("LONG", "SHORT") and r0.get("entry")
             and len(r0.get("take_profits") or []) == 3 and r0.get("stop_loss"))
    if r0.get("direction") == "LONG":
        okrow = okrow and r0["stop_loss"] < r0["entry"] < r0["take_profits"][0]
    elif r0.get("direction") == "SHORT":
        okrow = okrow and r0["take_profits"][0] < r0["entry"] < r0["stop_loss"]
    chk(f"scan {r0.get('symbol')}: ردیفِ کامل (جهت/ورود/۳TP/SL در سمتِ درست)", bool(okrow),
        {k: r0.get(k) for k in ("direction", "entry", "stop_loss")})
st, d = get("/api/mtf", symbol="BTC")
chk("mtf پاسخ ۲۰۰ و ok", st == 200 and (d or {}).get("ok", True), f"st={st}")
st, d = get("/api/compare", symbols="BTC,ETH,XAU")
chk("compare پاسخ ۲۰۰ و ok", st == 200 and (d or {}).get("ok", True), f"st={st}")

# ────────────────────────── بخش ۵: ارسالِ دستی (dry_run) ──────────────────────────
print("\n── ۵) ارسال به MT5 (پیش‌نمایشِ dry_run — از روی سیگنالِ واقعی) ──")
# روی لینوکس (بدونِ MT5) پاسخ، پیش‌نمایشِ planned است: entry/sl/tps/volume/tp_mode
for sym, want_dir in (("BTC", None), ("ETH", "LONG"), ("ETH", "SHORT"), ("XAU", "SHORT")):
    body = {"symbol": sym, "tf": "15m", "dry_run": True, "volume": 0.3}
    if want_dir:
        body["direction"] = want_dir
    st, d = post("/api/mt5/send", body)
    tag = f"send {sym}{'/' + want_dir if want_dir else ''}"
    res = (d or {}).get("data") or d or {}
    pl = res.get("planned") or {}
    sig = res.get("signal") or {}
    if want_dir is None and st == 400 and "خنثی" in str(d):
        # محافظِ درست: سیگنالِ لحظه‌ایِ نماد خنثی است و ارسالِ بدونِ جهتِ صریح رد می‌شود
        chk(f"{tag}: ردِ امنِ سیگنالِ خنثی (400 + پیامِ شفاف)",
            not (d or {}).get("ok", True), str(d)[:100])
        continue
    chk(f"{tag}: پاسخ ۲۰۰ و ok", st == 200 and bool(res.get("ok")), f"st={st} {str(d)[:120]}")
    chk(f"{tag}: پیش‌نمایشِ planned موجود", bool(pl), str(res)[:100])
    if not pl:
        continue
    d_dir = want_dir or res.get("direction")
    chk(f"{tag}: جهتِ پاسخ معتبر", res.get("direction") in ("LONG", "SHORT"), res.get("direction"))
    chk(f"{tag}: حجم انعکاس یافت", pl.get("volume") == 0.3, pl.get("volume"))
    chk(f"{tag}: سیگنالِ مرجع همان نماد/تایم‌فریم", sig.get("symbol") == sym and sig.get("tf") == "15m", sig)
    e, s_, tps_ = pl.get("entry"), pl.get("sl"), pl.get("tps") or []
    chk(f"{tag}: سه حدِ سود در نقشه", len(tps_) == 3, tps_)
    if e and s_ and len(tps_) == 3:
        if d_dir == "LONG":
            chk(f"{tag}: سمتِ LONG درست (sl<entry<tps↑)",
                s_ < e < tps_[0] < tps_[1] < tps_[2], f"sl={s_} e={e} tps={tps_}")
        elif d_dir == "SHORT":
            chk(f"{tag}: سمتِ SHORT درست (tps↓<entry<sl)",
                tps_[2] < tps_[1] < tps_[0] < e < s_, f"sl={s_} e={e} tps={tps_}")

# انعکاسِ tp_mode از overrides در پیش‌نمایش
for m in ("single", "none", "partial"):
    st, d = post("/api/mt5/send", {"symbol": "ETH", "tf": "15m", "dry_run": True,
                                   "volume": 0.2, "direction": "LONG",
                                   "overrides": {"tp_mode": m}})
    pl = (((d or {}).get("data") or {}).get("planned")) or {}
    chk(f"send tp_mode={m}: انعکاس در پیش‌نمایش", pl.get("tp_mode") == m, pl.get("tp_mode"))

# نمادِ نامعتبر در ارسال
st, d = post("/api/mt5/send", {"symbol": "NOSUCH", "tf": "15m", "dry_run": True})
chk("send نمادِ ناشناخته رد می‌شود", st != 200 or not (d or {}).get("ok", True), f"st={st}")

# ────────────────────────── بخش ۶: دریافتِ سفارش از ربات ──────────────────────────
print("\n── ۶) مسیرِ ربات: نرمال‌سازی، داوری، تکرار، خطاها، احرازِ هویت ──")
UNIQ = str(int(time.time()))
VALID = {"sym": "BTCUSD", "side": "buy", "lots": 0.05, "tp1": 999999.0,
         "stop_loss": 1000.0, "robot": "deep-io-" + UNIQ, "timeframe": "M15",
         "platform": "python"}
st, d = post("/api/robot/order", VALID)
rec = (d or {}).get("record") or {}
order = rec.get("order") or (d or {}).get("order") or {}
chk("ربات: پاسخ ۲۰۰", st == 200, f"st={st} {str(d)[:150]}")
chk("ربات: نرمال‌سازی مترادف‌ها (sym/side/lots/M15)",
    order.get("symbol", "").upper().startswith("BTC") and order.get("direction") == "LONG"
    and order.get("volume") == 0.05 and order.get("tf") in ("15m", "M15"),
    order)
chk("ربات: نتیجهٔ داوری ثبت شده", "approved" in rec or "approved" in (d or {}), str(d)[:120])

# تکرار (dedupe) — همان سفارش بلافاصله
st2, d2 = post("/api/robot/order", dict(VALID))
rec2 = (d2 or {}).get("record") or {}
txt2 = json.dumps(d2, ensure_ascii=False)
chk("ربات: سفارشِ تکراریِ هم‌جهت بلوکه می‌شود (dedupe)",
    (rec2.get("approved") is False) or ("تکرار" in txt2) or ("dedupe" in txt2.lower()),
    txt2[:160])

# payloadهای خراب → 400
for bad, why in (({"side": "buy", "lots": 0.1}, "بدونِ نماد"),
                 ({"sym": "BTCUSD", "side": "hold", "lots": 0.1}, "جهتِ نامعتبر"),
                 ({"sym": "BTCUSD", "side": "sell", "lots": "abc"}, "حجمِ نامعتبر"),
                 ({"sym": "BTCUSD", "side": "sell"}, "بدونِ حجم")):
    st, d = post("/api/robot/order", bad)
    chk(f"ربات: payload خراب ({why}) → 400", st == 400 and not (d or {}).get("ok", True),
        f"st={st} {str(d)[:100]}")

# سقفِ ۳ حدِ سود حتی با لیستِ طولانی
many_tps = {"sym": "ETHUSD", "side": "sell", "lots": 0.05,
            "take_profits": [1.0, 2.0, 3.0, 4.0, 5.0, 6.0], "robot": "deep-io2-" + UNIQ}
st, d = post("/api/robot/order", many_tps)
ord2 = ((d or {}).get("record") or {}).get("order") or (d or {}).get("order") or {}
chk("ربات: حدِ سودها به ۳ سقف می‌خورد", len(ord2.get("tps") or []) <= 3, ord2.get("tps"))

# احرازِ هویت: secret موقت بگذار، غلط → 401، درست (هدر و بدنه) → غیر401، سپس بازگردانی
st, cfg0 = get("/api/robot/config")
prev_secret = (((cfg0 or {}).get("data") or {}).get("config") or {}).get("shared_secret", "")
st, _ = post("/api/robot/config", {"shared_secret": "s3cret-" + UNIQ})
chk("ربات: ثبتِ secret موقت", st == 200, st)
st, d = post("/api/robot/order", dict(VALID, robot="auth-" + UNIQ))
chk("ربات: بدونِ secret → 401", st == 401, f"st={st}")
st, d = post("/api/robot/order", dict(VALID, robot="auth2-" + UNIQ), headers={"X-Robot-Secret": "WRONG"})
chk("ربات: secret غلط → 401", st == 401, f"st={st}")
st, d = post("/api/robot/order", dict(VALID, robot="auth3-" + UNIQ), headers={"X-Robot-Secret": "s3cret-" + UNIQ})
chk("ربات: secret درست در هدر پذیرفته می‌شود", st != 401, f"st={st}")
st, d = post("/api/robot/order", dict(VALID, robot="auth4-" + UNIQ, secret="s3cret-" + UNIQ))
chk("ربات: secret درست در بدنه پذیرفته می‌شود", st != 401, f"st={st}")
st, _ = post("/api/robot/config", {"shared_secret": prev_secret or ""})
chk("ربات: بازگردانیِ secret", st == 200, st)

# endpoint تستِ ربات (مسیرِ ui-test با همان داوری)
st, d = post("/api/robot/test", {"sym": "BTCUSD", "side": "buy", "lots": 0.01})
chk("ربات: /api/robot/test پاسخ می‌دهد", st in (200, 400), f"st={st}")

# ────────────────────────── بخش ۷: گزارشِ وضعیتِ ارسالِ زنده ──────────────────────────
print("\n── ۷) dispatch/live و سلامتِ گزارش‌ها ──")
st, d = get("/api/dispatch/live", tf="15m")
chk("dispatch/live پاسخ ۲۰۰ و ok", st == 200 and (d or {}).get("ok", True), f"st={st}")
st, d = get("/api/mt5/log")
chk("لاگِ MT5 خوانا", st == 200, st)
st, d = get("/api/robot/log")
chk("لاگِ ربات خوانا", st == 200, st)
st, d = get("/api/news/check", symbol="XAU")
chk("news/check پاسخ ۲۰۰", st == 200, st)
st, d = get("/api/mt5/marketwatch")
chk("marketwatch پاسخ ۲۰۰", st == 200, st)

print("\n" + "=" * 72)
print(f"  نتیجه: {PASS} پاس · {FAIL} ناموفق")
print("=" * 72)
if FAILURES:
    with open("signal_io_failures.json", "w", encoding="utf-8") as f:
        json.dump(FAILURES, f, ensure_ascii=False, indent=1)
    print("  جزئیات خطاها: signal_io_failures.json")
raise SystemExit(1 if FAIL else 0)
