# -*- coding: utf-8 -*-
"""رگرسیونِ AIDASH-001/002 — «توکن کم می‌شود ولی تحلیلِ هوش مصنوعی نمایش داده نمی‌شود».

ریشه‌ها:
  ۱) در تبِ «داشبورد تحلیل هوش مصنوعی» زیرتبِ پیش‌فرض «تکنیکال (داخلی)» بود؛
     تحلیلِ AI فقط با کلیکِ دستی روی زیرتبِ 🤖 دیده می‌شد.
  ۲) اگر خروجیِ مدل JSON تمیز نبود (مدل‌های reasoning با <think>، متنِ اضافه،
     code-fence، یا بریدگیِ max_tokens) تجزیه شکست می‌خورد؛ توکن مصرف شده بود ولی
     بی‌صدا تحلیلِ داخلی نمایش داده می‌شد.
"""
import os as _os_env; _os_env.environ.setdefault("BTC_AGENT_ALLOW_INSECURE_ROBOT", "1")  # محیط تست
import json
import shutil

import app
import ai_bridge as ab

PASS = 0
FAIL = 0


def chk(name, cond, detail=""):
    global PASS, FAIL
    if cond:
        PASS += 1
    else:
        FAIL += 1
        print(f"   FAIL  {name} — {str(detail)[:220]}")


shutil.copy("ai_config.json", "/tmp/aidash.bak")
app.app.config["TESTING"] = True
client = app.app.test_client()

GOOD = {"technical_score": 35, "fundamental_score": 10, "sentiment_score": -5,
        "overall_score": 22, "direction": "LONG", "confidence": 71,
        "summary": "جمع‌بندی آزمایشی", "reasons": ["دلیل ۱", "دلیل ۲", "دلیل ۳"]}
GJ = json.dumps(GOOD, ensure_ascii=False)

print("=" * 70)
print(" AIDASH-001/002: نمایشِ تحلیلِ AI و تجزیهٔ مقاومِ خروجیِ مدل")
print("=" * 70)

# ── ۱) تجزیهٔ مقاوم (_parse_json)
cases = [
    ("JSON خالص", GJ),
    ("code-fence", "```json\n" + GJ + "\n```"),
    ("<think> مدلِ reasoning", "<think>اول روند را بررسی می‌کنم…</think>\n" + GJ),
    ("متن قبل و بعدِ JSON", "تحلیل من:\n" + GJ + "\nامیدوارم مفید باشد."),
    ("فنس وسطِ متن", "خروجی:\n```json\n" + GJ + "\n```\nپایان."),
    ("think بازِ بدونِ بسته + فنس", "<think>…\n" + "```json\n" + GJ + "\n```"),
]
for name, raw in cases:
    p = ab._parse_json(raw)
    chk(f"تجزیه: {name}", isinstance(p, dict) and p.get("direction") == "LONG",
        str(p)[:60] if p else raw[:60])
chk("تجزیه: JSON بریده → None (خطای خوانا بعداً)",
    ab._parse_json(GJ[:60]) is None, "")

# ── ۲) analyze_market با پاسخ‌های کثیف → ok و امتیازها
_real_chat = ab.chat
ab.save_config({"enabled": True, "use_in_signal": True, "api_key": "k",
                "base_url": "https://x/v1", "model": "m1", "signal_weight": 0.3})
ab.chat = lambda prompt, **kw: {"ok": True, "model": "m1", "ms": 5,
                                "content": "<think>بررسی…</think>```json\n" + GJ + "\n```"}
r = ab.analyze_market({"symbol": "BTC"})
chk("analyze_market: خروجیِ کثیفِ reasoning تجزیه شد", r.get("ok") is True
    and r.get("overall_score") == 22, str(r)[:100])

ab.chat = lambda prompt, **kw: {"ok": True, "model": "m1", "ms": 5,
                                "content": "متأسفم، نمی‌توانم JSON بدهم."}
r = ab.analyze_market({"symbol": "BTC"})
chk("analyze_market: شکستِ تجزیه → خطای راهنما (توکن مصرف شد)",
    r.get("ok") is False and "توکن مصرف شد" in r.get("error", ""), r.get("error", "")[:90])

# ── ۳) سقفِ توکن ≥ ۹۰۰ تا JSON بریده نشود
CAPT = {}
def _cap(prompt, **kw):
    CAPT.update(kw)
    return {"ok": True, "content": GJ, "model": "m1", "ms": 1}
ab.chat = _cap
ab.analyze_market({"symbol": "BTC"})
chk("کفِ max_tokens ≥ 900", (CAPT.get("max_tokens") or 0) >= 900, CAPT.get("max_tokens"))

# ── ۴) سرتاسری: /api/signal?ai=1 → data.ai.used و امتیازها/ترکیب
ab.chat = lambda prompt, **kw: {"ok": True, "model": "m1", "ms": 5, "content": GJ}
r = client.get("/api/signal?symbol=BTC&tf=30m&ai=1")
d = ((r.get_json() or {}).get("data")) or {}
a = d.get("ai") or {}
chk("سرتاسری: ai.used=True", a.get("used") is True, str(a)[:120])
chk("سرتاسری: زیرامتیازهای AI موجود", a.get("technical_score") == 35
    and a.get("overall_score") == 22 and a.get("summary"), str(a)[:120])
chk("سرتاسری: وزنِ AI در ترکیب", (d.get("weights") or {}).get("ai", 0) > 0,
    d.get("weights"))

# خطای مدل → ai.error در پاسخ (برای بنرِ UI)
ab.chat = lambda prompt, **kw: {"ok": True, "model": "m1", "ms": 5, "content": "نه!"}
r = client.get("/api/signal?symbol=ETH&tf=30m&ai=1")
d = ((r.get_json() or {}).get("data")) or {}
a = d.get("ai") or {}
chk("سرتاسری: خطای تجزیه در ai.error گزارش می‌شود",
    a.get("used") is False and "توکن مصرف شد" in (a.get("error") or ""),
    str(a)[:140])
chk("سرتاسری: تحلیلِ داخلی همچنان سالم (قیمت/پلن)", (d.get("price") or 0) > 0, d.get("price"))

# ── ۶) AIDASH-003: کارت‌های واچ‌لیستِ AI (مسیر /api/compare) تحلیلِ AI را حمل کنند
ab.chat = lambda prompt, **kw: {"ok": True, "model": "m1", "ms": 5, "content": GJ}
r = client.get("/api/compare?symbols=BTC&tf=30m&ai=1")
rows = (((r.get_json() or {}).get("data")) or {}).get("rows") or []
r0 = rows[0] if rows else {}
chk("کارت: ai_used=True", r0.get("ai_used") is True, str(r0)[:100])
chk("کارت: امتیاز/جهت/اطمینانِ AI", r0.get("ai_score") == 22 and r0.get("ai_direction") == "LONG"
    and r0.get("ai_confidence") == 71, {k: r0.get(k) for k in ("ai_score", "ai_direction", "ai_confidence")})
chk("کارت: زیرامتیازهای AI", r0.get("ai_tech") == 35 and r0.get("ai_fund") == 10
    and r0.get("ai_sent") == -5, "")
chk("کارت: خلاصه و مدل", bool(r0.get("ai_summary")) and r0.get("ai_model") == "m1", "")

ab.chat = lambda prompt, **kw: {"ok": True, "model": "m1", "ms": 5, "content": "خیر"}
r = client.get("/api/compare?symbols=ETH&tf=30m&ai=1")
rows = (((r.get_json() or {}).get("data")) or {}).get("rows") or []
r0 = rows[0] if rows else {}
chk("کارت: خطای AI گزارش می‌شود", r0.get("ai_used") is False
    and "توکن مصرف شد" in (r0.get("ai_error") or ""), str(r0.get("ai_error"))[:90])

ui2 = open("static/index.html", encoding="utf-8").read()
chk("UI: بلوکِ wlAiBlock تعریف و به کارت وصل است",
    "function wlAiBlock" in ui2 and "AI_MODE?wlAiBlock(r):" in ui2, "")
chk("UI: ردیفِ امتیازهای داخلی در حالتِ AI حذف شده (AIDASH-006)",
    "AI_MODE?F('داخلی','Int')" not in ui2, "")
chk("UI: کارتِ خطا با عنوانِ توکن مصرف شد", "تحلیل AI ناموفق (توکن مصرف شد)" in ui2, "")

# ── ۷) AIDASH-004: در «داشبورد تحلیل داخلی» (ai=0) وضعیتِ واقعیِ AI گزارش شود
ab.save_config({"enabled": True, "use_in_signal": True, "api_key": "k",
                "base_url": "https://x/v1", "model": "m1"})
CALLS7 = []
ab.chat = lambda prompt, **kw: (CALLS7.append(1) or {"ok": True, "content": GJ, "model": "m1", "ms": 1})
r = client.get("/api/signal?symbol=SOL&tf=30m&ai=0")
d = ((r.get_json() or {}).get("data")) or {}
a = d.get("ai") or {}
chk("ai=0: مدل اصلاً صدا زده نمی‌شود (توکن صفر)", len(CALLS7) == 0, len(CALLS7))
chk("ai=0: وضعیتِ واقعی گزارش می‌شود (enabled=True, requested=False)",
    a.get("used") is False and a.get("requested") is False and a.get("enabled") is True,
    str(a)[:100])
ab.save_config({"enabled": False})
r = client.get("/api/signal?symbol=XAG&tf=30m&ai=0")
a = (((r.get_json() or {}).get("data")) or {}).get("ai") or {}
chk("ai=0 با AI خاموش: enabled=False", a.get("enabled") is False and a.get("requested") is False,
    str(a)[:80])

ui3 = open("static/index.html", encoding="utf-8").read()
chk("UI: ردیفِ امتیاز «در این تب خاموش است»", "در این تب خاموش است" in ui3, "")
chk("UI: پیامِ راهنمای تبِ داخلی (فعال ✅ ولی لحاظ نشده)",
    "هوش مصنوعی فعال و متصل است ✅" in ui3 and "تیکِ «🤖 هوش مصنوعی»" in ui3, "")

# ── ۸) AIDASH-005: پیش‌فرضِ تیکِ AI داشبورد داخلی روشن + ایمنیِ توکن وقتی مدل خاموش است
ab.save_config({"enabled": False})
CALLS8 = []
ab.chat = lambda prompt, **kw: (CALLS8.append(1) or {"ok": True, "content": GJ, "model": "m1", "ms": 1})
r = client.get("/api/signal?symbol=GBPUSD&tf=30m&ai=1")
a = (((r.get_json() or {}).get("data")) or {}).get("ai") or {}
chk("ai=1 با مدلِ خاموش: هیچ فراخوانی (توکن صفر)", len(CALLS8) == 0, len(CALLS8))
chk("ai=1 با مدلِ خاموش: وضعیتِ enabled=False گزارش می‌شود",
    a.get("used") is False and a.get("enabled") is False, str(a)[:80])
ui5 = open("static/index.html", encoding="utf-8").read()
chk("UI: پیش‌فرضِ WL.ai=true (داشبورد داخلی)",
    'let WL={symbols:[],tf:"1h",every:60,on:true,htf:"",ai:true,aiw:0.3};' in ui5, "")
chk("UI: مهاجرتِ یک‌بارهٔ تنظیماتِ قدیمی (wlAiMigr1)",
    'localStorage.getItem("wlAiMigr1")' in ui5 and 'W.ai=true;localStorage.setItem("wlAiMigr1","1")' in ui5, "")

# ── ۹) AIDASH-006: در داشبوردِ AI فقط محتوای مدل نمایش داده شود
ui6 = open("static/index.html", encoding="utf-8").read()
chk("پنل امتیازها: شاخهٔ مخصوصِ AI_MODE با امتیازهای مدل",
    "امتیازِ تحلیل‌های هوش مصنوعی" in ui6 and 'scoreBar("📊 "+t(\'technical\')+" (AI)"' in ui6, "")
chk("زیرتب‌ها: در AI_MODE فقط دکمهٔ 🤖",
    '${AI_MODE?`<div class="tabs"><button data-tab="ai">' in ui6, "")
chk("سطوح/فیبو/پرایس‌اکشنِ داخلی در AI_MODE حذف",
    "${AI_MODE?`<div class=\"src\" style=\"margin-top:10px\">${t('generated')}: ${d.generated_at}</div>`" in ui6, "")
chk("کارت‌ها: T/F/S و کل/ترکیبیِ داخلی فقط در حالتِ داخلی",
    "${AI_MODE?wlAiBlock(r):`" in ui6, "")
chk("پیلِ جهتِ کارت در AI_MODE از جهتِ مدل", "(AI_MODE&&r.ai_used&&r.ai_direction)?r.ai_direction:r.direction" in ui6, "")
chk("گیجِ سنتیمنتِ داخلی در AI_MODE نمایش داده نمی‌شود",
    ui6.count('class="gauge-wrap"') == 1, ui6.count('class="gauge-wrap"'))

# ── ۱۰) AIDASH-007: تحلیلِ متنیِ تکنیکال/فاندامنتال/سنتیمنتِ مدل + سطوحِ کلیدی
import json as _j
GOOD7 = dict(GOOD, technical_analysis="روند نزولی با شکستِ EMA50؛ RSI زیر ۴۰ و مقاومتِ تصمیم‌ساز ۲۶۷۰.",
             fundamental_analysis="مومنتوم هفتگی منفی است.",
             sentiment_analysis="طمع بالا ریسکِ اصلاح دارد.",
             key_levels={"support": [2610.5, 2588], "resistance": [2670, 2701.25]})
ab.save_config({"enabled": True, "use_in_signal": True, "api_key": "k",
                "base_url": "https://x/v1", "model": "m1"})
ab.chat = lambda prompt, **kw: {"ok": True, "model": "m1", "ms": 4,
                                "content": _j.dumps(GOOD7, ensure_ascii=False)}
r = client.get("/api/signal?symbol=XAU&tf=30m&ai=1")
a7 = (((r.get_json() or {}).get("data")) or {}).get("ai") or {}
chk("AIDASH-007: تحلیلِ تکنیکالِ متنیِ مدل عبور می‌کند",
    "EMA50" in (a7.get("technical_analysis") or ""), str(a7.get("technical_analysis"))[:60])
chk("AIDASH-007: تحلیلِ فاندامنتال/سنتیمنتِ متنی",
    a7.get("fundamental_analysis") and a7.get("sentiment_analysis"), "")
chk("AIDASH-007: سطوحِ کلیدیِ مدل (عددی و پاک‌سازی‌شده)",
    (a7.get("key_levels") or {}).get("support") == [2610.5, 2588.0]
    and (a7.get("key_levels") or {}).get("resistance") == [2670.0, 2701.25], a7.get("key_levels"))
# پاک‌سازی: سطوحِ خراب دور ریخته شوند
GOODBAD = dict(GOOD7, key_levels={"support": ["x", float("inf"), 10], "resistance": "nope"})
ab.chat = lambda prompt, **kw: {"ok": True, "model": "m1", "ms": 4,
                                "content": _j.dumps(GOODBAD, ensure_ascii=False, default=str)}
r = client.get("/api/signal?symbol=XAG&tf=30m&ai=1")
a8 = (((r.get_json() or {}).get("data")) or {}).get("ai") or {}
chk("AIDASH-007: پاک‌سازیِ سطوحِ خراب", (a8.get("key_levels") or {}).get("support") == [10.0]
    and not (a8.get("key_levels") or {}).get("resistance"), a8.get("key_levels"))
# مدلِ قدیمی بدونِ فیلدهای جدید → سازگار
ab.chat = lambda prompt, **kw: {"ok": True, "model": "m1", "ms": 4, "content": GJ}
r = client.get("/api/signal?symbol=SPX&tf=30m&ai=1")
a9 = (((r.get_json() or {}).get("data")) or {}).get("ai") or {}
chk("AIDASH-007: سازگاری با مدلِ بدونِ فیلدهای جدید", a9.get("used") is True
    and not a9.get("technical_analysis"), "")
ui7 = open("static/index.html", encoding="utf-8").read()
chk("UI: نمایشِ technical_analysis زیر نوارِ تکنیکال", "a.technical_analysis?" in ui7, "")
chk("UI: نمایشِ سطوحِ کلیدیِ مدل", "سطوحِ کلیدیِ مدل" in ui7, "")
chk("اسکیما/پرامپت: درخواستِ تحلیلِ تکنیکالِ متنی از مدل",
    "technical_analysis" in open("ai_bridge.py", encoding="utf-8").read()
    and "BOS/CHOCH" in open("ai_bridge.py", encoding="utf-8").read(), "")

ab.chat = _real_chat

# ── ۵) UI: زیرتبِ پیش‌فرضِ AI در داشبوردِ هوش مصنوعی + بنرِ وضعیت
ui = open("static/index.html", encoding="utf-8").read()
chk("UI: در AI_MODE زیرتبِ پیش‌فرض ai است",
    'if(AI_MODE&&activeTab!=="ai")activeTab="ai";' in ui, "")
chk("UI: بنرِ وضعیتِ aiStatusBanner تعریف شده", "function aiStatusBanner" in ui, "")
chk("UI: بنر در renderDash وصل است", ":aiStatusBanner(d)}" in ui, "")
chk("UI: متنِ بنر خطا شاملِ مصرفِ توکن", "توکنِ مدل مصرف شده است" in ui, "")

shutil.copy("/tmp/aidash.bak", "ai_config.json")
print("\n" + "=" * 70)
print(f"  نتیجه: {PASS} پاس · {FAIL} ناموفق")
print("=" * 70)
raise SystemExit(1 if FAIL else 0)
