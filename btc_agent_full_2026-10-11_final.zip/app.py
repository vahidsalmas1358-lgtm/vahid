"""سرور Flask برای ایجنت تحلیل چند‌بازاری (چند نماد + نمودار + بک‌تست + بهینه‌سازی + اسکنر + مقایسه + هشدار)."""
from __future__ import annotations
import time
import os
import json
import gzip
import hmac
import threading as _th_global   # OP5-CORE-16: قفلِ چرخهٔ عمرِ سرویس‌ها
import math
from concurrent.futures import ThreadPoolExecutor
from flask import Flask, jsonify, request, send_from_directory, Response, stream_with_context

import engine
import backtest
import optimizer
import data_sources as ds
import history
import alerts
import symbols as sym
import mt5_bridge
import news
import news_alerts
import ai_bridge
import robots
import schedule_hours
import dispatch
import signal_arbiter
import analytics
import bridge_injector
import server_log

app = Flask(__name__, static_folder="static", static_url_path="")

# --- احرازِ هویتِ مدیریتیِ اختیاری (APP-001) ---------------------------------
# اگر متغیرِ محیطیِ BTC_AGENT_ADMIN_TOKEN تنظیم شده باشد، همهٔ درخواست‌های
# تغییردهنده (POST/DELETE/PUT/PATCH) باید هدرِ X-Admin-Token با همان مقدار را
# بفرستند. وب‌هوکِ ربات‌ها مستثناست چون احرازِ هویتِ خودش (shared secret) را دارد.
# بدونِ تنظیمِ متغیر، رفتارِ برنامه مثل قبل است (مناسبِ اجرای محلی).
_ADMIN_TOKEN = (os.environ.get("BTC_AGENT_ADMIN_TOKEN") or "").strip()
# OP5-CORE-01: وب‌هوکِ ربات دیگر «معافِ بی‌قید» نیست؛ برای آن مسیرها هدرِ اختصاصیِ
# ربات (X-Robot-Secret) پذیرفته می‌شود و اگر هیچ توکنی تنظیم نشده و bind هم عمومی
# است، درخواست fail-closed رد می‌شود (قبلاً هر کسی از شبکه می‌توانست سفارش بفرستد).
_ADMIN_EXEMPT_PATHS = ()
_ROBOT_WEBHOOK_PATHS = ("/api/robot/order", "/api/robot/test")


def _robot_insecure_allowed() -> bool:
    """اجرای آگاهانهٔ ناامن (loopback یا پرچمِ صریحِ محیطی)."""
    if (os.environ.get("BTC_AGENT_ALLOW_INSECURE_ROBOT") or "").strip().lower() \
            in ("1", "true", "yes", "on"):
        return True
    host = (os.environ.get("BTC_AGENT_BIND_HOST", "127.0.0.1") or "").strip()
    return host in ("127.0.0.1", "localhost", "::1")


@app.before_request
def _admin_gate():
    if request.method in ("GET", "HEAD", "OPTIONS"):
        return None
    if request.path in _ROBOT_WEBHOOK_PATHS:
        robot_secret = (os.environ.get("BTC_AGENT_ROBOT_SECRET") or "").strip() or _ADMIN_TOKEN
        supplied_robot = (request.headers.get("X-Robot-Secret") or "").strip()
        if robot_secret:
            if supplied_robot and hmac.compare_digest(supplied_robot, robot_secret):
                return None
            if not _robot_insecure_allowed():
                return jsonify({"ok": False,
                                "error": ("توکنِ ربات (X-Robot-Secret) لازم است؛ "
                                          "روی bindِ عمومی نمی‌توان بدونِ توکن سفارش فرستاد.")}), 401
            return None      # loopback/اجرای آگاهانهٔ ناامن → ادامه (سازگاریِ اجرای محلی)
        if _robot_insecure_allowed():
            return None
        return jsonify({"ok": False,
                        "error": ("هیچ توکنِ رباتی تنظیم نشده و سرور روی bindِ عمومی است؛ "
                                  "BTC_AGENT_ROBOT_SECRET را تنظیم کنید یا "
                                  "BTC_AGENT_ALLOW_INSECURE_ROBOT=1 بگذارید.")}), 401
    if not _ADMIN_TOKEN:
        return None
    supplied = request.headers.get("X-Admin-Token") or ""
    if hmac.compare_digest(str(supplied), _ADMIN_TOKEN):
        return None
    return jsonify({"ok": False,
                    "error": "دسترسیِ مدیریتی لازم است (هدرِ X-Admin-Token نامعتبر یا غایب)."}), 401


VALID_TF = {"1m", "5m", "10m", "15m", "30m", "1h", "2h", "4h", "1d", "1w"}

# ترتیبِ تایم‌فریم‌ها برای معیارِ «تاییدیهٔ تایم‌فریمِ بالاتر»
_TF_ORDER = {"1m": 1, "5m": 2, "10m": 3, "15m": 4, "30m": 5,
             "1h": 6, "2h": 7, "4h": 8, "1d": 9, "1w": 10}


def _qint(name: str, default: int) -> int:
    """خواندنِ امنِ پارامترِ عددیِ صحیح از کوئری‌استرینگ (ورودیِ خراب → پیش‌فرض).

    اصلاح (APP-006): مقادیری مثل 1e309 به inf تبدیل می‌شوند و int(inf) خطای
    OverflowError می‌دهد که قبلاً گرفته نمی‌شد و پاسخ 500 می‌ساخت.
    """
    try:
        v = float(request.args.get(name, default))
        if not math.isfinite(v):
            return default
        return int(v)
    except (TypeError, ValueError, OverflowError):
        return default


def _qfloat(name: str, default: float) -> float:
    """خواندنِ امنِ پارامترِ عددیِ اعشاری از کوئری‌استرینگ (ورودیِ خراب → پیش‌فرض).

    اصلاح (APP-006): inf/NaN دیگر به لایه‌های محاسباتی راه پیدا نمی‌کنند.
    """
    try:
        v = float(request.args.get(name, default))
        return v if math.isfinite(v) else default
    except (TypeError, ValueError, OverflowError):
        return default


def _body_bool(body, name, default=False):
    """اصلاح (OPUS5-A7): bool("false")==True است؛ رشته‌ها معناییِ درست می‌گیرند."""
    value = body.get(name, default)
    if isinstance(value, str):
        return value.strip().lower() in ("1", "true", "yes", "on")
    return value if isinstance(value, bool) else bool(default)


def _body_text(body, name, default=""):
    value = body.get(name, default)
    return value.strip() if isinstance(value, str) else default


def _body_volume(body, name="volume"):
    value = body.get(name)
    if value is None or isinstance(value, bool):
        return None
    try:
        value = float(value)
    except (TypeError, ValueError):
        raise ValueError("حجم باید عددِ متناهیِ مثبت باشد")
    if not math.isfinite(value) or value <= 0:
        raise ValueError("حجم باید عددِ متناهیِ مثبت باشد")
    return value


def _json_body():
    """بدنهٔ JSONِ درخواست به‌صورتِ امن: فقط شیء (dict) پذیرفته می‌شود.

    اگر کلاینت آرایه/رشته/عدد بفرستد، به‌جای AttributeError و پاسخِ 500،
    دیکشنریِ خالی برمی‌گردد و اعتبارسنجیِ بعدی پیامِ مناسب می‌دهد.
    """
    b = request.get_json(force=True, silent=True)
    return b if isinstance(b, dict) else {}


def _higher_tf(tf, htf):
    """اگر htf (فقط 1h/4h) واقعاً بالاتر از tf باشد آن را برمی‌گرداند، وگرنه None.

    این‌طور «تاییدیهٔ تایم‌فریمِ بالاتر» فقط وقتی اعمال می‌شود که تایم‌فریمِ انتخابی
    از تایم‌فریمِ معامله بزرگ‌تر باشد (نه مساوی و نه کوچک‌تر).
    """
    if htf not in ("1h", "4h"):
        return None
    if _TF_ORDER.get(htf, 0) > _TF_ORDER.get(tf, 0):
        return htf
    return None

# فشرده‌سازیِ gzip برای پاسخ‌های بزرگ (آرایه‌های کندل/اسکن) → انتقالِ سریع‌تر روی شبکه.
# فقط وقتی مرورگر gzip را می‌پذیرد و حجمِ پاسخ ارزشِ فشرده‌سازی دارد اعمال می‌شود.
_GZIP_MIN = 1024


@app.after_request
def _compress(resp):
    try:
        if (resp.direct_passthrough
                or resp.status_code < 200 or resp.status_code >= 300
                or "Content-Encoding" in resp.headers):
            return resp
        if "gzip" not in (request.headers.get("Accept-Encoding") or "").lower():
            return resp
        ctype = (resp.headers.get("Content-Type") or "")
        if not (ctype.startswith("application/json") or ctype.startswith("text/")
                or "javascript" in ctype or "svg" in ctype):
            return resp
        data = resp.get_data()
        if len(data) < _GZIP_MIN:
            return resp
        comp = gzip.compress(data, compresslevel=6)
        resp.set_data(comp)
        resp.headers["Content-Encoding"] = "gzip"
        resp.headers["Content-Length"] = str(len(comp))
        resp.headers.add("Vary", "Accept-Encoding")
    except Exception:  # noqa
        return resp
    return resp

# آخرین جهت هر نماد برای تشخیص تغییر سیگنال (auto-alert)
_last_dir: dict = {}

# ─────────────────────────────────────────────────────────────────────────────
#  لاگِ سمتِ سرور: هر درخواستِ /api را با متد/مسیر/کدِ وضعیت/زمانِ پاسخ ثبت می‌کند.
#  مسیرهای پرتکرارِ پایش (لاگ/منابع/health) کنار گذاشته می‌شوند تا نویز و حلقهٔ
#  بازخوردی ایجاد نشود.
# ─────────────────────────────────────────────────────────────────────────────
import time as _time
from flask import g as _g

_LOG_SKIP = ("/api/logs", "/api/system/stats", "/health")


def _cat_for_path(p: str) -> str:
    """مسیرِ API را به دستهٔ لاگ نگاشت می‌کند."""
    seg = p[5:].split("/", 1)[0] if p.startswith("/api/") else "server"
    mapping = {
        "signal": "signal", "scan": "scan", "mtf": "mtf", "compare": "compare",
        "backtest": "backtest", "optimize": "optimize", "history": "history",
        "analytics": "perf", "alerts": "alert", "mt5": "mt5", "news": "news",
        "ai": "ai", "robot": "robot", "inject": "inject", "schedule": "system",
        "server": "system", "symbols": "system",
    }
    return mapping.get(seg, "net")


@app.before_request
def _log_start():
    _g._t0 = _time.time()


@app.after_request
def _log_request(resp):
    try:
        p = request.path or ""
        if p.startswith("/api/") and not p.startswith(_LOG_SKIP):
            dt = int((_time.time() - getattr(_g, "_t0", _time.time())) * 1000)
            code = resp.status_code
            lvl = "error" if code >= 500 else ("warn" if code >= 400 else "debug")
            q = ("?" + request.query_string.decode("utf-8", "ignore")) if request.query_string else ""
            server_log.log(lvl, _cat_for_path(p),
                           f"{request.method} {p}{q}"[:180],
                           f"HTTP {code} · {dt}ms")
    except Exception:  # noqa
        pass
    return resp


@app.route("/")
def index():
    # صفحهٔ اصلی هرگز کش نشود تا تغییراتِ رابط (مثلِ نامِ تب‌ها) بلافاصله دیده شوند
    # و مرورگر نسخهٔ قدیمیِ ذخیره‌شده را نشان ندهد.
    resp = send_from_directory("static", "index.html")
    resp.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    resp.headers["Pragma"] = "no-cache"
    resp.headers["Expires"] = "0"
    return resp


@app.route("/api/symbols")
def symbols_list():
    return jsonify({"ok": True, "data": [
        {"code": k, "name": v["name"], "pair": v["pair"]}
        for k, v in sym.SYMBOLS.items()
    ]})


def _resolve_symbol(raw):
    """نمادِ ورودی را تفکیک می‌کند.

    → (internal, broker):
      • نمادِ داخلی (BTC/XAU/…):            (INTERNAL, None)
      • نمادِ کارگزار که به داخلی نگاشت می‌شود: (INTERNAL, broker)  ← از دادهٔ رایگان
      • نمادِ صرفاً متاتریدری:                 ("", broker)         ← از دادهٔ MT5
    """
    s = (raw or "").strip()
    if not s:
        return "BTC", None
    if sym.valid(s.upper()):
        return s.upper(), None
    mapped = mt5_bridge.internal_for_broker(s)
    if mapped and sym.valid(mapped):
        return mapped, s
    return "", s


def _req_tf(raw, default="1h"):
    """تایم‌فریمِ درخواست را نرمال می‌کند (پشتیبانی از قالبِ MT5 مثل H1/M15).

    برگرداندنی: (tf, error). اگر نامعتبر باشد، tf=default و error متنی است —
    اما دیگر بی‌صدا جایگزین نمی‌شود: مسیرهای تحلیلی خطا می‌دهند و مسیرهای
    نمایشی هشدارِ tf_warning را در پاسخ می‌گذارند (اصلاحِ OP5-TF-SILENT).
    """
    if raw is None or str(raw).strip() == "":
        return default, None
    t = robots.normalize_tf(raw)
    if t in VALID_TF:
        return t, None
    return default, f"تایم‌فریمِ ناشناخته «{raw}» نادیده گرفته شد؛ «{default}» استفاده می‌شود."


def _mt5_connected():
    """آیا متاتریدر ۵ در دسترس و متصل است؟ (سبک و بی‌خطا)."""
    try:
        st = mt5_bridge.status()
        return bool(st.get("available") and st.get("connected"))
    except Exception:  # noqa
        return False


def _mt5_broker_for(internal, broker):
    """نمادِ کارگزار برای دریافتِ داده از متاتریدر را برمی‌گرداند (یا None).

    اگر کاربر نامِ کارگزار داده باشد همان؛ وگرنه نمادِ داخلی (مثل BTC) را با
    resolve_symbol متاتریدر به نمادِ واقعیِ کارگزار (مثل BTCUSD) نگاشت می‌کند.
    """
    if broker:
        return broker
    if internal:
        try:
            r = mt5_bridge.resolve_symbol(internal)
            if r.get("matched") and r.get("broker"):
                return r["broker"]
        except Exception:  # noqa
            pass
    return None


def _mt5_signal(broker_symbol, display_name, tf, with_ai=False, htf=None, ai_weight=None):
    """سیگنالِ «فقط تکنیکال» از دادهٔ خودِ متاتریدر می‌سازد. در صورتِ شکست None برمی‌گرداند.

    همهٔ کندل‌ها (و تاییدیهٔ تایم‌فریمِ بالاتر) مستقیماً از متاتریدر خوانده می‌شوند.
    """
    r = mt5_bridge.rates(broker_symbol, tf)
    if not r.get("ok"):
        return None
    htf_dir, htf_label = None, ""
    if htf and htf != tf:
        try:
            hr = mt5_bridge.rates(broker_symbol, htf)
            if hr.get("ok"):
                htf_dir = engine.htf_trend_dir(ds._df_from_rows(hr["rows"]))
                htf_label = htf
        except Exception:  # noqa
            htf_dir, htf_label = None, ""
    data = engine.build_signal_from_rows(display_name, tf, r["rows"], source="MT5",
                                         digits=r.get("digits"), with_ai=with_ai,
                                         htf_dir=htf_dir, htf_label=htf_label, ai_weight=ai_weight)
    # برچسبِ صریحِ منبع تا در همهٔ نماها (کارت‌ها/نمودار/بج) «متاتریدر ۵» دیده شود.
    try:
        data["technical"]["source"] = "متاتریدر ۵ (MT5)"
    except Exception:  # noqa
        pass
    data["data_source"] = "MT5"
    return data

def _signal_for(raw, tf, with_ai=False, htf=None, ai_weight=None):
    """سیگنالِ یک نماد را می‌سازد (داخلی، نگاشت‌شده یا صرفاً متاتریدری).

    → (data, internal, broker). اگر internal تهی باشد یعنی نمادِ صرفاً MT5 است.
    with_ai فقط در مسیرِ داشبورد True است تا اسکنر/مقایسه/چندتایم‌فریم کند نشوند.
    htf: تایم‌فریمِ بالاتر برای معیارِ «تاییدیهٔ تایم‌فریمِ بالاتر» (اختیاری).
    ai_weight: وزنِ ترکیبِ AI (۰..۰٫۹) که از داشبورد قابل‌تنظیم است؛ None یعنی از کانفیگِ تبِ هوش مصنوعی.
    """
    internal, broker = _resolve_symbol(raw)

    # ─── ترجیحِ متاتریدر ۵ به‌عنوان منبعِ داده ───
    # وقتی متاتریدر متصل است، کندل/قیمت/اندیکاتورهای همهٔ نمادها (حتی نمادهای داخلی مثل BTC/XAU)
    # از خودِ متاتریدر گرفته می‌شود، نه منابعِ خارجی. اگر متاتریدر در دسترس/متصل نباشد یا نمادِ
    # متناظری در کارگزار پیدا نشود، برای اینکه برنامه از کار نیفتد به منابعِ رایگان برمی‌گردد.
    if _mt5_connected():
        bsym = _mt5_broker_for(internal, broker)
        if bsym:
            data = _mt5_signal(bsym, (broker or internal or bsym), tf,
                               with_ai=with_ai, htf=htf, ai_weight=ai_weight)
            if data is not None:
                return data, internal, (broker or bsym)

    if internal:
        data = engine.build_signal(internal, tf, with_ai=with_ai, htf=htf, ai_weight=ai_weight)
        if broker:  # نامِ نمایشی را به نامِ کارگزارِ کاربر تغییر بده
            data["symbol"] = broker.upper()
            data["symbol_name"] = broker
            data["pair"] = broker
            data["source"] = "free+mt5map"
        # منبعِ داده = همان منبعِ رایگانِ تکنیکال (OKX/Yahoo/…)
        data["data_source"] = (data.get("technical") or {}).get("source") or "free"
        return data, internal, broker
    # نمادِ صرفاً متاتریدری → دادهٔ کندل مستقیماً از MT5
    data = _mt5_signal(broker, broker, tf, with_ai=with_ai, htf=htf, ai_weight=ai_weight)
    if data is None:
        r = mt5_bridge.rates(broker, tf)
        raise RuntimeError(r.get("error", "خطای دریافتِ داده از متاتریدر"))
    return data, "", broker


@app.route("/api/signal", methods=["GET", "POST"])
def signal():
    raw = request.args.get("symbol", "BTC")
    tf, tf_warn = _req_tf(request.args.get("tf"))
    htf = _higher_tf(tf, request.args.get("htf"))
    # ai=1 → تحلیلِ هوش مصنوعی لحاظ شود (تبِ «داشبورد تحلیل هوش مصنوعی»)؛ پیش‌فرض True برای سازگاری.
    with_ai = request.args.get("ai", "1") == "1"
    ai_weight = _parse_ai_weight(request.args.get("ai_w"))
    try:
        data, internal, broker = _signal_for(raw, tf, with_ai=with_ai, htf=htf, ai_weight=ai_weight)
        if tf_warn:
            try:
                data["tf_warning"] = tf_warn
            except Exception:  # noqa
                pass
        # ثبت تاریخچه + هشدار/معامله‌ی خودکار فقط برای نمادهای داخلی/نگاشت‌شده
        if internal:
            try:
                history.record(data)
            except Exception:  # noqa
                pass
            cfg = alerts.load_config()
            key = f"{internal}:{tf}"
            # اصلاح (OPUS5-A14): check-then-set بدونِ قفل بود؛ دو GET همزمان
            # می‌توانستند دو هشدارِ یکسان بفرستند. رزروِ اتمیک + بازگشت در شکست.
            with _signal_state_lock:
                prev = _last_dir.get(key)
                changed = (prev is not None and prev != data["direction"]
                           and data["direction"] != "NEUTRAL")
                _last_dir[key] = data["direction"]
            if cfg.get("auto_alert") and changed:
                _res_al = _dispatch(data)
                if _res_al and not any((v or {}).get("ok") for v in _res_al.values()):
                    with _signal_state_lock:
                        if _last_dir.get(key) == data["direction"]:
                            _last_dir[key] = prev   # اجازهٔ تلاشِ مجدد
        # اصلاح (OPUS5-A2 — بحرانی): GET /api/signal قبلاً خودِ «ارسالِ معامله» را هم
        # اجرا می‌کرد؛ یعنی refresh/prefetch/crawler مرورگر می‌توانست سفارش بفرستد.
        # اکنون GET فقط تحلیل می‌دهد. اجرای معامله ۲ مسیرِ صریح دارد:
        #   ۱) حلقهٔ خودکارِ سمتِ سرور (AUTOPILOT-001/002)
        #   ۲) POST /api/signal با execute=true (پایین‌تر)
        if request.method == "POST" and _body_bool(_json_body(), "execute", False):
            try:
                _program_auto_dispatch(data, internal, tf, broker=broker)
                data.setdefault("dispatch", {})["attempted"] = True
            except Exception as exc:  # noqa — اصلاح (OPUS5-A15): خطا بلعیده نشود
                server_log.log("error", "mt5_out", "ارسالِ خودکارِ درخواستی ناموفق بود",
                               f"symbol={broker or internal} tf={tf}: {exc}")
                data.setdefault("dispatch", {}).update(
                    {"attempted": True, "ok": False, "error": str(exc)[:200]})
        data["mt5_connected"] = _mt5_connected()
        return jsonify({"ok": True, "data": data})
    except Exception as e:  # noqa
        return jsonify({"ok": False, "error": str(e)}), 502


@app.route("/api/mt5/marketwatch")
def mt5_marketwatch():
    """نمادهای موجود در Market Watchِ متاتریدرِ کاربر (برای پرکردنِ لیستِ نمادها)."""
    return jsonify({"ok": True, "data": mt5_bridge.market_watch()})


def _display_name(raw):
    """نام و pairِ نمایشی یک نماد را برمی‌گرداند (داخلی یا نمادِ کارگزار)."""
    internal, broker = _resolve_symbol(raw)
    if broker or not internal:
        return (broker or str(raw or "").strip() or "—"), (broker or str(raw or "").strip() or "—")
    c = sym.resolve(internal)
    if not c:
        return internal, internal
    return c["name"], c["pair"]


def _history_df(raw, tf, bars):
    """DataFrameِ تاریخی یک نماد (برای بک‌تست/بهینه‌سازی) — داخلی یا مستقیماً از MT5.

    → (df, internal, broker). internalِ تهی یعنی نمادِ صرفاً متاتریدری.
    """
    internal, broker = _resolve_symbol(raw)
    # ─── ترجیحِ متاتریدر ۵ برای دادهٔ تاریخی هم (بک‌تست/بهینه‌سازی) ───
    # وقتی متاتریدر متصل است، حتی برای نمادهای داخلی (BTC/XAU/…) کندل‌های تاریخی از
    # خودِ متاتریدر خوانده می‌شود، نه منابعِ خارجی. اگر متصل نبود یا نماد در کارگزار
    # پیدا نشد، به منبعِ رایگان برمی‌گردیم تا برنامه از کار نیفتد.
    if _mt5_connected():
        bsym = _mt5_broker_for(internal, broker)
        if bsym:
            r = mt5_bridge.rates(bsym, tf, count=max(int(bars), 200))
            if r.get("ok"):
                return ds._df_from_rows(r["rows"]), internal, broker
    if internal:
        return ds.get_history(internal, tf, bars), internal, broker
    r = mt5_bridge.rates(broker, tf, count=max(int(bars), 200))
    if not r.get("ok"):
        raise RuntimeError(r.get("error", "خطای دریافتِ داده از متاتریدر"))
    return ds._df_from_rows(r["rows"]), "", broker


def _parse_ai_weight(raw):
    """پارسِ پارامترِ ai_w: کسر (۰..۰٫۹) یا درصد (>1 → تقسیم بر ۱۰۰). None اگر نامعتبر/غایب."""
    if raw is None or raw == "":
        return None
    try:
        v = float(raw)
    except Exception:  # noqa
        return None
    if v > 1:
        v = v / 100.0
    return max(0.0, min(0.9, v))


def _parse_sym_tf(entry, default_tf):
    """اصلاح (WL-TF-001): ورودیِ «SYM@TF» → (نماد، تایم‌فریمِ مخصوص).

    به کاربر اجازه می‌دهد در واچ‌لیست برای هر نماد تایم‌فریمِ تحلیلِ جداگانه
    انتخاب کند (مثلاً BTC@5m کنار XAU@1h)."""
    e = (entry or "").strip()
    if "@" in e:
        s_, _, t_ = e.partition("@")
        t_ = t_.strip()
        if t_ in VALID_TF:
            return s_.strip(), t_
        return s_.strip(), default_tf
    return e, default_tf


def _summary_row(raw, tf, spark_n=32, htf=None, with_ai=False, ai_weight=None):
    """ردیف خلاصه یک نماد (برای مقایسه و اسکنر) شامل sparkline قیمت.

    with_ai=True یعنی تحلیلِ هوش مصنوعی هم در امتیاز لحاظ شود (تبِ «داشبورد تحلیل هوش مصنوعی»).
    """
    try:
        d, internal, broker = _signal_for(raw, tf, with_ai=with_ai, htf=htf, ai_weight=ai_weight)
        cds = d["chart"]["candles"][-spark_n:]
        closes = [c["c"] for c in cds]
        _cfg_i = sym.resolve(internal) if internal else None
        ac = _cfg_i.get("asset_class") if _cfg_i else "mt5"
        return {
            "symbol": d["symbol"], "name": d["symbol_name"], "pair": d["pair"],
            "price": d["price"], "direction": d["direction"],
            "total_score": d["total_score"], "confidence": d["confidence"],
            "tech": round(d["technical"]["score"], 1),
            "fund": round(d["fundamental"]["score"], 1),
            "sent": round(d["sentiment"]["score"], 1),
            "sent_kind": d["sentiment"].get("kind"),
            "entry": d["plan"].get("entry"),
            "stop_loss": d["plan"].get("stop_loss"),
            "take_profits": [t["price"] for t in d["plan"].get("take_profits", [])],
            "rr": d["plan"].get("rr"),
            "source": d["technical"]["source"],
            "spark": closes,
            "ohlc": [{"o": c["o"], "h": c["h"], "l": c["l"], "c": c["c"]} for c in cds],
            "asset_class": ac,
            "mt5_only": bool(d.get("mt5_only")),
            "ai_used": bool((d.get("ai") or {}).get("used")),
            "internal_score": d.get("internal_score", d["total_score"]),
            # اصلاح (AIDASH-003): کارت‌های «داشبورد تحلیل هوش مصنوعی» باید خودِ
            # تحلیلِ AI را نشان دهند؛ قبلاً فقط ai_used بولی می‌آمد و کارت‌ها
            # همیشه امتیازهای داخلی را نمایش می‌دادند (با وجودِ مصرفِ توکن).
            "ai_error": ((d.get("ai") or {}).get("error") or None),
            "ai_direction": (d.get("ai") or {}).get("direction"),
            "ai_score": ((d.get("ai") or {}).get("overall_score")
                         if (d.get("ai") or {}).get("used") else None),
            "ai_confidence": (d.get("ai") or {}).get("confidence"),
            "ai_tech": (d.get("ai") or {}).get("technical_score"),
            "ai_fund": (d.get("ai") or {}).get("fundamental_score"),
            "ai_sent": (d.get("ai") or {}).get("sentiment_score"),
            "ai_summary": (((d.get("ai") or {}).get("summary") or "")[:220] or None),
            "ai_model": (d.get("ai") or {}).get("model"),
            "tf": tf,   # اصلاح (WL-TF-001): تایم‌فریمِ واقعاً استفاده‌شده برای این نماد
        }
    except Exception as e:  # noqa
        return {"symbol": raw, "error": str(e)}


def _build_rows(symbols, tf, max_workers=12, htf=None, with_ai=False, ai_weight=None):
    """ساخت ردیف‌های خلاصه به‌صورت موازی (I/O bound). نمادهای داخلی و کارگزار هر دو."""
    seen, cand = set(), []
    for s in symbols:
        # اصلاح (WL-TF-001): هر ورودی می‌تواند «SYM@TF» باشد (تایم‌فریمِ مخصوصِ نماد)
        s_, tf_i = _parse_sym_tf(s, tf)
        if not s_:
            continue
        k = (s_.upper(), tf_i)
        if k in seen:
            continue
        seen.add(k)
        cand.append((s_, tf_i))
    rows = [None] * len(cand)
    with ThreadPoolExecutor(max_workers=max_workers) as ex:
        futs = {}
        for i, (s_, tf_i) in enumerate(cand):
            # اگر تایم‌فریمِ مخصوص انتخاب شده، تاییدیهٔ تایم‌فریمِ بالاتر هم با همان محاسبه شود
            htf_i = htf if tf_i == tf else _higher_tf(tf_i, None)
            futs[ex.submit(_summary_row, s_, tf_i, htf=htf_i, with_ai=with_ai,
                           ai_weight=ai_weight)] = i
        for f in futs:
            rows[futs[f]] = f.result()
    return rows


@app.route("/api/compare")
def compare():
    """مقایسه سیگنال چند نماد کنار هم (خلاصه + sparkline)."""
    syms = request.args.get("symbols", "BTC,ETH,XAU").split(",")
    tf, tf_warn = _req_tf(request.args.get("tf"))
    htf = _higher_tf(tf, request.args.get("htf"))
    with_ai = request.args.get("ai", "0") == "1"
    ai_weight = _parse_ai_weight(request.args.get("ai_w"))
    rows = _build_rows(syms[:12], tf, max_workers=12, htf=htf, with_ai=with_ai, ai_weight=ai_weight)
    payload = {"tf": tf, "htf": htf, "ai": with_ai, "ai_w": ai_weight,
               "mt5_connected": _mt5_connected(), "rows": rows}
    if tf_warn:
        payload["tf_warning"] = tf_warn
    return jsonify({"ok": True, "data": payload})


@app.route("/api/scan")
def scan():
    """اسکن همه نمادها و رتبه‌بندی بر اساس قوی‌ترین سیگنال (|امتیاز کل|)."""
    tf, tf_warn = _req_tf(request.args.get("tf"))
    # اگر متاتریدر متصل است، نمادهای Market Watchِ کاربر را اسکن کن؛ وگرنه نمادهای داخلی
    mw = mt5_bridge.market_watch()
    if mw.get("connected") and mw.get("symbols"):
        all_codes = [s["name"] for s in mw["symbols"]][:60]
        src = "mt5"
    else:
        all_codes = list(sym.SYMBOLS.keys())
        src = "builtin"
    rows = _build_rows(all_codes, tf, max_workers=16)
    ok_rows = [r for r in rows if "error" not in r]
    err_rows = [r for r in rows if "error" in r]
    # قوی‌ترین سیگنال‌ها بر اساس قدرمطلق امتیاز
    ranked = sorted(ok_rows, key=lambda r: abs(r["total_score"] or 0), reverse=True)
    longs = sorted([r for r in ok_rows if r["direction"] == "LONG"],
                   key=lambda r: r["total_score"], reverse=True)
    shorts = sorted([r for r in ok_rows if r["direction"] == "SHORT"],
                    key=lambda r: r["total_score"])
    _scan_payload = {
        "tf": tf, "ranked": ranked, "longs": longs, "shorts": shorts,
        "count": len(ok_rows), "errors": err_rows, "source": src,
    }
    if tf_warn:
        _scan_payload["tf_warning"] = tf_warn
    return jsonify({"ok": True, "data": _scan_payload})


MTF_TFS = ["15m", "1h", "4h", "1d"]


@app.route("/api/mtf")
def mtf():
    """تحلیل چند تایم‌فریمی هم‌زمان یک نماد + اجماع (consensus)."""
    symbol = request.args.get("symbol", "BTC")

    def one(tf):
        try:
            d, _internal, _broker = _signal_for(symbol, tf)
            return {"tf": tf, "direction": d["direction"], "total_score": d["total_score"],
                    "tech": round(d["technical"]["score"], 1),
                    "fund": round(d["fundamental"]["score"], 1),
                    "sent": round(d["sentiment"]["score"], 1),
                    "price": d["price"], "rsi": round(d["technical"]["rsi"], 1),
                    "trend": d["technical"]["trend"], "confidence": d["confidence"]}
        except Exception as e:  # noqa
            return {"tf": tf, "error": str(e)}

    rows = [None] * len(MTF_TFS)
    with ThreadPoolExecutor(max_workers=4) as ex:
        futs = {ex.submit(one, tf): i for i, tf in enumerate(MTF_TFS)}
        for f in futs:
            rows[futs[f]] = f.result()

    ok = [r for r in rows if "error" not in r]
    longs = sum(1 for r in ok if r["direction"] == "LONG")
    shorts = sum(1 for r in ok if r["direction"] == "SHORT")
    neutrals = sum(1 for r in ok if r["direction"] == "NEUTRAL")
    avg = round(sum(r["total_score"] for r in ok) / len(ok), 1) if ok else 0
    if longs > shorts and longs >= max(1, len(ok) // 2):
        consensus = "LONG"
    elif shorts > longs and shorts >= max(1, len(ok) // 2):
        consensus = "SHORT"
    else:
        consensus = "MIXED"
    agree = round(max(longs, shorts) / len(ok) * 100) if ok else 0
    disp_name, disp_pair = _display_name(symbol)
    return jsonify({"ok": True, "data": {
        "symbol": symbol, "name": disp_name, "pair": disp_pair,
        "rows": rows, "consensus": consensus, "avg_score": avg,
        "longs": longs, "shorts": shorts, "neutrals": neutrals, "agreement": agree,
    }})


@app.route("/api/backtest")
def bt():
    raw = request.args.get("symbol", "BTC")
    tf, tf_err = _req_tf(request.args.get("tf"))
    if tf_err:
        return jsonify({"ok": False, "error": tf_err}), 400
    try:
        # اصلاح (RUNTIME-003): سقفِ bars تا درخواستِ عظیم، حلقهٔ تاریخچه/DataFrame را نبلعد.
        bars = max(120, min(10_000, _qint("bars", 800)))
        threshold = _qfloat("threshold", 25)
        allow_short = request.args.get("short", "1") != "0"
        sl_atr = _qfloat("sl", 1.5)
        tp_atr = _qfloat("tp", 3.0)
        df, internal, broker = _history_df(raw, tf, bars)
        label = (broker or internal or "BTC")
        data = backtest.run_backtest(label, tf, bars=bars,
                                     threshold=threshold, allow_short=allow_short,
                                     atr_mult_sl=sl_atr, atr_mult_tp=tp_atr, df=df,
                                     spread=_qfloat("spread", 0.0),
                                     slippage=_qfloat("slippage", 0.0),
                                     commission_pct=_qfloat("commission", 0.0))
        data["symbol"] = label
        data["mt5_only"] = not internal
        return jsonify({"ok": True, "data": data})
    except Exception as e:  # noqa
        return jsonify({"ok": False, "error": str(e)}), 502


@app.route("/api/optimize")
def optimize():
    raw = request.args.get("symbol", "BTC")
    tf, tf_err = _req_tf(request.args.get("tf"))
    if tf_err:
        return jsonify({"ok": False, "error": tf_err}), 400
    try:
        bars = max(120, min(10_000, _qint("bars", 800)))   # اصلاح (RUNTIME-003)
        allow_short = request.args.get("short", "1") != "0"
        metric = request.args.get("metric", "net_r")
        df, internal, broker = _history_df(raw, tf, bars)
        label = (broker or internal or "BTC")
        data = optimizer.optimize(label, tf, bars=bars,
                                  allow_short=allow_short, metric=metric, df=df,
                                  walk_forward=(request.args.get("wf", "0") == "1"),
                                  train_ratio=_qfloat("train_ratio", 0.7),
                                  spread=_qfloat("spread", 0.0),
                                  slippage=_qfloat("slippage", 0.0),
                                  commission_pct=_qfloat("commission", 0.0))
        data["symbol"] = label
        data["mt5_only"] = not internal
        return jsonify({"ok": True, "data": data})
    except Exception as e:  # noqa
        return jsonify({"ok": False, "error": str(e)}), 502


def _parse_date_ts(s, end=False):
    """رشتهٔ تاریخ (YYYY-MM-DD یا ISO) را به epochِ ثانیه (UTC) تبدیل می‌کند."""
    import datetime as _dt
    s = (s or "").strip()
    if not s:
        return None
    try:
        if "T" in s:
            d = _dt.datetime.fromisoformat(s.replace("Z", "+00:00"))
            if d.tzinfo is None:
                d = d.replace(tzinfo=_dt.timezone.utc)
        else:
            d = _dt.datetime.strptime(s, "%Y-%m-%d").replace(tzinfo=_dt.timezone.utc)
            if end:
                d = d.replace(hour=23, minute=59, second=59)
        return d.timestamp()
    except Exception:  # noqa
        return None


@app.route("/api/mt5/data/list")
def mt5_data_list():
    """فهرست دیتاسِت‌های کش‌شده (نماد/تایم‌فریم/تعداد کندل/بازه)."""
    return jsonify({"ok": True, "data": mt5_bridge.list_cached()})


@app.route("/api/mt5/data/load")
def mt5_data_load():
    """بارگذاری دادهٔ کش‌شدهٔ یک نماد+تایم‌فریم از پوشهٔ برنامه."""
    symbol = request.args.get("symbol", "").strip()
    tf = request.args.get("tf", "1h").strip()
    if not symbol:
        return jsonify({"ok": False, "error": "نماد مشخص نشده است."}), 400
    r = mt5_bridge.load_rates(symbol, tf)
    if not r.get("ok"):
        return jsonify({"ok": False, "error": r.get("error", "دادهٔ کش‌شده‌ای موجود نیست.")}), 404
    return jsonify({"ok": True, "data": {
        "symbol": symbol, "interval": tf, "bars": r.get("bars", 0),
        "from": r.get("from"), "to": r.get("to"),
    }})


@app.route("/api/backtest/mt5")
def bt_mt5():
    """بک‌تستِ سبک متاتریدر ۵: بازهٔ دقیقِ تاریخ + دیتای مستقیمِ کارگزار یا کشِ دیسک.

    پارامترها: symbol، tf، from، to (YYYY-MM-DD)، threshold، sl، tp، short،
    deposit، risk، use_cache (1=از کشِ دیسک بخوان، در غیر این صورت از MT5 بگیر و کش کن).
    """
    symbol = request.args.get("symbol", "").strip()
    tf = request.args.get("tf", "1h").strip()
    if not symbol:
        return jsonify({"ok": False, "error": "نماد مشخص نشده است."}), 400
    if tf not in mt5_bridge.TF_ORDER:
        return jsonify({"ok": False, "error": f"تایم‌فریمِ نامعتبر: {tf}"}), 400
    try:
        threshold = _qfloat("threshold", 25)
        allow_short = request.args.get("short", "1") != "0"
        sl_atr = _qfloat("sl", 1.5)
        tp_atr = _qfloat("tp", 3.0)
        deposit = _qfloat("deposit", 10000)
        risk = _qfloat("risk", 1.0)
    except Exception as e:  # noqa
        return jsonify({"ok": False, "error": f"پارامترِ نامعتبر: {e}"}), 400

    use_cache = request.args.get("use_cache", "0") == "1"
    from_ts = _parse_date_ts(request.args.get("from"), end=False)
    to_ts = _parse_date_ts(request.args.get("to"), end=True)

    try:
        if use_cache:
            r = mt5_bridge.load_rates(symbol, tf)
            if not r.get("ok") or not r.get("rows"):
                return jsonify({"ok": False, "error": r.get("error", "دادهٔ کش‌شده‌ای موجود نیست.")}), 404
            rows = r["rows"]
            # در صورت تعیینِ بازه، همان محدوده را فیلتر کن
            if from_ts and to_ts:
                lo, hi = from_ts * 1000, to_ts * 1000
                rows = [x for x in rows if lo <= x[0] <= hi]
            src = "cache"
        else:
            if from_ts is None or to_ts is None:
                return jsonify({"ok": False, "error": "بازهٔ تاریخِ «از/تا» را مشخص کنید."}), 400
            r = mt5_bridge.rates_range(symbol, tf, from_ts, to_ts)
            if not r.get("ok"):
                return jsonify({"ok": False, "error": r.get("error", "دریافتِ داده از متاتریدر ناموفق بود.")}), 502
            rows = r["rows"]
            # ذخیره در کشِ دیسک برای دفعاتِ بعد
            mt5_bridge.save_rates(symbol, tf, rows)
            src = "mt5"

        if not rows or len(rows) < 60:
            return jsonify({"ok": False, "error": "دادهٔ کافی برای بک‌تست در این بازه موجود نیست."}), 400

        df = ds._df_from_rows(rows)
        df.attrs["source"] = src
        data = backtest.run_backtest_df(
            df, symbol, tf, threshold=threshold, atr_mult_sl=sl_atr,
            atr_mult_tp=tp_atr, allow_short=allow_short,
            initial_deposit=deposit, risk_pct=risk)
        data["symbol"] = symbol
        data["mt5_only"] = True
        data["date_from"] = request.args.get("from")
        data["date_to"] = request.args.get("to")
        data["cached_bars"] = mt5_bridge.load_rates(symbol, tf).get("bars", len(rows))
        return jsonify({"ok": True, "data": data})
    except Exception as e:  # noqa
        return jsonify({"ok": False, "error": str(e)}), 502


@app.route("/api/history", methods=["GET"])
def get_history_api():
    symbol = request.args.get("symbol")
    # نمادِ داخلی یا کارگزار — هر دو مجازند (get_all با upper مقایسه می‌کند)
    if symbol:
        symbol = symbol.strip() or None
    # پارامترِ limit (پیش‌فرض ۱۰۰، سقف ۱۰۰۰) — پیش‌تر نادیده گرفته می‌شد
    limit = max(1, min(1000, _qint("limit", 100)))
    return jsonify({"ok": True, "data": history.get_all(symbol, limit=limit)})


@app.route("/api/history", methods=["DELETE"])
def clear_history_api():
    history.clear()
    return jsonify({"ok": True})


@app.route("/api/analytics")
def analytics_api():
    """تحلیلِ عملکردِ سیگنال‌های ثبت‌شده (win-rate / R محقق‌شده / توزیعِ TP) با فیلترِ تاریخی."""
    symbol = (request.args.get("symbol") or "").strip() or None
    tf = (request.args.get("tf") or "").strip() or None
    if tf and tf not in VALID_TF:
        tf = None
    direction = (request.args.get("direction") or "").strip().upper() or None
    if direction not in ("LONG", "SHORT", None):
        direction = None
    days_raw = (request.args.get("days") or "").strip()
    days = int(days_raw) if days_raw.isdigit() and int(days_raw) > 0 else None
    try:
        data = analytics.analyze(symbol=symbol, interval=tf, direction=direction, days=days)
        return jsonify({"ok": True, "data": data})
    except Exception as e:  # noqa
        return jsonify({"ok": False, "error": str(e)}), 500


# ------------------------------------------------------------ هشدارها
@app.route("/api/alerts/config", methods=["GET"])
def get_alert_cfg():
    return jsonify({"ok": True, "data": alerts.public_config()})


@app.route("/api/alerts/config", methods=["POST"])
def set_alert_cfg():
    body = _json_body()
    if not isinstance(body, dict):
        body = {}
    # مقادیرِ غیر-dict برای بخش‌های تو در تو → نادیده (جلوگیری از 500)
    tg = body.get("telegram")
    if not isinstance(tg, dict):
        body.pop("telegram", None)
        tg = {}
    em = body.get("email")
    if not isinstance(em, dict):
        body.pop("email", None)
        em = {}
    # فیلدهای خالی رمز/توکن را حذف کن تا مقدار قبلی بازنویسی نشود
    if tg.get("bot_token") == "":
        tg.pop("bot_token", None)
    if em.get("password") == "":
        em.pop("password", None)
    alerts.save_config(body)
    return jsonify({"ok": True, "data": alerts.public_config()})


def _dispatch(sig):
    cfg = alerts.load_config()
    results = {}
    if cfg.get("telegram", {}).get("enabled"):
        results["telegram"] = alerts.send_telegram(alerts.format_signal_text(sig))
    if cfg.get("email", {}).get("enabled"):
        results["email"] = alerts.send_email(
            f"سیگنال {sig['pair']} — {sig['direction']}",
            alerts.format_signal_html(sig))
    return results


@app.route("/api/alerts/send", methods=["POST"])
def send_alert():
    body = _json_body()
    raw_sym = (body.get("symbol") or "BTC").strip()
    tf = body.get("tf") or "1h"
    # اصلاح (MT5-SEND-002): نمادِ کارگزار/متاتریدری قبلاً بی‌صدا به BTC تبدیل
    # می‌شد و هشدار برای نمادِ اشتباه ارسال می‌شد؛ حالا مثل بقیهٔ مسیرها resolve می‌شود.
    _internal, _broker = _resolve_symbol(raw_sym)
    symbol = _internal if (_internal and not _broker) else (_broker or "BTC")
    if tf not in VALID_TF:
        tf = "1h"
    try:
        sig, _i, _b = _signal_for(symbol, tf)   # وقتی MT5 متصل است، از دادهٔ خودِ متاتریدر
        results = _dispatch(sig)
        if not results:
            return jsonify({"ok": False, "error": "هیچ کانالی (تلگرام/ایمیل) فعال نیست"}), 400
        any_ok = any(r.get("ok") for r in results.values())
        return jsonify({"ok": any_ok, "results": results})
    except Exception as e:  # noqa
        return jsonify({"ok": False, "error": str(e)}), 502


# ------------------------------------------------------------ متاتریدر ۵ (MT5)
@app.route("/api/mt5/config", methods=["GET"])
def mt5_get_cfg():
    return jsonify({"ok": True, "data": {
        "config": mt5_bridge.load_config(),
        "status": mt5_bridge.status(),
    }})


@app.route("/api/mt5/config", methods=["POST"])
def mt5_set_cfg():
    body = _json_body()
    saved = mt5_bridge.save_config(body)
    return jsonify({"ok": True, "data": {"config": saved, "status": mt5_bridge.status()}})


@app.route("/api/mt5/connect", methods=["POST"])
def mt5_connect():
    body = _json_body()
    st = mt5_bridge.connect(force=bool(body.get("force")))
    return jsonify({"ok": st.get("connected", False), "data": st})


@app.route("/api/mt5/disconnect", methods=["POST"])
def mt5_disconnect():
    return jsonify({"ok": True, "data": mt5_bridge.disconnect()})


@app.route("/api/mt5/status", methods=["GET"])
def mt5_status():
    return jsonify({"ok": True, "data": mt5_bridge.status()})


@app.route("/api/mt5/resolve", methods=["GET"])
def mt5_resolve():
    symbol = request.args.get("symbol", "BTC").upper()
    return jsonify({"ok": True, "data": mt5_bridge.resolve_symbol(symbol)})


@app.route("/api/mt5/send", methods=["POST"])
def mt5_send():
    """ساخت سیگنال زنده و ارسال آن به‌عنوان معامله به متاتریدر ۵.

    بدنه: {symbol, tf?, direction? (LONG/SHORT برای اجبار جهت), volume?, dry_run?, overrides?{...}}
    اگر direction داده نشود، از جهت سیگنال زنده استفاده می‌شود.
    """
    body = _json_body()
    raw_sym = (body.get("symbol") or "BTC").strip()
    tf = body.get("tf") or "1h"
    # اصلاح (MT5-SEND-001): این گیت قبلاً فقط نمادهای داخلی (sym.valid) را قبول
    # می‌کرد و نمادهای کارگزار/صرفاً متاتریدری (مثل BITCOIN) را با «نماد نامعتبر»
    # ۴۰۰ می‌داد — در حالی که سیگنال/نمودار/اسکنر همین نمادها را پشتیبانی می‌کنند
    # و mt5_bridge.send_order هم خودش نمادِ کارگزار را resolve می‌کند.
    _internal, _broker = _resolve_symbol(raw_sym)
    if _internal and not _broker:
        symbol = _internal                 # نمادِ داخلی (BTC/XAU/…)
    else:
        symbol = (_broker or "").strip()   # نمادِ کارگزار (نگاشت‌شده یا صرفاً متاتریدری)
    if not symbol:
        return jsonify({"ok": False, "error": f"نماد نامعتبر: {raw_sym}"}), 400
    if not _internal and not _mt5_connected():
        return jsonify({"ok": False, "error": (
            f"نماد {symbol} فقط در متاتریدر شناخته می‌شود و اتصال متاتریدر ۵ "
            "برقرار نیست؛ ابتدا از تب متاتریدر متصل شوید.")}), 400
    # اصلاح (INPUT-005): overrides رشته/لیست به mt5_bridge می‌رسید و .items() آن
    # AttributeError و پاسخ 500 می‌ساخت؛ باید 400 صریح باشد.
    _ovr = body.get("overrides")
    if _ovr is not None and not isinstance(_ovr, dict):
        return jsonify({"ok": False, "error": "overrides باید یک شیء JSON باشد."}), 400
    # اصلاح (OPUS5-A7): تبدیلِ امنِ ورودی‌ها — bool("false")/حجمِ True/عددِ نامتناهی
    dry_run_req = _body_bool(body, "dry_run", False)
    allow_duplicate_req = _body_bool(body, "allow_duplicate", False)
    allow_opposite_req = _body_bool(body, "allow_opposite", False)
    try:
        requested_volume = _body_volume(body)
    except ValueError as _ve:
        return jsonify({"ok": False, "error": str(_ve)}), 400
    _rawdir = body.get("direction")
    if _rawdir is not None and not isinstance(_rawdir, str):
        return jsonify({"ok": False, "error": "direction باید LONG یا SHORT باشد."}), 400
    if tf not in VALID_TF:
        tf = "1h"
    try:
        sig, _i, _b = _signal_for(symbol, tf)   # وقتی MT5 متصل است، از دادهٔ خودِ متاتریدر
    except Exception as e:  # noqa
        return jsonify({"ok": False, "error": f"خطا در ساخت سیگنال: {e}"}), 502

    direction = (body.get("direction") or sig["direction"]).upper()
    if direction not in ("LONG", "SHORT"):
        return jsonify({"ok": False, "error": "جهت سیگنال خنثی است؛ برای ارسال باید LONG یا SHORT باشد."}), 400

    # اصلاح (OPUS5-A3): کلِ «چکِ تکرار/مخالف → زمان‌بندی → نقشه → ارسال» اتمیک
    with _manual_send_lock:
        return _mt5_send_locked(body, symbol, tf, sig, direction, dry_run_req,
                                allow_duplicate_req, allow_opposite_req,
                                requested_volume)


def _mt5_send_locked(body, symbol, tf, sig, direction, dry_run_req,
                     allow_duplicate_req, allow_opposite_req, requested_volume):
    """بخشِ اتمیکِ ارسالِ دستی — سریال‌شده با _manual_send_lock (OPUS5-A3)."""
    # اصلاح (MT5-DUP-001): دکمهٔ «بازکردن این معامله» می‌توانست با دوبار کلیک/
    # هم‌زمانیِ حالتِ خودکار، معاملهٔ تکراریِ هم‌جهت باز کند. اگر پوزیشنِ بازِ
    # هم‌جهتِ همین ربات روی همان نماد موجود باشد، ارسالِ واقعی با 409 رد می‌شود؛
    # بازکردنِ عمدیِ معاملهٔ دوم با allow_duplicate=true همچنان ممکن است.
    if not dry_run_req and not allow_duplicate_req:
        try:
            _pres = mt5_bridge.positions(magic_only=True)
            if _pres.get("ok"):
                _rs = mt5_bridge.resolve_symbol(symbol)
                _bsym2 = _rs.get("broker") or symbol
                _dups = [p for p in (_pres.get("positions") or [])
                         if p.get("symbol") == _bsym2 and p.get("type") == direction]
                if _dups:
                    _d0 = _dups[0]
                    return jsonify({"ok": False, "duplicate": True, "ticket": _d0.get("ticket"),
                                    "error": (f"همین معامله از قبل باز است: پوزیشنِ {direction} روی "
                                              f"{_bsym2} (تیکت {_d0.get('ticket')}، حجم {_d0.get('volume')}). "
                                              "برای بازکردنِ عمدیِ معاملهٔ دوم، allow_duplicate را فعال کنید.")}), 409
                # اصلاح (PROG-GUARD-001): پوزیشنِ مخالفِ باز → جلوگیری از هجِ ناخواسته
                if not allow_opposite_req:
                    _opps = [p for p in (_pres.get("positions") or [])
                             if p.get("symbol") == _bsym2 and p.get("type") != direction]
                    if _opps:
                        _o0 = _opps[0]
                        return jsonify({"ok": False, "opposite": True, "ticket": _o0.get("ticket"),
                                        "error": (f"پوزیشنِ مخالف ({_o0.get('type')}) روی {_bsym2} باز است "
                                                  f"(تیکت {_o0.get('ticket')}). باز کردنِ خرید و فروشِ همزمان "
                                                  "(هج) خلافِ منطقِ برنامه است؛ ابتدا پوزیشنِ قبلی را ببندید یا "
                                                  "برای هجِ عمدی allow_opposite را فعال کنید.")}), 409
        except Exception:  # noqa
            pass

    # زمان‌بندیِ ساعاتِ کارِ سرور: خارج از بازهٔ کاری، ارسالِ دستی هم متوقف است
    prog_active, prog_info = _program_gate()
    if not prog_active and not dry_run_req:
        return jsonify({"ok": False, "error": (
            f"ساعاتِ کارِ سرور: {prog_info.get('reason','خارج از بازهٔ کاری')} "
            f"(ساعتِ سرور {prog_info.get('broker_time','')}). ارسال متوقف شد."),
            "schedule_blocked": True, "schedule": prog_info}), 409

    plan = sig.get("plan", {})
    # اگر جهت به‌صورت دستی برعکسِ نقشه انتخاب شده باشد، نقشه‌ی جهتِ درخواستی را از نو می‌سازیم
    if direction != sig["direction"]:
        try:
            tech = sig["technical"]
            plan = engine.build_trade_plan(
                direction, sig["price"], sig["atr"],
                tech["supports"], tech["resistances"],
                abs(sig["total_score"]), engine._dec(sig["price"]),
                fib=tech.get("fibonacci"),
                extra_sup=tech.get("conf_supports"), extra_res=tech.get("conf_resistances"))
        except Exception:  # noqa
            plan = sig.get("plan", {})

    res = mt5_bridge.send_order(
        symbol, direction, plan,
        volume=requested_volume,
        dry_run=dry_run_req,
        overrides=body.get("overrides") or {},
    )
    res["signal"] = {
        "symbol": symbol, "tf": tf, "direction": direction,
        "price": sig.get("price"), "total_score": sig.get("total_score"),
        "pair": sig.get("pair"),
    }
    code = 200 if res.get("ok") else 400
    # ثبتِ سیگنالِ خروجی (ارسال به متاتریدر ۵) در لاگِ سرور
    try:
        dry_req = dry_run_req
        # اصلاح (DISP-TRUTH-003): اگر کاربر ارسالِ واقعی خواسته ولی MT5 در دسترس
        # نبوده و نتیجه «شبیه‌سازی» شده، باید با هشدارِ صریح لاگ شود — نه «موفق».
        dry_actual = bool(res.get("dry_run") or res.get("simulated"))
        forced_sim = dry_actual and not dry_req
        ok = res.get("ok", False)
        _tks = res.get("tickets") or []
        if forced_sim:
            lvl = "warn"
            pfx = "ارسالِ درخواستی فقط «شبیه‌سازی» شد — معامله‌ای در متاتریدر باز نشد"
        else:
            lvl = "info" if dry_req else ("success" if ok else "error")
            pfx = "پیش‌نمایشِ ارسال" if dry_req else "ارسال"
        msg = f"{pfx} به متاتریدر ۵: {symbol} {direction}"
        detail = (f"قیمت={sig.get('price')} · امتیاز={sig.get('total_score')} · "
                  f"تایم‌فریم={tf} · حجم={res.get('volume') or body.get('volume')} · "
                  f"آزمایشی={dry_actual} · نتیجه={'موفق' if ok else 'ناموفق'}"
                  + (f" · تیکت‌ها={_tks}" if _tks else "")
                  + (f" · علت={res.get('note')}" if forced_sim and res.get('note') else "")
                  + (f" · خطا={res.get('error')}" if res.get('error') else ""))
        server_log.log(lvl, "mt5_out", msg, detail)
    except Exception:  # noqa
        pass
    return jsonify({"ok": res.get("ok", False), "data": res}), code


@app.route("/api/mt5/manager", methods=["POST"])
def mt5_manager():
    """روشن/خاموش کردن موتور مدیریت پوزیشن (Breakeven + Trailing)."""
    body = _json_body()
    enabled = bool(body.get("enabled"))
    mt5_bridge.save_config({"manage_positions": enabled})
    if enabled:
        st = mt5_bridge.start_manager()
    else:
        st = mt5_bridge.stop_manager()
    return jsonify({"ok": True, "data": st})


@app.route("/api/mt5/manager", methods=["GET"])
def mt5_manager_status():
    return jsonify({"ok": True, "data": mt5_bridge.manager_status()})


@app.route("/api/mt5/log", methods=["GET"])
def mt5_log():
    limit = _qint("limit", 200)
    return jsonify({"ok": True, "data": {
        "log": mt5_bridge.read_log(limit),
        "today": mt5_bridge._today_stats(),
    }})


@app.route("/api/mt5/log", methods=["DELETE"])
def mt5_log_clear():
    mt5_bridge.clear_log()
    return jsonify({"ok": True})


@app.route("/api/mt5/positions", methods=["GET"])
def mt5_positions():
    magic_only = request.args.get("all", "0") != "1"
    return jsonify({"ok": True, "data": mt5_bridge.positions(magic_only=magic_only)})


@app.route("/api/mt5/close", methods=["POST"])
def mt5_close():
    body = _json_body()
    if body.get("all"):
        return jsonify({"ok": True, "data": mt5_bridge.close_all(
            magic_only=not bool(body.get("include_manual")))})
    ticket = body.get("ticket")
    if not ticket:
        return jsonify({"ok": False, "error": "ticket لازم است"}), 400
    try:
        ticket = int(float(ticket))
    except (TypeError, ValueError):
        return jsonify({"ok": False, "error": f"ticket نامعتبر است: {ticket!r}"}), 400
    # OP5-CORE-09: پیش‌تر هر ticket (حتی پوزیشنِ دستی یا رباتِ دیگر) بسته می‌شد.
    # حالا فقط ticketهایی که واقعاً پوزیشنِ بازِ همین ایجنت‌اند (بر اساسِ magic)
    # بسته می‌شوند؛ وضعیتِ پوزیشن‌ها هم از متاتریدر خوانده می‌شود.
    pres = mt5_bridge.positions(magic_only=True)
    if not pres.get("ok"):
        return jsonify({"ok": False, "error": "position state unavailable"}), 503
    allowed = {int(p["ticket"]) for p in (pres.get("positions") or [])
               if p.get("ticket") is not None}
    if ticket not in allowed:
        return jsonify({"ok": False,
                        "error": "ticket is not an open position owned by this agent"}), 403
    return jsonify({"ok": True, "data": mt5_bridge.close_position(ticket)})


# ------------------------------------------------------------ فیلتر اخبار
@app.route("/api/news")
def news_calendar():
    """تقویم اقتصادی با فیلتر تأثیر/ارز/بازه‌ی زمانی."""
    min_impact = request.args.get("impact", "Medium")
    hours_ahead = _qint("hours", 168)
    hours_back = _qint("back", 6)
    cur = request.args.get("currencies")
    currencies = [c.strip().upper() for c in cur.split(",")] if cur else None
    symbol = request.args.get("symbol")
    if symbol and not currencies:
        currencies = news.currencies_for(symbol.upper())
    # منبعِ تقویم: از پارامترِ درخواست (انتخاب‌گرِ تب) یا پیش‌فرضِ کانفیگِ فیلترِ اخبار
    source = request.args.get("source") or dispatch.load_config().get("news_source", "both")
    return jsonify({"ok": True, "data": news.calendar(
        min_impact=min_impact, currencies=currencies,
        hours_ahead=hours_ahead, hours_back=hours_back, source=source)})


@app.route("/api/news/scheduler")
def news_scheduler_status():
    return jsonify({"ok": True, "data": news_alerts.status()})


@app.route("/api/news/check")
def news_check():
    """آیا اکنون به‌خاطر اخبار پرتأثیرِ نزدیک، معامله‌ی نماد باید مسدود شود؟"""
    symbol = request.args.get("symbol", "BTC").upper()
    cfg = mt5_bridge.load_config()
    dcfg = dispatch.load_config()
    res = news.is_blocked(
        symbol,
        before_min=_qint("before", int(cfg.get("news_before_min", 30) or 30)),
        after_min=_qint("after", int(cfg.get("news_after_min", 30) or 30)),
        min_impact=request.args.get("impact", cfg.get("news_impact", "High")),
        source=request.args.get("source") or dcfg.get("news_source", "both"))
    return jsonify({"ok": True, "data": res})


# ------------------------------------------------------------ هوش مصنوعی (AI)
@app.route("/api/ai/config", methods=["GET"])
def ai_get_cfg():
    return jsonify({"ok": True, "data": {
        "config": ai_bridge.public_config(),
        "status": ai_bridge.status(),
    }})


@app.route("/api/ai/config", methods=["POST"])
def ai_set_cfg():
    body = _json_body()
    # کلید خالی نباید مقدار قبلی را پاک کند (در ماژول هم محافظت شده)
    if body.get("api_key") == "":
        body.pop("api_key", None)
    ai_bridge.save_config(body)
    return jsonify({"ok": True, "data": {
        "config": ai_bridge.public_config(),
        "status": ai_bridge.status(),
    }})


@app.route("/api/ai/models", methods=["POST"])
def ai_models():
    body = _json_body()
    res = ai_bridge.list_models(base_url=body.get("base_url"),
                                api_key=body.get("api_key") or None)
    return jsonify({"ok": res.get("ok", False), "data": res})


@app.route("/api/ai/test", methods=["POST"])
def ai_test():
    body = _json_body()
    res = ai_bridge.test_connection(base_url=body.get("base_url"),
                                    api_key=body.get("api_key") or None,
                                    model=body.get("model"))
    return jsonify({"ok": res.get("ok", False), "data": res})


@app.route("/api/ai/connect", methods=["POST"])
def ai_connect():
    body = _json_body()
    res = ai_bridge.connect(base_url=body.get("base_url"),
                            api_key=body.get("api_key") or None,
                            model=body.get("model"))
    return jsonify({"ok": res.get("ok", False), "data": res})


@app.route("/api/ai/disconnect", methods=["POST"])
def ai_disconnect():
    return jsonify({"ok": True, "data": ai_bridge.disconnect()})


def _ai_chat_context(symbol, tf):
    """اصلاح (AI-CTX-001): بستهٔ فشردهٔ «دادهٔ زندهٔ بازار» برای پیوست به پرسشِ آزاد.

    مدل‌های زبانی به اینترنت دسترسی ندارند؛ قبلاً پرسشِ کاربر («بازار را تحلیل کن»)
    خام ارسال می‌شد و مدل به‌درستی پاسخ می‌داد «دسترسی ندارم». اکنون خودِ برنامه
    دادهٔ لحظه‌ای (قیمت، اندیکاتورها، سطوح، نقشه، فاندامنتال، سنتیمنت، وضعیت بازار)
    را داخل پیام می‌گذارد تا مدل بدونِ نیاز به اینترنت تحلیل کند.
    """
    try:
        sym = (symbol or "BTC").strip() or "BTC"
        tf2 = tf if tf in VALID_TF else "1h"
        data, _internal, _broker = _signal_for(sym, tf2, with_ai=False)
    except Exception as e:  # noqa
        return None, str(e)
    tech = data.get("technical") or {}
    fund = data.get("fundamental") or {}
    sent = data.get("sentiment") or {}
    plan = data.get("plan") or {}
    mkt = data.get("market") or {}
    snap = {
        "pair": data.get("pair"), "symbol": data.get("symbol"),
        "timeframe": data.get("interval"), "price": data.get("price"),
        "generated_at": data.get("generated_at"),
        "data_source": data.get("data_source"),
        "market_state": {"open": mkt.get("open"), "asset_class": mkt.get("asset_class"),
                         "reason": mkt.get("reason_fa")},
        "internal_direction": data.get("direction"),
        "internal_scores": {
            "technical": round(float(tech.get("score", 0) or 0), 1),
            "fundamental": round(float(fund.get("score", 0) or 0), 1),
            "sentiment": round(float(sent.get("score", 0) or 0), 1),
            "total": data.get("total_score"), "confidence": data.get("confidence"),
        },
        "technical": {
            "rsi": tech.get("rsi"), "trend": tech.get("trend"), "atr": tech.get("atr"),
            "supports": (tech.get("supports") or [])[:4],
            "resistances": (tech.get("resistances") or [])[:4],
            "signals": [{"name": x.get("name"), "value": x.get("value"), "dir": x.get("dir")}
                        for x in (tech.get("signals") or [])][:14],
        },
        "trade_plan": {
            "direction": plan.get("direction"), "entry": plan.get("entry"),
            "stop_loss": plan.get("stop_loss"),
            "take_profits": [t.get("price") if isinstance(t, dict) else t
                             for t in (plan.get("take_profits") or [])][:3],
            "rr": plan.get("rr"), "note": plan.get("note"),
        },
        "fundamental": {
            "available": fund.get("available"), "market_cap": fund.get("market_cap"),
            "signals": [{"name": x.get("name"), "value": x.get("value"), "dir": x.get("dir")}
                        for x in (fund.get("signals") or [])][:10],
        },
        "sentiment": {"title": sent.get("title"), "value": sent.get("value"),
                      "classification": sent.get("classification"), "kind": sent.get("kind")},
    }
    return snap, None


_AI_CTX_PREFIX = ("دادهٔ زنده و لحظه‌ایِ بازار که همین حالا «برنامه» برایت فراهم کرده است "
                  "(JSON):" + chr(10))
_AI_CTX_SUFFIX = (chr(10) + chr(10)
                  + "یادآوریِ مهم: برای این تحلیل به اینترنت یا دادهٔ بیرونی نیاز نداری؛ "
                  + "همهٔ اعدادِ لازم در JSON بالا آمده است. هرگز ننویس «به اینترنت/دادهٔ "
                  + "زنده دسترسی ندارم»؛ تحلیل را بر پایهٔ همین داده‌ها و دانشِ عمومی‌ات "
                  + "انجام بده و اگر دادهٔ دیگری لازم داری، دقیق نام ببر."
                  + chr(10) + chr(10) + "پرسشِ کاربر:" + chr(10))


def _ai_attach_context(body, prompt):
    """در صورتِ روشن‌بودنِ attach_market، دادهٔ زنده را به پرسش می‌چسباند."""
    attach = body.get("attach_market", True)
    if isinstance(attach, str):
        attach = attach.strip().lower() not in ("", "0", "false", "no", "off")
    if not attach:
        return prompt, {"market_attached": False}
    snap, err = _ai_chat_context(body.get("symbol"), body.get("tf"))
    if snap is None:
        return prompt, {"market_attached": False, "market_error": err}
    full = _AI_CTX_PREFIX + json.dumps(snap, ensure_ascii=False) + _AI_CTX_SUFFIX + prompt
    return full, {"market_attached": True, "market_symbol": snap.get("symbol"),
                  "market_tf": snap.get("timeframe"), "market_price": snap.get("price")}


@app.route("/api/ai/ask", methods=["POST"])
def ai_ask():
    body = _json_body()
    prompt = (body.get("prompt") or "").strip()
    if not prompt:
        return jsonify({"ok": False, "error": "متن پرسش خالی است"}), 400
    if len(prompt) > 12_000:   # اصلاح (RUNTIME-007): سقفِ طولِ پرسش
        return jsonify({"ok": False, "error": "متن پرسش بیش از ۱۲٬۰۰۰ نویسه است."}), 413
    # اصلاح (AI-CTX-001): پیوستِ دادهٔ زندهٔ بازار تا مدل بدونِ اینترنت تحلیل کند
    prompt, _ctx_meta = _ai_attach_context(body, prompt)
    res = ai_bridge.chat(prompt, model=body.get("model"))
    if isinstance(res, dict):
        res.update(_ctx_meta)
    # همیشه HTTP 200 با ok=false در بدنه (هم‌سان با سایر مسیرهای AI) تا پیامِ خطای
    # واقعیِ مدل در رابط کاربری نمایش داده شود، نه یک خطای عمومیِ سرور.
    return jsonify({"ok": res.get("ok", False), "data": res})


@app.route("/api/ai/ask_stream", methods=["POST"])
def ai_ask_stream():
    """نسخهٔ جریانیِ پرسش (SSE): پاسخِ مدل تکه‌تکه و بلافاصله به مرورگر ارسال می‌شود
    تا کاربر به‌جای انتظار برای کلِ پاسخ، کلمات را همان لحظه ببیند."""
    body = _json_body()
    prompt = (body.get("prompt") or "").strip()
    if not prompt:
        return jsonify({"ok": False, "error": "متن پرسش خالی است"}), 400
    if len(prompt) > 12_000:   # اصلاح (RUNTIME-007): سقفِ طولِ پرسش
        return jsonify({"ok": False, "error": "متن پرسش بیش از ۱۲٬۰۰۰ نویسه است."}), 413
    model = body.get("model")
    # اصلاح (AI-CTX-001): پیوستِ دادهٔ زندهٔ بازار در مسیرِ جریانی هم
    prompt, _ctx_meta = _ai_attach_context(body, prompt)

    def _gen():
        yield "data: " + json.dumps({"meta": _ctx_meta}, ensure_ascii=False) + "\n\n"
        for ev in ai_bridge.chat_stream(prompt, model=model):
            yield "data: " + json.dumps(ev, ensure_ascii=False) + "\n\n"

    return Response(stream_with_context(_gen()), mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache",
                             "X-Accel-Buffering": "no",  # جلوگیری از بافرِ پراکسی
                             "Connection": "keep-alive"})


@app.route("/api/ai/logs", methods=["GET"])
def ai_logs():
    limit = _qint("limit", 200)
    return jsonify({"ok": True, "data": {"log": ai_bridge.read_log(limit)}})


@app.route("/api/ai/logs", methods=["DELETE"])
def ai_logs_clear():
    ai_bridge.clear_log()
    return jsonify({"ok": True})


# ---------------------------------------------- روشِ ارسالِ سیگنال به متاتریدر ۵
@app.route("/api/dispatch/config", methods=["GET"])
def dispatch_get_cfg():
    acfg = ai_bridge.load_config()
    ai_ready = bool(acfg.get("enabled") and acfg.get("api_key")
                    and acfg.get("base_url") and acfg.get("model"))
    return jsonify({"ok": True, "data": {
        "config": dispatch.load_config(),
        "robot": robots.load_config(),
        "schedule": schedule_hours.load_config(),
        "ai_enabled": bool(acfg.get("enabled")),
        "ai_ready": ai_ready,
        "mt5": mt5_bridge.status(),
    }})


@app.route("/api/dispatch/config", methods=["POST"])
def dispatch_set_cfg():
    body = _json_body()
    # زیرشاخهٔ robot → به تنظیماتِ ربات‌ها می‌رود (روشِ صدورِ مجوز برای سیگنال‌های ربات)
    if isinstance(body.get("robot"), dict):
        robots.save_config(body.pop("robot"))
    # زیرشاخهٔ schedule → روشن/خاموش‌کردنِ سریعِ زمان‌بندی
    if isinstance(body.get("schedule"), dict):
        schedule_hours.save_config(body.pop("schedule"))
    saved = dispatch.save_config(body)
    return jsonify({"ok": True, "data": {"config": saved,
                                         "robot": robots.load_config(),
                                         "schedule": schedule_hours.load_config()}})


# کشِ کوتاهِ تصمیمِ AI برای نمایشِ زنده (تا API هوش مصنوعی بیش از حد صدا زده نشود)
_ai_live_cache = {}
_AI_LIVE_TTL = 90.0


def _ai_live_for(internal, tf, data):
    import time as _t
    ck = f"{internal}:{tf}"
    hit = _ai_live_cache.get(ck)
    if hit and (_t.time() - hit[0]) < _AI_LIVE_TTL:
        return hit[1]
    aev = _ai_eval_for_signal(data)
    if aev.get("available"):
        out = {"available": True, "direction": aev.get("direction"),
               "score": round(abs(float(aev.get("score", 0) or 0)), 1),
               "raw_score": aev.get("score"), "summary": aev.get("summary")}
    else:
        out = {"available": False, "error": aev.get("error")}
    _ai_live_cache[ck] = (_t.time(), out)
    return out


@app.route("/api/dispatch/live")
def dispatch_live():
    """تصمیم/تحلیلِ زندهٔ تحلیل‌گرِ داخلی و هوش مصنوعی روی همهٔ نمادهای Market Watch.

    اگر متاتریدر متصل نباشد، از فهرستِ نمادهای داخلیِ برنامه استفاده می‌شود.
    پارامترها: tf (تایم‌فریم)، ai=0/1 (شاملِ تحلیلِ هوش مصنوعی).
    """
    tf = request.args.get("tf", "1h")
    if tf not in VALID_TF:
        tf = "1h"
    want_ai = request.args.get("ai", "1") not in ("0", "false", "no")
    dcfg = dispatch.load_config()
    acfg = ai_bridge.load_config()
    ai_on = bool(want_ai and acfg.get("enabled") and acfg.get("api_key")
                 and acfg.get("base_url") and acfg.get("model"))

    # فهرستِ نمادها: Market Watchِ متاتریدر، وگرنه نمادهای داخلی
    mw = mt5_bridge.market_watch()
    items = []
    if mw.get("connected") and mw.get("symbols"):
        for s in mw["symbols"]:
            internal = s.get("internal") or (_resolve_symbol(s["name"])[0] or "")
            items.append({"symbol": s["name"], "internal": internal})
    else:
        for k in sym.SYMBOLS:
            items.append({"symbol": k, "internal": k})

    rows = []
    for it in items:
        internal = it["internal"]
        row = {"symbol": it["symbol"], "internal_symbol": internal,
               "internal": None, "ai": None, "decision": None}
        if not internal:
            row["error"] = "نمادِ صرفاً متاتریدری (بدونِ تحلیلِ داخلی)"
            rows.append(row)
            continue
        try:
            d, _i, _b = _signal_for(it["symbol"], tf, with_ai=False)   # MT5 متصل → دادهٔ متاتریدر
            try:
                isc = abs(float(d.get("internal_score", d.get("total_score", 0)) or 0))
            except Exception:  # noqa
                isc = 0.0
            row["internal"] = {"direction": d.get("direction"), "score": round(isc, 1),
                               "raw_score": d.get("internal_score"),
                               "price": d.get("price"), "confidence": d.get("confidence")}
            row["_data"] = d
        except Exception as e:  # noqa
            row["internal"] = {"error": str(e)}
        rows.append(row)

    # تحلیلِ هوش مصنوعی به‌صورتِ موازی (با کشِ کوتاه)
    if ai_on:
        try:
            from concurrent.futures import ThreadPoolExecutor
            targets = [r for r in rows if r.get("_data") is not None]

            def _fill(r):
                r["ai"] = _ai_live_for(r["internal_symbol"], tf, r["_data"])

            with ThreadPoolExecutor(max_workers=6) as ex:
                list(ex.map(_fill, targets))
        except Exception:  # noqa
            pass

    # تصمیمِ نهاییِ ارسال طبقِ روشِ انتخابی
    for r in rows:
        d = r.pop("_data", None)
        if d is None:
            continue
        # از همان نتیجهٔ AI که برای ستونِ نمایش محاسبه شد استفاده کن تا فراخوانِ
        # تکراریِ API انجام نشود و «تصمیم» با ستونِ AI هم‌خوان بماند.
        ai_e = r.get("ai")
        if ai_e is None:
            ai_e = {"available": False, "error": "AI off"}
        try:
            dec = _decide_program_signal(d, dcfg, ai_eval=ai_e)
            r["decision"] = {"source": dec["source"], "approved": dec["approved"],
                             "direction": dec["direction"]}
        except Exception:  # noqa
            r["decision"] = None

    return jsonify({"ok": True, "data": {
        "tf": tf, "ai_on": ai_on, "source": dcfg.get("program_source"),
        "program_enabled": dcfg.get("program_enabled"),
        "connected": bool(mw.get("connected")),
        "count": len(rows), "rows": rows,
    }})


# ======================= ساعاتِ کارِ سرور (زمان‌بندیِ فعال/غیرفعال) =======================
def _program_gate():
    """آیا برنامه اکنون (بر اساسِ ساعتِ سرورِ کارگزار و زمان‌بندی) اجازهٔ معامله دارد؟

    → (active: bool, info: dict). اگر زمان‌بندی خاموش باشد یا ساعتِ سرور در دسترس نباشد،
    fail-open است (active=True) تا کارِ برنامه بی‌جهت متوقف نشود.
    """
    scfg = schedule_hours.load_config()
    if not scfg.get("enabled"):
        return True, {"enabled": False, "active": True,
                      "reason": "زمان‌بندی غیرفعال است."}
    st = mt5_bridge.server_time()
    # اصلاح (OPUS5-A5 — بالا): وقتی کاربر زمان‌بندی را «روشن» کرده، نبودِ ساعتِ
    # معتبرِ زنده دیگر fail-open نیست؛ معامله تا معلوم‌شدنِ ساعت متوقف می‌شود.
    if not st.get("ok") or st.get("live") is False:
        return False, {"enabled": True, "active": False, "unknown": True,
                       "reason": ("زمانِ زنده/معتبرِ سرورِ کارگزار در دسترس نیست؛ "
                                  "طبقِ اصلِ احتیاط، ارسال متوقف شد."),
                       "server_error": st.get("error"), "server_live": st.get("live")}
    hhmmss = st.get("broker_time", "00:00:00")
    try:
        h, m = int(hhmmss[0:2]), int(hhmmss[3:5])
        minute = h * 60 + m
    except Exception:  # noqa
        return False, {"enabled": True, "active": False, "unknown": True,
                       "reason": "قالبِ زمانِ سرور نامعتبر است؛ ارسال متوقف شد."}
    # OP5-MH-05: کلیدِ درست broker_weekday است؛ نبودنش نباید فیلترِ «روزهای مجاز»
    # را بی‌صدا دور بزند (قبلاً با کلیدِ نادرستِ broker_weekday_idx همیشه None
    # می‌شد و روزهای هفته نادیده گرفته می‌شد).
    _wd = st.get("broker_weekday")
    if _wd is None:
        _wd = st.get("broker_weekday_idx")
    if _wd is None:
        return False, {"enabled": True, "active": False, "unknown": True,
                       "reason": ("روزِ هفتهٔ سرورِ کارگزار در دسترس نیست؛ طبقِ اصلِ "
                                  "احتیاط، ارسال متوقف شد."),
                       "server_error": st.get("error"), "server_live": st.get("live"),
                       "server": st}
    try:
        _wd = int(_wd) % 7
    except (TypeError, ValueError):
        return False, {"enabled": True, "active": False, "unknown": True,
                       "reason": "روزِ هفتهٔ سرور نامعتبر است؛ ارسال متوقف شد.",
                       "server_live": st.get("live"), "server": st}
    # OP5-SCH-TZ: اگر کاربر منطقهٔ زمانیِ زمان‌بندی را چیزی جز «ساعتِ بروکر» گذاشته،
    # بازه‌ها بر همان مبنای محلی سنجیده می‌شوند (قبلاً این کلید نادیده می‌ماند).
    _tz = str(scfg.get("timezone") or "broker").strip()
    if _tz and _tz != "broker":
        try:
            import datetime as _dtc
            _off = float(st.get("offset_hours") or 0.0)
            _utc = _dtc.datetime.fromtimestamp(float(st.get("broker_epoch")) - _off * 3600.0,
                                               tz=_dtc.timezone.utc)
            minute, _wd_tz = schedule_hours.minute_of_day(_utc, _tz)
            _wd = int(_wd_tz)
            hhmmss = _utc.astimezone(__import__("zoneinfo").ZoneInfo(_tz)).strftime("%H:%M:%S")
        except Exception as _e:  # noqa
            return False, {"enabled": True, "active": False, "unknown": True,
                           "reason": (f"محاسبهٔ زمان در منطقهٔ «{_tz}» ناموفق بود؛ "
                                      "طبقِ اصلِ احتیاط ارسال متوقف شد."),
                           "server_error": str(_e), "server_live": st.get("live"),
                           "server": st}
    res = schedule_hours.is_active(minute, scfg, weekday=_wd)
    info = {"enabled": True, "active": res["active"], "matched": res.get("matched"),
            "reason": res.get("reason"), "broker_time": hhmmss,
            "broker_date": st.get("broker_date"),
            "broker_weekday": st.get("broker_weekday"),
            "time_basis": st.get("time_basis", "broker"),   # OP5-MH-04
            "server_live": st.get("live"), "server": st}
    return res["active"], info


@app.route("/api/server/time")
def server_time_api():
    """ساعتِ زندهٔ سرورِ کارگزار + وضعیتِ زمان‌بندیِ برنامه."""
    st = mt5_bridge.server_time()
    active, sched = _program_gate()
    scfg = schedule_hours.load_config()
    return jsonify({"ok": True, "data": {
        "server": st,
        "schedule": scfg,
        "program_active": active,
        "state": sched,
    }})


@app.route("/api/schedule/config", methods=["GET"])
def schedule_get_cfg():
    active, sched = _program_gate()
    return jsonify({"ok": True, "data": {"config": schedule_hours.load_config(),
                                         "program_active": active, "state": sched}})


@app.route("/api/schedule/config", methods=["POST"])
def schedule_set_cfg():
    body = _json_body()
    saved = schedule_hours.save_config(body)
    active, sched = _program_gate()
    return jsonify({"ok": True, "data": {"config": saved,
                                         "program_active": active, "state": sched}})


# ============================ سیگنال‌های ورودیِ ربات‌ها ============================
def _ai_eval_for_signal(data):
    """امتیاز/جهتِ هوش مصنوعی را برای یک سیگنالِ ساخته‌شده به‌صورتِ مستقل می‌گیرد.

    مستقل از تنظیمِ use_in_signal است تا فیلترِ رباتْ همیشه بتواند نظرِ AI را بپرسد.
    خروجی: {available, direction, score, summary, error?}.
    """
    try:
        acfg = ai_bridge.load_config()
    except Exception:  # noqa
        return {"available": False, "error": "خطا در بارگذاری تنظیمات هوش مصنوعی."}
    if not acfg.get("enabled"):
        return {"available": False, "error": "هوش مصنوعی فعال نیست (تب 🤖 هوش مصنوعی)."}
    if not (acfg.get("api_key") and acfg.get("base_url") and acfg.get("model")):
        return {"available": False, "error": "پیکربندیِ هوش مصنوعی کامل نیست."}
    tech = data.get("technical", {}) or {}
    fund = data.get("fundamental", {}) or {}
    sent = data.get("sentiment", {}) or {}
    snapshot = {
        "symbol": data.get("symbol"), "timeframe": data.get("interval"),
        "price": data.get("price"),
        "internal_scores": {
            "technical": round(float(tech.get("score", 0) or 0), 1),
            "fundamental": round(float(fund.get("score", 0) or 0), 1),
            "sentiment": round(float(sent.get("score", 0) or 0), 1),
        },
        "technical": {
            "rsi": tech.get("rsi"), "trend": tech.get("trend"), "atr": tech.get("atr"),
            "supports": tech.get("supports"), "resistances": tech.get("resistances"),
            "signals": [{"name": s.get("name"), "value": s.get("value"), "dir": s.get("dir")}
                        for s in (tech.get("signals") or [])][:14],
        },
        "fundamental": {
            "available": fund.get("available"), "market_cap": fund.get("market_cap"),
            "signals": [{"name": s.get("name"), "value": s.get("value"), "dir": s.get("dir")}
                        for s in (fund.get("signals") or [])][:10],
        },
        "sentiment": {"title": sent.get("title"), "value": sent.get("value"),
                      "classification": sent.get("classification"), "kind": sent.get("kind")},
    }
    res = ai_bridge.analyze_market(snapshot)
    if not res.get("ok"):
        return {"available": False, "error": res.get("error", "تحلیلِ هوش مصنوعی ناموفق بود.")}
    return {
        "available": True,
        "direction": res.get("direction", "NEUTRAL"),
        "score": round(float(res.get("overall_score", 0) or 0), 1),
        "confidence": res.get("confidence"),
        "summary": res.get("summary", ""),
        "model": res.get("model"),
    }


def _decide_program_signal(data, dcfg=None, ai_eval=None):
    """تصمیمِ ارسال برای یک سیگنالِ تولیدیِ برنامه، بر اساسِ روشِ انتخابیِ کاربر.

    روش‌ها: internal (فقط داخلی) · ai (فقط هوش مصنوعی) · both (رأی‌گیری؛ هر دو).
    → dict شاملِ: source, approved, direction, internal{dir,score,ok}, ai{...}, reasons[].
    این تابع فقط «تصمیم» می‌گیرد؛ فیلترِ اخبار/زمان‌بندی جداگانه اعمال می‌شود.
    ai_eval: در صورتِ ارائه، به‌جای فراخوانِ دوبارهٔ API از همین نتیجهٔ ازپیش‌محاسبه‌شده
             استفاده می‌شود (برای جلوگیری از فراخوانِ تکراری/هزینه در نمایشِ زنده).
    """
    if dcfg is None:
        dcfg = dispatch.load_config()
    source = dcfg.get("program_source", "internal")
    if source not in dispatch.VALID_SOURCES:
        source = "internal"
    min_i = float(dcfg.get("program_min_internal", 15) or 0)
    min_a = float(dcfg.get("program_min_ai", 15) or 0)

    idir = data.get("direction")
    try:
        iscore = abs(float(data.get("internal_score", data.get("total_score", 0)) or 0))
    except Exception:  # noqa
        iscore = 0.0
    internal_ok = idir in ("LONG", "SHORT") and iscore >= min_i

    out = {"source": source, "approved": False, "direction": "NEUTRAL", "reasons": [],
           "internal": {"direction": idir, "score": round(iscore, 1), "ok": internal_ok},
           "ai": None}

    aidir, ai_ok = None, None
    if source in ("ai", "both"):
        aev = ai_eval if ai_eval is not None else _ai_eval_for_signal(data)
        if not aev.get("available"):
            out["ai"] = {"available": False, "error": aev.get("error")}
        else:
            aidir = aev.get("direction")
            try:
                ascore = abs(float(aev.get("score", 0) or 0))
            except Exception:  # noqa
                ascore = 0.0
            ai_ok = aidir in ("LONG", "SHORT") and ascore >= min_a
            out["ai"] = {"available": True, "direction": aidir, "score": round(ascore, 1),
                         "ok": ai_ok, "summary": aev.get("summary"), "model": aev.get("model")}

    if source == "internal":
        out["approved"] = bool(internal_ok)
        out["direction"] = idir if internal_ok else "NEUTRAL"
        out["reasons"].append(f"تحلیل‌گر داخلی: {idir} · قدرت {round(iscore,1)} "
                              f"(حدِ لازم {min_i}) → {'تأیید' if internal_ok else 'رد'}")
    elif source == "ai":
        out["approved"] = bool(ai_ok)
        out["direction"] = aidir if ai_ok else "NEUTRAL"
        if out["ai"] and out["ai"].get("available"):
            out["reasons"].append(f"هوش مصنوعی: {aidir} · قدرت {out['ai'].get('score')} "
                                  f"(حدِ لازم {min_a}) → {'تأیید' if ai_ok else 'رد'}")
        else:
            out["reasons"].append("هوش مصنوعی در دسترس نیست: "
                                  + str((out["ai"] or {}).get("error", "نامشخص")))
    else:  # both → رأی‌گیری
        both_ok = bool(internal_ok and ai_ok and idir == aidir and idir in ("LONG", "SHORT"))
        out["approved"] = both_ok
        out["direction"] = idir if both_ok else "NEUTRAL"
        if not internal_ok:
            out["reasons"].append(f"تحلیل‌گر داخلی تأیید نکرد ({idir} · {round(iscore,1)}).")
        if out["ai"] and not out["ai"].get("available"):
            out["reasons"].append("هوش مصنوعی در دسترس نیست: "
                                  + str(out["ai"].get("error", "نامشخص")))
        elif ai_ok is False:
            out["reasons"].append(f"هوش مصنوعی تأیید نکرد ({aidir}).")
        if internal_ok and ai_ok and idir != aidir:
            out["reasons"].append(f"جهت‌ها هم‌سو نیستند (داخلی {idir} ≠ هوش مصنوعی {aidir}).")
        if both_ok:
            out["reasons"].append(f"هر دو تأیید کردند: {idir}.")
    return out


# آخرین جهتِ ارسال‌شده برای هر (نماد:تایم‌فریم) تا از ارسالِ تکراری جلوگیری شود
_last_dispatch_dir = {}


def _eval_news_gate(symbol, dcfg, src_label, log_cat="mt5_out"):
    """فیلترِ اخبار را ارزیابی می‌کند و «شکستِ خاموش» را آشکار می‌سازد.

    اگر تقویمِ اخبار در دسترس نباشد (خطای شبکه/محدودیتِ نرخ) یا استثنایی رخ دهد،
    فیلتر عملاً غیرفعال می‌شود؛ برخلافِ قبل، این وضعیت دیگر بی‌صدا نیست: یک هشدار
    در لاگِ سرور ثبت می‌شود. اگر news_fail_closed روشن باشد، معامله در این حالت
    «محتاطانه مسدود» می‌شود.

    → {"blocked", "inoperative", "event", "reason", "raw"}
    """
    if not dcfg.get("news_filter_enabled", True):
        return {"blocked": False, "inoperative": False, "event": None, "reason": None, "raw": {"blocked": False}}
    fail_closed = bool(dcfg.get("news_fail_closed", True))   # OP5-CORE-17: پیش‌فرضِ محافظه‌کارانه
    tail = ("معامله محتاطانه مسدود شد (fail-closed)." if fail_closed
            else "معامله بدونِ محافظتِ اخبار ادامه یافت (fail-open).")
    try:
        nb = news.is_blocked(
            symbol,
            before_min=int(dcfg.get("news_before_min", 30)),
            after_min=int(dcfg.get("news_after_min", 30)),
            min_impact=dcfg.get("news_impact", "High"),
            source=dcfg.get("news_source", "both"))
    except Exception as e:  # noqa
        server_log.log("warn", log_cat,
                       f"فیلترِ اخبار موقتاً کار نکرد (خطا) — {symbol}",
                       f"روش={src_label} · خطا={e} · {tail}")
        return {"blocked": fail_closed, "inoperative": True, "event": None,
                "reason": ("تقویمِ اخبار در دسترس نیست و «مسدودسازیِ محتاطانه» روشن است."
                           if fail_closed else None),
                "raw": {"blocked": fail_closed, "inoperative": True, "error": str(e)}}
    if nb.get("blocked"):
        return {"blocked": True, "inoperative": False,
                "event": nb.get("event", {}) or {}, "reason": None, "raw": nb}
    if nb.get("error"):  # تقویم در دسترس نبود → فیلتر عملاً غیرفعال بوده است
        server_log.log("warn", log_cat,
                       f"فیلترِ اخبار موقتاً در دسترس نبود — {symbol}",
                       f"روش={src_label} · دلیل={nb.get('error')} · {tail}")
        nb = dict(nb); nb["inoperative"] = True
        if fail_closed:
            nb["blocked"] = True
        return {"blocked": fail_closed, "inoperative": True, "event": None,
                "reason": ("تقویمِ اخبار در دسترس نیست و «مسدودسازیِ محتاطانه» روشن است."
                           if fail_closed else None), "raw": nb}
    return {"blocked": False, "inoperative": False, "event": None, "reason": None, "raw": nb}


def _log_schedule_unknown(info, src_label, log_cat="mt5_out"):
    """اگر ساعتِ سرور نامشخص باشد و فیلترِ زمان‌بندی عملاً اعمال نشده باشد، هشدار بده."""
    if info and info.get("unknown"):
        server_log.log("warn", log_cat,
                       "فیلترِ زمان‌بندی اعمال نشد: ساعتِ سرورِ کارگزار در دسترس نیست",
                       f"روش={src_label} · {info.get('reason','')}")


import threading as _threading  # اصلاح (CONC-004)
_auto_dispatch_lock = _threading.RLock()


# اصلاح (PROG-GUARD-001): ارسالِ خودکارِ برنامه فقط حافظهٔ «آخرین جهت» را داشت؛
# با تغییرِ تایم‌فریم/نامِ نماد/ری‌استارت، معاملهٔ هم‌جهتِ تکراری باز می‌شد و با
# چرخشِ جهتِ سیگنال، معاملهٔ مخالف کنارِ پوزیشنِ بازِ قبلی می‌نشست (هجِ ناخواسته).
# این گارد وضعیتِ «واقعیِ» پوزیشن‌های باز را از متاتریدر می‌پرسد.
_prog_guard_last_log = {}


def _program_position_guard(send_sym, direction, dcfg):
    """→ (blocked, reason, opposites) بر اساسِ پوزیشن‌های بازِ همین ربات روی نمادِ بروکر.

    اصلاح (REVERSE-001): پوزیشن‌های مخالف برگردانده می‌شوند تا دستورالعملِ کاربر
    («با سیگنالِ مخالف، پوزیشنِ قبلی بسته شود») قابلِ اجرا باشد.
    """
    try:
        pres = mt5_bridge.positions(magic_only=True)
        if not pres.get("ok"):
            # اصلاح (OPUS5-A4): اگر MT5 واقعاً متصل است ولی خواندنِ پوزیشن‌ها شکست
            # خورده، دقیقاً در لحظهٔ عدمِ قطعیت نباید سفارش برود (fail-closed).
            if mt5_bridge.MT5_AVAILABLE and mt5_bridge._conn.get("connected"):
                return True, (f"خواندنِ پوزیشن‌های MT5 ناموفق بود "
                              f"({pres.get('error')})؛ تا رفعِ ابهام، ارسال متوقف شد."), []
            return False, "", []      # بدونِ MT5 (شبیه‌سازی)، گارد موضوعیت ندارد
        rs = mt5_bridge.resolve_symbol(send_sym)
        bsym = (rs.get("broker") or send_sym)
        same, opp = [], []
        for p in (pres.get("positions") or []):
            if p.get("symbol") != bsym:
                continue
            (same if p.get("type") == direction else opp).append(p)
        if same and dcfg.get("program_block_duplicate_open", True):
            p0 = same[0]
            return True, (f"پوزیشنِ بازِ هم‌جهت ({direction}) روی {bsym} موجود است "
                          f"(تیکت {p0.get('ticket')}، حجم {p0.get('volume')})؛ از ارسالِ تکراری جلوگیری شد."), opp
        if opp and dcfg.get("program_block_opposite_open", True):
            act = dcfg.get("program_opposite_action", "reverse")
            if act == "block":
                p0 = opp[0]
                return True, (f"پوزیشنِ بازِ مخالف روی {bsym} موجود است "
                              f"(تیکت {p0.get('ticket')})؛ طبقِ تنظیم، سیگنالِ مخالف رد شد (هج ممنوع)."), opp
            # close / reverse → مسدود نیست؛ caller پوزیشن‌های مخالف را می‌بندد
            return False, "", opp
        return False, "", []
    except Exception:  # noqa
        return False, "", []


def _program_auto_dispatch(data, internal, tf, broker=None):
    """اصلاح (CONC-004): دو GET همزمانِ /api/signal با threaded=True می‌توانستند
    check و write روی _last_dispatch_dir را جدا از هم اجرا و سفارشِ تکراری بفرستند."""
    with _auto_dispatch_lock:
        return _program_auto_dispatch_inner(data, internal, tf, broker)


def _program_auto_dispatch_inner(data, internal, tf, broker=None):
    """ارسالِ خودکارِ سیگنالِ تولیدیِ برنامه به متاتریدر طبقِ روشِ انتخابی + فیلترها.

    اصلاح (MT5-SEND-003): مبنای ارسال، نامِ نمادِ کارگزار در متاتریدر (با پسوند)
    است — همان نمادی که کاربر انتخاب کرده — نه نامِ داخلی؛ تا اگر کارگزار چند
    نمادِ هم‌خانواده دارد (BTCUSD و BITCOIN و…) سفارش روی نمادِ دیگری نرود.
    """
    dcfg = dispatch.load_config()
    if not dcfg.get("program_enabled"):
        return
    send_sym = ((broker or internal) or "").strip()
    if not send_sym:
        return
    decision = _decide_program_signal(data, dcfg)
    direction = decision.get("direction")
    if not decision.get("approved") or direction not in ("LONG", "SHORT"):
        return

    key = f"{send_sym}:{tf}"
    if _last_dispatch_dir.get(key) == direction:
        return  # همان جهت قبلاً ارسال شده

    src_lbl = dispatch.source_label(decision["source"])

    # --- فیلترِ اخبار (شکستِ خاموش آشکار می‌شود؛ در صورتِ روشن‌بودنِ fail-closed مسدود) ---
    ng = _eval_news_gate(send_sym, dcfg, src_lbl, "mt5_out")
    if ng["blocked"]:
        evn = ng.get("event") or {}
        server_log.log("warn", "mt5_out",
                       f"ارسالِ خودکار مسدود شد (فیلتر اخبار): {send_sym} {direction}",
                       f"روش={src_lbl} · رویداد={evn.get('title','')} ({evn.get('country','')})"
                       + (f" · {ng['reason']}" if ng.get("reason") else ""))
        return

    # --- فیلترِ زمان‌بندیِ ساعاتِ کارِ سرور ---
    if dcfg.get("schedule_filter_enabled", True):
        active, info = _program_gate()
        _log_schedule_unknown(info, src_lbl, "mt5_out")
        if info.get("unknown") and dcfg.get("schedule_fail_closed", False):
            server_log.log("warn", "mt5_out",
                           f"ارسالِ خودکار مسدود شد (زمان‌بندیِ نامشخص، محتاطانه): {send_sym} {direction}",
                           f"روش={src_lbl} · ساعتِ سرور در دسترس نیست")
            return
        if not active:
            server_log.log("warn", "mt5_out",
                           f"ارسالِ خودکار مسدود شد (زمان‌بندی): {send_sym} {direction}",
                           f"روش={src_lbl} · {info.get('reason','خارج از بازهٔ کاری')} "
                           f"(ساعتِ سرور {info.get('broker_time','')})")
            return

    # --- اصلاح (PROG-GUARD-001 + REVERSE-001): گارد و دستورالعملِ پوزیشن‌های باز ---
    _blocked, _greason, _opps = _program_position_guard(send_sym, direction, dcfg)
    if _blocked:
        _gkey = f"{send_sym}:{tf}:{direction}"
        if _prog_guard_last_log.get(_gkey) != _greason:   # بدونِ اسپمِ لاگ در هر چرخه
            _prog_guard_last_log[_gkey] = _greason
            server_log.log("info", "mt5_out",
                           f"ارسالِ خودکار مسدود شد (گاردِ پوزیشن): {send_sym} {direction}",
                           f"روش={src_lbl} · {_greason}")
        return
    _prog_guard_last_log.pop(f"{send_sym}:{tf}:{direction}", None)
    if _opps:
        # دستورالعملِ کاربر: با سیگنالِ مخالف، پوزیشن(های) قبلی بسته شوند
        _act = dcfg.get("program_opposite_action", "reverse")
        _closed, _errs = [], []
        for _p in _opps:
            try:
                _r = mt5_bridge.close_position(_p.get("ticket"))
                (_closed if _r.get("ok") else _errs).append(_p.get("ticket"))
            except Exception as _e:  # noqa
                _errs.append(f"{_p.get('ticket')}:{_e}")
        server_log.log("success" if not _errs else "warn", "mt5_out",
                       f"سیگنالِ مخالفِ {direction} → بستنِ پوزیشن(های) مخالف روی {send_sym}",
                       f"بسته‌شده: {_closed or '—'}"
                       + (f" · ناموفق: {_errs}" if _errs else "")
                       + (" · طبقِ تنظیم، معاملهٔ جدید باز نمی‌شود (close)" if _act == "close" else
                          " · اکنون معاملهٔ جدیدِ معکوس باز می‌شود (reverse)"))
        if _errs:
            return   # تا وقتی بستن کامل نشده، معاملهٔ معکوس باز نشود (ضدِ هج)
        # اصلاح (OPUS5-A18): ok گرفتن از close کافی نیست؛ با read-after-write تا
        # ۵ ثانیه تأیید می‌کنیم هیچ پوزیشنِ مخالفی روی نماد نمانده است.
        _deadline = time.monotonic() + 5.0
        while time.monotonic() < _deadline:
            _chk = mt5_bridge.positions(magic_only=True)
            if not _chk.get("ok"):
                server_log.log("error", "mt5_out",
                               "تأییدِ بستنِ مخالف ناممکن شد؛ معکوس لغو شد", send_sym)
                return
            _rs2 = mt5_bridge.resolve_symbol(send_sym)
            _bs2 = _rs2.get("broker") or send_sym
            _left = [p for p in (_chk.get("positions") or [])
                     if p.get("symbol") == _bs2 and p.get("type") != direction]
            if not _left:
                break
            time.sleep(0.1)
        else:
            server_log.log("warn", "mt5_out",
                           "پوزیشنِ مخالف هنوز باز است؛ معاملهٔ معکوس ارسال نشد", send_sym)
            return
        if _act == "close":
            _last_dispatch_dir[key] = direction   # از تکرارِ «بستن» در هر چرخه جلوگیری شود
            return

    # --- نقشهٔ معامله برای جهتِ تصمیم (اگر با جهتِ داخلی فرق دارد، از نو ساخته می‌شود) ---
    plan = data.get("plan", {})
    if direction != data.get("direction"):
        try:
            tech = data["technical"]
            plan = engine.build_trade_plan(
                direction, data["price"], data["atr"],
                tech["supports"], tech["resistances"],
                abs(data["total_score"]), engine._dec(data["price"]),
                fib=tech.get("fibonacci"),
                extra_sup=tech.get("conf_supports"), extra_res=tech.get("conf_resistances"))
        except Exception:  # noqa
            plan = data.get("plan", {})

    try:
        # فیلترِ اخبار همین‌جا (بالاتر) اعمال شد؛ در send_order دوباره بررسی نشود.
        res = mt5_bridge.send_order(send_sym, direction, plan, skip_news_filter=True)
        ok = res.get("ok")
        # اصلاح (DISP-TRUTH-002): مسیرِ خودکار هرگز dry_run نمی‌خواهد؛ پس اگر نتیجه
        # dry_run/simulated بود یعنی MT5 واقعاً در دسترس نبود و «هیچ معامله‌ای باز
        # نشده است». قبلاً این حالت با عنوانِ موفق لاگ می‌شد و جهت هم ثبت می‌شد؛
        # کاربر گمان می‌کرد معامله ارسال شده در حالی که در متاتریدر خبری نبود.
        simulated = bool(res.get("simulated") or res.get("dry_run"))
        # اصلاح (APP-005): جهت فقط در ارسالِ واقعیِ «موفق» ثبت می‌شود تا در صورتِ
        # شکست (requote/قطعی و…)، چرخهٔ بعدی بتواند دوباره تلاش کند.
        if ok and not simulated:
            _last_dispatch_dir[key] = direction
        _tks = res.get("tickets") or []
        _pend = (res.get("execution") == "pending")
        if simulated:
            server_log.log("warn", "mt5_out",
                           f"ارسالِ خودکار فقط «شبیه‌سازی» شد — معامله‌ای در متاتریدر باز نشد: "
                           f"{send_sym} {direction}",
                           f"روش={decision['source']} · قیمت={data.get('price')} · "
                           f"تایم‌فریم={tf} · علت={res.get('note') or 'MT5 در دسترس نیست (کتابخانه/اتصال)'} · "
                           f"برای ارسالِ واقعی باید برنامه روی ویندوزِ دارای MT5 با پایتونِ "
                           f"دارای بستهٔ MetaTrader5 اجرا و ترمینال متصل باشد.")
        else:
            server_log.log("success" if ok else "error", "mt5_out",
                           f"ارسالِ خودکار به متاتریدر ۵ ({src_lbl}): {send_sym} {direction}",
                           f"روش={decision['source']} · قیمت={data.get('price')} · "
                           f"امتیاز={data.get('total_score')} · تایم‌فریم={tf} · "
                           f"نتیجه={'موفق' if ok else 'ناموفق'}"
                           + (f" · تیکت‌ها={_tks}" if _tks else "")
                           + (" · سفارشِ معلق ثبت شد؛ پوزیشن تا رسیدنِ قیمت به نقطهٔ "
                              "ورود باز نمی‌شود" if (ok and _pend) else "")
                           + (f" · خطا={res.get('error')}" if res.get('error') else ""))
    except Exception as e:  # noqa
        server_log.log("error", "mt5_out",
                       f"خطا در ارسالِ خودکار به متاتریدر ۵: {send_sym} {direction}", str(e))


# ───────────────────── اصلاح (AUTOPILOT-001): ارسالِ خودکارِ مستقل از مرورگر ─────
# قبلاً _program_auto_dispatch فقط از مسیرِ /api/signal (یعنی بازبودنِ داشبورد در
# مرورگر یا کلیکِ «تحلیل اکنون») اجرا می‌شد. این زمان‌بندِ سمتِ سرور، خودش هر
# چند ثانیه سیگنالِ نمادهای تنظیم‌شده را می‌سازد و همان مسیرِ ارسال را اجرا می‌کند.
_autorun_state = {"thread": None, "stop": None, "last_run": 0.0, "last_error": ""}
_signal_state_lock = _threading.RLock()      # اصلاح (OPUS5-A14)
_manual_send_lock = _threading.RLock()       # اصلاح (OPUS5-A3)
_autorun_lifecycle_lock = _threading.RLock()  # اصلاح (OPUS5-A16)


def _program_autorun_once():
    """یک دورِ کاملِ تحلیل→تصمیم→ارسال برای نمادهای پیکربندی‌شده (قابلِ تست)."""
    dcfg = dispatch.load_config()
    if not (dcfg.get("program_enabled") and dcfg.get("program_autorun", True)):
        return {"ran": False, "reason": "خاموش"}
    tf = dcfg.get("program_tf") or "15m"
    if tf not in VALID_TF:
        tf = "15m"
    syms_ = [str(x).strip() for x in (dcfg.get("program_symbols") or []) if str(x).strip()][:12]
    if not syms_:
        return {"ran": False, "reason": "نمادی تنظیم نشده"}
    out = []
    for s_ in syms_:
        try:
            # اصلاح (AUTOPILOT-002): هر نماد می‌تواند تایم‌فریمِ مخصوص داشته باشد (SYM@TF)
            s_, tf_i = _parse_sym_tf(s_, tf)
            with app.test_request_context():
                data, internal, broker = _signal_for(s_, tf_i, with_ai=False)
                _program_auto_dispatch(data, internal, tf_i, broker=broker)
            out.append({"symbol": s_, "ok": True, "tf": tf_i,
                        "direction": data.get("direction")})
        except Exception as e:  # noqa
            out.append({"symbol": s_, "ok": False, "error": str(e)})
            _autorun_state["last_error"] = f"{s_}: {e}"
    _autorun_state["last_run"] = time.time()
    return {"ran": True, "results": out}


def _program_autorun_loop(stop_ev):
    _err_logged = 0.0
    while not stop_ev.is_set():
        try:
            dcfg = dispatch.load_config()
            every = max(15, int(float(dcfg.get("program_every_sec", 60) or 60)))
        except Exception:  # noqa
            every = 60
        try:
            _program_autorun_once()
        except Exception as e:  # noqa
            if time.time() - _err_logged > 300:   # حداکثر هر ۵ دقیقه یک هشدار
                _err_logged = time.time()
                try:
                    server_log.log("warn", "mt5_out", "خطا در حلقهٔ ارسالِ خودکارِ سمتِ سرور", str(e))
                except Exception:  # noqa
                    pass
        stop_ev.wait(every)


# ======================= گاردِ سشنِ بازار (OP5-MH-CLOSE) =======================
# C-§4: گاردِ آخرهفته فقط «ورود» را می‌بست و هیچ‌وقت پوزیشنِ باز را نمی‌بست؛ حالا
# بستنِ خودکارِ پیش‌از‌پایانِ‌سشن در حلقهٔ پس‌زمینهٔ سرور اجرا می‌شود.
_market_session_state = {"thread": None, "stop": None, "last": {}}


def _market_session_symbols():
    """نمادهایی که گاردِ سشن روی آن‌ها اجرا می‌شود (نمادهای مجازِ متاتریدر یا همه)."""
    try:
        cfg = mt5_bridge.load_config()
        allowed = [str(x).upper() for x in (cfg.get("allowed_symbols") or []) if x]
    except Exception:  # noqa
        allowed = []
    if allowed:
        return allowed
    try:
        return list(symbols.SYMBOLS.keys())
    except Exception:  # noqa
        return []


def _market_session_rows():
    """وضعیتِ باز/بستهٔ نمادها برای نمایش در UI."""
    rows = []
    for s in _market_session_symbols():
        try:
            st = market_hours.status(s)
        except Exception as e:  # noqa
            st = {"open": None, "error": str(e)}
        rows.append({"symbol": s, "open": st.get("open"),
                     "asset_class": st.get("asset_class"),
                     "minutes_to_close": st.get("minutes_to_close"),
                     "next_change_in_min": st.get("next_change_in_min"),
                     "reason_fa": st.get("reason_fa")})
    return rows


def _market_close_sweep(apply=True):
    """پوزیشن‌های نمادهایی که سشن‌شان تمام می‌شود را می‌بندد (یا فقط گزارش می‌دهد)."""
    try:
        cfg = mt5_bridge.load_config()
        cutoff = max(0, int(float(cfg.get("market_close_cutoff_min", 15) or 0)))
    except Exception:  # noqa
        cutoff = 15
    syms = _market_session_symbols()
    due = market_hours.due_symbols(syms, cutoff_min=cutoff)
    if not due:
        return {"ok": True, "due": [], "closed": [], "errors": [], "applied": False,
                "cutoff_min": cutoff}
    if not apply:
        return {"ok": True, "due": due, "closed": [], "errors": [], "applied": False,
                "cutoff_min": cutoff}
    try:
        conn = mt5_bridge.status() or {}
    except Exception:  # noqa
        conn = {}
    if not (conn.get("available") and conn.get("connected")):
        return {"ok": False, "due": due, "closed": [], "errors": ["MetaTrader not connected"],
                "applied": False, "cutoff_min": cutoff}
    res = market_hours.close_before_session_end(mt5_bridge, syms, cutoff_min=cutoff,
                                                magic_only=True)
    res.update({"applied": True, "cutoff_min": cutoff})
    if res.get("closed"):
        server_log.log("success", "mt5_out",
                       f"پیش از پایانِ سشن، {len(res['closed'])} پوزیشن بسته شد",
                       f"نمادهای در آستانهٔ بسته‌شدن: {', '.join(res.get('due') or [])}")
    if res.get("errors"):
        server_log.log("warn", "mt5_out", "بستنِ پیش‌از‌پایانِ‌سشن کامل نشد",
                       " · ".join(res.get("errors") or [])[:300])
    return res


def _market_session_loop(stop_ev):
    while not stop_ev.is_set():
        try:
            cfg = mt5_bridge.load_config()
            if cfg.get("market_close_before_session_end"):
                res = _market_close_sweep(apply=True)
                _market_session_state["last"] = dict(res or {}, ts=time.time())
        except Exception as e:  # noqa
            try:
                server_log.log("warn", "mt5_out", "خطا در گاردِ پایانِ سشن", str(e)[:200])
            except Exception:  # noqa
                pass
        stop_ev.wait(60)


def _start_market_session_loop():
    import threading as _th
    if _market_session_state["thread"] and _market_session_state["thread"].is_alive():
        return
    ev = _th.Event()
    t = _th.Thread(target=_market_session_loop, args=(ev,),
                   name="market-session-guard", daemon=True)
    _market_session_state.update(thread=t, stop=ev)
    t.start()


@app.route("/api/market/status")
def market_status_api():
    """وضعیتِ باز/بستهٔ بازارِ نمادها + تنظیماتِ محافظِ سشن + نتیجهٔ آخرین بستنِ خودکار."""
    try:
        cfg = mt5_bridge.load_config()
    except Exception:  # noqa
        cfg = {}
    return jsonify({"ok": True, "data": {
        "rows": _market_session_rows(),
        "config": {
            "market_hours_guard": bool(cfg.get("market_hours_guard", True)),
            "market_entry_cutoff_min": int(float(cfg.get("market_entry_cutoff_min", 0) or 0)),
            "market_close_before_session_end": bool(cfg.get("market_close_before_session_end")),
            "market_close_cutoff_min": int(float(cfg.get("market_close_cutoff_min", 15) or 0)),
        },
        "last_sweep": _market_session_state.get("last") or {},
    }})


@app.route("/api/market/sweep", methods=["POST"])
def market_sweep_api():
    """اجرای دستیِ بستنِ پوزیشن‌های نمادهایی که سشن‌شان تمام شده/می‌شود."""
    body = _json_body()
    apply = bool(body.get("apply"))
    res = _market_close_sweep(apply=apply)
    code = 200 if res.get("ok") else 503
    return jsonify({"ok": bool(res.get("ok")), "data": res}), code


_autorun_lifecycle_lock = _th_global.RLock()   # OP5-CORE-16
_services_started = {"done": False}


def _start_program_autorun():
    import threading as _th
    with _autorun_lifecycle_lock:                 # check-then-start اتمیک
        if _autorun_state["thread"] and _autorun_state["thread"].is_alive():
            return
        ev = _th.Event()
        t = _th.Thread(target=_program_autorun_loop, args=(ev,),
                       name="program-autorun", daemon=True)
        _autorun_state.update(thread=t, stop=ev)
        t.start()


def start_background_services():
    """زمان‌بندِ اخبار + ارسالِ خودکار + گاردِ سشن را یک‌بار و ایمن راه می‌اندازد.

    OP5-CORE-16: در اجرای معمول (`python app.py`) خودکار از __main__ صدا زده
    می‌شود؛ اگر برنامه را زیرِ gunicorn/flask-run اجرا می‌کنید (که __main__ را
    اجرا نمی‌کند)، با گذاشتنِ BTC_AGENT_AUTOSTART_BACKGROUND=1 این تابع از اولین
    درخواست به‌صورتِ اتمیک و یک‌بار اجرا می‌شود.
    """
    with _autorun_lifecycle_lock:
        if _services_started["done"]:
            return
        _services_started["done"] = True
    try:
        news_alerts.start()
    except Exception:  # noqa
        pass
    try:
        _start_program_autorun()
    except Exception:  # noqa
        pass
    try:
        _start_market_session_loop()
    except Exception:  # noqa
        pass


@app.before_request
def _maybe_start_background():
    if app.config.get("TESTING"):
        return None
    if (os.environ.get("BTC_AGENT_AUTOSTART_BACKGROUND") or "").strip().lower() \
            not in ("1", "true", "yes", "on"):
        return None
    start_background_services()
    return None


def _evaluate_robot_order(order, cfg):
    """سفارشِ نرمال‌شده‌ی ربات را با سیگنالِ داخلی و/یا هوش مصنوعی می‌سنجد.

    خروجی شامل: approved، دلایل، جزئیاتِ سیگنالِ داخلی و AI. ارسال به متاتریدر
    در تابعِ فراخوان انجام می‌شود.
    """
    tf = order.get("tf") or cfg.get("default_tf", "1h")
    if tf not in VALID_TF:
        tf = cfg.get("default_tf", "1h") if cfg.get("default_tf") in VALID_TF else "1h"
    mode = cfg.get("filter_mode", "both")
    need_match = bool(cfg.get("require_direction_match", True))
    want = order["direction"]

    ev = {"symbol": order["symbol"], "tf": tf, "filter_mode": mode,
          "robot_direction": want, "internal": None, "ai": None,
          "internal_ok": None, "ai_ok": None, "approved": False, "reasons": []}

    # ---- سیگنالِ داخلی ----
    data = None
    try:
        data, internal, broker = _signal_for(order["symbol"], tf, with_ai=False)
        idir = data.get("direction")
        iscore = float(data.get("internal_score", data.get("total_score", 0)) or 0)
        ev["internal"] = {"direction": idir, "score": round(iscore, 1),
                          "confidence": data.get("confidence"),
                          "price": data.get("price")}
        ev["_internal_symbol"] = internal
        ev["_broker"] = broker
    except Exception as e:  # noqa
        ev["internal"] = {"error": str(e)}

    # ---- سیگنالِ هوش مصنوعی ----
    if mode in ("ai", "both"):
        if data is not None:
            ev["ai"] = _ai_eval_for_signal(data)
        else:
            ev["ai"] = {"available": False, "error": "سیگنالِ پایه ساخته نشد."}

    # ---- تصمیم‌گیری ----
    min_i = float(cfg.get("min_internal_score", 15) or 0)
    min_a = float(cfg.get("min_ai_score", 15) or 0)

    def _dir_ok(sig_dir):
        return (not need_match) or (sig_dir == want)

    internal_ok = None
    if mode in ("internal", "both"):
        i = ev.get("internal") or {}
        if "error" in i:
            internal_ok = False
            ev["reasons"].append("سیگنالِ داخلی ساخته نشد: " + i["error"])
        else:
            dir_ok = _dir_ok(i.get("direction"))
            score_ok = abs(i.get("score", 0)) >= min_i
            internal_ok = bool(dir_ok and score_ok)
            if not dir_ok:
                ev["reasons"].append(f"جهتِ سیگنالِ داخلی ({i.get('direction')}) با سفارش ({want}) هم‌سو نیست.")
            elif not score_ok:
                ev["reasons"].append(f"قدرتِ سیگنالِ داخلی ({abs(i.get('score',0))}) کمتر از حدِ لازم ({min_i}) است.")
            else:
                ev["reasons"].append(f"سیگنالِ داخلی تأیید کرد ({i.get('direction')} · {i.get('score')}).")
    ev["internal_ok"] = internal_ok

    ai_ok = None
    if mode in ("ai", "both"):
        a = ev.get("ai") or {}
        if not a.get("available"):
            ai_ok = False
            ev["reasons"].append("هوش مصنوعی در دسترس نیست: " + str(a.get("error", "نامشخص")))
        else:
            dir_ok = _dir_ok(a.get("direction"))
            score_ok = abs(a.get("score", 0)) >= min_a
            ai_ok = bool(dir_ok and score_ok)
            if not dir_ok:
                ev["reasons"].append(f"جهتِ هوش مصنوعی ({a.get('direction')}) با سفارش ({want}) هم‌سو نیست.")
            elif not score_ok:
                ev["reasons"].append(f"قدرتِ سیگنالِ هوش مصنوعی ({abs(a.get('score',0))}) کمتر از حدِ لازم ({min_a}) است.")
            else:
                ev["reasons"].append(f"هوش مصنوعی تأیید کرد ({a.get('direction')} · {a.get('score')}).")
    ev["ai_ok"] = ai_ok

    if mode == "internal":
        ev["approved"] = bool(internal_ok)
    elif mode == "ai":
        ev["approved"] = bool(ai_ok)
    else:  # both
        ev["approved"] = bool(internal_ok and ai_ok)

    return ev


def _quality_score(ev):
    """امتیازِ کیفیتِ یک سیگنالِ ربات برای داوری (ترکیبِ قدرتِ سیگنالِ داخلی و هوش مصنوعی)."""
    i = (ev.get("internal") or {})
    a = (ev.get("ai") or {})
    s_i = abs(float(i.get("score", 0) or 0)) if "error" not in i else 0.0
    s_a = abs(float(a.get("score", 0) or 0)) if a.get("available") else 0.0
    # اگر هر دو موجودند میانگین‌گیریِ وزنی؛ وگرنه هرکدام که هست
    parts = [x for x in (s_i, s_a) if x > 0]
    base = (sum(parts) / len(parts)) if parts else 0.0
    conf = float(i.get("confidence") or a.get("confidence") or 0) or 0.0
    return round(base + conf * 0.1, 3)


def _positions_on_symbol(internal_symbol):
    """پوزیشن‌های بازِ (هر منبعی) روی این نماد را برمی‌گرداند.

    → (positions, meta) که در آن:
      • positions: لیستی از {"type","symbol"}؛ یا None اگر خواندن ممکن نبود.
      • meta: {"checked": bool, "available": bool, "error": str|None}
        - available=False → کتابخانهٔ MT5 روی این سیستم نصب/فعال نیست (حالتِ عادیِ
          استقرارِ «فقط‌ربات»؛ محافظِ پوزیشنِ بازِ درون‌فرایندی اصلاً موضوعیت ندارد).
        - available=True و checked=False → متاتریدر هست ولی خواندنِ پوزیشن‌ها ناموفق
          شد (خطر: محافظِ تکرار/تضاد ممکن است ناخواسته دور زده شود → باید آشکار شود).
    """
    available = bool(getattr(mt5_bridge, "MT5_AVAILABLE", False))
    try:
        res = mt5_bridge.positions(magic_only=False)
    except Exception as e:  # noqa
        return None, {"checked": False, "available": available, "error": str(e)}
    if not res.get("ok"):
        return None, {"checked": False, "available": available,
                      "error": res.get("error")}
    want = (internal_symbol or "").upper()
    out = []
    for p in res.get("positions", []):
        bsym = p.get("symbol", "")
        try:
            isym = (mt5_bridge.internal_for_broker(bsym) or "").upper()
        except Exception:  # noqa
            isym = ""
        if isym == want or (bsym or "").upper() == want:
            out.append({"type": p.get("type"), "symbol": bsym})
    return out, {"checked": True, "available": available, "error": None}


def _position_recent_guard(internal_symbol, direction, cfg):
    """بررسیِ پوزیشنِ باز و ارسالِ اخیر: در صورتِ تکرار/تضاد، دلیلِ ردّ را برمی‌گرداند وگرنه None."""
    # ۱) پوزیشنِ بازِ موجود روی این نماد
    pos, pmeta = _positions_on_symbol(internal_symbol)
    # اگر متاتریدر «هست» ولی خواندنِ پوزیشن‌ها ناموفق شد، محافظِ تکرار/تضاد عملاً
    # دور زده می‌شود. این «شکستِ خاموش» را آشکار کن و در صورتِ روشن‌بودنِ
    # fail-closed، ارسال را محتاطانه مسدود کن.
    if pos is None and pmeta.get("available") and not pmeta.get("checked"):
        # اصلاح (OP5-CORE-04): پیش‌تر پیش‌فرض False بود و دقیقاً وقتی MT5 «در
        # دسترس» ولی خواندنِ پوزیشن‌ها ناموفق بود، گارد بی‌صدا دور زده می‌شد.
        # حالا این حالت همیشه fail-closed است (پیش‌فرضِ کلید هم True شد).
        fail_closed = bool(cfg.get("position_guard_fail_closed", True))
        server_log.log(
            "warn", "robot",
            f"محافظِ پوزیشنِ باز اعمال نشد: خواندنِ پوزیشن‌های متاتریدر ناموفق بود — {internal_symbol}",
            f"خطا={pmeta.get('error')} · "
            + ("ارسال محتاطانه مسدود شد (fail-closed)." if fail_closed
               else "ارسال بدونِ بررسیِ پوزیشنِ باز ادامه یافت (fail-open)."))
        if fail_closed:
            return {"blocked": True, "kind": "position_unknown",
                    "reason": ("وضعیتِ پوزیشن‌های بازِ متاتریدر قابل خواندن نیست و «مسدودسازیِ "
                               "محتاطانه» روشن است؛ برای جلوگیری از پوزیشنِ تکراری/متضاد ارسال نشد.")}
    if pos:
        same = [p for p in pos if p.get("type") == direction]
        opp = [p for p in pos if p.get("type") and p.get("type") != direction]
        if same and cfg.get("block_duplicate_open", True):
            return {"blocked": True, "kind": "duplicate_open",
                    "reason": "پوزیشنِ بازِ هم‌جهت روی این نماد وجود دارد؛ سیگنالِ تکراری ارسال نشد."}
        if opp and cfg.get("block_opposite_open", True):
            return {"blocked": True, "kind": "conflict_open",
                    "reason": ("پوزیشنِ بازِ مخالف روی این نماد وجود دارد؛ "
                               "برای جلوگیری از خرید و فروشِ همزمان ارسال نشد.")}
    # ۲) ارسالِ اخیر (پنجرهٔ ضدِّ تکرار)
    ttl = float(cfg.get("dedupe_window_sec", 60) or 0)
    if ttl > 0:
        r = signal_arbiter.recent(internal_symbol, ttl)
        if r:
            if r.get("direction") == direction:
                return {"blocked": True, "kind": "duplicate_recent",
                        "reason": "سیگنالِ هم‌جهتِ تکراری در بازهٔ اخیر ارسال شده بود؛ رد شد."}
            return {"blocked": True, "kind": "conflict_recent",
                    "reason": ("به‌تازگی سیگنالِ مخالف برای این نماد ارسال شده؛ "
                               "برای جلوگیری از خرید و فروشِ همزمان رد شد.")}
    return None


def _do_forward(order, ev, cfg, dry_run=False):
    """ارسالِ واقعیِ سفارش به متاتریدر. → (forward_res, forwarded).

    dry_run=True: فقط پیش‌نمایش/شبیه‌سازی (برای دکمهٔ «آزمایش» در رابطِ کاربری) —
    هیچ سفارشِ واقعی‌ای ثبت نمی‌شود، اما تمامِ منطقِ تأیید/فیلتر/نقشه اجرا می‌شود.
    """
    try:
        # اصلاح (ROBOT-SYM-001): سفارش باید روی «عینِ نمادی که ربات فرستاده» فوروارد
        # شود؛ قبلاً نامِ داخلی (مثل XAU) ارسال می‌شد و resolve می‌توانست نمادِ
        # هم‌خانوادهٔ دیگری از بروکر (مثل XAUUSD به‌جای XAUUSD.m یا GOLD) انتخاب
        # کند — نتیجه: نمادِ معامله با نمادِ رباتِ کاربر ناهماهنگ می‌شد.
        # نامِ داخلی فقط برای ارزیابیِ سیگنال/اخبار است، نه مقصدِ سفارش.
        fwd_symbol = (order.get("symbol") or "").strip()             or (ev.get("_internal_symbol") or "")
        plan = {"entry": order.get("entry"), "stop_loss": order.get("sl"),
                "take_profits": order.get("tps") or []}
        overrides = {"use_plan_sl": True, "use_plan_tp": True}
        if cfg.get("respect_robot_volume", True):
            overrides["risk_mode"] = "fixed"
        # فیلترِ اخبار در _handle_robot_order پیش از این اعمال شده؛ دوباره بررسی نشود.
        forward_res = mt5_bridge.send_order_from_robot(
            fwd_symbol, order["direction"], plan,
            volume=order.get("volume"), overrides=overrides,
            skip_news_filter=True, dry_run=dry_run)
        # در حالتِ آزمایش، «forwarded» یعنی «شبیه‌سازیِ موفق»، نه ارسالِ واقعی.
        return forward_res, bool(forward_res.get("ok"))
    except Exception as e:  # noqa
        return {"ok": False, "error": str(e)}, False


def _arbitrate_and_forward(order, ev, cfg, dry_run=False):
    """مدیریتِ سیگنال‌های همزمان/تکراری/متضاد، سپس ارسالِ «فقط بهترین» سیگنال.

    → {"forwarded", "forward", "arb", "reason"}.
    dry_run=True: ارسالِ نهایی شبیه‌سازی می‌شود (دکمهٔ «آزمایش»).
    """
    symbol = ev.get("_internal_symbol") or order["symbol"]
    direction = order["direction"]
    score = _quality_score(ev)
    arb = {"symbol": symbol, "score": score}

    # (الف) بازبینیِ اولیه: پوزیشنِ باز / ارسالِ اخیر
    guard = _position_recent_guard(symbol, direction, cfg)
    if guard:
        arb.update(guard)
        return {"forwarded": False, "forward": None, "arb": arb, "reason": guard["reason"]}

    # (ب) داوریِ سیگنال‌های همزمان در پنجرهٔ کوتاه (انتخابِ بهترین)
    win = float(cfg.get("aggregate_window_sec", 2.0) or 0)
    if win > 0:
        res = signal_arbiter.submit(symbol, direction, score, window=win,
                                    meta={"src_dir": direction})
        arb.update(res)
        if not res["win"]:
            if res["kind"] == "duplicate":
                reason = ("در داوریِ سیگنال‌های همزمان، سیگنالِ هم‌جهتِ قوی‌تری برای این نماد "
                          f"انتخاب شد (امتیازِ برنده {res.get('winner_score')} ≥ این {score})؛ "
                          "این سیگنالِ تکراری ارسال نشد.")
            else:
                reason = ("سیگنالِ مخالفِ قوی‌تری برای این نماد انتخاب شد "
                          f"(امتیازِ برنده {res.get('winner_score')})؛ برای جلوگیری از "
                          "خرید و فروشِ همزمان این سیگنال ارسال نشد.")
            return {"forwarded": False, "forward": None, "arb": arb, "reason": reason}

    # (ج) برنده: سریال‌سازیِ «بازبینیِ نهایی → ارسال → ثبت» برای هر نماد
    with signal_arbiter.symbol_lock(symbol):
        guard = _position_recent_guard(symbol, direction, cfg)  # بازبینیِ مجددِ درونِ قفل
        if guard:
            arb.update(guard)
            return {"forwarded": False, "forward": None, "arb": arb, "reason": guard["reason"]}
        forward_res, forwarded = _do_forward(order, ev, cfg, dry_run=dry_run)
        # در حالتِ آزمایش، حافظهٔ «ارسالِ اخیر» را آلوده نمی‌کنیم تا سیگنال‌های
        # واقعیِ بعدی به‌اشتباه به‌عنوان «تکراری» رد نشوند.
        if forwarded and not dry_run:
            signal_arbiter.note_forward(symbol, direction, score)
    arb["forwarded"] = forwarded
    return {"forwarded": forwarded, "forward": forward_res, "arb": arb, "reason": None}


def _detect_robot_platform(order):
    """نوعِ سکوی فرستنده را تشخیص می‌دهد → (key, label_fa, label_en, log_cat).

    ترتیبِ تشخیص: فیلدِ صریحِ platform در payload، سپس User-Agent.
    """
    p = (order.get("platform") or "").strip().lower() if isinstance(order, dict) else ""
    ua = (request.headers.get("User-Agent") or "").lower()
    key = "unknown"
    if p in ("python", "py", "python-bot", "pybot"):
        key = "python"
    elif p in ("mql5", "mt5", "mql", "expert", "ea", "metatrader"):
        key = "mql5"
    elif "python-requests" in ua or "python" in ua:
        key = "python"
    elif "metatrader" in ua or "mt5" in ua or "mql" in ua:
        key = "mql5"
    if key == "python":
        return "python", "رباتِ پایتون", "Python robot", "robot_py"
    if key == "mql5":
        return "mql5", "اکسپرتِ متاتریدر ۵", "MT5 Expert", "robot_mql5"
    return "unknown", "ربات (نامشخص)", "Robot (unknown)", "robot"


def _log_robot_signal(order, source, decision):
    """رویدادِ «سیگنالِ ورودی از ربات» را در لاگِ سرور با تفکیکِ نوعِ سکو ثبت می‌کند."""
    try:
        _key, fa, _en, cat = _detect_robot_platform(order)
        d = order or {}
        tps = d.get("tps") or []
        rid = d.get("robot_id") or "-"
        direction = d.get("direction") or "?"
        symbol = d.get("symbol") or "?"
        approved = decision.get("approved")
        forwarded = decision.get("forwarded")
        err = decision.get("error")
        if forwarded:
            lvl = "success"
        elif err or approved is False:
            lvl = "warn"
        else:
            lvl = "info"
        src_lbl = "آزمایشِ رابط" if source == "ui-test" else "وب‌هوک"
        msg = f"سیگنالِ ورودی از {fa}: {symbol} {direction}"
        detail = (f"منبع={src_lbl} · شناسه={rid} · حجم={d.get('volume')} · "
                  f"تایم‌فریم={d.get('tf') or '-'} · ورود={d.get('entry')} · "
                  f"SL={d.get('sl')} · TP={tps} · "
                  f"تأیید={approved} · ارسال‌شده={forwarded}"
                  + (f" · دلیل={err}" if err else ""))
        server_log.log(lvl, cat, msg, detail)
    except Exception:  # noqa
        pass


def _robot_auth_required_but_missing():
    """اصلاح (OPUS5-A1 — بحرانی): وب‌هوکِ معامله با bind عمومی (0.0.0.0) بدونِ
    secret اجباری در دسترس بود. اگر هاستِ bind غیرمحلی و هیچ secretی تنظیم نشده
    باشد، مسیرهای ربات fail-closed می‌شوند (401) مگر با
    BTC_AGENT_ALLOW_INSECURE_ROBOT=1 (انتخابِ صریحِ کاربر)."""
    host = (os.environ.get("BTC_AGENT_BIND_HOST", "0.0.0.0") or "").strip()
    if host in ("127.0.0.1", "localhost", "::1"):
        return False
    if (os.environ.get("BTC_AGENT_ALLOW_INSECURE_ROBOT", "") or "").strip().lower() in ("1", "true"):
        return False
    secret = (os.environ.get("BTC_AGENT_ROBOT_SECRET")
              or (robots.load_config().get("shared_secret") or "")).strip()
    return not secret


def _handle_robot_order(payload, source="robot"):
    """جریانِ کاملِ یک سفارشِ ربات: نرمال‌سازی → ارزیابی → (در صورتِ تأیید) ارسال به MT5.

    اگر source == "ui-test" باشد (دکمهٔ «آزمایش» در رابطِ کاربری)، مرحلهٔ ارسال فقط
    شبیه‌سازی (dry_run) می‌شود: هیچ معاملهٔ واقعی ثبت نمی‌شود، ولی کلِ منطقِ
    تأیید/رد، فیلترِ اخبار، زمان‌بندی و داوریِ سیگنال دقیقاً مثلِ مسیرِ واقعی اجرا می‌شود.
    """
    cfg = robots.load_config()
    is_test = (source == "ui-test")
    # اصلاح (OPUS5-A1): بدونِ secret روی bind عمومی، وب‌هوک بسته است.
    if _robot_auth_required_but_missing():
        rec = robots.append_log({"source": source, "approved": False, "forwarded": False,
                                 "error": "bind عمومی بدونِ secret — fail-closed", "order": {}})
        return {"ok": False, "error": (
            "برنامه روی هاستِ عمومی bind شده و هیچ توکنِ امنیتی (shared_secret یا "
            "BTC_AGENT_ROBOT_SECRET) تنظیم نیست؛ مسیرِ ربات بسته است. یا secret تنظیم "
            "کنید، یا BTC_AGENT_BIND_HOST=127.0.0.1، یا آگاهانه "
            "BTC_AGENT_ALLOW_INSECURE_ROBOT=1 بگذارید."), "record": rec}, 401

    # احرازِ هویتِ اختیاری با توکنِ مشترک
    # اصلاح (APP-002): متغیرِ محیطیِ BTC_AGENT_ROBOT_SECRET بر config مقدم است و
    # مقایسه با hmac.compare_digest (مقاوم به timing attack) انجام می‌شود.
    secret = (os.environ.get("BTC_AGENT_ROBOT_SECRET")
              or cfg.get("shared_secret") or "").strip()
    if secret:
        provided = (request.headers.get("X-Robot-Secret")
                    or (payload.get("secret") if isinstance(payload, dict) else "") or "")
        if not hmac.compare_digest(str(provided).strip(), secret):
            rec = robots.append_log({"source": source, "approved": False,
                                     "forwarded": False, "error": "توکنِ امنیتی نامعتبر",
                                     "order": {}})
            _log_robot_signal(payload if isinstance(payload, dict) else {}, source,
                              {"approved": False, "forwarded": False, "error": "توکنِ امنیتی نامعتبر"})
            return {"ok": False, "error": "توکنِ امنیتی (shared secret) نامعتبر است.",
                    "record": rec}, 401

    if not cfg.get("enabled"):
        rec = robots.append_log({"source": source, "approved": False, "forwarded": False,
                                 "error": "پُلِ ربات‌ها غیرفعال است", "order": {}})
        _log_robot_signal(payload if isinstance(payload, dict) else {}, source,
                          {"approved": False, "forwarded": False, "error": "پُلِ ربات‌ها غیرفعال است"})
        return {"ok": False, "error": "پُلِ سیگنالِ ربات‌ها غیرفعال است — از تبِ "
                                      "«📡 روشِ ارسالِ سیگنال به متاتریدر ۵» فعال کنید.",
                "record": rec}, 200

    order = robots.normalize_order(payload if isinstance(payload, dict) else {})
    # OP5-CORE-12: اگر ربات تایم‌فریم را «صریحاً» فرستاده باشد و آن تایم‌فریم
    # پشتیبانی نشود (مثلاً MN1 ماهانه)، سفارش رد می‌شود؛ پیش‌تر بی‌صدا روی
    # «تایم‌فریمِ پیش‌فرض» (1h) ارزیابی می‌شد و فیلتر روی تایم‌فریمِ دیگری
    # تصمیم می‌گرفت. fallback فقط وقتی مجاز است که tf اصلاً نیامده باشد.
    _raw_tf = ""
    if isinstance(payload, dict):
        _raw_tf = str(payload.get("tf") or payload.get("timeframe")
                      or payload.get("period") or "").strip()
    if _raw_tf and str(order.get("tf") or "") not in VALID_TF:
        verr_tf = (f"تایم‌فریمِ «{_raw_tf}» پشتیبانی نمی‌شود؛ "
                   f"مقادیرِ مجاز: {', '.join(sorted(VALID_TF))}")
        rec = robots.append_log({"source": source, "approved": False, "forwarded": False,
                                 "error": verr_tf, "order": order})
        _log_robot_signal(order, source, {"approved": False, "forwarded": False, "error": verr_tf})
        return {"ok": False, "error": verr_tf, "order": order, "record": rec}, 400
    verr = robots.validate_order(order)
    if verr:
        rec = robots.append_log({"source": source, "approved": False, "forwarded": False,
                                 "error": verr, "order": order})
        _log_robot_signal(order, source, {"approved": False, "forwarded": False, "error": verr})
        return {"ok": False, "error": verr, "order": order, "record": rec}, 400

    ev = _evaluate_robot_order(order, cfg)

    # --- فیلتر اخبار: از تنظیماتِ مشترکِ تبِ «روشِ ارسالِ سیگنال» خوانده می‌شود ---
    # شکستِ خاموش (تقویم در دسترس نبود) اکنون در لاگ ثبت و در evalِ سفارش نمایان می‌شود.
    dcfg = dispatch.load_config()
    news_block = {"blocked": False}
    if dcfg.get("news_filter_enabled", True):
        sym_for_news = (ev.get("_internal_symbol") or order["symbol"] or "").upper()
        ng = _eval_news_gate(sym_for_news, dcfg, f"robot/{source}", "robot")
        news_block = ng.get("raw") or {"blocked": ng["blocked"]}
        news_block["blocked"] = ng["blocked"]
        ev["news"] = news_block
        ev["news_ok"] = not ng["blocked"]
        if ng.get("inoperative"):
            ev["reasons"].append(
                "فیلترِ اخبار موقتاً در دسترس نبود؛ "
                + ("معامله محتاطانه مسدود شد." if ng["blocked"]
                   else "ارسال بدونِ محافظتِ اخبار ادامه یافت."))
        elif ng["blocked"]:
            evn = ng.get("event") or {}
            ev["reasons"].append(
                f"فیلتر اخبار: رویداد پرتأثیر «{evn.get('title','')}» "
                f"({evn.get('country','')}) نزدیک است؛ ارسال مسدود شد.")

    # --- زمان‌بندیِ ساعاتِ کارِ سرور (طبقِ تنظیمِ مشترک): خارج از بازهٔ کاری، ارسال متوقف است ---
    if dcfg.get("schedule_filter_enabled", True):
        prog_active, prog_info = _program_gate()
        _log_schedule_unknown(prog_info, f"robot/{source}", "robot")
        # اگر ساعتِ سرور نامشخص است و حالتِ محتاطانه روشن است → مسدود
        if prog_info.get("unknown") and dcfg.get("schedule_fail_closed", False):
            prog_active = False
            prog_info = dict(prog_info)
            prog_info["reason"] = "ساعتِ سرورِ کارگزار در دسترس نیست (مسدودسازیِ محتاطانه)."
    else:
        prog_active, prog_info = True, {"reason": "فیلتر زمان‌بندی خاموش است"}
    if not prog_active:
        ev["schedule"] = prog_info
        ev["schedule_ok"] = False
        ev["reasons"].append(
            f"ساعاتِ کارِ سرور: {prog_info.get('reason','خارج از بازهٔ کاری')} "
            f"(ساعتِ سرور {prog_info.get('broker_time','')}).")
    else:
        ev["schedule_ok"] = True

    # ارسال فقط وقتی: تأیید شد، اخبار مسدود نکرد، و در بازهٔ کاری هستیم
    allow_forward = ev["approved"] and not news_block.get("blocked") and prog_active

    forwarded, forward_res, arb = False, None, None
    if allow_forward and cfg.get("auto_forward", True):
        if cfg.get("conflict_guard_enabled", True):
            decision = _arbitrate_and_forward(order, ev, cfg, dry_run=is_test)
            forwarded = decision["forwarded"]
            forward_res = decision["forward"]
            arb = decision["arb"]
            if decision.get("reason"):
                ev["reasons"].append(decision["reason"])
        else:
            forward_res, forwarded = _do_forward(order, ev, cfg, dry_run=is_test)

    # حذفِ کلیدهای داخلی از خروجی
    ev_clean = {k: v for k, v in ev.items() if not k.startswith("_")}
    blocked_news = bool(news_block.get("blocked"))
    blocked_sched = not prog_active
    # آیا با وجودِ تأیید، به‌خاطرِ تکرار/تضاد ارسال نشد؟
    arb_blocked = bool(arb and arb.get("blocked")) or bool(
        arb and ("kind" in arb) and not arb.get("forwarded") and arb.get("kind") != "win")
    # اصلاح (DISP-TRUTH-002/ربات): اگر MT5 در دسترس نبود، فورواردِ «موفق» فقط
    # شبیه‌سازی است؛ قبلاً simulated فقط برای دکمهٔ آزمایش True می‌شد.
    _fsim = bool(forwarded and (is_test or (forward_res or {}).get("simulated")
                                or (forward_res or {}).get("dry_run")))
    if _fsim and not is_test:
        ev["reasons"].append("هشدار: MT5 در دسترس نبود؛ ارسال فقط شبیه‌سازی شد و "
                             "معامله‌ای در متاتریدر باز نشده است.")
        try:
            server_log.log("warn", "robot",
                           f"فورواردِ سفارشِ ربات فقط «شبیه‌سازی» شد (MT5 در دسترس نیست): "
                           f"{order.get('symbol')} {order.get('direction')}",
                           str((forward_res or {}).get("note") or ""))
        except Exception:  # noqa
            pass
    rec = robots.append_log({
        "source": source, "test": is_test, "order": order, "eval": ev_clean,
        "approved": ev["approved"], "forwarded": forwarded,
        "simulated": _fsim,
        "news_blocked": blocked_news, "schedule_blocked": blocked_sched,
        "arb_blocked": arb_blocked, "arb": arb,
        "forward": forward_res,
        "error": (None if (ev["approved"] and not blocked_news
                           and not blocked_sched and not arb_blocked)
                  else "؛ ".join(ev["reasons"][-2:])),
    })
    _log_robot_signal(order, source, {
        "approved": ev["approved"], "forwarded": forwarded,
        "error": rec.get("error") if isinstance(rec, dict) else None,
    })
    return {"ok": True, "approved": ev["approved"], "forwarded": forwarded,
            "test": is_test, "simulated": _fsim,
            "news_blocked": blocked_news, "news": news_block,
            "schedule_blocked": blocked_sched, "schedule": prog_info,
            "arb_blocked": arb_blocked, "arb": arb,
            "eval": ev_clean, "forward": forward_res, "order": order,
            "record": rec}, 200


@app.route("/api/robot/order", methods=["POST"])
def robot_order():
    """وب‌هوکِ دریافتِ سفارشِ ربات‌ها (ربات‌ها به‌جای MT5، اینجا POST می‌کنند)."""
    payload = _json_body() or request.form.to_dict() or {}
    body, code = _handle_robot_order(payload, source="robot")
    return jsonify(body), code


@app.route("/api/robot/test", methods=["POST"])
def robot_test():
    """آزمایشِ یک سفارشِ ساختگی از رابطِ کاربری (بدونِ نیاز به ربات)."""
    payload = _json_body()
    body, code = _handle_robot_order(payload, source="ui-test")
    return jsonify(body), code


@app.route("/api/robot/config", methods=["GET"])
def robot_get_cfg():
    return jsonify({"ok": True, "data": {"config": robots.load_config(),
                                         "stats": robots.stats()}})


@app.route("/api/robot/config", methods=["POST"])
def robot_set_cfg():
    body = _json_body()
    saved = robots.save_config(body)
    return jsonify({"ok": True, "data": {"config": saved, "stats": robots.stats()}})


@app.route("/api/robot/log", methods=["GET"])
def robot_get_log():
    limit = _qint("limit", 100)
    return jsonify({"ok": True, "data": {"log": robots.read_log(limit),
                                         "stats": robots.stats()}})


@app.route("/api/robot/log", methods=["DELETE"])
def robot_clear_log():
    robots.clear_log()
    return jsonify({"ok": True})


@app.route("/api/inject", methods=["POST"])
def inject_code():
    """تزریقِ خودکارِ کدِ اتصال به فایلِ رباتِ پایتونی/اکسپرتِ متاتریدر.

    ورودی JSON: {filename, content, url?, secret?}
    خروجی: {ok, filename, out_filename, lang, changed, patched, report[], diff}
    """
    body = _json_body()
    filename = str(body.get("filename") or "").strip()
    content = body.get("content")
    if not filename or content is None:
        return jsonify({"ok": False, "error": "filename و content لازم است."}), 400
    ext = os.path.splitext(filename)[1].lower()
    if ext not in (".py", ".mq5", ".mqh"):
        return jsonify({"ok": False,
                        "error": "فقط فایل‌های .py / .mq5 / .mqh پشتیبانی می‌شوند."}), 400

    url = str(body.get("url") or bridge_injector.DEFAULT_URL).strip() or bridge_injector.DEFAULT_URL
    secret = str(body.get("secret") or "")
    try:
        patched, report, lang = bridge_injector.patch_source(filename, content, url, secret)
    except ValueError as exc:
        return jsonify({"ok": False, "error": str(exc)}), 400
    except Exception as exc:  # noqa
        return jsonify({"ok": False, "error": f"خطا در تزریق: {exc}"}), 500

    changed = (patched != content)
    diff = bridge_injector.make_diff(filename, content, patched) if changed else ""
    base, e = os.path.splitext(filename)
    out_filename = f"{base}.bridge{e}"
    return jsonify({"ok": True, "filename": filename, "out_filename": out_filename,
                    "lang": lang, "changed": changed, "patched": patched,
                    "report": report, "diff": diff})


@app.route("/api/logs", methods=["GET"])
def server_logs():
    """رویدادهای سمتِ سرور (برای تبِ لاگ). پارامترها: since, level, cat, limit."""
    try:
        since = _qint("since", 0)
    except Exception:
        since = 0
    try:
        limit = _qint("limit", 1000)
    except Exception:
        limit = 1000
    level = request.args.get("level", "") or ""
    cat = request.args.get("cat", "") or ""
    # پاک‌سازیِ زمانیِ اختیاری: max_age_h ساعت (۰ = غیرفعال)
    try:
        max_age_h = _qfloat("max_age_h", 0)
    except Exception:
        max_age_h = 0
    purged = server_log.purge_age(max_age_h * 3600) if max_age_h > 0 else 0
    items = server_log.get(since_id=since, level=level, cat=cat, limit=limit)
    return jsonify({"ok": True, "data": {"events": items, "stats": server_log.stats(), "purged": purged}})


@app.route("/api/logs", methods=["DELETE"])
def server_logs_clear():
    server_log.clear()
    return jsonify({"ok": True})


@app.route("/api/system/stats")
def system_stats():
    """مصرفِ دقیقِ RAM/CPUِ پردازهٔ سرور و سیستم."""
    return jsonify({"ok": True, "data": server_log.resources()})


@app.route("/health")
def health():
    return jsonify({"ok": True})


# ─────────────────────────────────────────────────────────────────────────────
#  مدیریتِ خطای سراسری: برای مسیرهای /api/* همیشه JSON برگردان (نه صفحهٔ HTML)،
#  تا همهٔ تب‌های داشبورد به‌جای کرش، پیامِ خوانا بگیرند و به‌آرامی افت کنند.
# ─────────────────────────────────────────────────────────────────────────────
def _wants_json():
    p = request.path or ""
    return p.startswith("/api/") or "application/json" in (request.headers.get("Accept") or "")


@app.errorhandler(404)
def _err_404(e):
    try:
        server_log.log("warn", "net", f"404 {request.method} {request.path}")
    except Exception:  # noqa
        pass
    if _wants_json():
        return jsonify({"ok": False, "error": "این مسیر یافت نشد (۴۰۴). ممکن است نسخهٔ سرور با صفحه هماهنگ نباشد؛ صفحه را تازه کنید."}), 404
    return e


@app.errorhandler(405)
def _err_405(e):
    try:
        server_log.log("warn", "net", f"405 {request.method} {request.path}")
    except Exception:  # noqa
        pass
    if _wants_json():
        return jsonify({"ok": False, "error": "این عملیات روی این مسیر مجاز نیست (۴۰۵)."}), 405
    return e


@app.errorhandler(Exception)
def _err_500(e):
    # خطاهای HTTPِ عمدی (مثلِ abort(404)) را دست‌نخورده رد کن تا هندلرهای بالا کار کنند.
    from werkzeug.exceptions import HTTPException
    if isinstance(e, HTTPException):
        return e
    import traceback
    traceback.print_exc()
    try:
        server_log.log("error", "error", f"{type(e).__name__} @ {request.method} {request.path}", str(e)[:300])
    except Exception:  # noqa
        pass
    if _wants_json():
        # اصلاح (INFO-006): متنِ خامِ استثنا (مسیر/URL داخلی/جزئیات provider) دیگر به
        # کلاینت نشت نمی‌کند؛ جزئیات کامل در لاگِ سرور ثبت شده است.
        return jsonify({
            "ok": False,
            "error": "خطای داخلیِ سرور. احتمالاً منبعِ دادهٔ رایگان موقتاً در دسترس نیست یا محدودیتِ نرخ خورده؛ چند لحظه بعد دوباره تلاش کنید.",
        }), 500
    return ("خطای داخلی سرور", 500)


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8000))
    try:
        news_alerts.start()  # زمان‌بندِ اعلان/بستن خودکار پیش از اخبار
        _start_program_autorun()  # اصلاح (AUTOPILOT-001): ارسالِ خودکارِ مستقل از مرورگر
        _start_market_session_loop()  # OP5-MH-CLOSE: گاردِ پایانِ سشن (آخرهفته/تعطیلات)
    except Exception:  # noqa
        pass
    try:
        _r = server_log.resources()
        server_log.log("success", "system",
                       f"سرور روی پورت {port} راه‌اندازی شد",
                       f"backend={_r.get('backend')} · RSS={round(_r.get('proc_rss',0)/1048576,1)}MB · CPUx{_r.get('cpu_count')}")
    except Exception:  # noqa
        pass
    # اصلاح (REM-SEC-001): میزبانِ bind با متغیرِ محیطی قابل‌تنظیم شد تا راه‌اندازهای
    # لوکال (run_vps.bat) بتوانند فقط روی 127.0.0.1 گوش بدهند.
    host = (os.environ.get("BTC_AGENT_BIND_HOST", "127.0.0.1").strip() or "127.0.0.1")
    # OP5-CORE-01: پیش‌فرضِ bind حالا لوکال است (مثل run_vps.bat) و اجرای عمومیِ
    # بدونِ توکن صریحاً متوقف می‌شود، مگر کاربر آگاهانه پرچمِ ناامن را بگذارد.
    if host not in ("127.0.0.1", "localhost", "::1"):
        _has_admin = bool((os.environ.get("BTC_AGENT_ADMIN_TOKEN") or "").strip())
        _has_robot = bool((os.environ.get("BTC_AGENT_ROBOT_SECRET") or "").strip())
        if not (_has_admin and _has_robot) and not _robot_insecure_allowed():
            raise RuntimeError(
                "اجرای سرور روی bindِ عمومی بدونِ توکن مجاز نیست: "
                "BTC_AGENT_ADMIN_TOKEN و BTC_AGENT_ROBOT_SECRET را تنظیم کنید یا "
                "BTC_AGENT_ALLOW_INSECURE_ROBOT=1 بگذارید (آگاهانه/ناامن).")
    # اصلاح (APP-SEC-001 — نسخهٔ تعدیل‌شده): الزامِ سختِ secret استقرارهای فعلی را
    # می‌شکست؛ به‌جای آن اگر روی همهٔ interfaceها گوش می‌دهیم و secretِ ربات ست
    # نشده باشد، هشدارِ صریح در لاگ ثبت می‌شود.
    if host not in ("127.0.0.1", "localhost", "::1") and \
            not (os.environ.get("BTC_AGENT_ROBOT_SECRET") or "").strip() and \
            _robot_insecure_allowed():
        try:
            server_log.log("warn", "security",
                           "BTC_AGENT_ROBOT_SECRET تنظیم نشده و سرور روی interface عمومی گوش می‌دهد",
                           "هر کسی که به پورت دسترسی دارد می‌تواند سفارشِ ربات بفرستد؛ "
                           "برای دسترسیِ غیرلوکال حتماً secret بگذارید یا BTC_AGENT_BIND_HOST=127.0.0.1 کنید.")
        except Exception:  # noqa
            pass
        print("⚠️  هشدار امنیتی: BTC_AGENT_ROBOT_SECRET تنظیم نشده و bind روی "
              f"{host} است؛ endpointهای ربات بدون احراز هویت در دسترس‌اند.")
    app.run(host=host, port=port, debug=False, threaded=True)
