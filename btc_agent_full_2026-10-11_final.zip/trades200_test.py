# -*- coding: utf-8 -*-
"""۲۰۰ معاملهٔ خرید/فروش با دادهٔ واقعیِ بازار روی نمادهای با قیمت‌های بسیار متفاوت.

نمادها: طلا/نقره (هزار دلاری/ده‌دلاری)، بیت‌کوین (ده‌ها هزار)، اتریوم/سولانا،
نفت/گاز/مس، سه جفت‌ارز (~۱)، دو شاخصِ سهام (هزارها). سناریوها: market/pending،
split/single/partial/none، ریسکِ درصدی/ثابت، حجم‌های ۰٫۰۱ تا ۵، سفارشِ ربات
(هم‌سو/مخالف/خنثی)، و ورودی‌های مرزی.

هر معامله ده‌ها invariant را چک می‌کند:
  • نقشهٔ سیگنال: دقیقاً ۳ حدِ سود؛ ترتیبِ LONG: sl<entry<tp1<tp2<tp3 (SHORT برعکس)؛
    rr صعودی و مثبت؛ سهمِ بستن 40/35/25؛ فاصلهٔ ورود از قیمتِ لحظه‌ای معقول.
  • پیش‌نمایشِ ارسال (dry): همان اعداد بدونِ دستکاری؛ tp_mode/execution منعکس شود؛
    حجمِ برنامه‌ریزی‌شده == درخواستی.
  • پاسخِ پلِ ربات: تصمیمِ approved/رد با دلیلِ روشن؛ ارزیابی روی tf درست؛ 
    سفارشِ نرمال‌شده مقادیرِ دقیقِ ورودی را حفظ کند.
"""
import json
import random
import sys
import urllib.request

BASE = "http://127.0.0.1:8000"
PASS = FAIL = 0
NOTES = []
random.seed(20261001)

SYMBOLS = ["XAU", "XAG", "BTC", "ETH", "SOL", "WTI", "NG", "HG",
           "EURUSD", "GBPUSD", "USDJPY", "SPX", "NASDAQ"]
TFS = ["15m", "1h", "4h"]


def http(method, path, body=None, timeout=90):
    req = urllib.request.Request(BASE + path, method=method)
    data = None
    if body is not None:
        data = json.dumps(body).encode()
        req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, data=data, timeout=timeout) as r:
            return r.status, json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        try:
            return e.code, json.loads(e.read().decode())
        except Exception:
            return e.code, {}
    except Exception as e:
        return 0, {"error": str(e)}


def check(name, cond, detail=""):
    global PASS, FAIL
    if cond:
        PASS += 1
    else:
        FAIL += 1
        print(f"  \033[31mFAIL\033[0m {name}  {str(detail)[:300]}")


def get_signal(sym, tf):
    st, j = http("GET", f"/api/signal?symbol={sym}&tf={tf}&ai=0")
    if st != 200 or not j.get("ok"):
        return None
    return j.get("data")


def plan_invariants(sym, tf, sig):
    """چکِ کاملِ نقشهٔ معامله برای هر جهتِ دارِ سیگنال."""
    d = sig.get("direction")
    price = sig.get("price")
    p = sig.get("plan") or {}
    check(f"{sym}/{tf}: قیمتِ زنده مثبت", isinstance(price, (int, float)) and price > 0, price)
    if d == "NEUTRAL":
        return
    tps = p.get("take_profits") or []
    entry, sl = p.get("entry"), p.get("stop_loss")
    check(f"{sym}/{tf}: دقیقاً ۳ حدِ سود", len(tps) == 3, len(tps))
    if len(tps) != 3 or entry is None or sl is None:
        return
    tp_prices = [t["price"] for t in tps]
    rrs = [t.get("rr") for t in tps]
    pct = [t.get("close_pct") for t in tps]
    if d == "LONG":
        check(f"{sym}/{tf} LONG: sl<entry<tp1<tp2<tp3",
              sl < entry < tp_prices[0] < tp_prices[1] < tp_prices[2],
              f"sl={sl} e={entry} tps={tp_prices}")
    else:
        check(f"{sym}/{tf} SHORT: tp3<tp2<tp1<entry<sl",
              tp_prices[2] < tp_prices[1] < tp_prices[0] < entry < sl,
              f"sl={sl} e={entry} tps={tp_prices}")
    check(f"{sym}/{tf}: R:R صعودی و مثبت",
          all(isinstance(r, (int, float)) and r > 0 for r in rrs)
          and rrs[0] < rrs[1] < rrs[2], rrs)
    check(f"{sym}/{tf}: سهمِ بستن 40/35/25", pct == [40, 35, 25], pct)
    # فاصلهٔ ورود از قیمتِ لحظه‌ای: باید در حدِ چند درصد باشد (اینترادی)
    dev = abs(entry - price) / price * 100
    check(f"{sym}/{tf}: ورود نزدیکِ قیمت (|{dev:.2f}%|<8%)", dev < 8, f"entry={entry} price={price}")
    # ریسک منطقی: |entry-sl| کسری از قیمت (نه صفر، نه نصفِ قیمت)
    risk_pct = abs(entry - sl) / price * 100
    check(f"{sym}/{tf}: ریسکِ نقشه ۰٪<r<15٪", 0 < risk_pct < 15, f"{risk_pct:.2f}%")


def send_dry(sym, direction, plan, volume, overrides):
    body = {"symbol": sym, "direction": direction, "dry_run": True,
            "volume": volume, "plan": plan, "overrides": overrides}
    st, j = http("POST", "/api/mt5/send", body)
    return st, (j.get("data") if j.get("ok") and "data" in j else j)


def robot_order(body, test=True):
    # نکتهٔ طراحی: حالتِ «آزمایش/شبیه‌سازی» با مسیرِ /api/robot/test فعال می‌شود
    # (نه با فیلدِ test در بدنه). مسیرِ /api/robot/order مخصوصِ ربات‌های واقعی است.
    path = "/api/robot/test" if test else "/api/robot/order"
    st, j = http("POST", path, body)
    return st, (j.get("data") if isinstance(j, dict) and "data" in j else j)


def main():
    trades = 0
    # پیکربندیِ امنِ ربات برای تست
    http("POST", "/api/robot/config", {
        "enabled": True, "filter_mode": "internal", "require_direction_match": True,
        "min_internal_score": 0, "auto_forward": True, "conflict_guard_enabled": False,
        "news_filter_enabled": False, "shared_secret": ""})
    http("POST", "/api/dispatch/config", {"news_filter_enabled": False})

    # ---------- فاز ۱: سیگنالِ واقعی + ارسالِ dry با سناریوهای مختلف ----------
    print("\n[فاز ۱] سیگنالِ زنده + ارسالِ شبیه‌سازی‌شده (mt5/send dry) — همهٔ نمادها × سناریوها")
    sigs = {}
    for sym in SYMBOLS:
        for tf in TFS:
            sig = get_signal(sym, tf)
            check(f"{sym}/{tf}: دریافتِ سیگنالِ زنده", sig is not None)
            if sig:
                sigs[(sym, tf)] = sig
                plan_invariants(sym, tf, sig)

    tp_modes = ["split", "single", "partial", "none"]
    execs = ["market", "pending"]
    vols = [0.01, 0.03, 0.1, 0.25, 1.0, 5.0]
    keys = [k for k, s in sigs.items() if s.get("direction") != "NEUTRAL"] or list(sigs.keys())
    scenario_i = 0
    while trades < 120 and keys:
        sym, tf = keys[scenario_i % len(keys)]
        sig = sigs[(sym, tf)]
        d = sig["direction"] if sig["direction"] != "NEUTRAL" else random.choice(["LONG", "SHORT"])
        # نیمی هم‌سو با سیگنال، نیمی جهتِ مخالف (فروش/خرید هر دو تست شود)
        if scenario_i % 2 == 1:
            d = "SHORT" if d == "LONG" else "LONG"
        p = sig.get("plan") or {}
        plan = {"entry": p.get("entry") or sig["price"],
                "stop_loss": p.get("stop_loss") or (sig["price"] * (0.99 if d == "LONG" else 1.01)),
                "take_profits": p.get("take_profits") or [
                    {"price": sig["price"] * (1.01 if d == "LONG" else 0.99)},
                    {"price": sig["price"] * (1.02 if d == "LONG" else 0.98)},
                    {"price": sig["price"] * (1.03 if d == "LONG" else 0.97)}]}
        # اگر جهت را برعکس کردیم، نقشه را آینه کن تا ترتیبِ TP/SL معتبر بماند
        if d != sig["direction"] and sig["direction"] != "NEUTRAL":
            e = plan["entry"]
            plan = {"entry": e,
                    "stop_loss": 2 * e - plan["stop_loss"],
                    "take_profits": [{"price": 2 * e - t["price"]} for t in plan["take_profits"]]}
        ov = {"tp_mode": tp_modes[scenario_i % 4], "execution": execs[scenario_i % 2],
              "risk_mode": "risk_pct" if scenario_i % 5 == 0 else "fixed",
              "risk_pct": 1.0 + (scenario_i % 3)}
        vol = vols[scenario_i % len(vols)]
        st, r = send_dry(sym, d, plan, vol, ov)
        trades += 1
        scenario_i += 1
        tag = f"{sym}/{tf} {d} v{vol} {ov['tp_mode']}/{ov['execution']}"
        check(f"[{trades}] {tag}: پاسخ ۲۰۰ و ok", st == 200 and r.get("ok") is True,
              f"st={st} err={r.get('error')}")
        if not r.get("ok"):
            continue
        check(f"[{trades}] {tag}: dry_run است", r.get("dry_run") is True, r)
        pl = r.get("planned") or {}
        check(f"[{trades}] {tag}: حجمِ برنامه == درخواستی", abs((pl.get("volume") or 0) - vol) < 1e-9,
              pl.get("volume"))
        check(f"[{trades}] {tag}: tp_mode/execution منعکس شد",
              pl.get("tp_mode") == ov["tp_mode"] and pl.get("execution") == ov["execution"], pl)
        # نکتهٔ طراحی: /api/mt5/send نقشه را خودش از سیگنالِ زنده می‌سازد (و برای
        # جهتِ اجباریِ مخالف، نقشهٔ همان جهت را از نو می‌سازد). پس معیارِ درست،
        # «سازگاریِ درونیِ نقشهٔ سرور» است نه برابری با نقشهٔ ارسالیِ ما.
        e_, sl_, tps_ = pl.get("entry"), pl.get("sl"), pl.get("tps") or []
        check(f"[{trades}] {tag}: نقشهٔ سرور کامل است (entry/sl/3TP)",
              e_ is not None and sl_ is not None and len(tps_) == 3, pl)
        if e_ is not None and sl_ is not None and len(tps_) == 3:
            if d == "LONG":
                check(f"[{trades}] {tag}: ترتیبِ LONG: sl<entry<tp1<tp2<tp3",
                      sl_ < e_ < tps_[0] < tps_[1] < tps_[2],
                      f"sl={sl_} e={e_} tps={tps_}")
            else:
                check(f"[{trades}] {tag}: ترتیبِ SHORT: tp3<tp2<tp1<entry<sl",
                      tps_[2] < tps_[1] < tps_[0] < e_ < sl_,
                      f"sl={sl_} e={e_} tps={tps_}")
            dev = abs(e_ - sig["price"]) / sig["price"] * 100
            check(f"[{trades}] {tag}: ورودِ نقشهٔ سرور نزدیکِ قیمت (<8%)", dev < 8,
                  f"entry={e_} price={sig['price']} dev={dev:.2f}%")

    # ---------- فاز ۲: ۶۰ سفارشِ ربات (test=true) با دادهٔ واقعی ----------
    print("\n[فاز ۲] سفارش‌های ربات (robot/order test) — تا معاملهٔ ۱۸۰")
    ri = 0
    while trades < 180:
        sym, tf = list(sigs.keys())[ri % len(sigs)]
        sig = sigs[(sym, tf)]
        live_d = sig["direction"]
        # سه حالت: هم‌سو / مخالف / بدونِ tf (پیش‌فرض)
        mode = ri % 3
        d = live_d if live_d != "NEUTRAL" else "LONG"
        if mode == 1:
            d = "SHORT" if d == "LONG" else "LONG"
        px = sig["price"]
        body = {"symbol": sym, "direction": "BUY" if d == "LONG" else "SELL",
                "volume": round(0.01 + (ri % 7) * 0.02, 2),
                "sl": px * (0.99 if d == "LONG" else 1.01),
                "tp1": px * (1.005 if d == "LONG" else 0.995),
                "tp2": px * (1.01 if d == "LONG" else 0.99),
                "tp3": px * (1.02 if d == "LONG" else 0.98),
                "tf": tf if mode != 2 else None,
                "robot_id": f"T200-{ri}", "platform": "python"}
        st, r = robot_order(body)
        trades += 1
        ri += 1
        tag = f"{sym}/{tf} {body['direction']} ربات"
        check(f"[{trades}] {tag}: پاسخ ۲۰۰", st == 200 and isinstance(r, dict),
              f"st={st} {str(r)[:120]}")
        if st != 200:
            continue
        ev = r.get("eval") or {}
        o = r.get("order") or {}
        check(f"[{trades}] {tag}: حجم/SL/TPها دقیقاً حفظ شد",
              abs((o.get("volume") or 0) - body["volume"]) < 1e-9
              and abs((o.get("sl") or 0) - body["sl"]) < 1e-9
              and len(o.get("tps") or []) == 3, o)
        if mode != 2:
            check(f"[{trades}] {tag}: ارزیابی روی tf درخواستی", ev.get("tf") == tf, ev.get("tf"))
        idir = (ev.get("internal") or {}).get("direction")
        if r.get("approved"):
            check(f"[{trades}] {tag}: تأیید ⇒ جهتِ داخلی هم‌سو",
                  idir == d, f"internal={idir} order={d}")
            check(f"[{trades}] {tag}: تأیید ⇒ ارسالِ شبیه‌سازی‌شده",
                  r.get("forwarded") is True and r.get("simulated") is True, r.get("forward"))
            fw = r.get("forward") or {}
            check(f"[{trades}] {tag}: forward جهت/حجمِ درست",
                  fw.get("direction") == d and fw.get("dry_run") is True, fw)
        else:
            reasons = ev.get("reasons") or [r.get("error")]
            check(f"[{trades}] {tag}: رد ⇒ دلیلِ روشن", bool(reasons and reasons[0]), r)

    # ---------- فاز ۳: ۲۰ معاملهٔ مرزی/خراب (باید مؤدبانه رد شوند) ----------
    print("\n[فاز ۳] ورودی‌های مرزی و خراب — تا معاملهٔ ۲۰۰")
    edge_bodies = [
        {"symbol": "BTC", "direction": "BUY"},                          # بدونِ حجم
        {"symbol": "", "direction": "SELL", "volume": 0.1},             # بدونِ نماد
        {"symbol": "BTC", "direction": "HOLD", "volume": 0.1},          # جهتِ نامعتبر
        {"symbol": "BTC", "direction": "BUY", "volume": -1},            # حجمِ منفی
        {"symbol": "BTC", "direction": "BUY", "volume": "abc"},         # حجمِ غیرعددی
    ]
    for k in range(20):
        eb = dict(edge_bodies[k % len(edge_bodies)])
        # ده موردِ اول روی مسیرِ آزمایش، ده موردِ بعد روی مسیرِ واقعیِ ربات
        st, r = robot_order(eb, test=(k < 10))
        trades += 1
        ok_shape = st in (200, 400) and isinstance(r, dict) and (
            r.get("error") or (r.get("eval") or {}).get("reasons") or r.get("approved") is False)
        check(f"[{trades}] مرزی#{k % 5}: ردِ مؤدبانه (بدونِ ۵۰۰)", ok_shape,
              f"st={st} {str(r)[:150]}")

    # ---------- جمع‌بندی ----------
    http("POST", "/api/robot/config", {
        "filter_mode": "both", "require_direction_match": True,
        "min_internal_score": 15, "min_ai_score": 15,
        "auto_forward": True, "conflict_guard_enabled": True, "enabled": True})
    http("POST", "/api/dispatch/config", {"news_filter_enabled": True})
    http("DELETE", "/api/robot/log")
    print("\n" + "=" * 66)
    print(f"  معاملاتِ اجراشده: {trades} · نتیجه: {PASS} پاس · {FAIL} ناموفق")
    print("=" * 66)
    sys.exit(1 if FAIL else 0)


if __name__ == "__main__":
    main()
