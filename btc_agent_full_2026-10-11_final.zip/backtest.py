"""بک‌تست استراتژی روی داده تاریخی.

استراتژی بر پایه امتیاز تکنیکال (همان منطق موتور زنده) است. در هر کندل امتیاز
تکنیکال محاسبه می‌شود؛ اگر از آستانه عبور کند و پوزیشن باز نباشد، معامله باز
می‌شود. ورود = قیمت بسته‌شدن، استاپ = ۱.۵×ATR، هدف = ۳×ATR (معادل TP2 موتور).
سپس روی کندل‌های بعدی بررسی می‌شود که ابتدا استاپ خورده یا هدف.

نکته: تحلیل فاندامنتال و سنتیمنتال چون فقط لحظه‌ای در دسترس‌اند در بک‌تست
تاریخی لحاظ نمی‌شوند و بک‌تست صرفاً بخش تکنیکال را می‌سنجد.
"""
from __future__ import annotations
import numpy as np
import pandas as pd

import indicators as ind
import data_sources as ds


def _dec(price):
    """اعشار پویا برای گِرد کردن قیمت‌ها (فارکس/ین/کریپتو با بزرگی متفاوت).

    به منبعِ حقیقتِ واحدِ indicators.price_decimals واگذار می‌شود تا اعشارِ
    گزارشِ بک‌تست دقیقاً با موتورِ سیگنال و اندیکاتورها هماهنگ باشد
    (پیش‌تر بازهٔ ≥۱۰۰ سه‌رقمی بود و با بقیه ناسازگار می‌شد).
    """
    return ind.price_decimals(price)


_SCORE_CACHE: dict = {}   # کشِ سریِ امتیاز تکنیکال (کلید → Series)


def _technical_score_series(df):
    """امتیاز تکنیکال برای هر کندل — آینهٔ علّیِ موتورِ زنده (اصلاحِ OP5-BT-SCALE).

    پیش‌تر این تابع فقط ۸ بلوک از ۱۶ بلوکِ موتورِ زنده را داشت و بر ۷٫۶ نرمال
    می‌کرد؛ یعنی مقیاسِ امتیازِ بک‌تست با اجرای زنده (۱۴٫۴) یکی نبود و آستانه‌های
    بهینه‌ساز (۱۵..۳۵) قابلِ انتقال به اجرای زنده نبودند. اکنون:

      • همان ۱۶ بلوکِ engine.TECH_WEIGHTS با همان منطقِ موتورِ زنده محاسبه می‌شود،
      • هر کندل فقط با دادهٔ «تا خودش» (کاملاً علّی/causal) امتیاز می‌گیرد — بدونِ
        نگاه به آینده،
      • نرمال‌سازی بر engine.TECH_MAX_WEIGHT انجام می‌شود.
    """
    import engine as _eng
    W = _eng.TECH_WEIGHTS
    NORM = _eng.TECH_MAX_WEIGHT or 14.4

    # --- کشِ سریِ امتیاز (بهینه‌ساز همان دیتافریم را ۴۰ بار اجرا می‌کند) ---
    try:
        _ck = (len(df), int(df["time"].iloc[0]), int(df["time"].iloc[-1]),
               round(float(df["close"].iloc[-1]), 6), round(float(df["close"].iloc[0]), 6))
    except Exception:  # noqa
        _ck = None
    if _ck is not None and _ck in _SCORE_CACHE:
        return _SCORE_CACHE[_ck].copy()

    n = len(df)
    idx = df.index
    if n == 0:
        return pd.Series(dtype=float, index=idx)
    c = df["close"].to_numpy(dtype=float)
    h = df["high"].to_numpy(dtype=float)
    l = df["low"].to_numpy(dtype=float)
    cs = df["close"]

    # --- سری‌های برداری (فقط دادهٔ ≤ هر کندل مصرف می‌شود؛ خروجی علّی است) ---
    ema20 = ind.ema(cs, 20).to_numpy(dtype=float)
    ema50 = ind.ema(cs, 50).to_numpy(dtype=float)
    ema200 = (ind.ema(cs, 200) if n >= 200 else ind.ema(cs, min(n - 1, 100))).to_numpy(dtype=float)
    rsi_v = ind.rsi(cs, 14).to_numpy(dtype=float)
    _, _, hist = ind.macd(cs)
    hist_v = hist.to_numpy(dtype=float)
    up_b, _, low_b = ind.bollinger(cs)
    up_v = up_b.to_numpy(dtype=float)
    low_v = low_b.to_numpy(dtype=float)
    k_v, d_v = (x.to_numpy(dtype=float) for x in ind.stochastic(df))
    adx_v, pdi_v, mdi_v = (x.to_numpy(dtype=float) for x in ind.adx(df, 14))
    tenkan, kijun, senkou_a, senkou_b = (x.to_numpy(dtype=float) for x in ind.ichimoku(df))
    atr_v = ind.atr(df, 14).to_numpy(dtype=float)
    tr_floor = pd.Series(h - l, index=idx).rolling(14, min_periods=1).mean().to_numpy(dtype=float)

    # --- پیوت‌های تأییدشده (lag = کندل‌های سمتِ راست) ---
    ph5 = ind._swing_idx(h, 5, 5, "high")
    pl5 = ind._swing_idx(l, 5, 5, "low")
    ph3 = ind._swing_idx(h, 3, 3, "high")
    pl3 = ind._swing_idx(l, 3, 3, "low")

    # --- گروه‌بندیِ روزانه/هفتگی (برای پیوت و PDH/PDL) ---
    dt = pd.to_datetime(df["time"], unit="ms")
    dkey = dt.dt.strftime("%Y-%m-%d").to_numpy()
    wkey = dt.dt.strftime("%G-W%V").to_numpy()
    day_hlc: dict = {}
    week_hlc: dict = {}
    day_order: list = []
    week_order: list = []

    # خلاصهٔ روزها را یک‌بار از پیش می‌سازیم: دیکشنری روز → H/L/C کامل
    for i in range(n):
        dd, ww = dkey[i], wkey[i]
        if day_order and day_order[-1] == dd:
            cur = day_hlc[dd]
            cur["h"] = max(cur["h"], h[i]); cur["l"] = min(cur["l"], l[i]); cur["c"] = c[i]
        else:
            day_hlc[dd] = {"h": h[i], "l": l[i], "c": c[i]}; day_order.append(dd)
        if week_order and week_order[-1] == ww:
            cur = week_hlc[ww]
            cur["h"] = max(cur["h"], h[i]); cur["l"] = min(cur["l"], l[i]); cur["c"] = c[i]
        else:
            week_hlc[ww] = {"h": h[i], "l": l[i], "c": c[i]}; week_order.append(ww)
    day_pos = {d: j for j, d in enumerate(day_order)}
    week_pos = {w: j for j, w in enumerate(week_order)}
    day_first_bar: dict = {}
    for i in range(n):
        day_first_bar.setdefault(dkey[i], i)

    # --- وضعیتِ تجمعیِ بلوک‌های مسیرمحور ---
    open_gaps: list = []          # FVGهای پُرنشده: {"kind","top","bottom","born"}
    zig: list = []                # زیگزاگ ساختار (پیوت‌های متناوب)
    res_streak = {"ph": [], "pl": []}

    score = np.zeros(n, dtype=float)
    for i in range(n):
        price = c[i]
        ssum = 0.0

        # ۱) روند EMA20/50
        if price > ema50[i] and ema20[i] > ema50[i]:
            ssum += W["ema_trend"]
        elif price < ema50[i] and ema20[i] < ema50[i]:
            ssum -= W["ema_trend"]

        # ۲) بایاسِ EMA200
        ssum += W["ema200"] if price > ema200[i] else -W["ema200"]

        # ۳) RSI (دورهٔ گرم‌شدن → خنثی)
        if np.isfinite(rsi_v[i]):
            if rsi_v[i] < 30 or rsi_v[i] >= 50:
                ssum += W["rsi"]
            else:
                ssum -= W["rsi"]

        # ۴) MACD
        ssum += W["macd"] if hist_v[i] > 0 else -W["macd"]

        # ۵) Stochastic
        if k_v[i] < 20:
            ssum += W["stoch"]
        elif k_v[i] > 80:
            ssum -= W["stoch"]
        else:
            ssum += W["stoch"] if k_v[i] > d_v[i] else -W["stoch"]

        # ۶) بولینگر
        if np.isfinite(low_v[i]) and np.isfinite(up_v[i]):
            if price <= low_v[i]:
                ssum += W["bollinger"]
            elif price >= up_v[i]:
                ssum -= W["bollinger"]

        # ۷) ADX + DI
        if np.isfinite(adx_v[i]) and adx_v[i] >= 20:
            ssum += W["adx"] if pdi_v[i] > mdi_v[i] else -W["adx"]

        # ۸) ایچیموکو
        sa, sb = senkou_a[i], senkou_b[i]
        if np.isfinite(sa) and np.isfinite(sb):
            ctop, cbot = max(sa, sb), min(sa, sb)
            if price > ctop and tenkan[i] > kijun[i]:
                ssum += W["ichimoku"]
            elif price < cbot and tenkan[i] < kijun[i]:
                ssum -= W["ichimoku"]
            elif price > ctop:
                ssum += W["ichimoku"]
            elif price < cbot:
                ssum -= W["ichimoku"]

        # ۹) فیبوناچی (آخرین جفتِ پیوتِ متضاد در پنجرهٔ ۹۰ کندلی)
        if i >= 6:
            lo_bound = max(0, i + 1 - 90) + 3
            hi_bound = i - 3
            pts = [(x, h[x], "H") for x in ph3 if lo_bound <= x <= hi_bound]
            pts += [(x, l[x], "L") for x in pl3 if lo_bound <= x <= hi_bound]
            pts.sort(key=lambda t: t[0])
            if len(pts) >= 2 and pts[-1][2] != pts[-2][2]:
                (i1, v1, k1), (_, v2, _) = pts[-2], pts[-1]
                if k1 == "L":       # کفِ تأییدشده سپس سقف → موجِ صعودی
                    up_leg, s_low, s_high = True, float(v1), float(v2)
                else:
                    up_leg, s_low, s_high = False, float(v2), float(v1)
                rng = s_high - s_low
                if rng > 0:
                    pr = ((s_high - price) / rng) if up_leg else ((price - s_low) / rng)
                    pr = max(-1.0, min(2.0, pr))
                    if up_leg:
                        if pr <= 0.786:
                            ssum += W["fib"]
                        else:
                            ssum -= W["fib"]
                    else:
                        if pr <= 0.786:
                            ssum -= W["fib"]
                        else:
                            ssum += W["fib"]

        # ۱۰) نواحیِ حمایت/مقاومت (ادغامِ پیوت‌های ۱۱کندلی + آستانهٔ ۰٫۶×ATR)
        atr_i = atr_v[i] if np.isfinite(atr_v[i]) else tr_floor[i]
        ph_ok = [h[x] for x in ph5 if x + 5 <= i]
        pl_ok = [l[x] for x in pl5 if x + 5 <= i]
        if (len(ph_ok) or len(pl_ok)) and (i + 1) >= 12:
            tol = max(atr_i * 0.6, price * 0.0015)
            def _cluster(points):
                zones = []
                for p in sorted(points):
                    if zones and abs(p - (zones[-1]["_s"] / zones[-1]["n"])) <= tol:
                        z = zones[-1]; z["_s"] += p; z["n"] += 1
                        z["low"] = min(z["low"], p); z["high"] = max(z["high"], p)
                    else:
                        zones.append({"_s": p, "n": 1, "low": p, "high": p})
                return [z["_s"] / z["n"] for z in zones]
            sup_c = [p for p in _cluster(pl_ok) if p < price]
            res_c = [p for p in _cluster(ph_ok) if p > price]
            near_sup = max(sup_c) if sup_c else None
            near_res = min(res_c) if res_c else None
            thr = 0.6 * atr_i if atr_i else price * 0.003
            dsu = abs(price - near_sup) if near_sup is not None else 1e18
            dru = abs(near_res - price) if near_res is not None else 1e18
            if near_sup is not None and dsu <= thr and dsu <= dru:
                ssum += W["zones"]
            elif near_res is not None and dru <= thr:
                ssum -= W["zones"]

        # ۱۱) پیوتِ کلاسیک + ۱۲) PDH/PDL (روزِ کاملِ قبلی؛ در نبود، هفتهٔ قبل)
        dd, ww = dkey[i], wkey[i]
        pd_ = day_pos[dd]
        prev_day = day_order[pd_ - 1] if pd_ >= 1 else None
        pw_ = week_pos[ww]
        prev_week = week_order[pw_ - 1] if pw_ >= 1 else None
        if prev_day is not None:
            ph_d, pl_d, pc_d = day_hlc[prev_day]["h"], day_hlc[prev_day]["l"], day_hlc[prev_day]["c"]
            P = (ph_d + pl_d + pc_d) / 3.0
            ssum += W["pivot"] if price > P else -W["pivot"]
            if price > ph_d:
                ssum += W["daily"]
            elif price < pl_d:
                ssum -= W["daily"]
        elif prev_week is not None:
            wk = week_hlc[prev_week]
            P = (wk["h"] + wk["l"] + wk["c"]) / 3.0
            ssum += W["pivot"] if price > P else -W["pivot"]

        # ۱۳) تِرندلاین (برازشِ آخرین ۳ پیوتِ ۸۰ کندلِ اخیر)
        start80 = max(0, i + 1 - 80)
        sup_fit = res_fit = None
        lows_in = [x for x in pl3 if start80 + 3 <= x <= i - 3]
        highs_in = [x for x in ph3 if start80 + 3 <= x <= i - 3]
        for arr, fit_kind in ((lows_in, "sup"), (highs_in, "res")):
            if len(arr) >= 2:
                pts = arr[-3:]
                xs = np.array(pts, dtype=float)
                ys = h[xs.astype(int)] if fit_kind == "res" else l[xs.astype(int)]
                slope, intercept = np.polyfit(xs, ys.astype(float), 1)
                val = float(slope * i + intercept)
                if fit_kind == "sup":
                    sup_fit = {"slope": float(slope), "value": val}
                else:
                    res_fit = {"slope": float(slope), "value": val}
        if sup_fit or res_fit:
            tdir = 0
            if (sup_fit and res_fit and sup_fit["slope"] > 0 and res_fit["slope"] > 0):
                tdir = 1
            elif (sup_fit and res_fit and sup_fit["slope"] < 0 and res_fit["slope"] < 0):
                tdir = -1
            if sup_fit and price < sup_fit["value"]:
                tdir = -1
            elif res_fit and price > res_fit["value"]:
                tdir = 1
            ssum += tdir * W["trendline"]

        # ۱۴) لیکوئیدیتی (جاروی ۹۰ کندلی)
        start90 = max(0, i + 1 - 90)
        if i - 1 > start90:
            prior_hi = float(np.max(h[start90:i - 1]))
            prior_lo = float(np.min(l[start90:i - 1]))
            last_hi = float(np.max(h[i - 1:i + 1]))
            last_lo = float(np.min(l[i - 1:i + 1]))
            if last_hi > prior_hi and c[i] < prior_hi:
                ssum -= W["liquidity"]
            elif last_lo < prior_lo and c[i] > prior_lo:
                ssum += W["liquidity"]

        # ۱۵) FVG (گپِ پُرنشده در پنجرهٔ ۴۰ کندلی)
        if i >= 2:
            for g in open_gaps:
                if g["kind"] == "bull" and l[i] <= g["bottom"]:
                    g["filled"] = True
                elif g["kind"] == "bear" and h[i] >= g["top"]:
                    g["filled"] = True
            if l[i] > h[i - 2]:
                open_gaps.append({"kind": "bull", "top": float(l[i]),
                                  "bottom": float(h[i - 2]), "born": i})
            elif h[i] < l[i - 2]:
                open_gaps.append({"kind": "bear", "top": float(l[i - 2]),
                                  "bottom": float(h[i]), "born": i})
            horizon = max(2, i + 1 - 40)
            open_gaps = [g for g in open_gaps if not g.get("filled") and g.get("born", 0) >= horizon]
            below = [g for g in open_gaps if g["kind"] == "bull" and g["top"] <= price]
            above = [g for g in open_gaps if g["kind"] == "bear" and g["bottom"] >= price]
            ns = max(below, key=lambda g: g["top"]) if below else None
            nr = min(above, key=lambda g: g["bottom"]) if above else None
            if ns and not nr:
                ssum += W["fvg"]
            elif nr and not ns:
                ssum -= W["fvg"]
            elif ns and nr:
                if abs(price - ns["top"]) <= abs(nr["bottom"] - price):
                    ssum += W["fvg"]
                else:
                    ssum -= W["fvg"]

        # ۱۶) ساختارِ بازار: BOS/CHOCH از زیگزاگِ پیوت‌ها (پنجرهٔ ۱۲۰ کندل — آینهٔ دقیقِ
        # ind.market_structure که هر بار از نو ساخته می‌شود تا با موتورِ زنده یکی بماند)
        zz = []
        pts_all = ([(x, float(h[x]), "H") for x in ph3] + [(x, float(l[x]), "L") for x in pl3])
        start120 = max(0, i + 1 - 120)
        pts_all = sorted([t for t in pts_all if t[0] + 3 <= i and t[0] >= start120],
                         key=lambda t: t[0])
        for x, pv, kind in pts_all:
            if not zz:
                zz.append({"idx": x, "price": pv, "kind": kind})
                continue
            if kind == zz[-1]["kind"]:
                if kind == "H" and pv >= zz[-1]["price"]:
                    zz[-1] = {"idx": x, "price": pv, "kind": kind}
                elif kind == "L" and pv <= zz[-1]["price"]:
                    zz[-1] = {"idx": x, "price": pv, "kind": kind}
            else:
                zz.append({"idx": x, "price": pv, "kind": kind})
        hs = [p for p in zz if p["kind"] == "H"]
        ls = [p for p in zz if p["kind"] == "L"]
        if len(zz) >= 2 and hs and ls:
            trend = None
            ph_p = pl_p = None
            for p in zz:
                if p["kind"] == "H":
                    if ph_p is not None and p["price"] > ph_p:
                        trend = "up"
                    ph_p = p["price"]
                else:
                    if pl_p is not None and p["price"] < pl_p:
                        trend = "down"
                    pl_p = p["price"]
            if trend is None:
                lh = "H" if len(hs) < 2 else ("HH" if hs[-1]["price"] > hs[-2]["price"] else "LH")
                ll = "L" if len(ls) < 2 else ("HL" if ls[-1]["price"] > ls[-2]["price"] else "LL")
                if lh == "HH" and ll == "HL":
                    trend = "up"
                elif lh == "LH" and ll == "LL":
                    trend = "down"
                else:
                    trend = "range"
            last_H, last_L = hs[-1]["price"], ls[-1]["price"]
            if price > last_H:
                if trend == "down":
                    ssum += 0.7
                else:
                    ssum += W["structure"]
            elif price < last_L:
                if trend == "up":
                    ssum -= 0.7
                else:
                    ssum -= W["structure"]

        score[i] = float(np.clip(ssum / NORM * 100.0, -100.0, 100.0))

    _out = pd.Series(score, index=idx)
    if _ck is not None:
        if len(_SCORE_CACHE) >= 4:
            _SCORE_CACHE.clear()
        _SCORE_CACHE[_ck] = _out
    return _out.copy()


def run_backtest(symbol="BTC", interval="1h", bars=800,
                 threshold=25.0, atr_mult_sl=1.5, atr_mult_tp=3.0,
                 allow_short=True, df=None,
                 spread=0.0, slippage=0.0, commission_pct=0.0):
    """بک‌تست با مدلِ هزینهٔ واقعی (اصلاحِ OP5-BT-COST).

    spread: کلِ اسپرد (واحدِ قیمت) — نصفش در ورود و نصفش در خروج کسر می‌شود.
    slippage: لغزشِ هر سمت (واحدِ قیمت) — در ورود و در خروج‌های بازاری.
    commission_pct: کمیسیونِ هر سمت به‌صورتِ کسری از نوشنال (مثلاً 0.0004 = ۴bp).
    پیش‌تر بک‌تست بدونِ هیچ هزینه‌ای اجرا می‌شد و سود را خوش‌بینانه نشان می‌داد.
    """
    if df is None:
        df = ds.get_history(symbol, interval, bars)
    df = df.reset_index(drop=True)
    if len(df) < 120:
        raise RuntimeError("داده تاریخی کافی برای بک‌تست موجود نیست")
    return run_backtest_df(df, symbol, interval, threshold=threshold,
                           atr_mult_sl=atr_mult_sl, atr_mult_tp=atr_mult_tp,
                           allow_short=allow_short,
                           spread=spread, slippage=slippage, commission_pct=commission_pct)


def run_backtest_df(df, symbol="BTC", interval="1h",
                    threshold=25.0, atr_mult_sl=1.5, atr_mult_tp=3.0,
                    allow_short=True, initial_deposit=10000.0, risk_pct=1.0,
                    spread=0.0, slippage=0.0, commission_pct=0.0):
    """اجرای بک‌تست روی یک DataFrame از پیش دریافت‌شده (برای بهینه‌سازی سریع).

    initial_deposit: موجودی اولیهٔ حساب (دلار). risk_pct: درصد ریسک روی موجودیِ
    جاری در هر معامله (کامپاند). سود هر معامله = ریسکِ دلاری × R.
    """
    df = df.reset_index(drop=True)
    atr = ind.atr(df, 14).values
    tscore = _technical_score_series(df).values
    high = df["high"].values
    low = df["low"].values
    close = df["close"].values
    open_ = df["open"].values if "open" in df.columns else df["close"].values
    times = df["time"].values

    # اصلاح (BACKTEST-001): inf از گاردِ <=0 عبور می‌کرد و ضرایبِ ATR منفی/غیرهانتم
    # اصلاً اعتبارسنجی نمی‌شدند؛ همه با fallback امن مهار می‌شوند.
    import math as _m
    try:
        initial_deposit = float(initial_deposit)
    except Exception:  # noqa
        initial_deposit = 10000.0
    if not _m.isfinite(initial_deposit) or initial_deposit <= 0:
        initial_deposit = 10000.0
    try:
        risk_pct = float(risk_pct)
    except Exception:  # noqa
        risk_pct = 1.0
    if not _m.isfinite(risk_pct) or not (0 < risk_pct <= 100):
        risk_pct = 1.0
    try:
        atr_mult_sl = float(atr_mult_sl)
    except Exception:  # noqa
        atr_mult_sl = 1.5
    if not _m.isfinite(atr_mult_sl) or atr_mult_sl <= 0:
        atr_mult_sl = 1.5
    try:
        atr_mult_tp = float(atr_mult_tp)
    except Exception:  # noqa
        atr_mult_tp = 3.0
    if not _m.isfinite(atr_mult_tp) or atr_mult_tp <= 0:
        atr_mult_tp = 3.0

    # --- اعتبارسنجیِ پارامترهای هزینه (اصلاحِ OP5-BT-COST) ---
    def _num(v, fb, lo=None, hi=None):
        try:
            x = float(v)
        except (TypeError, ValueError):
            return fb
        if not _m.isfinite(x):
            return fb
        if lo is not None and x < lo:
            return fb
        if hi is not None and x > hi:
            return fb
        return x

    spread = _num(spread, 0.0, lo=0.0)
    slippage = _num(slippage, 0.0, lo=0.0)
    commission_pct = _num(commission_pct, 0.0, lo=0.0, hi=0.05)   # سقفِ ۵٪ برای جلوگیری از ورودیِ غلط
    _cost_half = spread / 2.0
    _round_trip = spread + 2.0 * slippage   # هزینهٔ قیمتیِ رفت‌وبرگشت (نمایشی)

    warmup = 50
    trades = []
    equity = []           # منحنی سرمایه: [{t, balance, r}]
    cum_r = 0.0
    balance = initial_deposit
    equity.append({"t": int(times[warmup]) if warmup < len(times) else int(times[0]),
                   "balance": round(balance, 2), "r": 0.0})
    i = warmup
    n = len(df)

    while i < n - 1:
        s = tscore[i]
        direction = None
        if s >= threshold:
            direction = "LONG"
        elif s <= -threshold and allow_short:
            direction = "SHORT"

        if direction is None:
            i += 1
            continue

        a = atr[i]
        if not np.isfinite(a) or a <= 0:
            i += 1
            continue

        # --- ورود در «بازِ کندلِ بعد» (اصلاحِ OP5-BT-ENTRY) ---
        # سیگنال با بسته‌شدن کندلِ i نهایی می‌شود؛ پرکردن در close[i] عملاً
        # معامله با قیمتی بود که در لحظهٔ تصمیم دیگر قابلِ دسترسی نیست. اکنون
        # ورود روی open کندلِ i+1 با هزینهٔ اسپرد/لغزش (به‌صورتِ نامطلوب) است.
        if i + 1 >= n:
            break
        raw_open = open_[i + 1]
        entry_bar = i + 1
        _entry_cost = _cost_half + slippage
        if direction == "LONG":
            entry = raw_open + _entry_cost
        else:
            entry = raw_open - _entry_cost

        if direction == "LONG":
            sl = entry - atr_mult_sl * a
            tp = entry + atr_mult_tp * a
        else:
            sl = entry + atr_mult_sl * a
            tp = entry - atr_mult_tp * a

        risk = abs(entry - sl)
        if risk <= 0:
            i = entry_bar + 1
            continue
        outcome, exit_price, exit_i = None, None, None

        for j in range(entry_bar, n):
            hi, lo, op = high[j], low[j], open_[j]
            # --- پرکردنِ گپ (اصلاحِ OP5-BT-GAP): اگر کندل آن‌سوی سطح باز شود،
            # پرکردن با «بازِ» کندل انجام می‌شود (بدتر برای استاپ، بهتر برای هدف).
            if direction == "LONG":
                if j > entry_bar and op <= sl:
                    outcome, exit_price, exit_i = "loss", op, j
                    break
                if j > entry_bar and op >= tp:
                    outcome, exit_price, exit_i = "win", op, j
                    break
                hit_sl = lo <= sl
                hit_tp = hi >= tp
            else:
                if j > entry_bar and op >= sl:
                    outcome, exit_price, exit_i = "loss", op, j
                    break
                if j > entry_bar and op <= tp:
                    outcome, exit_price, exit_i = "win", op, j
                    break
                hit_sl = hi >= sl
                hit_tp = lo <= tp
            if hit_sl and hit_tp:      # هر دو در یک کندل → محافظه‌کارانه: استاپ
                outcome, exit_price, exit_i = "loss", sl, j
                break
            if hit_sl:
                outcome, exit_price, exit_i = "loss", sl, j
                break
            if hit_tp:
                outcome, exit_price, exit_i = "win", tp, j
                break

        if outcome is None:            # تا انتها بسته نشد → با آخرین قیمت خروج
            exit_price, exit_i = close[-1], n - 1
            outcome = "open_end"

        # --- هزینهٔ خروج: استاپ/خروجِ بازاری هزینهٔ رفت‌وبرگشت را می‌پردازد؛
        # پرکردنِ حدِ سود به‌صورتِ سفارشِ لیمیت انجام می‌شود (بدونِ لغزش — فقط
        # نصفِ اسپرد که پیش‌تر در ورود لحاظ شده کافی است).
        if outcome == "win":
            exit_net = float(exit_price)
        else:
            _xcost = _cost_half + slippage
            exit_net = float(exit_price) - _xcost if direction == "LONG" else float(exit_price) + _xcost

        r_mult = ((exit_net - entry) if direction == "LONG" else (entry - exit_net)) / risk
        if outcome == "win" and not np.isfinite(r_mult):
            r_mult = atr_mult_tp / atr_mult_sl

        cum_r += r_mult
        # سود/زیانِ دلاری با کامپاند: ریسکِ هر معامله = درصد ریسک × موجودیِ جاری
        risk_amount = balance * (risk_pct / 100.0)
        # کمیسیون: کسری از نوشنال، دو سمت (واحد = ریسکِ دلاری ÷ ریسکِ قیمتی)
        units = (risk_amount / risk) if risk > 0 else 0.0
        commission_money = 2.0 * commission_pct * units * abs(entry)
        profit = risk_amount * r_mult - commission_money
        balance += profit
        pdec = _dec(entry)
        trades.append({
            "dir": direction,
            "entry": round(float(entry), pdec),
            "exit": round(float(exit_price), pdec),
            "sl": round(float(sl), pdec),
            "tp": round(float(tp), pdec),
            "outcome": outcome,
            "r": round(float(r_mult), 2),
            "profit": round(float(profit), 2),
            "balance": round(float(balance), 2),
            "commission": round(float(commission_money), 2),
            "t_in": int(times[entry_bar]),
            "t_out": int(times[exit_i]),
        })
        equity.append({"t": int(times[exit_i]), "balance": round(balance, 2),
                       "r": round(cum_r, 2)})

        i = exit_i + 1   # بعد از خروج، دنبال معامله بعدی

    # متریک‌ها
    wins = [t for t in trades if t["r"] > 0]
    losses = [t for t in trades if t["r"] <= 0]
    total = len(trades)
    win_rate = (len(wins) / total * 100) if total else 0
    gross_win = sum(t["r"] for t in wins)
    gross_loss = abs(sum(t["r"] for t in losses))
    # اصلاحِ OP5-BT-PF: پیش‌تر در نبودِ ضرر، PF برابرِ sum(Rِ بردها) برگردانده می‌شد
    # (می‌توانست ۱٫۴ یا ۲٫۱ باشد که «نسبت» نیست). اکنون سه حالتِ معنایی تفکیک شده:
    #   ضررِ صفر و بردِ صفر → None (تعریف‌نشده)،  ضررِ صفر و بردِ >۰ → None + پرچمِ
    #   profit_factor_infinite=True (بی‌نهایت، JSON-safe)، وگرنه نسبتِ واقعی.
    if gross_loss > 0:
        profit_factor = round(gross_win / gross_loss, 2)
        pf_inf = False
    else:
        profit_factor = None
        pf_inf = bool(gross_win > 0 and total > 0)

    # حداکثر افت سرمایه (max drawdown) روی منحنی R
    peak, max_dd = -1e9, 0.0
    for e in equity:
        peak = max(peak, e["r"])
        max_dd = max(max_dd, peak - e["r"])

    # ---- متریک‌های پولی به سبک متاتریدر ۵ ----
    gross_profit_money = sum(t["profit"] for t in wins)
    gross_loss_money = abs(sum(t["profit"] for t in losses))
    net_profit_money = balance - initial_deposit
    if gross_loss_money > 0:
        profit_factor_money = round(gross_profit_money / gross_loss_money, 2)
        pfm_inf = False
    else:
        profit_factor_money = None
        pfm_inf = bool(gross_profit_money > 0 and total > 0)
    ret_pct = (net_profit_money / initial_deposit * 100.0) if initial_deposit else 0.0
    expected_payoff = (net_profit_money / total) if total else 0.0

    # افت سرمایهٔ پولی روی منحنی موجودی
    peak_b, max_dd_money, max_dd_pct = -1e18, 0.0, 0.0
    for e in equity:
        peak_b = max(peak_b, e["balance"])
        dd = peak_b - e["balance"]
        if dd > max_dd_money:
            max_dd_money = dd
            max_dd_pct = (dd / peak_b * 100.0) if peak_b > 0 else 0.0

    win_profits = [t["profit"] for t in wins]
    loss_profits = [t["profit"] for t in losses]
    largest_win = max(win_profits) if win_profits else 0.0
    largest_loss = min(loss_profits) if loss_profits else 0.0
    avg_win_money = (sum(win_profits) / len(win_profits)) if win_profits else 0.0
    avg_loss_money = (sum(loss_profits) / len(loss_profits)) if loss_profits else 0.0

    # بیشترین بُردها/باخت‌های متوالی
    max_cons_win = max_cons_loss = 0
    cw = cl = 0
    for t in trades:
        if t["r"] > 0:
            cw += 1
            cl = 0
        else:
            cl += 1
            cw = 0
        max_cons_win = max(max_cons_win, cw)
        max_cons_loss = max(max_cons_loss, cl)

    return {
        "symbol": symbol.upper(),
        "interval": interval,
        "bars_tested": int(n),
        "params": {"threshold": threshold, "sl_atr": atr_mult_sl, "tp_atr": atr_mult_tp,
                   "allow_short": allow_short, "initial_deposit": round(initial_deposit, 2),
                   "risk_pct": risk_pct,
                   "spread": spread, "slippage": slippage, "commission_pct": commission_pct},
        "costs": {"spread": spread, "slippage": slippage, "commission_pct": commission_pct,
                  "round_trip_price_cost": round(_round_trip, 8),
                  "total_commission": round(sum(t.get("commission", 0.0) for t in trades), 2),
                  "net_profit_before_costs": float(round(net_profit_money + sum(t.get("commission", 0.0) for t in trades), 2))},
        "total_trades": total,
        "wins": len(wins),
        "losses": len(losses),
        "win_rate": round(win_rate, 1),
        "net_r": round(cum_r, 2),
        "profit_factor": profit_factor,
        "profit_factor_infinite": pf_inf,
        "avg_win_r": round(np.mean([t["r"] for t in wins]), 2) if wins else 0,
        "avg_loss_r": round(np.mean([t["r"] for t in losses]), 2) if losses else 0,
        "max_drawdown_r": round(max_dd, 2),
        # --- پولی به سبک MT5 ---
        "initial_deposit": round(initial_deposit, 2),
        "final_balance": round(balance, 2),
        "net_profit": round(net_profit_money, 2),
        "return_pct": round(ret_pct, 2),
        "gross_profit": round(gross_profit_money, 2),
        "gross_loss": round(gross_loss_money, 2),
        "profit_factor_money": profit_factor_money,
        "profit_factor_money_infinite": pfm_inf,
        "expected_payoff": round(expected_payoff, 2),
        "max_drawdown_money": round(max_dd_money, 2),
        "max_drawdown_pct": round(max_dd_pct, 2),
        "largest_win": round(largest_win, 2),
        "largest_loss": round(largest_loss, 2),
        "avg_win_money": round(avg_win_money, 2),
        "avg_loss_money": round(avg_loss_money, 2),
        "max_consecutive_wins": max_cons_win,
        "max_consecutive_losses": max_cons_loss,
        "equity": equity,
        "trades": trades[-40:],   # ۴۰ معامله آخر برای نمایش
        "source": df.attrs.get("source", "?"),
    }


if __name__ == "__main__":
    import json
    print(json.dumps(run_backtest("BTC", "1h"), ensure_ascii=False, indent=2)[:1500])
