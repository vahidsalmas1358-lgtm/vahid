"""بهینه‌سازی خودکار پارامترهای استراتژی با جست‌وجوی شبکه‌ای (grid search).

روی یک بار داده تاریخی، ترکیب‌های مختلف آستانه ورود، مضرب استاپ و مضرب هدف را
آزمایش کرده و بهترین‌ها را بر اساس معیار انتخابی مرتب می‌کند.
"""
from __future__ import annotations
import data_sources as ds
import backtest as bt

THRESHOLDS = [15, 20, 25, 30, 35]
SL_MULTS = [1.0, 1.5, 2.0]
TP_MULTS = [2.0, 3.0, 4.0]


def optimize(symbol="BTC", interval="1h", bars=800, allow_short=True,
             metric="net_r", min_trades=8, df=None,
             walk_forward=False, train_ratio=0.7,
             spread=0.0, slippage=0.0, commission_pct=0.0):
    """جست‌وجوی شبکه‌ای + اعتبارسنجیِ walk-forward (اصلاحِ OP5-OPT-WF).

    پیش‌تر «بهترین» ترکیب روی همان داده‌ای انتخاب می‌شد که ارزیابی می‌شد
    (overfit) و اگر هیچ ترکیبی به حداقلِ تعدادِ معامله نمی‌رسید، بی‌سروصدا روی
    همهٔ نتایج (حتی بی‌اعتبارها) تصمیم گرفته می‌شد. اکنون:
      • `min_trades_met` صریحاً گزارش می‌شود،
      • با walk_forward=True آموزش روی ۷۰٪ اول و آزمون روی ۳۰٪ آخر (با ۶۰ کندلِ
        هم‌پوشانیِ گرم‌شدنِ اندیکاتورها) انجام و نتیجهٔ آزمون گزارش می‌شود.
    """
    if df is None:
        df = ds.get_history(symbol, interval, bars)
    df = df.reset_index(drop=True)
    if len(df) < 120:
        raise RuntimeError("داده تاریخی کافی برای بهینه‌سازی موجود نیست")

    try:
        train_ratio = float(train_ratio)
    except (TypeError, ValueError):
        train_ratio = 0.7
    train_ratio = min(0.9, max(0.3, train_ratio))
    _split = int(len(df) * train_ratio) if walk_forward else len(df)
    _train_df = df.iloc[:_split].reset_index(drop=True) if walk_forward else df
    if walk_forward and len(_train_df) < 100:
        walk_forward = False
        _train_df = df

    results = []
    for th in THRESHOLDS:
        for sl in SL_MULTS:
            for tp in TP_MULTS:
                if tp <= sl:      # هدف باید بزرگ‌تر از استاپ باشد
                    continue
                r = bt.run_backtest_df(_train_df, symbol, interval, threshold=th,
                                       atr_mult_sl=sl, atr_mult_tp=tp,
                                       allow_short=allow_short,
                                       spread=spread, slippage=slippage,
                                       commission_pct=commission_pct)
                results.append({
                    "threshold": th, "sl_atr": sl, "tp_atr": tp,
                    "trades": int(r["total_trades"]), "win_rate": float(r["win_rate"]),
                    "net_r": float(r["net_r"]), "profit_factor": float(r["profit_factor"]),
                    "max_dd": float(r["max_drawdown_r"]),
                })

    # فقط ترکیب‌هایی با حداقل تعداد معامله معتبرند (شفاف و گزارش‌شده)
    valid = [x for x in results if x["trades"] >= min_trades]
    min_trades_met = bool(valid)
    pool = valid if valid else results

    key_map = {
        "net_r": lambda x: x["net_r"],
        "profit_factor": lambda x: x["profit_factor"],
        "win_rate": lambda x: x["win_rate"],
    }
    # اصلاح (OPT-001): متریکِ ناشناخته به net_r برمی‌گردد ولی قبلاً در پاسخ همان
    # متریکِ درخواستی گزارش می‌شد و UI نتیجه را به‌اشتباه «بهترین X» می‌خواند.
    metric_used = metric if metric in key_map else "net_r"
    keyfn = key_map[metric_used]
    pool.sort(key=keyfn, reverse=True)

    best = pool[0] if pool else None

    out = {
        "symbol": symbol.upper(),
        "interval": interval,
        "bars_tested": int(len(df)),
        "metric": metric_used,
        "requested_metric": metric,
        "combinations": len(results),
        "min_trades": int(min_trades),
        "min_trades_met": min_trades_met,
        "best": best,
        "top": pool[:12],
        "source": df.attrs.get("source", "?"),
        "costs": {"spread": spread, "slippage": slippage, "commission_pct": commission_pct},
    }
    if not min_trades_met:
        out["note"] = ("هیچ ترکیبی به حداقل تعداد معامله نرسید؛ رتبه‌بندی روی همهٔ "
                       "ترکیب‌ها (شاملِ کم‌معامله‌ها) انجام شد و قابلِ اعتماد نیست.")
    if walk_forward and best:
        pad = 60
        test_df = df.iloc[max(0, _split - pad):].reset_index(drop=True)
        tr = bt.run_backtest_df(test_df, symbol, interval,
                                threshold=best["threshold"], atr_mult_sl=best["sl_atr"],
                                atr_mult_tp=best["tp_atr"], allow_short=allow_short,
                                spread=spread, slippage=slippage,
                                commission_pct=commission_pct)
        out["walk_forward"] = {
            "train_bars": int(_split),
            "test_bars": int(len(df) - _split),
            "train_best": dict(best),
            "test": {"trades": int(tr["total_trades"]), "win_rate": float(tr["win_rate"]),
                     "net_r": float(tr["net_r"]), "profit_factor": float(tr["profit_factor"]),
                     "max_dd": float(tr["max_drawdown_r"]),
                     "net_profit": float(tr["net_profit"])},
        }
    return out


if __name__ == "__main__":
    import json
    print(json.dumps(optimize("BTC", "1h", bars=600), ensure_ascii=False, indent=2)[:1200])
