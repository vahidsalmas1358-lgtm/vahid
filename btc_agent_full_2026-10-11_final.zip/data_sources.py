"""دریافت داده‌های زنده از منابع رایگان و بدون کلید API (چند نماد).

- کندل‌ها (تکنیکال): OKX  -> fallback: Coinbase, Kraken
- فاندامنتال: CoinGecko
- سنتیمنتال: Fear & Greed Index (alternative.me) — کل بازار
"""
from __future__ import annotations
import time
import threading
import requests
from requests.adapters import HTTPAdapter
import pandas as pd

import symbols as sym

# (connect_timeout, read_timeout) — اتصالِ سریع، مهلتِ خواندنِ معقول
TIMEOUT = (4, 10)
HEADERS = {"User-Agent": "crypto-agent/2.0"}


# ---------------------------------------------------------------- Session مشترک
# یک Sessionِ مشترک با connection-pool و keep-alive و retry خودکار:
#   • اتصالِ TCP/TLS بین درخواست‌ها بازاستفاده می‌شود (تأخیرِ هر فراخوانی به‌شدت کم می‌شود)
#   • خطاهای گذرا (429/5xx) با backoff کوتاه دوباره تلاش می‌شوند
def _build_session() -> requests.Session:
    s = requests.Session()
    s.headers.update(HEADERS)
    try:
        from urllib3.util.retry import Retry
        # فقط خطاهای گذرای شبکه/سرور را با backoffِ کوتاه دوباره تلاش می‌کنیم.
        # ۴۲۹ (rate-limit) را دوباره تلاش نمی‌کنیم و به Retry-Afterِ سرور توجه نمی‌کنیم
        # تا یک درخواستِ محدودشده هرگز چند ده‌ثانیه بلاک نشود (به‌جای آن از کشِ کهنه استفاده می‌شود).
        retry = Retry(
            total=1, connect=2, read=1,
            backoff_factor=0.3,
            status_forcelist=(500, 502, 503, 504),
            allowed_methods=frozenset(["GET"]),
            respect_retry_after_header=False,
            raise_on_status=False,
        )
        try:
            retry.backoff_max = 1.5      # سقفِ backoff (نسخه‌های جدیدِ urllib3)
        except Exception:  # noqa
            pass
    except Exception:  # noqa
        retry = None
    adapter = HTTPAdapter(pool_connections=48, pool_maxsize=64, max_retries=retry)
    s.mount("https://", adapter)
    s.mount("http://", adapter)
    return s


_SESSION = _build_session()


def _get(url, headers=None, timeout=None):
    """درخواستِ GET روی Sessionِ مشترک (keep-alive + retry)."""
    return _SESSION.get(url, headers=headers, timeout=timeout or TIMEOUT)

OKX_BAR = {"1m": "1m", "5m": "5m", "15m": "15m", "1h": "1H", "4h": "4H", "1d": "1D", "1w": "1W"}
CB_GRAN = {"1m": 60, "5m": 300, "15m": 900, "1h": 3600, "4h": 14400, "1d": 86400}  # کوین‌بیس هفتگی ندارد
KRAKEN_INT = {"1m": 1, "5m": 5, "15m": 15, "1h": 60, "4h": 240, "1d": 1440, "1w": 10080}

# Yahoo: (interval, range, resample_to)  — یاهو 4 ساعته ندارد، از 60m ساخته می‌شود
YF_LIVE = {"1m": ("1m", "1d", None), "5m": ("5m", "5d", None),
           "15m": ("15m", "5d", None), "1h": ("60m", "1mo", None),
           "4h": ("60m", "3mo", "4h"), "1d": ("1d", "2y", None),
           "1w": ("1wk", "5y", None)}
YF_HIST = {"1m": ("1m", "7d", None), "5m": ("5m", "60d", None),
           "15m": ("15m", "60d", None), "1h": ("60m", "730d", None),
           "4h": ("60m", "2y", "4h"), "1d": ("1d", "5y", None),
           "1w": ("1wk", "10y", None)}

# تایم‌فریم‌هایی که هیچ منبعی به‌صورتِ بومی ندارد و از یک تایم‌فریمِ کوچک‌تر
# با تجمیع (resample) ساخته می‌شوند:  synthetic → (base_interval, pandas_rule)
RESAMPLE_FROM = {"10m": ("5m", "10min"), "30m": ("15m", "30min"), "2h": ("1h", "2h")}

# --- TTLِ کش بر حسبِ تایم‌فریم (اصلاحِ OP5-DS-TTL) ---
# پیش‌تر همهٔ تایم‌فریم‌ها یک TTLِ ثابتِ ۴۵ ثانیه‌ای داشتند؛ برای ۱ روزه این
# یعنی درخواستِ شبکه‌ایِ بی‌دلیل و برای ۱ دقیقه یعنی دادهٔ کهنه. eکنون هر تایم‌فریم
# TTLِ متناسب با خودش دارد (کمی بزرگ‌تر از طولِ کندل ولی به‌اندازه‌ای کوتاه که UI
# تازه بماند).
_TTL_BY_INTERVAL = {"1m": 20, "5m": 30, "10m": 40, "15m": 50, "30m": 60,
                    "1h": 90, "2h": 120, "4h": 180, "1d": 300, "1w": 600, "1mn": 600}
_INTERVAL_MS = {"1m": 60_000, "5m": 300_000, "10m": 600_000, "15m": 900_000,
                "30m": 1_800_000, "1h": 3_600_000, "2h": 7_200_000, "4h": 14_400_000,
                "1d": 86_400_000, "1w": 604_800_000, "1mn": 2_592_000_000}


def _ttl_for(interval, default=None):
    return _TTL_BY_INTERVAL.get(str(interval or "").lower(), default if default is not None else _CACHE_TTL)


_cache: dict = {}
_CACHE_TTL = 45
_cache_lock = threading.Lock()          # محافظِ خودِ dictِ کش
_key_locks: dict = {}                    # قفلِ اختصاصیِ هر کلید (ضدِ cache-stampede)
_key_locks_guard = threading.Lock()


def _cache_get(key, ttl=_CACHE_TTL):
    with _cache_lock:
        v = _cache.get(key)
    if v and (time.time() - v[0] < ttl):
        return v[1]
    return None


def _cache_ts(key):
    """زمانِ ذخیرهٔ مقدارِ کش (یا 0)."""
    with _cache_lock:
        v = _cache.get(key)
    return v[0] if v else 0.0


def _stale_note(payload):
    if isinstance(payload, dict):
        payload["stale"] = True


def _cache_get_stale(key):
    """آخرین مقدارِ کش‌شده را بدونِ توجه به کهنگی برمی‌گرداند (برای fallback)."""
    with _cache_lock:
        v = _cache.get(key)
    return v[1] if v else None


def _cache_set(key, val):
    with _cache_lock:
        _cache[key] = (time.time(), val)
    return val


def _key_lock(key) -> threading.Lock:
    """قفلِ اختصاصیِ هر کلید با محدودیتِ نگه‌داری (اصلاحِ OP5-DS-LOCKLRU).

    پیش‌تر این dict هرگز پاک نمی‌شد و با هر کلیدِ تازه (نماد/تایم‌فریم/حد) یک
    قفلِ جدید تا ابد می‌ماند → نشتِ حافظه در اجرای طولانی. اکنون وقتی تعداد از
    سقف بگذرد، قفل‌های بی‌استفاده (بدونِ انتظارنده) هرس می‌شوند.
    """
    with _key_locks_guard:
        lk = _key_locks.get(key)
        if lk is None:
            if len(_key_locks) >= 128:
                for k in [k for k, v in _key_locks.items() if not v.locked()]:
                    if k == key:
                        continue
                    _key_locks.pop(k, None)
                    if len(_key_locks) < 96:
                        break
            lk = _key_locks.setdefault(key, threading.Lock())
        return lk


def _memoize(key, producer, ttl=_CACHE_TTL, allow_stale=True):
    """کشِ thread-safe با قفلِ هر کلید:

    ۱) اگر مقدارِ تازه در کش بود → بلافاصله برگردان (بدونِ شبکه)
    ۲) قفلِ همان کلید را بگیر تا تنها یک ترد برای آن کلید به شبکه برود
       (بقیهٔ تردها منتظر می‌مانند و از نتیجهٔ آن استفاده می‌کنند = بدونِ درخواستِ تکراری)
    ۳) در صورتِ خطا، اگر نسخهٔ کهنه موجود بود همان را برگردان (پایداریِ بیشتر)
    """
    hit = _cache_get(key, ttl)
    if hit is not None:
        return hit
    lk = _key_lock(key)
    with lk:
        hit = _cache_get(key, ttl)      # بازبینیِ دوباره پس از گرفتنِ قفل
        if hit is not None:
            return hit
        try:
            return _cache_set(key, producer())
        except Exception:
            if allow_stale:
                stale = _cache_get_stale(key)
                if stale is not None:
                    # پرچمِ صریحِ کهنگی تا UI بتواند «دادهٔ قدیمی» را نشان دهد
                    try:
                        if hasattr(stale, "attrs"):
                            stale.attrs["stale"] = True
                            stale.attrs["stale_since"] = time.time() - _cache_ts(key)
                        else:
                            _stale_note(stale)
                    except Exception:  # noqa
                        pass
                    return stale
            raise


def _sym_cfg(symbol):
    """پیکربندیِ نماد با خطای روشن (به‌جای fallbackِ پنهان به BTCِ symbols.get)."""
    cfg = sym.resolve(symbol)
    if not cfg:
        raise RuntimeError(f"نمادِ پشتیبانی‌نشده: {symbol!r}")
    return cfg


def _finalize_candles(df, interval, live=True):
    """پاک‌سازی و اعتبارسنجیِ کندل‌ها (اصلاحِ OP5-DS-FINALIZE).

    • time به میلی‌ثانیهٔ UTCِ عددی تبدیل می‌شود (ترتیبِ صعودی، بدونِ تکرار)،
    • کندلِ «در حالِ تشکیل» (کندلِ جاریِ زنده) حذف می‌شود تا اندیکاتورها روی
      کندلِ ناقص حساب نکنند (ری‌پینت نگیریم)،
    • کهنگی و گپ‌های داده به‌صورتِ attrs گزارش می‌شوند (به‌جای پنهان‌کاری).
    """
    if df is None or len(df) == 0:
        return df
    try:
        df = df.copy()
        iv_ms = _INTERVAL_MS.get(str(interval or "").lower())
        t = pd.to_numeric(df["time"], errors="coerce")
        if t.isna().any():
            df = df[~t.isna()].copy()
            t = pd.to_numeric(df["time"], errors="coerce")
        df["time"] = t.astype("int64")
        if t.max() < 10_000_000_000:      # ثانیه → میلی‌ثانیه
            df["time"] = df["time"] * 1000
        df = (df.drop_duplicates("time", keep="last")
                .sort_values("time").reset_index(drop=True))
        now_ms = time.time() * 1000.0
        if live and iv_ms and len(df):
            last_open = int(df["time"].iloc[-1])
            if last_open + iv_ms > now_ms:
                df = df.iloc[:-1].reset_index(drop=True)
        gaps = 0
        if iv_ms and len(df) > 1:
            diffs = df["time"].diff().dropna()
            gaps = int((diffs > iv_ms * 1.5).sum())
        df.attrs["gaps"] = gaps
        if iv_ms and len(df):
            age_ms = now_ms - (int(df["time"].iloc[-1]) + iv_ms)
            df.attrs["stale"] = bool(age_ms > iv_ms * 3)
            df.attrs["age_ms"] = float(max(0.0, age_ms))
        return df
    except Exception:  # noqa
        return df


def _df_from_rows(rows):
    df = pd.DataFrame(rows, columns=["time", "open", "high", "low", "close", "volume"])
    for c in ["time", "open", "high", "low", "close", "volume"]:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    df = df.dropna().drop_duplicates("time").sort_values("time").reset_index(drop=True)
    # اصلاح (DS-001 — نسخهٔ نرم): کندل‌های ازنظرِ ساختاری نامعتبر (high<low،
    # close/open خارج از بازهٔ low..high، قیمتِ ≤0) بی‌صدا در اندیکاتورها خطا
    # می‌ساختند؛ به‌جای خطای سخت (فیدهای رایگان گاهی ردیفِ خراب می‌دهند)،
    # فقط همان ردیف‌ها حذف می‌شوند.
    ok = ((df["high"] >= df["low"]) & (df["low"] > 0) &
          (df["close"] >= df["low"]) & (df["close"] <= df["high"]) &
          (df["open"] >= df["low"]) & (df["open"] <= df["high"]) &
          (df["volume"] >= 0))
    if not ok.all():
        df = df[ok].reset_index(drop=True)
    return df


def _okx(cfg, interval, limit=300, history=False):
    inst = cfg["okx"]
    bar = OKX_BAR[interval]
    path = "history-candles" if history else "candles"
    url = f"https://www.okx.com/api/v5/market/{path}?instId={inst}&bar={bar}&limit={min(limit,300)}"
    r = _get(url)
    r.raise_for_status()
    data = r.json()["data"]
    rows = [[int(d[0]), d[1], d[2], d[3], d[4], d[5]] for d in reversed(data)]
    return _df_from_rows(rows)


def _coinbase(cfg, interval, limit=300, history=False):
    if not cfg.get("coinbase"):
        raise RuntimeError("Coinbase: نماد پشتیبانی نمی‌شود")
    gran = CB_GRAN[interval]
    url = f"https://api.exchange.coinbase.com/products/{cfg['coinbase']}/candles?granularity={gran}"
    r = _get(url)
    r.raise_for_status()
    data = r.json()
    rows = [[int(d[0]) * 1000, d[3], d[2], d[1], d[4], d[5]] for d in reversed(data)]
    return _df_from_rows(rows)


def _kraken(cfg, interval, limit=300, history=False):
    if not cfg.get("kraken"):
        raise RuntimeError("Kraken: نماد پشتیبانی نمی‌شود")
    it = KRAKEN_INT[interval]
    url = f"https://api.kraken.com/0/public/OHLC?pair={cfg['kraken']}&interval={it}"
    r = _get(url)
    r.raise_for_status()
    res = r.json()["result"]
    key = [k for k in res if k != "last"][0]
    rows = [[int(d[0]) * 1000, d[1], d[2], d[3], d[4], d[6]] for d in res[key]]
    return _df_from_rows(rows)


def _yahoo_chart(ysymbol, interval, rng):
    from urllib.parse import quote
    enc = quote(ysymbol, safe="=.-")   # ^ -> %5E و کاراکترهای خاص
    url = (f"https://query1.finance.yahoo.com/v8/finance/chart/{enc}"
           f"?interval={interval}&range={rng}")
    r = _get(url, headers={"User-Agent": "Mozilla/5.0"})
    r.raise_for_status()
    res = r.json()["chart"]["result"]
    if not res:
        raise RuntimeError("Yahoo: داده‌ای برنگشت")
    res = res[0]
    ts = res["timestamp"]
    q = res["indicators"]["quote"][0]
    rows = []
    for i, t in enumerate(ts):
        o, h, l, c = q["open"][i], q["high"][i], q["low"][i], q["close"][i]
        v = (q.get("volume") or [0] * len(ts))[i]
        if None in (o, h, l, c):
            continue
        rows.append([int(t) * 1000, o, h, l, c, v if v is not None else 0])
    return _df_from_rows(rows)


def _resample(df, rule):
    # اصلاح (DS-001): تایم‌استمپِ کندل‌ها «شروعِ بازه» است؛ بنابراین باکتینگ باید
    # closed/label="left" باشد. حالتِ قبلی ("right") کندلِ شروع‌شده در مرزِ باکت را
    # به باکتِ قبلی می‌چسباند و تجمیعِ 10m/30m/2h نیم‌باکت جابه‌جا می‌شد.
    d = df.copy()
    d["dt"] = pd.to_datetime(d["time"], unit="ms")
    d = d.set_index("dt")
    out = d.resample(rule, label="left", closed="left").agg(
        {"time": "first", "open": "first", "high": "max", "low": "min",
         "close": "last", "volume": "sum"}).dropna()
    return out.reset_index(drop=True)


def _yahoo(cfg, interval, limit=300, history=False):
    ysym = cfg["yahoo"]
    yi, rng, resample_to = (YF_HIST if history else YF_LIVE)[interval]
    df = _yahoo_chart(ysym, yi, rng)
    if resample_to:
        df = _resample(df, resample_to)
    return df


def get_candles(symbol="BTC", interval="1h", limit=300):
    cfg = _sym_cfg(symbol)

    # تایم‌فریمِ ترکیبی (مثل ۱۰ دقیقه): از تایم‌فریمِ پایه می‌گیریم و تجمیع می‌کنیم
    if interval in RESAMPLE_FROM:
        base, rule = RESAMPLE_FROM[interval]
        ckr = f"cndl:{symbol}:{interval}:{int(limit)}"  # اصلاح (DS-002): limit در کلید کش

        def _produce_rs():
            df0 = get_candles(symbol, base, min(limit * 2 + 60, 300))
            out = _resample(df0, rule)
            out.attrs["source"] = str(df0.attrs.get("source", "?")) + f"→{interval}"
            if len(out) < 30:
                raise RuntimeError(f"کندلِ کافی برای {interval} ساخته نشد")
            return out

        return _memoize(ckr, _produce_rs, ttl=_ttl_for(interval))

    ck = f"cndl:{symbol}:{interval}:{int(limit)}"  # اصلاح (DS-002): limit در کلید کش

    def _produce():
        errors = []
        if cfg.get("asset_class") != "crypto":
            try:
                df = _yahoo(cfg, interval, limit)
                if len(df) > 60:
                    df.attrs["source"] = "Yahoo"
                    return df
                raise RuntimeError("کندل کافی نیست")
            except Exception as e:  # noqa
                raise RuntimeError(f"دریافت کندل ({symbol}) ناموفق: {e}")

        for name, fn in [("OKX", _okx), ("Coinbase", _coinbase), ("Kraken", _kraken)]:
            try:
                df = fn(cfg, interval, limit)
                if len(df) > 60:
                    df.attrs["source"] = name
                    return df
            except Exception as e:  # noqa
                errors.append(f"{name}: {e}")
        raise RuntimeError("دریافت کندل ناموفق: " + " | ".join(errors))

    df = _memoize(ck, _produce, ttl=_ttl_for(interval))
    return _finalize_candles(df, interval, live=True)


def get_history(symbol="BTC", interval="1h", bars=800):
    """دریافت داده تاریخی بیشتر برای بک‌تست."""
    cfg = _sym_cfg(symbol)
    ck = f"hist:{symbol}:{interval}:{bars}"
    cached = _cache_get(ck, _ttl_for(interval))
    if cached is not None:
        return cached

    # تایم‌فریمِ ترکیبی (مثل ۱۰ دقیقه): از تایم‌فریمِ پایه ساخته می‌شود
    if interval in RESAMPLE_FROM:
        base, rule = RESAMPLE_FROM[interval]
        try:
            df0 = get_history(symbol, base, bars * 2 + 100)
            out = _resample(df0, rule)
            out.attrs["source"] = str(df0.attrs.get("source", "?")) + f"→{interval}"
            if len(out) < 30:
                raise RuntimeError("کافی نیست")
            return _cache_set(ck, _finalize_candles(out, interval, live=True))
        except Exception:
            return get_candles(symbol, interval)

    if cfg.get("asset_class") != "crypto":
        try:
            df = _yahoo(cfg, interval, bars, history=True)
            df.attrs["source"] = "Yahoo-history"
            return _cache_set(ck, _finalize_candles(df, interval, live=True))
        except Exception:
            df = get_candles(symbol, interval)
            return df

    inst = cfg["okx"]
    bar = OKX_BAR[interval]
    all_rows = []
    after = ""
    try:
        while len(all_rows) < bars:
            url = (f"https://www.okx.com/api/v5/market/history-candles?"
                   f"instId={inst}&bar={bar}&limit=100")
            if after:
                url += f"&after={after}"
            r = _get(url)
            r.raise_for_status()
            data = r.json().get("data", [])
            if not data:
                break
            for d in data:
                all_rows.append([int(d[0]), d[1], d[2], d[3], d[4], d[5]])
            after = data[-1][0]
            time.sleep(0.15)
        if len(all_rows) < 60:
            raise RuntimeError("داده کافی نیست")
        df = _df_from_rows(all_rows)
        df.attrs["source"] = "OKX-history"
        return _cache_set(ck, _finalize_candles(df, interval, live=True))
    except Exception:
        # fالبک: از کندل معمول استفاده کن
        df = get_candles(symbol, interval)
        return df


def _yahoo_fundamentals(cfg):
    """فاندامنتال/ماکرو دارایی‌های Yahoo (فلز/کالا/شاخص/فارکس) از کندل روزانه."""
    df = _yahoo_chart(cfg["yahoo"], "1d", "1y")
    close = df["close"]
    price = float(close.iloc[-1])

    def chg(bars):
        if len(close) > bars:
            return (price / float(close.iloc[-1 - bars]) - 1) * 100
        return None

    high52 = float(df["high"].max())
    return {
        "price": price,
        "market_cap": None, "total_volume": None,
        "change_24h": chg(1), "change_7d": chg(5), "change_30d": chg(22),
        "ath": high52,
        "ath_change_pct": (price / high52 - 1) * 100,
        "circulating_supply": None, "max_supply": None,
        "ok": True, "is_metal": True,
    }


# نگاشتِ CoinGecko-id → نمادِ داخلی (برای دریافتِ دسته‌ایِ فاندامنتال)
_CG_ID_TO_SYM = {v["cg"]: k for k, v in sym.SYMBOLS.items()
                 if v.get("asset_class") == "crypto" and v.get("cg")}


def _prefetch_crypto_fund():
    """همهٔ فاندامنتال‌های کریپتو را با یک درخواستِ /coins/markets می‌گیرد.

    به‌جای ۶ درخواستِ جدا (که CoinGecko را rate-limit می‌کند) فقط یک درخواست می‌زند،
    و کشِ تک‌تکِ نمادها (fund:BTC …) را هم پر می‌کند تا فراخوانی‌های بعدی بدونِ شبکه باشند.
    برمی‌گرداند: {SYMBOL: fund_dict}
    """
    ids = ",".join(_CG_ID_TO_SYM.keys())
    url = ("https://api.coingecko.com/api/v3/coins/markets"
           f"?vs_currency=usd&ids={ids}&price_change_percentage=24h,7d,30d"
           "&sparkline=false")
    r = _get(url)
    r.raise_for_status()
    out = {}
    for m in r.json():
        s = _CG_ID_TO_SYM.get(m.get("id"))
        if not s:
            continue
        d = {
            "price": m.get("current_price"),
            "market_cap": m.get("market_cap"),
            "total_volume": m.get("total_volume"),
            "change_24h": m.get("price_change_percentage_24h_in_currency"),
            "change_7d": m.get("price_change_percentage_7d_in_currency"),
            "change_30d": m.get("price_change_percentage_30d_in_currency"),
            "ath": m.get("ath"),
            "ath_change_pct": m.get("ath_change_percentage"),
            "circulating_supply": m.get("circulating_supply"),
            "max_supply": m.get("max_supply"),
            "ok": True,
        }
        out[s] = d
        _cache_set(f"fund:{s}", d)      # پرکردنِ کشِ تک‌نمادی
    if not out:
        raise RuntimeError("CoinGecko markets: دادهٔ خالی")
    return out


def get_fundamentals(symbol="BTC"):
    cfg = _sym_cfg(symbol)
    ck = f"fund:{symbol}"

    if cfg.get("asset_class") != "crypto":
        def _noncrypto():
            out = _yahoo_fundamentals(cfg)
            # اصلاح (FUND-MACRO-001): فاندامنتالِ واقعیِ کلان — رویدادهای پرتأثیرِ
            # پیش‌رو (تا ۴۸ ساعت) برای ارزهای مرتبطِ نماد، از تقویمِ اقتصادیِ
            # رایگانِ خودِ برنامه (ForexFactory/TradingView). قبلاً «فاندامنتال»
            # فقط مومنتومِ قیمتِ خودِ نماد بود.
            try:
                import news as _news
                import time as _t
                _cur = cfg.get("macro_currencies") or (["USD"] if cfg.get("asset_class")
                                                       in ("metal", "index", "commodity") else ["USD"])
                base = (symbol or "").upper()
                if len(base) == 6 and cfg.get("asset_class") == "forex":
                    _cur = [base[:3], base[3:]]
                res = _news.fetch()
                evs = []
                if res.get("ok"):
                    now = _t.time()
                    for e in res.get("events") or []:
                        # Medium و High تا ۷۲ ساعت (آخرِ هفته‌ها اغلب High نزدیک ندارند)
                        if e.get("impact_rank", 0) < 2:
                            continue
                        if e.get("country") not in _cur:
                            continue
                        dt = (e.get("ts") or 0) - now
                        if 0 < dt <= 72 * 3600:
                            evs.append({"title": e.get("title"), "country": e.get("country"),
                                        "impact": e.get("impact"),
                                        "impact_rank": e.get("impact_rank", 2),
                                        "in_hours": round(dt / 3600, 1)})
                # اولویت: High قبل از Medium، سپس نزدیک‌ترین زمان
                evs.sort(key=lambda x: (-x.get("impact_rank", 2), x["in_hours"]))
                out["macro_events"] = evs[:4]
                out["macro_currencies"] = _cur
            except Exception:  # noqa
                pass
            return out
        try:
            return _memoize(ck, _noncrypto)
        except Exception as e:  # noqa
            return {"ok": False, "error": str(e)}

    # ۱) کشِ تازه؟ فوراً برگردان
    hit = _cache_get(ck)
    if hit is not None:
        return hit
    # ۲) دریافتِ دسته‌ایِ همهٔ کریپتوها با یک درخواست (کش‌شده و ضدِ stampede)
    try:
        batch = _memoize("fund:cg:batch", _prefetch_crypto_fund)
        if symbol.upper() in batch:
            return batch[symbol.upper()]
    except Exception:  # noqa
        pass
    # ۳) fallback: نسخهٔ کهنه یا درخواستِ تک‌کوینِ CoinGecko
    stale = _cache_get_stale(ck)
    if stale is not None:
        return stale

    cid = cfg["cg"]
    url = (f"https://api.coingecko.com/api/v3/coins/{cid}"
           "?localization=false&tickers=false&market_data=true"
           "&community_data=false&developer_data=false&sparkline=false")

    def _produce():
        r = _get(url)
        r.raise_for_status()
        m = r.json()["market_data"]
        out = {
            "price": m["current_price"]["usd"],
            "market_cap": m["market_cap"]["usd"],
            "total_volume": m["total_volume"]["usd"],
            "change_24h": m.get("price_change_percentage_24h"),
            "change_7d": m.get("price_change_percentage_7d"),
            "change_30d": m.get("price_change_percentage_30d"),
            "ath": m["ath"]["usd"],
            "ath_change_pct": m["ath_change_percentage"]["usd"],
            "circulating_supply": m.get("circulating_supply"),
            "max_supply": m.get("max_supply"),
            "ok": True,
        }
        return out

    try:
        return _memoize(ck, _produce)
    except Exception as e:  # noqa
        return {"ok": False, "error": str(e)}


def _dxy_raw():
    """داده خام شاخص دلار (کش‌شده و مشترک بین همه نمادها)."""
    def _produce():
        df = _yahoo_chart(sym.DXY_SYMBOL, "1d", "1mo")
        close = df["close"]
        dxy = float(close.iloc[-1])
        chg_1d = (dxy / float(close.iloc[-2]) - 1) * 100 if len(close) > 1 else 0.0
        chg_5d = (dxy / float(close.iloc[-6]) - 1) * 100 if len(close) > 5 else chg_1d
        return (dxy, chg_1d, chg_5d)

    return _memoize("dxy:raw", _produce)


def _dxy_sentiment(dxy_k=-1):
    """سنتیمنت مبتنی بر شاخص دلار (DXY).

    dxy_k = -1 : دلار ضعیف → مثبت (فلزات/کالا/EURUSD/GBPUSD)
    dxy_k = +1 : دلار قوی → مثبت (USDJPY)
    bull = chg_5d * dxy_k  (بزرگ‌تر از صفر یعنی صعودی برای این دارایی)
    """
    dxy, chg_1d, chg_5d = _dxy_raw()
    bull = chg_5d * dxy_k
    value = int(max(0, min(100, round(50 + bull * 10))))
    if value >= 60:
        cls = "دلار ضعیف (مثبت دارایی)" if dxy_k < 0 else "دلار قوی (مثبت دارایی)"
    elif value <= 40:
        cls = "دلار قوی (منفی دارایی)" if dxy_k < 0 else "دلار ضعیف (منفی دارایی)"
    else:
        cls = "خنثی"
    return {"ok": True, "kind": "dxy", "value": value, "classification": cls,
            "title": "سنتیمنت مبتنی بر شاخص دلار (DXY)",
            "dxy": round(dxy, 2), "dxy_chg_1d": round(chg_1d, 2),
            "dxy_chg_5d": round(chg_5d, 2), "bull": round(bull, 3),
            "dxy_k": dxy_k, "history": []}


def _vix_sentiment():
    """سنتیمنت شاخص سهام مبتنی بر VIX: نوسان پایین/کاهشی → مثبت برای سهام."""
    df = _yahoo_chart(sym.VIX_SYMBOL, "1d", "1mo")
    close = df["close"]
    vix = float(close.iloc[-1])
    chg_5d = (vix / float(close.iloc[-6]) - 1) * 100 if len(close) > 5 else 0.0
    value = int(max(0, min(100, round(100 - vix * 2.5))))   # VIX پایین = طمع/آرامش
    if value >= 60:
        cls = "آرامش بازار (مثبت سهام)"
    elif value <= 40:
        cls = "ترس/نوسان بالا (منفی سهام)"
    else:
        cls = "خنثی"
    return {"ok": True, "kind": "vix", "value": value, "classification": cls,
            "title": "سنتیمنت مبتنی بر شاخص نوسان (VIX)",
            "vix": round(vix, 2), "vix_chg_5d": round(chg_5d, 2), "history": []}


def get_sentiment(symbol="BTC"):
    cfg = _sym_cfg(symbol)
    stype = cfg.get("sentiment")
    if stype == "dxy":
        dxy_k = cfg.get("dxy_k", -1)
        try:
            return _memoize(f"sent:dxy:{dxy_k}", lambda: _dxy_sentiment(dxy_k))
        except Exception as e:  # noqa
            return {"ok": False, "error": str(e), "kind": "dxy",
                    "title": "سنتیمنت مبتنی بر شاخص دلار (DXY)"}
    if stype == "vix":
        try:
            return _memoize("sent:vix", _vix_sentiment)
        except Exception as e:  # noqa
            return {"ok": False, "error": str(e), "kind": "vix",
                    "title": "سنتیمنت مبتنی بر شاخص نوسان (VIX)"}

    def _produce():
        r = _get("https://api.alternative.me/fng/?limit=7")
        r.raise_for_status()
        data = r.json()["data"]
        latest = data[0]
        return {
            "ok": True, "kind": "fng",
            "value": int(latest["value"]),
            "classification": latest["value_classification"],
            "title": "شاخص ترس و طمع (کل بازار کریپتو)",
            "history": [int(d["value"]) for d in data],
        }

    try:
        return _memoize("sent", _produce)
    except Exception as e:  # noqa
        return {"ok": False, "error": str(e), "kind": "fng",
                "title": "شاخص ترس و طمع (کل بازار کریپتو)"}
