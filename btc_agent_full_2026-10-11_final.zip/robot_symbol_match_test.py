# -*- coding: utf-8 -*-
"""رگرسیونِ هماهنگیِ نمادِ ربات با نمادِ بروکر (ROBOT-SYM-001 + MT5-SYM-CASE-001).

شکایتِ کاربر: «نمادهایی که در تبِ سیگنال‌های ورودی ربات‌ها ثبت می‌شوند با نمادهای
بروکرِ من در متاتریدر۵ هماهنگ نیستند و متفاوت‌اند.»

ریشه‌ها:
  ۱) _do_forward نامِ داخلی (XAU) را به‌جای عینِ نمادِ ربات (XAUUSD.m) فوروارد می‌کرد
     و resolve می‌توانست نمادِ هم‌خانوادهٔ دیگری از بروکر انتخاب کند.
  ۲) resolve_symbol ورودی را upper() می‌کرد؛ پسوندهای کوچکِ بروکری (.m/.z/micro)
     خراب می‌شد و جست‌وجوی فازی (startswith سه حرفِ اول) نمادِ دیگری برمی‌داشت.
"""
import os as _os_env; _os_env.environ.setdefault("BTC_AGENT_ALLOW_INSECURE_ROBOT", "1")  # محیط تست
import shutil

import app
import robots
import dispatch
import mock_mt5
import mt5_bridge as mb
import market_hours as mh

PASS = 0
FAIL = 0


def chk(name, cond, detail=""):
    global PASS, FAIL
    if cond:
        PASS += 1
    else:
        FAIL += 1
        print(f"   FAIL  {name} — {str(detail)[:200]}")


for i, f in enumerate(("mt5_config.json", "dispatch_config.json", "robot_config.json")):
    shutil.copy(f, f"/tmp/rsm_{i}.bak")

app.app.config["TESTING"] = True
client = app.app.test_client()
_real_status = mh.status
_real_sigfor = app._signal_for
mh.status = lambda s, now=None: {"open": True, "state": "open", "reason": ""}

b = mock_mt5.Broker(balance=100000)
# XAUEUR عمداً قبل از XAUUSD.m — اگر فازی اشتباه برگردد، تست می‌شکند
b.add_symbol("XAUEUR", digits=2, point=0.01, volume_min=0.01, volume_step=0.01,
             stops_level=10, tick_value=1.0, tick_size=0.01, price=3450.0)
b.add_symbol("XAUUSD.m", digits=2, point=0.01, volume_min=0.01, volume_step=0.01,
             stops_level=10, tick_value=1.0, tick_size=0.01, price=4000.0)
b.add_symbol("BITCOIN", digits=2, point=0.01, volume_min=0.01, volume_step=0.01,
             stops_level=10, tick_value=1.0, tick_size=0.01, price=84000.0)
for k in dir(mock_mt5):
    if k.isupper():
        setattr(b, k, getattr(mock_mt5, k))
mb.mt5 = b
mb.MT5_AVAILABLE = True
mb._conn.update(connected=True, error=None, since=1.0)

mb.save_config({"market_hours_guard": False, "news_filter_enabled": False,
                "max_daily_trades": 0, "max_daily_risk_pct": 0, "allowed_symbols": [],
                "manage_positions": False, "risk_mode": "fixed", "tp_mode": "single",
                "execution": "market", "symbol_map": {"BTC": "BITCOIN"}})
robots.save_config({"enabled": True, "auto_forward": True, "filter_mode": "internal",
                    "min_internal_score": 0, "require_direction_match": False,
                    "conflict_guard_enabled": False, "dedupe_window_sec": 0.0,
                    "aggregate_window_sec": 0.0, "block_duplicate_open": False,
                    "block_opposite_open": False, "shared_secret": ""})
dispatch.save_config({"news_filter_enabled": False, "schedule_filter_enabled": False})

DATA = {"direction": "SHORT", "internal_score": -50.0, "total_score": -50.0,
        "price": 4000.0, "atr": 10.0, "pair": "XAU/USD", "interval": "15m",
        "generated_at": "x",
        "plan": {"direction": "SHORT", "entry": 4000.0, "stop_loss": 4010.0,
                 "take_profits": [{"price": 3990.0}, {"price": 3980.0}, {"price": 3970.0}]},
        "technical": {"supports": [], "resistances": []}}
app._signal_for = lambda sym, tf, with_ai=False: (DATA, "XAU", None)

print("=" * 70)
print(" هماهنگیِ نمادِ ربات ↔ نمادِ بروکر")
print("=" * 70)

# ➊ نمادِ پسونددارِ بروکر عیناً معامله می‌شود
r = client.post("/api/robot/order", json={"symbol": "XAUUSD.m", "direction": "SELL",
                                          "volume": 0.05, "sl": 4010.0, "tp": 3990.0,
                                          "robot_id": "sym-test"})
d = r.get_json() or {}
fwd = d.get("forward") or {}
pos = list(b.positions.values())
chk("فوروارد شد", d.get("forwarded") is True, d.get("forwarded"))
chk("broker_symbol دقیقاً XAUUSD.m", fwd.get("broker_symbol") == "XAUUSD.m",
    fwd.get("broker_symbol"))
chk("پوزیشن روی عینِ نمادِ ربات باز شد (نه XAUEUR/XAUUSD)",
    len(pos) == 1 and pos[0].symbol == "XAUUSD.m", [p.symbol for p in pos])
chk("حجمِ دقیقِ ربات حفظ شد", pos and abs(pos[0].volume - 0.05) < 1e-9,
    pos and pos[0].volume)
b.positions.clear()

# ➋ resolve با حفظِ بزرگ/کوچکیِ حروف
res = mb.resolve_symbol("XAUUSD.m")
chk("resolve('XAUUSD.m') تطبیقِ دقیق", res.get("matched") is True
    and res.get("broker") == "XAUUSD.m", res)

# ➌ نگاشتِ داخلی (BTC→BITCOIN) سالم ماند
DATA2 = dict(DATA, direction="LONG", internal_score=50.0, total_score=50.0,
             plan={"direction": "LONG", "entry": 84000.0, "stop_loss": 83500.0,
                   "take_profits": [{"price": 84500.0}]})
app._signal_for = lambda sym, tf, with_ai=False: (DATA2, "BTC", None)
r = client.post("/api/robot/order", json={"symbol": "BTC", "direction": "BUY",
                                          "volume": 0.01, "sl": 83500.0, "tp": 84500.0,
                                          "robot_id": "sym-test"})
pos = list(b.positions.values())
chk("نمادِ داخلی BTC طبقِ نگاشت به BITCOIN رفت",
    len(pos) == 1 and pos[0].symbol == "BITCOIN", [p.symbol for p in pos])

# ➍ در گزارشِ تب، نماد همان است که ربات فرستاده
log = robots.read_log(5)
syms = [e.get("order", {}).get("symbol") for e in log[:2]]
chk("گزارشِ تب نمادِ خودِ ربات را ثبت می‌کند", "XAUUSD.m" in syms and "BTC" in syms, syms)

mh.status = _real_status
app._signal_for = _real_sigfor
for i, f in enumerate(("mt5_config.json", "dispatch_config.json", "robot_config.json")):
    shutil.copy(f"/tmp/rsm_{i}.bak", f)

print("\n" + "=" * 70)
print(f"  نتیجه: {PASS} پاس · {FAIL} ناموفق")
print("=" * 70)
raise SystemExit(1 if FAIL else 0)
