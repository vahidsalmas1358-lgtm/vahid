"""پل ارتباطی با سرویس‌های هوش مصنوعیِ سازگار با OpenAI (OpenAI-compatible).

با وارد کردنِ «Base URL»، «API Key» و انتخابِ «مدل» می‌توان به هر سرویسِ سازگار با
استانداردِ OpenAI وصل شد (OpenAI، OpenRouter، Groq، Together، LM Studio/Ollama محلی، …).

قابلیت‌ها:
  - ذخیره/بارگذاری تنظیمات در ai_config.json (کلید به‌صورت امن نگهداری و در UI ماسک می‌شود).
  - تست اتصال (فهرست مدل‌ها از `GET {base}/models`).
  - اتصال (تأیید کلید + مدل و ثبتِ وضعیت متصل).
  - پرسشِ آزمایشی (`POST {base}/chat/completions`) برای اطمینان از کارکردِ واقعیِ مدل.
  - لاگِ کاملِ همه‌ی رخدادها (ai_logs.json) با امکان مشاهده/پاک‌سازی.

نکته: همه‌ی درخواست‌ها سمتِ سرور (این بک‌اند) انجام می‌شود تا کلیدِ API هرگز در مرورگرِ
کاربر لو نرود.
"""
from __future__ import annotations

import os
import json
import math
import time
import threading

import requests
from requests.adapters import HTTPAdapter

CONFIG_PATH = os.path.join(os.path.dirname(__file__), "ai_config.json")
LOG_PATH = os.path.join(os.path.dirname(__file__), "ai_logs.json")

_lock = threading.RLock()
_log_lock = threading.Lock()

# وضعیت اتصالِ درون‌حافظه‌ای (پس از ری‌استارت صفر می‌شود)
_conn = {"connected": False, "since": None, "model": None, "error": None}

TIMEOUT = 30                      # سازگاری با کدِ قدیمی (سقفِ کلی)
CONNECT_TIMEOUT = 6               # اتصالِ TCP/TLS: اگر سرویس در دسترس نباشد، سریع شکست بخور
MODELS_TIMEOUT = (CONNECT_TIMEOUT, 15)          # فهرستِ مدل‌ها باید سریع باشد
CHAT_TIMEOUT = (CONNECT_TIMEOUT, 90)            # اجازهٔ زمانِ بیشتر برای تولیدِ پاسخِ مدل

# نشستِ مشترک با keep-alive و connection-pooling: به‌جای باز کردنِ یک اتصالِ تازه
# (و دست‌دهیِ کاملِ TLS) در هر فراخوانی، اتصال‌ها بازاستفاده می‌شوند. این تأخیرِ هر
# درخواستِ متوالی (models / test / chat / analyze) را محسوس کاهش می‌دهد. بدونِ retry
# تا خطاها فوری برگردند و کاربر پشتِ تلاش‌های مجدد معطل نماند.
_session = requests.Session()
_adapter = HTTPAdapter(pool_connections=8, pool_maxsize=8, max_retries=0)
_session.mount("http://", _adapter)
_session.mount("https://", _adapter)


# --------------------------------------------------------------------- تنظیمات
def _default_config() -> dict:
    return {
        "enabled": False,
        "base_url": "https://api.openai.com/v1",
        "api_key": "",
        "model": "gpt-4o-mini",
        "temperature": 0.7,
        "max_tokens": 512,
        "use_in_signal": False,      # آیا امتیاز AI در سیگنالِ نهایی لحاظ شود؟
        "signal_weight": 0.30,       # وزنِ AI در ترکیبِ نهایی (۰ تا ۰٫۹)
        "system_prompt": ("تو یک دستیارِ تحلیلگرِ بازارهای مالی هستی که به‌فارسی و کوتاه"
                          " و دقیق پاسخ می‌دهی. این ابزار آموزشی است و توصیه‌ی مالی نیست."),
        # اصلاح (AI-NET-001): پروکسیِ اختیاری برای عبور از فیلترینگ/تحریمِ سرویس‌دهنده
        # (مثل socks5h://127.0.0.1:1080 یا http://127.0.0.1:8086). خالی = بدونِ پروکسی.
        "proxy": "",
    }


def _sanitize_cfg(cfg: dict) -> dict:
    """اصلاح (AI-002 — تکمیلی): اعتبارسنجیِ نوع/بازهٔ مقادیر که قبلاً فقط در
    save_config انجام می‌شد؛ فایلِ دستی‌ویرایش‌شده با signal_weight="x" از
    load_config خام عبور می‌کرد و مصرف‌کننده‌ها (ترکیبِ سیگنال/فرانت) می‌شکستند."""
    def _as_bool(v):
        if isinstance(v, str):
            return v.strip().lower() not in ("", "0", "false", "no", "off", "none")
        return bool(v)
    for _k, _dv in _default_config().items():
        if isinstance(_dv, bool):
            cfg[_k] = _as_bool(cfg.get(_k, _dv))
    def _clampf(key, default, lo, hi):
        try:
            v = float(cfg.get(key, default))
            if v != v or v in (float("inf"), float("-inf")):
                raise ValueError
            cfg[key] = max(lo, min(hi, v))
        except Exception:  # noqa
            cfg[key] = default
    _clampf("temperature", 0.7, 0.0, 2.0)
    _clampf("signal_weight", 0.30, 0.0, 0.9)
    try:
        cfg["max_tokens"] = max(1, min(200000, int(float(cfg.get("max_tokens", 512)))))
    except Exception:  # noqa
        cfg["max_tokens"] = 512
    for _k in ("base_url", "api_key", "model", "system_prompt", "proxy"):
        _v = cfg.get(_k)
        cfg[_k] = _v.strip() if isinstance(_v, str) else ("" if _v is None else str(_v))
    return cfg


def load_config() -> dict:
    cfg = _default_config()
    if os.path.exists(CONFIG_PATH):
        try:
            with open(CONFIG_PATH, encoding="utf-8") as f:
                saved = json.load(f)
            # اصلاح (AI-002): فایلِ JSONِ معتبر ولی غیرdict (رشته/لیست) نباید
            # load_config و endpointهای مصرف‌کننده را بشکند.
            if isinstance(saved, dict):
                cfg.update(saved)
        except Exception:  # noqa
            pass
    return _sanitize_cfg(cfg)


def save_config(patch: dict) -> dict:
    cfg = load_config()
    allowed = set(_default_config().keys())   # فقط کلیدهای شناخته‌شده
    for k, v in (patch or {}).items():
        if k not in allowed:
            continue
        # کلیدِ خالی نباید مقدارِ قبلی را پاک کند
        if k == "api_key" and (v is None or v == ""):
            continue
        cfg[k] = v
    for k in [k for k in cfg if k not in allowed]:
        cfg.pop(k, None)
    # اصلاح (هم‌خانوادهٔ DISP-001 + AI-002): اعتبارسنجیِ مشترک با load_config
    cfg = _sanitize_cfg(cfg)
    with _lock:
        with open(CONFIG_PATH, "w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False, indent=2)
    return cfg


def public_config() -> dict:
    """نسخه‌ی امن برای فرانت (بدون کلیدِ کامل)."""
    c = load_config()
    key = c.get("api_key") or ""
    masked = ("••••" + key[-4:]) if len(key) > 4 else ("" if not key else "••••")
    return {
        "enabled": c.get("enabled", False),
        "base_url": c.get("base_url", ""),
        "model": c.get("model", ""),
        "temperature": c.get("temperature", 0.7),
        "max_tokens": c.get("max_tokens", 512),
        "use_in_signal": bool(c.get("use_in_signal", False)),
        "signal_weight": float(c.get("signal_weight", 0.30)),
        "system_prompt": c.get("system_prompt", ""),
        "api_key_set": bool(key),
        "api_key_masked": masked,
        "proxy": c.get("proxy", ""),
    }


# --------------------------------------------------------------------- لاگ (SQLite + مهاجرتِ یک‌باره)
import db  # noqa: E402

_LOG_CHANNEL = "ai"
_LOG_CAP = 500
_log_migrated = False


def _ensure_log_migrated():
    global _log_migrated
    if _log_migrated:
        return
    with _log_lock:
        if _log_migrated:
            return
        try:
            db.migrate_logs_from_json(_LOG_CHANNEL, LOG_PATH, _LOG_CAP)
        except Exception:  # noqa
            pass
        _log_migrated = True


def append_log(entry: dict) -> None:
    _ensure_log_migrated()
    db.add_log(_LOG_CHANNEL, entry, cap=_LOG_CAP)


def read_log(limit: int = 200) -> list:
    _ensure_log_migrated()
    return db.get_logs(_LOG_CHANNEL, limit)


def clear_log() -> None:
    _ensure_log_migrated()
    db.clear_logs(_LOG_CHANNEL)


# --------------------------------------------------------------------- کمک‌ها
def _proxies(cfg: dict = None) -> dict:
    """دیکشنریِ پروکسی برای requests (اصلاح AI-NET-001)؛ None یعنی بدونِ پروکسی."""
    try:
        p = ((cfg or load_config()).get("proxy") or "").strip()
    except Exception:  # noqa
        p = ""
    if not p:
        return None
    return {"http": p, "https": p}


def _net_err_fa(e) -> str:
    """ترجمهٔ خطاهای شبکهٔ خام (مثل HTTPSConnectionPool port=443) به راهنمای روشن.

    اصلاح (AI-NET-001): کاربر «port=443» را به‌اشتباه «ارور 443 سرور» می‌خواند؛
    یعنی اتصالِ HTTPS از همین سیستم به سرویس‌دهنده برقرار نشده (فیلترینگ/تحریم/
    نبودِ پروکسی/قطعی)، نه خطای خودِ سرویس.
    """
    t = str(e)
    low = t.lower()
    hint = ""
    if "missing dependencies for socks" in low:
        hint = ("پشتیبانیِ SOCKS نصب نیست؛ روی سیستمِ خودتان اجرا کنید: "
                "pip install requests[socks]")
    elif "proxyerror" in low or "cannot connect to proxy" in low or "socks" in low:
        hint = ("اتصال به «پروکسیِ» تنظیم‌شده برقرار نشد؛ آدرس/پورتِ پروکسی و "
                "روشن‌بودنِ آن را بررسی کنید.")
    elif "nameresolution" in low or "getaddrinfo" in low or "name or service not known" in low:
        hint = ("نامِ دامنهٔ سرویس‌دهنده پیدا نشد (DNS)؛ اینترنت/DNS سیستم را بررسی "
                "کنید یا Base URL را اصلاح کنید.")
    elif "ssl" in low or "certificate" in low:
        hint = ("دست‌دادنِ SSL ناموفق بود؛ معمولاً نشانهٔ فیلترینگ/دستکاریِ مسیر است؛ "
                "از پروکسی/VPN سالم استفاده کنید.")
    elif ("port=443" in t or "max retries" in low or "connection refused" in low
          or "timed out" in low or "newconnectionerror" in low
          or "connectionerror" in low or "connecttimeout" in low):
        hint = ("اتصالِ HTTPS (پورت 443) به سرویس‌دهندهٔ هوش مصنوعی برقرار نشد. "
                "این «کدِ خطای سرور» نیست؛ یعنی از این سیستم به آن سرور راه نیست. "
                "علت‌های رایج: فیلترینگ/تحریمِ سرویس (مثل OpenAI از ایران)، قطعی/"
                "محدودیتِ اینترنت، یا نبودِ پروکسی. راه‌حل‌ها: ۱) در فیلدِ «پروکسی» "
                "تبِ هوش مصنوعی یک پروکسیِ سالم بدهید (socks5h://127.0.0.1:1080 یا "
                "http://…)، ۲) از سرویسِ سازگارِ در دسترس (OpenRouter/Groq/Together "
                "یا مدلِ محلی LM Studio/Ollama با Base URL محلی) استفاده کنید.")
    if hint:
        return hint + " (جزئیات فنی: " + t[:220] + ")"
    return t


def _base(base_url: str = None) -> str:
    b = (base_url if base_url is not None else load_config().get("base_url", "")) or ""
    return b.strip().rstrip("/")


def _key(api_key: str = None) -> str:
    k = api_key if api_key not in (None, "") else load_config().get("api_key", "")
    return (k or "").strip()


def _headers(api_key: str = None) -> dict:
    # سرورهای محلی (LM Studio/Ollama) اغلب کلید نمی‌خواهند؛ اگر کلیدی نبود،
    # هدرِ Authorization اصلاً فرستاده نمی‌شود تا این سرورها هم کار کنند.
    h = {"Content-Type": "application/json",
         "HTTP-Referer": "https://multimarket.agent",
         "X-Title": "MultiMarket Agent"}
    k = _key(api_key)
    if k:
        h["Authorization"] = f"Bearer {k}"
    return h


# --------------------------------------------------------------------- عملیات
def list_models(base_url: str = None, api_key: str = None) -> dict:
    """فهرستِ مدل‌های در دسترس از `GET {base}/models`."""
    base = _base(base_url)
    if not base:
        return {"ok": False, "error": "Base URL وارد نشده است."}
    # کلید اجباری نیست: سرورهای محلی بدون کلید هم پشتیبانی می‌شوند. اگر سرویسِ ابری
    # به کلید نیاز داشته باشد، خطای ۴۰۱ خودش با پیامِ روشن بازگردانده می‌شود.
    url = base + "/models"
    t0 = time.time()
    try:
        r = _session.get(url, headers=_headers(api_key), timeout=MODELS_TIMEOUT,
                         proxies=_proxies())
        ms = int((time.time() - t0) * 1000)
        if r.status_code >= 400:
            msg = _extract_error(r)
            append_log({"kind": "models", "ok": False, "status": r.status_code,
                        "ms": ms, "detail": msg})
            return {"ok": False, "error": f"[{r.status_code}] {msg}", "status": r.status_code}
        body = r.json()
        raw = body.get("data", body if isinstance(body, list) else [])
        models = sorted({(m.get("id") if isinstance(m, dict) else str(m)) for m in raw})
        append_log({"kind": "models", "ok": True, "status": r.status_code,
                    "ms": ms, "detail": f"{len(models)} مدل دریافت شد"})
        return {"ok": True, "models": models, "count": len(models), "ms": ms}
    except Exception as e:  # noqa
        append_log({"kind": "models", "ok": False, "detail": str(e)})
        return {"ok": False, "error": _net_err_fa(e)}


def _extract_error(r) -> str:
    try:
        j = r.json()
        if isinstance(j, dict):
            err = j.get("error")
            if isinstance(err, dict):
                return err.get("message", str(err))
            if err:
                return str(err)
            return j.get("message", r.text[:300])
    except Exception:  # noqa
        pass
    return (r.text or "خطای نامشخص")[:300]


def chat(prompt: str, base_url: str = None, api_key: str = None,
         model: str = None, system_prompt: str = None,
         temperature: float = None, max_tokens: int = None) -> dict:
    """ارسالِ یک پیام به مدل و دریافتِ پاسخ (`POST {base}/chat/completions`)."""
    cfg = load_config()
    base = _base(base_url)
    mdl = model or cfg.get("model")
    if not base:
        return {"ok": False, "error": "Base URL وارد نشده است."}
    if not mdl:
        return {"ok": False, "error": "مدل انتخاب نشده است."}
    sysp = system_prompt if system_prompt is not None else cfg.get("system_prompt", "")
    messages = []
    if sysp:
        messages.append({"role": "system", "content": sysp})
    messages.append({"role": "user", "content": prompt})
    payload = {
        "model": mdl,
        "messages": messages,
        "temperature": float(temperature if temperature is not None else cfg.get("temperature", 0.7)),
        "max_tokens": int(max_tokens if max_tokens is not None else cfg.get("max_tokens", 512)),
    }
    url = base + "/chat/completions"
    t0 = time.time()
    try:
        r = _session.post(url, headers=_headers(api_key), json=payload, timeout=CHAT_TIMEOUT,
                          proxies=_proxies())
        ms = int((time.time() - t0) * 1000)
        if r.status_code >= 400:
            msg = _extract_error(r)
            append_log({"kind": "chat", "ok": False, "status": r.status_code,
                        "ms": ms, "model": mdl, "detail": msg})
            return {"ok": False, "error": f"[{r.status_code}] {msg}", "status": r.status_code}
        j = r.json()
        choice = (j.get("choices") or [{}])[0]
        content = (choice.get("message") or {}).get("content", "")
        usage = j.get("usage", {})
        append_log({"kind": "chat", "ok": True, "status": r.status_code, "ms": ms,
                    "model": mdl, "detail": f"{len(content)} کاراکتر پاسخ",
                    "usage": usage})
        return {"ok": True, "content": content, "model": mdl, "usage": usage, "ms": ms}
    except Exception as e:  # noqa
        append_log({"kind": "chat", "ok": False, "model": mdl, "detail": str(e)})
        return {"ok": False, "error": _net_err_fa(e)}


def chat_stream(prompt: str, base_url: str = None, api_key: str = None,
                model: str = None, system_prompt: str = None,
                temperature: float = None, max_tokens: int = None):
    """نسخهٔ جریانیِ chat: قطعاتِ متن را همان لحظه که مدل تولید می‌کند yield می‌کند.

    هر رخداد یک دیکشنری است:
      {"delta": "..."}                              → یک تکه‌متنِ تازه
      {"__error__": "..."}                          → خطا (پیش از پایان)
      {"__done__": True, "ms", "model", "content"}  → پایانِ موفق
    این تأخیرِ «تا اولین کلمه» را از چند ثانیه به چند دهمِ ثانیه می‌رساند و کندیِ
    محسوس در ارسال/دریافتِ پیام را برطرف می‌کند. در پایان همان لاگِ chat ثبت می‌شود.
    """
    cfg = load_config()
    base = _base(base_url)
    mdl = model or cfg.get("model")
    if not base:
        yield {"__error__": "Base URL وارد نشده است."}
        return
    if not mdl:
        yield {"__error__": "مدل انتخاب نشده است."}
        return
    sysp = system_prompt if system_prompt is not None else cfg.get("system_prompt", "")
    messages = []
    if sysp:
        messages.append({"role": "system", "content": sysp})
    messages.append({"role": "user", "content": prompt})
    payload = {
        "model": mdl,
        "messages": messages,
        "temperature": float(temperature if temperature is not None else cfg.get("temperature", 0.7)),
        "max_tokens": int(max_tokens if max_tokens is not None else cfg.get("max_tokens", 512)),
        "stream": True,
    }
    url = base + "/chat/completions"
    t0 = time.time()
    acc = []
    r = None  # اصلاح (AI-003): پاسخِ stream=True باید در هر مسیری بسته شود
    try:
        r = _session.post(url, headers=_headers(api_key), json=payload,
                          timeout=CHAT_TIMEOUT, stream=True, proxies=_proxies())
        if r.status_code >= 400:
            msg = _extract_error(r)
            append_log({"kind": "chat", "ok": False, "status": r.status_code,
                        "model": mdl, "detail": msg})
            yield {"__error__": f"[{r.status_code}] {msg}"}
            return
        for line in r.iter_lines(decode_unicode=True):
            if not line:
                continue
            data = line[5:].strip() if line.startswith("data:") else line.strip()
            if data == "[DONE]":
                break
            try:
                chunk = json.loads(data)
            except Exception:  # noqa
                continue
            delta = ((chunk.get("choices") or [{}])[0].get("delta") or {})
            piece = delta.get("content")
            if piece:
                acc.append(piece)
                yield {"delta": piece}
        ms = int((time.time() - t0) * 1000)
        full = "".join(acc)
        append_log({"kind": "chat", "ok": True, "ms": ms, "model": mdl,
                    "detail": f"{len(full)} کاراکتر پاسخ (جریانی)"})
        yield {"__done__": True, "ms": ms, "model": mdl, "content": full}
    except Exception as e:  # noqa
        append_log({"kind": "chat", "ok": False, "model": mdl, "detail": str(e)})
        yield {"__error__": _net_err_fa(e)}
    finally:
        # اصلاح (AI-003): اگر کلاینت وسطِ SSE قطع کند یا خطای HTTP رخ دهد،
        # سوکتِ keep-alive بدونِ close تا GC اشغال می‌ماند.
        try:
            if r is not None:
                r.close()
        except Exception:  # noqa
            pass


def _safe_text(value, limit: int = 700) -> str:
    """متنِ مدل را برای نمایش امن می‌کند (OP5-AI-09).

    قرارداد: خروجیِ مدل دادهٔ «غیرقابل‌اعتماد» است. فرانت‌اند با esc() نمایش
    می‌دهد، ولی این لایه هم تگ‌های HTML/اسکریپت، کاراکترهای کنترلی و توالی‌های
    خطرناک را حذف می‌کند تا حتی اگر جایی خام نمایش داده شود، تزریق رخ ندهد.
    """
    if value is None:
        return ""
    import re as _re
    t = str(value)
    # کاراکترهای کنترلی (به‌جز خط/تب) و BOM
    t = "".join(ch for ch in t if ch in "\n\t" or ord(ch) >= 32)
    t = t.replace("\ufeff", "")
    # حذفِ تگ‌های HTML و بلوک‌های اسکریپت/استایل (چند مرحله‌ای تا تودرتویی‌ها)
    for _ in range(3):
        t2 = _re.sub(r"<\s*(script|style)[^>]*>.*?<\s*/\s*\1\s*>", " ", t,
                     flags=_re.S | _re.I)
        # فقط چیزی که «شکلِ تگ» دارد حذف می‌شود تا متن‌هایی مثل «RSI < 30» آسیب نبینند
        t2 = _re.sub(r"<\s*/?\s*[a-zA-Z!][^>]*>", " ", t2)
        if t2 == t:
            break
        t = t2
    # توالی‌های مشکوکِ پروتکل/هندلر
    t = _re.sub(r"(?i)(javascript|vbscript|data)\s*:", "", t)
    t = _re.sub(r"(?i)\bon[a-z]+\s*=", "", t)
    t = t.replace("\x00", "").strip()
    return t[:limit]


def _parse_json(text: str):
    """استخراجِ مطمئنِ یک شیء JSON از پاسخِ مدل (با تحملِ code-fence و متنِ اضافه).

    اصلاح (AIDASH-002): مدل‌های reasoning (مثل DeepSeek-R1) خروجی را با بلوکِ
    <think>…</think> یا متنِ توضیحی دورِ JSON می‌فرستند؛ قبلاً تجزیه شکست می‌خورد،
    توکن مصرف می‌شد ولی «تحلیل هوش مصنوعی» نمایش داده نمی‌شد.
    """
    import re
    if not text:
        return None
    t = text.strip()
    # حذفِ زنجیرهٔ تفکرِ مدل‌های reasoning
    t = re.sub(r"<think>.*?</think>", "", t, flags=re.S).strip()
    # think بازِ بدونِ بسته: فقط تا شروعِ اولین fence یا { حذف شود (نه کلِ متن)
    if t.startswith("<think>"):
        _cut = min([x for x in (t.find("```"), t.find("{")) if x != -1] or [len(t)])
        t = t[_cut:].strip()
    # حذفِ code-fence در هر جای متن (```json … ```)
    m = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", t, flags=re.S)
    if m:
        try:
            return json.loads(m.group(1))
        except Exception:  # noqa
            pass
    t = re.sub(r"^```(?:json)?", "", t).strip()
    t = re.sub(r"```$", "", t).strip()
    try:
        return json.loads(t)
    except Exception:  # noqa
        pass
    # برشِ بزرگ‌ترین بازهٔ آکولادی
    i, j = t.find("{"), t.rfind("}")
    if i != -1 and j != -1 and j > i:
        try:
            return json.loads(t[i:j + 1])
        except Exception:  # noqa
            pass
        # تطبیقِ آکولادِ متوازن از اولین { (وقتی متنِ اضافه بعدِ JSON است)
        depth = 0
        for k in range(i, len(t)):
            if t[k] == "{":
                depth += 1
            elif t[k] == "}":
                depth -= 1
                if depth == 0:
                    try:
                        return json.loads(t[i:k + 1])
                    except Exception:  # noqa
                        break
    return None


# اصلاح (AIDASH-007): از مدل، تحلیلِ «متنیِ» جداگانه برای هر بُعد + سطوحِ کلیدی هم
# خواسته می‌شود تا تبِ «داشبورد تحلیل هوش مصنوعی» تحلیلِ تکنیکالِ حرفه‌ایِ کامل
# نمایش دهد، نه فقط یک امتیاز. فیلدهای جدید اختیاری‌اند (سازگار با مدل‌های ضعیف‌تر).
_ANALYSIS_SYS = (
    "تو یک تحلیلگرِ ارشد و حرفه‌ایِ بازارهای مالی هستی. بر پایه‌ی داده‌های عددیِ ارائه‌شده،"
    " سه تحلیلِ «تکنیکال»، «فاندامنتال» و «سنتیمنتال» را دقیق و حرفه‌ای انجام بده و برای هرکدام"
    " یک امتیازِ عددی بین ۱۰۰- (کاملاً نزولی) تا ۱۰۰+ (کاملاً صعودی) بده."
    " در تحلیلِ تکنیکال از همهٔ داده‌ها استفاده کن: اندیکاتورها (RSI/MACD/EMA/ADX/Ichimoku/"
    "Bollinger/Stochastic)، حمایت/مقاومت، فیبوناچی، پیوت، سقف/کفِ روز قبل، ترندلاین،"
    " ساختارِ بازار (BOS/CHOCH) و FVG؛ و در technical_analysis تحلیلِ ۲ تا ۴ جمله‌ایِ"
    " حرفه‌ای بنویس (روند، مومنتوم، سطوحِ تصمیم‌ساز)."
    " سپس یک امتیازِ کلیِ جمع‌بندی‌شده (overall_score) و جهتِ پیشنهادی بده."
    " فقط و فقط یک شیءِ JSON معتبر برگردان؛ هیچ متن، توضیح یا code-fence بیرون از JSON ننویس."
    " همهٔ متن‌ها فارسیِ کوتاه و دقیق باشند. این ابزار آموزشی است."
)

_ANALYSIS_SCHEMA = (
    '{"technical_score": <عدد -100..100>, "fundamental_score": <عدد -100..100>,'
    ' "sentiment_score": <عدد -100..100>, "overall_score": <عدد -100..100>,'
    ' "direction": "LONG|SHORT|NEUTRAL", "confidence": <عدد 0..100>,'
    ' "summary": "<خلاصه‌ی حرفه‌ایِ فارسی>", "reasons": ["<دلیل ۱>", "<دلیل ۲>", "<دلیل ۳>"],'
    ' "technical_analysis": "<تحلیلِ تکنیکالِ حرفه‌ای ۲-۴ جمله>",'
    ' "fundamental_analysis": "<تحلیلِ فاندامنتال ۱-۲ جمله>",'
    ' "sentiment_analysis": "<تحلیلِ سنتیمنت ۱-۲ جمله>",'
    ' "key_levels": {"support": [<عدد>...], "resistance": [<عدد>...]}}'
)


def analyze_market(snapshot: dict, model: str = None) -> dict:
    """تحلیلِ حرفه‌ایِ تکنیکال/فاندامنتال/سنتیمنتالِ یک نماد توسط مدل و بازگرداندنِ امتیازها (JSON)."""
    cfg = load_config()
    user = ("داده‌های نماد برای تحلیل (JSON):\n"
            + json.dumps(snapshot, ensure_ascii=False)
            + "\n\nخروجی را دقیقاً و تنها در این قالبِ JSON بده:\n" + _ANALYSIS_SCHEMA)
    try:
        # اصلاح (AIDASH-002): کفِ بالاتر تا JSON وسطِ راه بریده نشود (علتِ رایجِ
        # «توکن مصرف شد ولی تحلیل نیامد» در مدل‌های پرحرف/reasoning).
        max_tok = max(int(float(cfg.get("max_tokens", 512))), 900)
    except Exception:  # noqa
        max_tok = 900
    try:
        temp = min(float(cfg.get("temperature", 0.7)), 0.4)  # برای پایداریِ خروجی (۰ محترم است)
    except Exception:  # noqa
        temp = 0.4
    res = chat(user, system_prompt=_ANALYSIS_SYS, temperature=temp,
               max_tokens=max_tok, model=model)
    if not res.get("ok"):
        return {"ok": False, "error": res.get("error")}
    parsed = _parse_json(res.get("content", ""))
    if not isinstance(parsed, dict):
        return {"ok": False,
                "error": ("پاسخِ مدل قابلِ تجزیه به JSON نبود (توکن مصرف شد). "
                          "راه‌حل: مدلِ دیگری انتخاب کنید یا max_tokens را بیشتر کنید؛ "
                          "برخی مدل‌های reasoning خروجیِ غیر-JSON می‌دهند."),
                "raw": (res.get("content") or "")[:400]}

    def _cl(x, lo=-100.0, hi=100.0):
        # اصلاح (AI-001): max(lo, min(hi, nan)) در پایتون 100.0 برمی‌گرداند؛
        # NaN/inf از مدل باید 0 (خنثی) شود، نه امتیازِ قطبی.
        try:
            v = float(x)
            if not math.isfinite(v):
                return 0.0
            return max(lo, min(hi, v))
        except Exception:  # noqa
            return 0.0

    direction = str(parsed.get("direction", "NEUTRAL")).upper()
    if direction not in ("LONG", "SHORT", "NEUTRAL"):
        direction = "NEUTRAL"
    reasons = parsed.get("reasons") or []
    if isinstance(reasons, str):
        reasons = [reasons]
    out = {
        "ok": True,
        "technical_score": _cl(parsed.get("technical_score", 0)),
        "fundamental_score": _cl(parsed.get("fundamental_score", 0)),
        "sentiment_score": _cl(parsed.get("sentiment_score", 0)),
        "overall_score": _cl(parsed.get("overall_score", parsed.get("score", 0))),
        "direction": direction,
        "confidence": int(_cl(parsed.get("confidence", 50), 0, 100)),
        "summary": _safe_text(parsed.get("summary", "")),
        "reasons": [_safe_text(r, 300) for r in reasons][:8],
        "model": res.get("model"),
        "ms": res.get("ms"),
    }
    # اصلاح (AIDASH-007): فیلدهای تحلیلیِ اختیاری — با پاک‌سازیِ نوع/طول
    for _k in ("technical_analysis", "fundamental_analysis", "sentiment_analysis"):
        _v = parsed.get(_k)
        if isinstance(_v, str) and _v.strip():
            out[_k] = _safe_text(_v, 700)
    _kl = parsed.get("key_levels")
    if isinstance(_kl, dict):
        import math as _math

        def _nums(x):
            o = []
            for v in (x or []) if isinstance(x, (list, tuple)) else []:
                try:
                    f = float(v)
                    if _math.isfinite(f):
                        o.append(f)
                except Exception:  # noqa
                    pass
            return o[:6]
        _sup, _res2 = _nums(_kl.get("support")), _nums(_kl.get("resistance"))
        if _sup or _res2:
            out["key_levels"] = {"support": _sup, "resistance": _res2}
    return out


def test_connection(base_url: str = None, api_key: str = None, model: str = None) -> dict:
    """تستِ کامل: ابتدا فهرست مدل‌ها، سپس یک پرسشِ کوتاه با مدلِ انتخابی."""
    ml = list_models(base_url, api_key)
    out = {"ok": False, "models": ml.get("models", []), "count": ml.get("count", 0),
           "models_ok": ml.get("ok", False), "models_ms": ml.get("ms")}
    if not ml.get("ok"):
        out["error"] = ml.get("error")
        return out
    mdl = model or load_config().get("model")
    # اگر مدلِ انتخابی در فهرست نبود، هشدار بده ولی همچنان تست کن
    if mdl and out["models"] and mdl not in out["models"]:
        out["model_warning"] = f"مدلِ «{mdl}» در فهرستِ سرویس نیست؛ ممکن است کار نکند."
    # پرسشِ حداقلی برای تستِ اتصال: کم‌ترین توکنِ ممکن تا نتیجه سریع برگردد.
    ping = chat("ping", base_url=base_url, api_key=api_key, model=mdl,
                max_tokens=5, temperature=0.0)
    out["chat_ok"] = ping.get("ok")
    out["chat_ms"] = ping.get("ms")
    out["reply"] = ping.get("content")
    out["model"] = mdl
    if not ping.get("ok"):
        out["error"] = ping.get("error")
        out["ok"] = False
    else:
        out["ok"] = True
    return out


def connect(base_url: str = None, api_key: str = None, model: str = None) -> dict:
    """تأییدِ اتصال و ثبتِ وضعیتِ «متصل». تنظیمات هم ذخیره می‌شود."""
    patch = {}
    if base_url is not None:
        patch["base_url"] = base_url
    if api_key:
        patch["api_key"] = api_key
    if model:
        patch["model"] = model
    if patch:
        save_config(patch)
    res = test_connection(model=model)
    with _lock:
        if res.get("ok"):
            _conn.update(connected=True, since=time.time(),
                         model=res.get("model"), error=None)
            save_config({"enabled": True})
            append_log({"kind": "connect", "ok": True,
                        "detail": f"متصل شد · مدل {res.get('model')}"})
        else:
            _conn.update(connected=False, since=None, error=res.get("error"))
            append_log({"kind": "connect", "ok": False, "detail": res.get("error")})
    res["connected"] = _conn["connected"]
    return res


def disconnect() -> dict:
    with _lock:
        _conn.update(connected=False, since=None, error=None)
    save_config({"enabled": False})
    append_log({"kind": "disconnect", "ok": True, "detail": "قطع شد"})
    return status()


def status() -> dict:
    c = load_config()
    return {
        "connected": bool(_conn["connected"]),
        "since": _conn["since"],
        "model": _conn["model"] or c.get("model"),
        "error": _conn["error"],
        "base_url": c.get("base_url"),
        "api_key_set": bool(c.get("api_key")),
        "enabled": c.get("enabled", False),
    }
