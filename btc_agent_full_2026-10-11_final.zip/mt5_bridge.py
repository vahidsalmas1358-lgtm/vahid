"""پل ارتباطی با متاتریدر ۵ (MetaTrader 5) برای اجرای خودکار معاملات.

نکات مهم معماری (بسیار مهم بخوانید):
--------------------------------------------------------------------------
1) کتابخانه‌ی رسمی «MetaTrader5» فقط روی **ویندوز** کار می‌کند و از طریق یک
   کانال ارتباطی محلی (IPC) به ترمینال متاتریدر ۵ که روی همان کامپیوتر نصب و
   **در حال اجرا و لاگین‌شده** است، وصل می‌شود. بنابراین این سرور Flask باید روی
   همان ویندوزی اجرا شود که ترمینال MT5 در آن باز و لاگین است.

2) اتصال «بدون وارد کردن یوزرنیم/پسورد/سرور» دقیقاً به این شکل ممکن است:
   فراخوانی `mt5.initialize()` بدون آرگومان به ترمینالِ در حال اجرا و
   لاگین‌شده وصل می‌شود و همان حسابِ فعال را برای معامله استفاده می‌کند.
   یعنی هویت از خودِ ترمینالِ باز خوانده می‌شود و نیازی به کردنشیال نیست.

3) روی لینوکس/مک این ماژول در حالت «غیرفعال» بارگذاری می‌شود (بدون خطا) تا بقیه‌ی
   داشبورد کار کند؛ ولی ارسال واقعی سفارش فقط روی ویندوزِ دارای MT5 انجام می‌شود.
"""
from __future__ import annotations

import os
import json
import threading
import time
from datetime import datetime, timezone

import news
import market_hours
import dispatch  # منبعِ واحدِ تنظیماتِ فیلترِ اخبار (تبِ «روشِ ارسالِ سیگنال»)

try:  # کتابخانه فقط روی ویندوز با MT5 نصب‌شده در دسترس است
    import MetaTrader5 as mt5  # type: ignore
    MT5_AVAILABLE = True
    _IMPORT_ERR = None
except Exception as e:  # noqa
    mt5 = None
    MT5_AVAILABLE = False
    _IMPORT_ERR = str(e)

CONFIG_PATH = os.path.join(os.path.dirname(__file__), "mt5_config.json")

# قفل سراسری چون API متاتریدر thread-safe نیست و Flask چند‌نخی است
_lock = threading.RLock()
# اصلاح (OPUS5-M9): کلِ توالیِ «چکِ ریسک → ارسال → ثبت» باید زیر یک قفلِ مشترک
# باشد؛ دو درخواستِ همزمان (خودکار+دستی) قبلاً هر دو از سقف‌ها رد می‌شدند.
_trade_lock = threading.RLock()
_conn = {"connected": False, "error": None, "since": None}

# وضعیت موتور مدیریت پوزیشن (Breakeven + Trailing)
_manager = {"thread": None, "stop": None, "running": False,
            "last_run": None, "last_error": None, "actions": []}
# حافظه‌ی هر پوزیشن: استاپ اولیه و ریسک اولیه (برای محاسبه R و breakeven)
_pos_state: dict = {}


# --------------------------------------------------------------------- تنظیمات
def _default_config() -> dict:
    return {
        "enabled": True,               # فعال بودن ماژول
        "auto_trade": False,           # ارسال خودکار هنگام تغییر جهت سیگنال
        "default_volume": 0.01,        # حجم پایه (لات)
        "risk_mode": "fixed",          # fixed = حجم ثابت | risk_pct = درصدی از موجودی
        "risk_pct": 1.0,               # درصد ریسک هر معامله (وقتی risk_mode=risk_pct)
        "tp_mode": "split",            # split=۳ پوزیشن | single=یک پوزیشن با TP1 | partial=یک پوزیشن + بستن جزئی | none=بدون TP
        "partial_fractions": [0.5, 0.3],  # سهم بسته‌شدن در TP1 و TP2 (بقیه تا TP3/تریلینگ می‌ماند)
        "execution": "market",         # market=اجرای فوری با قیمت روز | pending=سفارش معلق روی نقطه ورود
        "deviation": 20,               # حداکثر لغزش قیمت (points) برای اجرای بازار
        "magic": 532025,               # شناسه‌ی اکسپرت (برای تفکیک معاملات این ربات)
        "comment": "MultiMarketAgent",
        "use_plan_sl": True,           # استفاده از استاپ‌لاس نقشه‌ی معامله
        "use_plan_tp": True,           # استفاده از حد سودهای نقشه‌ی معامله
        "allowed_symbols": [],         # اگر خالی باشد همه مجازند؛ وگرنه فقط این‌ها
        # --- محافظ ریسک (Risk Guard) ---
        "max_open_positions": 0,       # حداکثر پوزیشن باز هم‌زمانِ این ربات (۰ = نامحدود)
        "max_daily_trades": 0,         # حداکثر تعداد معامله‌ی واقعی در روز (۰ = نامحدود)
        "max_daily_risk_pct": 0,       # سقف مجموع ریسک معاملات امروز به‌درصد موجودی (۰ = نامحدود)
        # --- فیلتر اخبار (News Filter) ---
        "news_filter_enabled": False,  # جلوگیری از باز کردن معامله نزدیک اخبار پرتأثیر
        "news_impact": "High",         # حداقل تأثیر برای مسدودسازی: High | Medium | Low
        "news_before_min": 30,         # چند دقیقه قبل از رویداد، معامله مسدود شود
        "news_after_min": 30,          # چند دقیقه بعد از رویداد، معامله مسدود شود
        # --- اعلان پیش از اخبار (Telegram/Email) ---
        "news_alert_enabled": False,   # ارسال اعلان پیش از رویدادهای پرتأثیر
        "news_alert_before_min": 30,   # چند دقیقه قبل از رویداد اعلان ارسال شود
        "news_alert_impact": "High",   # حداقل تأثیر برای اعلان
        "news_alert_currencies": [],   # ارزهای موردنظر (خالی = ارزهای اصلی USD/EUR/GBP/JPY)
        # --- بستن خودکار پوزیشن‌ها پیش از اخبار ---
        "news_autoclose_enabled": False,
        "news_close_before_min": 15,   # چند دقیقه قبل از رویداد، پوزیشن‌ها بسته شوند
        "news_close_impact": "High",   # حداقل تأثیر برای بستن خودکار
        "news_close_scope": "matching",  # matching = فقط پوزیشن‌های مرتبط با ارز رویداد | all = همه
        # --- محافظ ساعات بازار (آخر هفته/جمعه/تعطیلات/دقایقِ آخر) ---
        "market_hours_guard": True,    # جلوگیری از ارسال معامله‌ی واقعی روی بازارِ بسته (فارکس/فلز/کالا/شاخص در آخر هفته)
        "market_entry_cutoff_min": 0,  # OP5-MH-CUTOFF: ورودِ تازه در N دقیقهٔ آخرِ سشن بسته شود (۰ = خاموش)
        "market_close_before_session_end": False,  # OP5-MH-CLOSE: بستنِ خودکارِ پوزیشن‌ها پیش از پایانِ سشن (حلقهٔ پس‌زمینه)
        "market_close_cutoff_min": 15,             # چند دقیقه پیش از پایانِ سشن بسته شود
        # --- مدیریت خودکار پوزیشن (Breakeven + Trailing) ---
        "manage_positions": False,     # روشن/خاموش کردن موتور مدیریت پوزیشن در پس‌زمینه
        "manage_interval": 5,          # فاصله بررسی (ثانیه)
        "breakeven_enabled": True,     # انتقال استاپ به نقطه ورود پس از سود کافی (معادل رسیدن به TP1)
        "breakeven_r": 1.0,            # چند برابرِ ریسک اولیه سود لازم است تا سربه‌سر شود (۱R ≈ TP1)
        "breakeven_buffer_pts": 5,     # چند point بالاتر/پایین‌تر از ورود، استاپ قرار گیرد (پوشش اسپرد/کارمزد)
        "trailing_enabled": True,      # تریلینگ‌استاپ
        "trailing_mode": "points",     # points | percent | atr  (اصلاح OPUS5-M7)
        "trailing_atr_mult": 2.0,       # ضریبِ ATR وقتی trailing_mode=atr
        "trailing_points": 300,        # فاصله تریلینگ بر حسب point
        "trailing_percent": 0.5,       # فاصله تریلینگ بر حسب درصد قیمت
        "trailing_start_r": 1.0,       # تریلینگ فقط پس از رسیدن سود به این R شروع شود
        # نگاشت نماد داخلی → نماد کارگزار (چون هر بروکر نام‌گذاری متفاوتی دارد)
        "symbol_map": {},
    }


def load_config() -> dict:
    cfg = _default_config()
    if os.path.exists(CONFIG_PATH):
        try:
            with open(CONFIG_PATH, encoding="utf-8") as f:
                saved = json.load(f)
            cfg.update(saved or {})
        except Exception:  # noqa
            pass
    return cfg


def save_config(patch: dict) -> dict:
    cfg = load_config()
    allowed = set(_default_config().keys())   # فقط کلیدهای شناخته‌شده
    for k, v in (patch or {}).items():
        if k not in allowed:
            continue
        if k == "symbol_map" and isinstance(v, dict) and isinstance(cfg.get(k), dict):
            cfg[k].update({kk: vv for kk, vv in v.items()})
        else:
            cfg[k] = v
    for k in [k for k in cfg if k not in allowed]:
        cfg.pop(k, None)
    # اصلاح (هم‌خانوادهٔ DISP-001): کلیدِ بولی با رشتهٔ "false"/"0"/"off" دیگر True نمی‌شود
    def _as_bool(v):
        if isinstance(v, str):
            return v.strip().lower() not in ("", "0", "false", "no", "off", "none")
        return bool(v)
    for _k, _dv in _default_config().items():
        if isinstance(_dv, bool):
            cfg[_k] = _as_bool(cfg.get(_k, _dv))
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)
    return cfg


# --------------------------------------------------------------------- لاگ معاملات
LOG_PATH = os.path.join(os.path.dirname(__file__), "mt5_trades.json")
_log_lock = threading.Lock()


import db  # noqa: E402

_LOG_CHANNEL = "mt5"
_LOG_CAP = 1000
_log_migrated = False


def _ensure_log_migrated():
    global _log_migrated
    if _log_migrated:
        return
    with _log_lock:
        if _log_migrated:
            return
        try:
            db.migrate_logs_from_json(_LOG_CHANNEL, LOG_PATH, _LOG_CAP)
        except Exception:  # noqa
            pass
        _log_migrated = True


def read_log(limit: int = 200) -> list:
    _ensure_log_migrated()
    return db.get_logs(_LOG_CHANNEL, limit)


def append_log(entry: dict) -> None:
    _ensure_log_migrated()
    db.add_log(_LOG_CHANNEL, entry, cap=_LOG_CAP)


def clear_log() -> None:
    _ensure_log_migrated()
    db.clear_logs(_LOG_CHANNEL)


def _today_key() -> str:
    return time.strftime("%Y-%m-%d", time.localtime())


def _today_stats() -> dict:
    """آمار معاملات واقعیِ امروز از روی لاگ (تعداد و مجموع ریسک)."""
    today = _today_key()
    trades, risk = 0, 0.0
    for e in read_log(1000):
        if e.get("dry_run"):
            continue
        if not e.get("ok"):
            continue
        if time.strftime("%Y-%m-%d", time.localtime(e.get("ts", 0))) != today:
            continue
        trades += 1
        risk += float(e.get("risk_amount") or 0)
    return {"trades": trades, "risk": risk}


def check_risk_guard(risk_amount: float = 0.0, balance: float = 0.0) -> dict:
    """بررسی محدودیت‌های ریسک قبل از ارسال معامله. خروجی: {ok, reason}."""
    cfg = load_config()
    stats = _today_stats()
    # حداکثر پوزیشن باز
    max_open = int(cfg.get("max_open_positions", 0) or 0)
    if max_open > 0 and MT5_AVAILABLE and _conn.get("connected"):
        try:
            with _lock:
                ps = mt5.positions_get() or []
            magic = int(cfg.get("magic", 532025))
            open_n = sum(1 for p in ps if (not magic or p.magic == magic))
            if open_n >= max_open:
                return {"ok": False, "reason": f"سقف پوزیشن باز ({max_open}) پر است — اکنون {open_n} پوزیشن باز است."}
        except Exception:  # noqa
            pass
    # حداکثر معاملات روزانه
    max_daily = int(cfg.get("max_daily_trades", 0) or 0)
    if max_daily > 0 and stats["trades"] >= max_daily:
        return {"ok": False, "reason": f"سقف معاملات روزانه ({max_daily}) پر شده — امروز {stats['trades']} معامله انجام شده."}
    # سقف ریسک روزانه (درصدی از موجودی)
    max_risk_pct = float(cfg.get("max_daily_risk_pct", 0) or 0)
    if max_risk_pct > 0 and balance > 0:
        limit_cash = balance * max_risk_pct / 100.0
        if stats["risk"] + risk_amount > limit_cash:
            return {"ok": False,
                    "reason": f"سقف ریسک روزانه ({max_risk_pct}% ≈ {round(limit_cash,2)}) رد می‌شود — ریسک مصرف‌شده امروز {round(stats['risk'],2)}."}
    return {"ok": True, "today": stats}


# رجیستری برنامه‌ی «بستن جزئی» برای هر پوزیشن (ticket → پلن)
_partial_plans: dict = {}


STATE_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "mt5_pos_state.json")


def _persist_state():
    """اصلاح (OPUS5-M6): وضعیتِ بریک‌ایون/تریلینگ/پارشیال پس از ری‌استارتِ سرور
    از بین می‌رفت (فقط در RAM بود) و init_risk از SLِ جابه‌جاشده بازخوانی می‌شد.
    ذخیرهٔ اتمیک روی دیسک."""
    try:
        tmp = STATE_PATH + ".tmp"
        data = {"pos": {str(k): v for k, v in _pos_state.items()},
                "partial": {str(k): v for k, v in _partial_plans.items()}}
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False)
        os.replace(tmp, STATE_PATH)
    except Exception:  # noqa
        pass


def _restore_state():
    if not os.path.exists(STATE_PATH):
        return
    try:
        with open(STATE_PATH, encoding="utf-8") as f:
            d = json.load(f)
        for k, v in (d.get("pos") or {}).items():
            _pos_state.setdefault(int(k), v)
        for k, v in (d.get("partial") or {}).items():
            _partial_plans.setdefault(int(k), v)
    except Exception:  # noqa
        pass


def register_partial(ticket: int, tps: list, fractions: list, init_volume: float, is_buy: bool):
    _partial_plans[ticket] = {
        "tps": list(tps), "fractions": list(fractions),
        "init_volume": init_volume, "is_buy": is_buy, "done": []}
    _persist_state()


# ═══ اصلاح (OPUS5-M3): سفارش‌های معلق پس از فعال‌شدن، خودکار تحتِ مدیریت می‌روند
_pending_watch = {}   # order_ticket → متادیتای پارشیال/مدیریت


def _watch_pending(order_ticket, tps, fractions, init_volume, is_buy, cmt):
    if not order_ticket:
        return
    _pending_watch[int(order_ticket)] = {
        "tps": list(tps or []), "fractions": list(fractions or []),
        "init_volume": float(init_volume or 0), "is_buy": bool(is_buy),
        "cmt": str(cmt or "")}


def _resolve_pending_fills():
    """هر سفارشِ معلقی که به پوزیشن تبدیل شده را پیدا و به منیجر وصل می‌کند."""
    if not _pending_watch:
        return
    cfg = load_config()
    magic = int(cfg.get("magic", 532025))
    try:
        open_orders = {o.ticket for o in (mt5.orders_get() or [])}
    except Exception:  # noqa
        return
    for ot, meta in list(_pending_watch.items()):
        if ot in open_orders:
            continue          # هنوز معلق است
        try:
            cands = [p for p in (mt5.positions_get() or [])
                     if getattr(p, "magic", None) == magic
                     and getattr(p, "comment", "") == meta["cmt"]
                     and (p.type == 0) == meta["is_buy"]]
        except Exception:  # noqa
            continue
        if cands:
            p = sorted(cands, key=lambda x: getattr(x, "time_msc", getattr(x, "time", 0)),
                       reverse=True)[0]
            if meta.get("tps") and meta.get("fractions"):
                register_partial(p.ticket, meta["tps"], meta["fractions"],
                                 meta["init_volume"], meta["is_buy"])
        _pending_watch.pop(ot, None)
    _persist_state()


# ---------------------------------------------- نگاشتِ فارسیِ retcodeهای مهمِ MT5
# اصلاح (DISP-TRUTH-004): وقتی سفارش رد می‌شود، کاربر باید «علت» را به زبانِ روشن
# در لاگ ببیند (مثلِ خاموش‌بودنِ دکمهٔ AutoTrading) نه فقط یک عددِ خام.
RETCODE_FA = {
    10004: "ری‌کوت (تغییرِ قیمت) — دوباره تلاش کنید",
    10006: "درخواست توسط کارگزار رد شد",
    10013: "درخواستِ نامعتبر",
    10014: "حجمِ نامعتبر (کمتر از حداقل یا خارج از گام)",
    10015: "قیمتِ نامعتبر",
    10016: "استاپِ نامعتبر (SL/TP خیلی نزدیک یا سمتِ اشتباه)",
    10017: "معامله روی این نماد غیرفعال است",
    10018: "بازار بسته است",
    10019: "موجودی/مارجینِ ناکافی",
    10020: "قیمت تغییر کرد",
    10021: "قیمتی برای پردازش نیست (بازار/فید قطع)",
    10026: "معاملهٔ خودکار سمتِ «سرورِ کارگزار» غیرفعال است",
    10027: "معاملهٔ خودکار در ترمینال غیرفعال است — دکمهٔ «Algo Trading/AutoTrading» را در MT5 روشن کنید",
    10028: "درخواست در صفِ پردازش قفل شد",
    10030: "حالتِ پرشدنِ سفارش (filling) پشتیبانی نمی‌شود",
    10031: "ارتباط با سرورِ معاملات برقرار نیست",
    10044: "روی این حساب فقط بستنِ پوزیشن مجاز است",
}


def retcode_hint(rc) -> str:
    """توضیحِ فارسیِ retcode؛ اگر ناشناخته بود، رشتهٔ خالی."""
    try:
        return RETCODE_FA.get(int(rc), "")
    except (TypeError, ValueError):
        return ""


# ------------------------------------------------- نگاشت پیش‌فرض نماد → کارگزار
# هر بروکر نام‌های متفاوتی دارد؛ این‌ها نامزدهای رایج‌اند و به‌ترتیب امتحان می‌شوند.
DEFAULT_SYMBOL_CANDIDATES = {
    "BTC": ["BTCUSD", "BTCUSDT", "BTCUSD.", "Bitcoin", "BITCOIN", "BTC/USD"],
    "ETH": ["ETHUSD", "ETHUSDT", "Ethereum", "ETH/USD"],
    "SOL": ["SOLUSD", "SOLUSDT", "Solana"],
    "BNB": ["BNBUSD", "BNBUSDT"],
    "XRP": ["XRPUSD", "XRPUSDT", "Ripple"],
    "DOGE": ["DOGEUSD", "DOGEUSDT", "Dogecoin"],
    "XAU": ["XAUUSD", "GOLD", "XAUUSD.", "Gold"],
    "XAG": ["XAGUSD", "SILVER", "Silver"],
    "HG": ["XCUUSD", "COPPER", "Copper", "HG"],
    "WTI": ["XTIUSD", "USOIL", "WTI", "CL", "OILUSD", "USOil"],
    "NG": ["XNGUSD", "NGAS", "NATGAS", "NatGas", "XNG/USD"],
    "SPX": ["US500", "SPX500", "SP500", "US500.cash", "USA500", "SPXm"],
    "NASDAQ": ["USTEC", "NAS100", "US100", "NASDAQ", "USTECH", "NDX"],
    "EURUSD": ["EURUSD"],
    "GBPUSD": ["GBPUSD"],
    "USDJPY": ["USDJPY"],
}


def _err() -> str:
    """آخرین خطای متاتریدر به‌صورت متن."""
    if not MT5_AVAILABLE:
        return f"کتابخانه MetaTrader5 در دسترس نیست ({_IMPORT_ERR}). این قابلیت فقط روی ویندوزِ دارای ترمینال MT5 کار می‌کند."
    try:
        code, msg = mt5.last_error()
        return f"[{code}] {msg}"
    except Exception:  # noqa
        return "خطای نامشخص متاتریدر"


# --------------------------------------------------------------------- اتصال
def connect(force: bool = False) -> dict:
    """(OPUS5-M6: پس از اتصال، وضعیتِ ذخیره‌شدهٔ منیجر بازیابی می‌شود)"""
    """اتصال به ترمینال MT5 در حال اجرا (بدون کردنشیال).

    اگر ترمینال باز و لاگین باشد، `initialize()` بدون آرگومان به همان حساب وصل می‌شود.
    """
    with _lock:
        if not MT5_AVAILABLE:
            _conn.update(connected=False, error=_err())
            return status()
        try:
            if force:
                try:
                    mt5.shutdown()
                except Exception:  # noqa
                    pass
            ok = mt5.initialize()  # ← بدون login/password/server: به ترمینال باز وصل می‌شود
            if not ok:
                _conn.update(connected=False, error=_err(), since=None)
                return status()
            acc = mt5.account_info()
            if acc is None:
                _conn.update(connected=False,
                             error="ترمینال وصل شد اما هیچ حسابی لاگین نیست. لطفاً داخل متاتریدر وارد حساب شوید.",
                             since=None)
                return status()
            _conn.update(connected=True, error=None, since=time.time())
            # در صورت فعال بودن، موتور مدیریت پوزیشن را روشن کن
            try:
                if load_config().get("manage_positions"):
                    _restore_state()   # اصلاح (OPUS5-M6)
                    start_manager()
            except Exception:  # noqa
                pass
            return status()
        except Exception as e:  # noqa
            _conn.update(connected=False, error=str(e), since=None)
            return status()


def disconnect() -> dict:
    try:
        stop_manager()
    except Exception:  # noqa
        pass
    with _lock:
        if MT5_AVAILABLE:
            try:
                mt5.shutdown()
            except Exception:  # noqa
                pass
        _conn.update(connected=False, since=None)
        return status()


def _ensure() -> bool:
    """اطمینان از برقرار بودن اتصال؛ در صورت نیاز دوباره وصل می‌شود.

    اصلاح (MT5-005): خواندن account_info بیرون از _lock با سایر فراخوانی‌های
    MT5 در Flaskِ چندنخی تداخل داشت (API رسماً thread-safe نیست).
    """
    with _lock:
        if not MT5_AVAILABLE:
            return False
        try:
            if _conn["connected"]:
                if mt5.account_info() is not None:
                    return True
                # اصلاح (CONN-FLAP-002): خطای گذرا (ترمینالِ لحظه‌ای مشغول) نباید
                # فوراً به «بازاتصالِ کامل» و قطع/وصلِ نمایشی بینجامد؛ یک تلاشِ
                # کوتاهِ مجدد اغلب کافی است.
                time.sleep(0.15)
                if mt5.account_info() is not None:
                    return True
        except Exception:  # noqa
            pass
        return connect().get("connected", False)


def status() -> dict:
    """وضعیت اتصال + اطلاعات حساب و ترمینال (برای نمایش در داشبورد)."""
    out = {
        "available": MT5_AVAILABLE,
        "connected": bool(_conn["connected"]),
        "error": _conn["error"],
        "import_error": _IMPORT_ERR,
        "account": None,
        "terminal": None,
        "manager": manager_status(),
    }
    if not MT5_AVAILABLE:
        return out
    try:
        with _lock:
            acc = mt5.account_info() if _conn["connected"] else None
            term = mt5.terminal_info() if _conn["connected"] else None
        if acc is not None:
            out["connected"] = True
            out["account"] = {
                "login": acc.login, "name": getattr(acc, "name", ""),
                "server": getattr(acc, "server", ""),
                "currency": acc.currency, "balance": acc.balance,
                "equity": acc.equity, "margin_free": acc.margin_free,
                "leverage": acc.leverage,
                "trade_allowed": bool(getattr(acc, "trade_allowed", True)),
            }
        if term is not None:
            out["terminal"] = {
                "name": getattr(term, "name", ""),
                "company": getattr(term, "company", ""),
                "connected": bool(getattr(term, "connected", False)),
                "trade_allowed": bool(getattr(term, "trade_allowed", False)),
                "path": getattr(term, "path", ""),
            }
    except Exception as e:  # noqa
        out["error"] = str(e)
    return out


# ---------------------------------------------- Market Watch و دریافتِ کندل‌ها
# تایم‌فریم‌های پشتیبانی‌شده برای بک‌تست (سازگار با MetaTrader 5)
TF_ORDER = ["1m", "5m", "10m", "15m", "30m", "1h", "2h", "4h", "1d", "1w", "1mn"]


def _tf_const(interval: str):
    """رشته‌ی تایم‌فریم برنامه را به ثابتِ MetaTrader5 نگاشت می‌کند."""
    if not MT5_AVAILABLE:
        return None
    m = {
        "1m": mt5.TIMEFRAME_M1,
        "5m": mt5.TIMEFRAME_M5,
        "10m": mt5.TIMEFRAME_M10,
        "15m": mt5.TIMEFRAME_M15,
        "30m": mt5.TIMEFRAME_M30,
        "1h": mt5.TIMEFRAME_H1,
        "2h": mt5.TIMEFRAME_H2,
        "4h": mt5.TIMEFRAME_H4,
        "1d": mt5.TIMEFRAME_D1,
        "1w": mt5.TIMEFRAME_W1,
        "1mn": mt5.TIMEFRAME_MN1,
    }
    return m.get(interval, mt5.TIMEFRAME_H1)



def market_watch() -> dict:
    """نمادهای موجود در Market Watchِ کاربر (نمادهای visible) را برمی‌گرداند."""
    out = {"available": MT5_AVAILABLE, "connected": False, "symbols": [], "count": 0}
    if not MT5_AVAILABLE or not _ensure():
        out["error"] = _err()
        return out
    out["connected"] = True
    try:
        with _lock:
            allsy = mt5.symbols_get() or []
        syms = []
        for s in allsy:
            if not getattr(s, "visible", False):
                continue  # فقط نمادهای Market Watch (visible)
            name = s.name
            syms.append({
                "name": name,
                "description": (getattr(s, "description", "") or "").strip(),
                "path": getattr(s, "path", "") or "",
                "digits": int(getattr(s, "digits", 5) or 5),
                "internal": internal_for_broker(name) or "",
            })
        syms.sort(key=lambda x: (x["path"], x["name"]))
        out["symbols"] = syms
        out["count"] = len(syms)
    except Exception as e:  # noqa
        out["error"] = str(e)
    return out


_srv_time_cache = {"ts": 0.0, "data": None}
_srv_prev = {"epoch": None, "wall": None}  # برای تشخیصِ زنده/کهنه بودنِ زمانِ سرور
_SRV_TTL = 4.0  # ثانیه — جلوگیری از پیمایشِ مکررِ نمادها


def server_time() -> dict:
    """زمانِ سرورِ کارگزار (همان ساعتِ Market Watch متاتریدر) را برمی‌گرداند.

    متاتریدر زمانِ سرور را مستقیماً در API پایتون نمی‌دهد؛ اما زمانِ آخرین تیکِ نمادها
    دقیقاً ساعتِ سرور را (به‌صورتِ epochِ UTC که معادلِ ساعتِ دیواریِ بروکر است) نشان می‌دهد.
    تازه‌ترین تیک را میانِ نمادهای Market Watch پیدا می‌کنیم.

    خروجی: {ok, connected, broker_epoch, broker_time "HH:MM:SS", broker_date,
             broker_weekday (0=دوشنبه), utc_epoch, offset_hours}
    """
    now = time.time()
    cached = _srv_time_cache["data"]
    if cached and (now - _srv_time_cache["ts"] < _SRV_TTL):
        return dict(cached)

    out = {"available": MT5_AVAILABLE, "connected": False, "ok": False}
    if not MT5_AVAILABLE or not _ensure():
        out["error"] = _err()
        return out

    best = 0
    try:
        with _lock:
            allsy = mt5.symbols_get() or []
            checked = 0
            for s in allsy:
                if not getattr(s, "visible", False):
                    continue  # فقط نمادهای Market Watch
                t = mt5.symbol_info_tick(s.name)
                if t is not None:
                    tt = int(getattr(t, "time", 0) or 0)
                    if tt > best:
                        best = tt
                checked += 1
                if checked >= 80:      # سقفِ ایمن برای سرعت
                    break
    except Exception as e:  # noqa
        out["error"] = str(e)
        return out

    if best <= 0:
        out["error"] = ("زمانِ سرور از تیکِ نمادها به‌دست نیامد. "
                        "مطمئن شوید حداقل یک نماد در Market Watch فعال است.")
        return out

    dt = datetime.fromtimestamp(best, tz=timezone.utc)  # ساعتِ دیواریِ بروکر
    utc_now = time.time()
    offset_hours = round((best - utc_now) / 1800.0) / 2.0  # آفستِ تقریبیِ منطقهٔ بروکر

    # تشخیصِ زنده/کهنه: آیا زمانِ سرور از فراخوانیِ قبلی به‌اندازهٔ زمانِ واقعی جلو رفته است؟
    live = None
    prev = _srv_prev
    if prev["epoch"] is not None and prev["wall"] is not None:
        d_broker = best - prev["epoch"]
        d_wall = utc_now - prev["wall"]
        if d_wall > 5:
            live = d_broker >= d_wall * 0.5  # بازارِ فعال ≈ پیشرویِ همگام؛ تعطیلات ≈ توقف
    _srv_prev["epoch"] = best
    _srv_prev["wall"] = utc_now

    out.update(ok=True, connected=True,
               broker_epoch=best,
               broker_time=dt.strftime("%H:%M:%S"),
               broker_date=dt.strftime("%Y-%m-%d"),
               broker_weekday=int(dt.weekday()),
               utc_epoch=utc_now,
               offset_hours=offset_hours,
               live=live)
    _srv_time_cache["ts"] = now
    _srv_time_cache["data"] = dict(out)
    return out


def rates(broker_symbol: str, interval: str = "1h", count: int = 400) -> dict:
    """کندل‌های OHLC یک نمادِ کارگزار را مستقیماً از متاتریدر می‌گیرد.

    خروجی سازگار با data_sources: rows = [[time_ms, open, high, low, close, volume], ...]
    """
    out = {"ok": False, "symbol": broker_symbol, "interval": interval, "rows": []}
    if not MT5_AVAILABLE or not _ensure():
        out["error"] = _err()
        return out
    tf = _tf_const(interval)
    try:
        with _lock:
            info = mt5.symbol_info(broker_symbol)
            if info is None:
                out["error"] = f"نماد «{broker_symbol}» در کارگزار یافت نشد."
                return out
            if not info.visible:
                mt5.symbol_select(broker_symbol, True)
            rs = mt5.copy_rates_from_pos(broker_symbol, tf, 0, count)
        if rs is None or len(rs) == 0:
            out["error"] = f"دادهٔ کندل برای «{broker_symbol}» دریافت نشد."
            return out
        rows = []
        for r in rs:
            rows.append([
                int(r["time"]) * 1000,          # ثانیه → میلی‌ثانیه (سازگار با بقیه منابع)
                float(r["open"]), float(r["high"]),
                float(r["low"]), float(r["close"]),
                float(r["tick_volume"]),
            ])
        out.update(ok=True, rows=rows,
                   digits=int(getattr(info, "digits", 5) or 5),
                   description=(getattr(info, "description", "") or "").strip())
    except Exception as e:  # noqa
        out["error"] = str(e)
    return out


def rates_range(broker_symbol: str, interval: str = "1h",
                from_ts: float = None, to_ts: float = None) -> dict:
    """کندل‌های OHLC یک نماد را بینِ دو تاریخ (بازه) مستقیماً از متاتریدر می‌گیرد.

    from_ts/to_ts بر حسبِ ثانیه‌ی epoch (UTC). خروجی مانند rates(): rows = [[time_ms, o,h,l,c,v], ...].
    """
    out = {"ok": False, "symbol": broker_symbol, "interval": interval, "rows": []}
    if not MT5_AVAILABLE or not _ensure():
        out["error"] = _err()
        return out
    tf = _tf_const(interval)
    try:
        d_from = datetime.fromtimestamp(float(from_ts), tz=timezone.utc)
        d_to = datetime.fromtimestamp(float(to_ts), tz=timezone.utc)
    except Exception as e:  # noqa
        out["error"] = f"بازه‌ی تاریخِ نامعتبر: {e}"
        return out
    try:
        with _lock:
            info = mt5.symbol_info(broker_symbol)
            if info is None:
                out["error"] = f"نماد «{broker_symbol}» در کارگزار یافت نشد."
                return out
            if not info.visible:
                mt5.symbol_select(broker_symbol, True)
            rs = mt5.copy_rates_range(broker_symbol, tf, d_from, d_to)
        if rs is None or len(rs) == 0:
            out["error"] = (f"دادهٔ کندل برای «{broker_symbol}» در این بازه دریافت نشد. "
                            "بازه/تایم‌فریم را تغییر دهید یا مطمئن شوید نماد در دسترسِ کارگزار است.")
            return out
        rows = [[int(r["time"]) * 1000, float(r["open"]), float(r["high"]),
                 float(r["low"]), float(r["close"]), float(r["tick_volume"])] for r in rs]
        out.update(ok=True, rows=rows,
                   digits=int(getattr(info, "digits", 5) or 5),
                   description=(getattr(info, "description", "") or "").strip())
    except Exception as e:  # noqa
        out["error"] = str(e)
    return out


# ------------------------------------------------------ کشِ دیسکِ دادهٔ نمادها
_DATA_DIR = os.path.join(os.path.dirname(__file__), "mt5_data")


def _safe_name(s: str) -> str:
    return "".join(c if (c.isalnum() or c in "._-") else "_" for c in str(s))


def _data_path(symbol: str, interval: str) -> str:
    return os.path.join(_DATA_DIR, f"{_safe_name(symbol)}__{_safe_name(interval)}.csv")


def save_rates(symbol: str, interval: str, rows: list) -> dict:
    """کندل‌ها را در پوشه‌ی برنامه ذخیره می‌کند (ادغام با دادهٔ قبلی برای رشدِ کش)."""
    try:
        os.makedirs(_DATA_DIR, exist_ok=True)
        merged = {}
        # دادهٔ قبلی را بخوان و ادغام کن (کلید: زمان)
        prev = load_rates(symbol, interval)
        for r in (prev.get("rows") or []):
            merged[int(r[0])] = r
        for r in (rows or []):
            merged[int(r[0])] = [int(r[0]), float(r[1]), float(r[2]),
                                 float(r[3]), float(r[4]), float(r[5])]
        allrows = [merged[k] for k in sorted(merged.keys())]
        path = _data_path(symbol, interval)
        with _lock:
            with open(path, "w", encoding="utf-8") as f:
                f.write("time,open,high,low,close,volume\n")
                for r in allrows:
                    f.write(f"{int(r[0])},{r[1]},{r[2]},{r[3]},{r[4]},{r[5]}\n")
        return {"ok": True, "path": os.path.basename(path), "bars": len(allrows)}
    except Exception as e:  # noqa
        return {"ok": False, "error": str(e)}


def load_rates(symbol: str, interval: str) -> dict:
    """کندل‌های ذخیره‌شده‌ی یک نماد/تایم‌فریم را از پوشه‌ی برنامه می‌خواند."""
    path = _data_path(symbol, interval)
    if not os.path.exists(path):
        return {"ok": False, "rows": [], "error": "دادهٔ ذخیره‌شده‌ای برای این نماد/تایم‌فریم موجود نیست."}
    try:
        rows = []
        with open(path, encoding="utf-8") as f:
            next(f, None)  # سرستون
            for line in f:
                p = line.strip().split(",")
                if len(p) < 6:
                    continue
                rows.append([int(p[0]), float(p[1]), float(p[2]),
                             float(p[3]), float(p[4]), float(p[5])])
        rng = {}
        if rows:
            rng = {"from": rows[0][0], "to": rows[-1][0]}
        return {"ok": True, "rows": rows, "bars": len(rows), **rng}
    except Exception as e:  # noqa
        return {"ok": False, "rows": [], "error": str(e)}


def list_cached() -> dict:
    """فهرستِ دیتاسِت‌های ذخیره‌شده در پوشه‌ی برنامه."""
    out = []
    try:
        if os.path.isdir(_DATA_DIR):
            for fn in sorted(os.listdir(_DATA_DIR)):
                if not fn.endswith(".csv") or "__" not in fn:
                    continue
                base = fn[:-4]
                sym, tf = base.split("__", 1)
                path = os.path.join(_DATA_DIR, fn)
                # شمارشِ سریعِ خطوط
                n = 0
                first = last = None
                with open(path, encoding="utf-8") as f:
                    next(f, None)
                    for line in f:
                        if not line.strip():
                            continue
                        n += 1
                        if first is None:
                            first = line.split(",", 1)[0]
                        last = line.split(",", 1)[0]
                out.append({"symbol": sym, "interval": tf, "bars": n,
                            "from": int(first) if first else None,
                            "to": int(last) if last else None,
                            "size_kb": round(os.path.getsize(path) / 1024, 1)})
    except Exception as e:  # noqa
        return {"ok": False, "error": str(e), "datasets": []}
    return {"ok": True, "datasets": out, "count": len(out)}


# ------------------------------------------------------------- تفکیک نماد کارگزار
def _fuzzy_match(base: str, names: list) -> list:
    """اصلاح (OPUS5-M1): فقط نمادهایی که هستهٔ نامشان با base یکی است.

    پسوندهای بروکری مثل EURUSD.m / EURUSDm / EURUSD# / EURUSD.pro مجازند؛
    جفت‌های دیگر مثل EURGBP برای EURUSD مجاز نیستند."""
    import re as _re
    core = _re.sub(r"[^A-Z0-9]", "", (base or "").upper())
    if not core:
        return []
    suffix_ok = _re.compile(r"^(?:[._#\-][A-Z0-9]{1,6}|M|Z|PRO|ECN|RAW|MICRO|C|I)?$")
    out = []
    for n in names:
        nu = str(n).upper()
        if not nu.startswith(core):
            continue
        rest = nu[len(core):]
        if rest == "" or suffix_ok.match(rest):
            out.append(n)
    return out


def resolve_symbol(internal: str) -> dict:
    """نمادِ داخلی (مثل XAU) را به نماد واقعی کارگزار (مثل XAUUSD) نگاشت می‌کند.

    ترتیب: ۱) نگاشت دستیِ کاربر  ۲) نامزدهای پیش‌فرض  ۳) جست‌وجوی فازی در نمادهای بروکر.
    """
    raw = str(internal or "").strip()
    internal = raw.upper()
    cfg = load_config()
    result = {"internal": internal, "broker": None, "matched": False, "candidates": []}
    if not MT5_AVAILABLE or not _ensure():
        result["error"] = _err()
        return result

    # ۱) نگاشت دستی
    manual = (cfg.get("symbol_map") or {}).get(internal)
    tried = []
    if manual:
        tried.append(manual)
    # اصلاح (MT5-SYM-CASE-001): نامِ دقیقِ ورودی با همان بزرگ/کوچکیِ حروف هم
    # امتحان می‌شود؛ پسوندهای بروکری (مثل .m و .z و micro) معمولاً حروفِ کوچک‌اند
    # و upper() آن‌ها را خراب می‌کرد؛ در نتیجه جست‌وجوی فازی می‌توانست نمادِ
    # هم‌خانوادهٔ دیگری را به‌جای نمادِ واقعیِ کاربر انتخاب کند.
    if raw and raw not in tried:
        tried.append(raw)
    tried += [c for c in DEFAULT_SYMBOL_CANDIDATES.get(internal, [internal])
              if c not in tried]
    result["candidates"] = tried

    with _lock:
        for name in tried:
            info = mt5.symbol_info(name)
            if info is not None:
                if not info.visible:
                    mt5.symbol_select(name, True)
                result.update(broker=name, matched=True)
                return result

        # اصلاح (OPUS5-M1): جست‌وجوی فازیِ قبلی فقط ۳ حرفِ اول را می‌سنجید و
        # می‌توانست برای EURUSD نمادِ EURGBP/EURAUD را انتخاب و «جفت‌ارزِ اشتباه»
        # را معامله کند. اکنون فقط نمادهایی مجازند که هستهٔ نامشان دقیقاً یکی است
        # و باقیمانده صرفاً پسوندِ بروکری است (.m/.pro/#/micro/…).
        base = (tried[-1] if tried else internal).rstrip(".")
        try:
            allsy = mt5.symbols_get()
        except Exception:  # noqa
            allsy = []
        cands = _fuzzy_match(base, [s.name for s in (allsy or [])])
        result["fuzzy"] = cands[:20]
        for name in cands:
            info = mt5.symbol_info(name)
            if info is not None:
                mt5.symbol_select(name, True)
                result.update(broker=name, matched=True, fuzzy_used=True)
                return result
    result["error"] = f"نمادی برای «{internal}» در کارگزار پیدا نشد. لطفاً نگاشت دستی تنظیم کنید."
    return result


# --------------------------------------------------------------- ابزار کمکی حجم/قیمت
import math


def _round_step(value: float, step: float) -> float:
    if step <= 0:
        return value
    return round(round(value / step) * step, 8)


def _floor_step(value: float, step: float) -> float:
    """گِرد کردن به پایین به نزدیک‌ترین مضربِ گام حجم (برای تقسیم امنِ لات)."""
    if step <= 0:
        return value
    return round(math.floor(round(value / step, 8)) * step, 8)


def _decimals_of(step: float) -> int:
    s = f"{step:.8f}".rstrip("0")
    return len(s.split(".")[1]) if "." in s else 0


def _norm_volume(info, vol: float) -> float:
    # اصلاح (MT5-001): حجمِ NaN/inf/صفر/منفی دیگر clamp نمی‌شود؛ قبلاً
    # min(vmax, nan) → vmax برمی‌گشت و حجمِ NaN به «حداکثرِ لاتِ مجاز» تبدیل می‌شد!
    try:
        vol = float(vol)
    except (TypeError, ValueError):
        return 0.0
    if not math.isfinite(vol) or vol <= 0:
        return 0.0
    vmin, vmax, vstep = info.volume_min, info.volume_max, info.volume_step
    vol = max(vmin, min(vmax, vol))
    vol = _round_step(vol, vstep)
    if vol < vmin:
        vol = vmin
    return round(vol, _decimals_of(vstep))


def _pick_filling(info):
    """انتخاب حالت پرکردن سفارش سازگار با نماد."""
    fm = getattr(info, "filling_mode", 0)
    # bitmask: 1=FOK, 2=IOC
    if fm & 2:
        return mt5.ORDER_FILLING_IOC
    if fm & 1:
        return mt5.ORDER_FILLING_FOK
    return mt5.ORDER_FILLING_RETURN


def _apply_stops_level(info, price: float, sl: float, tp: float, is_buy: bool):
    """رعایت حداقل فاصله‌ی مجاز استاپ/تی‌پی از قیمت (trade_stops_level)."""
    point = info.point or 0.0
    min_dist = (getattr(info, "trade_stops_level", 0) or 0) * point
    digits = info.digits
    if sl is not None and min_dist > 0:
        if is_buy and (price - sl) < min_dist:
            sl = price - min_dist
        if (not is_buy) and (sl - price) < min_dist:
            sl = price + min_dist
    if tp is not None and min_dist > 0:
        if is_buy and (tp - price) < min_dist:
            tp = price + min_dist
        if (not is_buy) and (price - tp) < min_dist:
            tp = price - min_dist
    sl = round(sl, digits) if sl is not None else 0.0
    tp = round(tp, digits) if tp is not None else 0.0
    return sl, tp


def _order_type(direction: str, execution: str, entry: float, ask: float, bid: float):
    """تعیین نوع سفارش و قیمت اجرا بر اساس جهت و نوع اجرا."""
    is_buy = direction == "LONG"
    if execution == "market" or not entry:
        price = ask if is_buy else bid
        otype = mt5.ORDER_TYPE_BUY if is_buy else mt5.ORDER_TYPE_SELL
        action = mt5.TRADE_ACTION_DEAL
        return otype, action, price, is_buy
    # سفارش معلق روی نقطه‌ی ورود
    ref = ask if is_buy else bid
    if is_buy:
        otype = mt5.ORDER_TYPE_BUY_LIMIT if entry < ref else mt5.ORDER_TYPE_BUY_STOP
    else:
        otype = mt5.ORDER_TYPE_SELL_LIMIT if entry > ref else mt5.ORDER_TYPE_SELL_STOP
    return otype, mt5.TRADE_ACTION_PENDING, entry, is_buy


def _legs(volume: float, tps: list, tp_mode: str, info) -> list:
    """تقسیم حجم بین حد سودها. خروجی: لیست (حجم، tp).

    نکته‌ی بحرانی (رفع باگ اضافه‌شدنِ حجم): تقسیم باید طوری باشد که مجموعِ
    لات‌ها دقیقاً برابر حجمِ درخواستی بماند و اگر حجم برای تقسیم به تعدادِ
    حد سودها کافی نبود، تعدادِ پله‌ها به‌صورت خودکار کم شود (نه اینکه هر پله
    به حداقلِ لات گِرد شود و مجموع چند برابر گردد).
    """
    dec = _decimals_of(info.volume_step)
    total = _norm_volume(info, volume)
    if tp_mode == "none" or not tps:
        return [(total, None)]
    if tp_mode == "single":
        return [(total, tps[0])]

    # split: بیشترین تعداد پله‌ای که با حداقلِ لات جا می‌شود.
    # نکتهٔ بحرانی (رفعِ باگِ تورمِ حجم): باید «کف» گرفته شود نه «گِرد». اگر گِرد شود،
    # به‌خاطرِ خطای اعشاریِ ممیزِ شناور (مثلاً 0.25/0.1 = 2.4999… + 1e-9 → 2.5) ممکن است
    # به بالا گِرد شده و یک پلهٔ اضافه بسازد که پس از گِردکردن به حداقلِ لات، مجموعِ
    # لات‌ها را از حجمِ درخواستی بیشتر کند (۰٫۲۵ → ۰٫۳).
    max_legs = int(math.floor(total / info.volume_min + 1e-9)) if info.volume_min > 0 else len(tps)
    n = min(len(tps), max(1, max_legs))
    # اصلاح (TP-RUNNER-001): وقتی حجم برای همهٔ پله‌ها کافی نیست، قبلاً حدهای
    # انتهایی حذف می‌شدند (تک‌لگ → فقط TP1؛ دو لگ → TP1,TP2) و پوزیشن در TP1
    # بسته می‌شد — یعنی TP2/TP3 عملاً نادیده گرفته می‌شدند. اکنون «لگِ آخر همیشه
    # هدفِ نهایی (TP آخر)» را می‌گیرد تا سود تا انتهای نقشه دنبال شود (بریک‌ایون/
    # تریلینگِ منیجر هم در مسیر از آن محافظت می‌کنند):
    #   ۱ لگ → [TP3] · ۲ لگ → [TP1, TP3] · ۳ لگ → [TP1, TP2, TP3]
    if n <= 1:
        return [(total, tps[-1])]
    tps = tps[:n - 1] + [tps[-1]]

    each = _floor_step(total / n, info.volume_step)
    if each < info.volume_min:
        each = info.volume_min
    legs = []
    allocated = 0.0
    for i, tp in enumerate(tps):
        if i < n - 1:
            v = each
        else:
            # پله‌ی آخر باقیمانده را می‌گیرد تا مجموع دقیقاً برابر حجم شود
            v = round(total - allocated, dec)
            if v < info.volume_min:
                v = info.volume_min
        v = round(v, dec)
        legs.append((v, tp))
        allocated = round(allocated + v, dec)
    return legs


# --------------------------------------------------------------------- ارسال سفارش
# اصلاح (MT5-002): توکنِ داخلیِ callerِ مطمئن — مسیرِ ربات (app.py) برای حفظِ حجمِ
# صریحِ ربات به risk_mode=fixed و use_plan_sl/tp نیاز دارد؛ این کلیدها از whitelist
# عمومی حذف شده‌اند و بدونِ این توکن از بیرون قابلِ تنظیم نیستند.
_ROBOT_CALL_TOKEN = object()
_robot_call_ctx = threading.local()  # پرچمِ thread-local؛ با monkeypatchِ تست‌ها هم سازگار است


def send_order_from_robot(internal_symbol: str, direction: str, plan: dict,
                          volume: float = None, dry_run: bool = False,
                          overrides: dict = None, skip_news_filter: bool = False) -> dict:
    """نسخهٔ مطمئنِ send_order برای مسیرِ داخلیِ ربات (نه APIِ عمومی).

    به‌جای کیوردِ اضافه، از context استفاده می‌شود تا تست‌هایی که send_order را
    جایگزین (monkeypatch) می‌کنند با آرگومانِ ناشناخته نشکنند.
    """
    _robot_call_ctx.trusted = True
    try:
        # عمداً «ارجاعِ ماژولی» تا نسخهٔ monkeypatch‌شده هم دیده شود
        import sys as _sys
        _self = _sys.modules[__name__]
        return _self.send_order(internal_symbol, direction, plan, volume=volume,
                                dry_run=dry_run, overrides=overrides,
                                skip_news_filter=skip_news_filter)
    finally:
        _robot_call_ctx.trusted = False


def send_order(internal_symbol: str, direction: str, plan: dict,
               volume: float = None, dry_run: bool = False,
               overrides: dict = None, skip_news_filter: bool = False,
               _trusted_caller=None) -> dict:
    """یک سیگنال (جهت + نقشه‌ی معامله) را به یک یا چند سفارش MT5 تبدیل و ارسال می‌کند.

    plan: {"entry":.., "stop_loss":.., "take_profits":[{"price":..},..] یا [قیمت‌ها]}
    """
    overrides = dict(overrides or {})
    # اصلاح (APP-004): فقط کلیدهای اجراییِ امن قابلِ override هستند؛ محافظ‌ها
    # (ساعتِ بازار، سقفِ ریسکِ روزانه، مدیریتِ پوزیشن و…) از طریقِ بدنهٔ درخواست
    # قابلِ خاموش‌کردن نیستند و فقط از تنظیماتِ ذخیره‌شده خوانده می‌شوند.
    _SAFE_OVERRIDE_KEYS = {"tp_mode", "execution", "deviation",
                           "pending_offset_atr", "comment", "magic",
                           "partial_fractions"}
    # اصلاح (MT5-002): whitelist دورِ قبل نیتِ مسیرِ ربات (risk_mode=fixed برای حفظِ
    # حجمِ صریحِ ربات) را هم بی‌صدا حذف می‌کرد؛ با تنظیمِ risk_pct در کانفیگ، حجمِ
    # ربات دوباره با درصدِ ریسک محاسبه می‌شد. callerِ مطمئن این سه کلید را نگه می‌دارد.
    _trusted_overrides = {}
    if (_trusted_caller is _ROBOT_CALL_TOKEN) or getattr(_robot_call_ctx, "trusted", False):
        _trusted_overrides = {k: overrides[k]
                              for k in ("risk_mode", "use_plan_sl", "use_plan_tp")
                              if k in overrides}
    overrides = {k: v for k, v in overrides.items() if k in _SAFE_OVERRIDE_KEYS}
    overrides.update(_trusted_overrides)
    cfg = load_config()
    cfg.update({k: v for k, v in overrides.items() if v is not None})

    if direction not in ("LONG", "SHORT"):
        return {"ok": False, "error": f"جهت نامعتبر: {direction}"}
    with _trade_lock:
        return _send_order_locked(internal_symbol, direction, plan, volume, dry_run,
                                  overrides, skip_news_filter, cfg)


def _send_order_locked(internal_symbol, direction, plan, volume, dry_run,
                       overrides, skip_news_filter, cfg):
    """بدنهٔ اصلیِ ارسال — سریال‌شده با _trade_lock (اصلاح OPUS5-M9)."""

    allowed = cfg.get("allowed_symbols") or []
    if allowed and internal_symbol.upper() not in [a.upper() for a in allowed]:
        return {"ok": False, "error": f"نماد {internal_symbol} در فهرست مجاز نیست."}

    if not MT5_AVAILABLE:
        # روی لینوکس فقط پیش‌نمایش می‌دهیم
        dry_run = True

    res = resolve_symbol(internal_symbol)
    if not res.get("matched") and not (dry_run and not MT5_AVAILABLE):
        return {"ok": False, "error": res.get("error", "نماد پیدا نشد"), "resolve": res}
    bsym = res.get("broker") or (cfg.get("symbol_map", {}).get(internal_symbol.upper())
                                 or (DEFAULT_SYMBOL_CANDIDATES.get(internal_symbol.upper(), [internal_symbol])[0]))

    # استخراج نقطه ورود/استاپ/حد سودها از نقشه
    entry = plan.get("entry")
    sl = plan.get("stop_loss") if cfg.get("use_plan_sl", True) else None
    raw_tps = plan.get("take_profits") or []
    tps = [t["price"] if isinstance(t, dict) else t for t in raw_tps]
    if not cfg.get("use_plan_tp", True):
        tps = []
    else:
        # اصلاح (MT5-007): قراردادِ برنامه حداکثر ۳ حد سود است؛ پلنِ مستقیمِ API با
        # ۴+ TP در حالت split چهار لگ می‌ساخت. single/none در _legs جدا مدیریت می‌شوند.
        tps = tps[:3]

    # حجم پایه
    base_vol = volume if volume else float(cfg.get("default_volume", 0.01))

    # حالت پیش‌نمایش روی لینوکس (بدون اتصال واقعی)
    if not MT5_AVAILABLE:
        return {
            "ok": True, "dry_run": True, "simulated": True,
            "broker_symbol": bsym, "direction": direction,
            "note": "پیش‌نمایش: کتابخانه MT5 روی این سیستم نصب نیست. روی ویندوزِ دارای MT5 اجرا شود.",
            "planned": {"entry": entry, "sl": sl, "tps": tps, "volume": base_vol,
                        "tp_mode": cfg.get("tp_mode"), "execution": cfg.get("execution")},
        }

    if not _ensure():
        return {"ok": False, "error": _err()}

    with _lock:
        info = mt5.symbol_info(bsym)
        if info is None:
            return {"ok": False, "error": f"symbol_info برای {bsym} خالی است."}
        if not info.visible:
            mt5.symbol_select(bsym, True)
            info = mt5.symbol_info(bsym)
        tick = mt5.symbol_info_tick(bsym)
        if tick is None:
            return {"ok": False, "error": f"قیمت لحظه‌ای {bsym} در دسترس نیست."}

        # محاسبه حجم بر اساس ریسک (اختیاری)
        if cfg.get("risk_mode") == "risk_pct" and sl and entry:
            acc = mt5.account_info()
            if acc is not None:
                risk_cash = acc.balance * float(cfg.get("risk_pct", 1.0)) / 100.0
                # اصلاح (MT5-003): مرجعِ قیمت برای SHORT باید bid باشد نه ask؛
                # قبلاً خطای به‌اندازهٔ اسپرد در فاصلهٔ استاپ (و حجم) ایجاد می‌شد.
                _ref = entry if entry else (tick.ask if direction == "LONG" else tick.bid)
                sl_dist = abs(_ref - sl)
                tick_val = getattr(info, "trade_tick_value", 0) or 0
                tick_size = getattr(info, "trade_tick_size", 0) or info.point
                if sl_dist > 0 and tick_val > 0 and tick_size > 0:
                    val_per_unit = (sl_dist / tick_size) * tick_val
                    if val_per_unit > 0:
                        _calc_vol = risk_cash / val_per_unit
                        # اصلاح (OPUS5-M2): اگر حجمِ ریسک‌محور از حداقلِ بروکر کمتر
                        # باشد، قبلاً بی‌صدا به volume_min بزرگ می‌شد (ریسکِ واقعی
                        # چند برابرِ تنظیم). اکنون سفارش صریحاً رد می‌شود.
                        _vmin0 = float(getattr(info, "volume_min", 0) or 0)
                        if _vmin0 > 0 and _calc_vol < _vmin0 * 0.999:
                            return {"ok": False, "blocked": True,
                                    "error": (f"حجمِ محاسبه‌شده بر اساس ریسکِ {cfg.get('risk_pct')}٪ "
                                              f"({_calc_vol:.4f}) از حداقلِ بروکر ({_vmin0}) کمتر است؛ "
                                              "برای جلوگیری از ریسکِ بیش از تنظیم، سفارش لغو شد."),
                                    "broker_symbol": bsym, "direction": direction}
                        base_vol = _calc_vol

        execution = cfg.get("execution", "market")
        tp_mode = cfg.get("tp_mode", "split")
        otype, action, price, is_buy = _order_type(direction, execution, entry, tick.ask, tick.bid)
        filling = _pick_filling(info)
        # اصلاح (MT5-001، تکمیلی): حجمِ صریحِ کمتر از حداقلِ بروکر قبلاً بی‌صدا به
        # volume_min «بزرگ» می‌شد (مثلاً 0.001 → 0.01؛ ۱۰ برابرِ خواستهٔ ربات!).
        # بزرگ‌کردنِ خاموشِ ریسک ممنوع؛ گردکردن به step و سقفِ max همچنان انجام می‌شود.
        if volume is not None:
            try:
                _vreq = float(volume)
            except Exception:  # noqa
                _vreq = 0.0
            _vmin = float(getattr(info, "volume_min", 0) or 0)
            if _vmin > 0 and 0 < _vreq < _vmin * 0.999:
                return {"ok": False,
                        "error": f"حجمِ درخواستی ({_vreq}) از حداقلِ بروکر ({_vmin}) کمتر است؛ "
                                 "به‌جای بزرگ‌کردنِ خاموشِ ریسک، سفارش رد شد.",
                        "broker_symbol": bsym, "direction": direction}
        total_vol = _norm_volume(info, base_vol)
        # اصلاح (MT5-001): حجمِ نامعتبر (NaN/inf/صفر/منفی) صریحاً رد می‌شود.
        if total_vol <= 0:
            return {"ok": False,
                    "error": f"حجمِ سفارش نامعتبر است ({base_vol!r}).",
                    "broker_symbol": bsym, "direction": direction}

        # حالت partial: یک پوزیشن با کل حجم و TP نهایی (TP3)؛ بستن جزئی توسط موتور مدیریت
        partial = tp_mode == "partial" and len(tps) >= 2
        partial_downgraded = None
        if partial:
            # اصلاح (OPUS5-M4): اگر سهمِ یکی از پله‌ها یا باقیمانده از حداقلِ لات کمتر
            # شود، بستنِ جزئی عملاً «کل پوزیشن در TP1» یا پله‌ی سوخته می‌شد؛ از قبل
            # می‌سنجیم و به‌جای رفتارِ نامشخص، به single سقوطِ شفاف می‌کنیم.
            _frs = [float(x) for x in (cfg.get("partial_fractions") or [0.5, 0.3])]
            _vols = [total_vol * f for f in _frs]        # سهم‌های خام (قبل از گردکردن)
            _rest = round(total_vol - sum(_vols), 8)
            _vmin4 = float(getattr(info, "volume_min", 0) or 0)
            if any(v < _vmin4 - 1e-12 for v in _vols) or (0 < _rest < _vmin4 - 1e-12):
                partial = False
                tp_mode = "single"
                partial_downgraded = ("حجم برای بستنِ جزئی کافی نیست (سهمِ پله یا باقیمانده "
                                      f"کمتر از حداقلِ لاتِ {_vmin4})؛ حالتِ single اعمال شد.")
                append_log({"symbol": internal_symbol.upper(), "broker_symbol": bsym,
                            "direction": direction, "warn": partial_downgraded})
        if partial:
            legs = [(total_vol, tps[-1])]
        else:
            legs = _legs(total_vol, tps, tp_mode, info)

        # محاسبه ریسک تقریبی معامله (به ارز حساب) برای محافظ ریسک و لاگ
        acc = mt5.account_info()
        balance = acc.balance if acc else 0.0
        tick_val = getattr(info, "trade_tick_value", 0) or 0
        tick_size = getattr(info, "trade_tick_size", 0) or info.point
        sl_dist = abs((entry or price) - sl) if sl else 0.0
        risk_amount = 0.0
        if sl_dist > 0 and tick_val > 0 and tick_size > 0:
            risk_amount = (sl_dist / tick_size) * tick_val * total_vol

        # --- محافظ ساعات بازار: جلوگیری از ارسال روی بازارِ بسته (آخر هفته/جمعه) ---
        market_state = market_hours.status(internal_symbol.upper())
        if (not dry_run and cfg.get("market_hours_guard", True)
                and not market_state.get("open")):
            reason = (f"بازارِ {internal_symbol.upper()} اکنون بسته است "
                      f"({market_state.get('reason_fa','')}) — ارسال معامله لغو شد.")
            append_log({"symbol": internal_symbol.upper(), "broker_symbol": bsym,
                        "direction": direction, "mode": tp_mode, "volume": total_vol,
                        "dry_run": False, "ok": False, "blocked": True,
                        "reason": reason, "risk_amount": round(risk_amount, 2)})
            return {"ok": False, "blocked": True, "error": reason,
                    "broker_symbol": bsym, "direction": direction,
                    "market": market_state}

        # --- OP5-MH-CUTOFF: جلوگیری از ورودِ تازه در دقایقِ آخرِ سشن/پیش از آخرهفته
        #     (پیش‌فرض ۰ = خاموش تا رفتار فعلی تغییر نکند). این گارد فقط «ورودِ
        #     تازه» را می‌بندد؛ پوزیشنِ باز طبق تنظیمِ بازار بسته/می‌ماند تا گاردِ
        #     بستنِ پس‌زمینه (market_close_before_session_end) آن را ببندد.
        try:
            _cut = max(0, int(float(cfg.get("market_entry_cutoff_min", 0) or 0)))
        except (TypeError, ValueError):
            _cut = 0
        if not dry_run and _cut > 0:
            _block_cutoff, _why = market_hours.should_block_new_entry(
                internal_symbol.upper(), cutoff_min=_cut)
            _left = market_hours.minutes_to_close(internal_symbol.upper())
            if _block_cutoff and _left is not None and 0 < _left <= _cut:
                reason = (f"تا پایانِ سشنِ {internal_symbol.upper()} کمتر از {_cut} دقیقه مانده "
                          f"({_left} دقیقه) — ورودِ تازه لغو شد (محافظِ دقایقِ آخر).")
                append_log({"symbol": internal_symbol.upper(), "broker_symbol": bsym,
                            "direction": direction, "mode": tp_mode, "volume": total_vol,
                            "dry_run": False, "ok": False, "blocked": True,
                            "reason": reason, "risk_amount": round(risk_amount, 2)})
                return {"ok": False, "blocked": True, "error": reason,
                        "broker_symbol": bsym, "direction": direction,
                        "market": market_state, "minutes_to_close": _left}

        # --- فیلتر اخبار (منبعِ واحد: تنظیماتِ تبِ «روشِ ارسالِ سیگنال») ---
        # مسیرهای خودکار (برنامه/ربات) این فیلتر را پیش از ارسال اعمال کرده‌اند و
        # skip_news_filter=True می‌فرستند تا دوباره بررسی نشود؛ ارسالِ دستی اینجا
        # با همان تنظیماتِ مرکزی محافظت می‌شود.
        news_block = {"blocked": False}
        if not skip_news_filter:
            try:
                _dcfg = dispatch.load_config()
            except Exception:  # noqa
                _dcfg = {}
            if _dcfg.get("news_filter_enabled", True):
                # OP5-CORE-17: هم‌تراز با پیش‌فرضِ dispatch (fail-closed)
                _fc = bool(_dcfg.get("news_fail_closed", True))
                try:
                    news_block = news.is_blocked(
                        internal_symbol.upper(),
                        before_min=int(_dcfg.get("news_before_min", 30)),
                        after_min=int(_dcfg.get("news_after_min", 30)),
                        min_impact=_dcfg.get("news_impact", "High"),
                        source=_dcfg.get("news_source", "both"))
                except Exception as _e:  # noqa
                    # شکستِ خاموش را آشکار کن: خطا را نگه‌دار (بلع نکن) و در صورتِ
                    # روشن‌بودنِ fail-closed معامله را محتاطانه مسدود کن.
                    news_block = {"blocked": _fc, "inoperative": True, "error": str(_e)}
                # اگر تقویمِ اخبار در دسترس نبود (fail-open)، هشدار ثبت کن تا کاربر
                # بداند این معامله بدونِ محافظتِ اخبار ارسال می‌شود.
                if news_block.get("error") and not news_block.get("blocked"):
                    news_block = dict(news_block)
                    news_block["inoperative"] = True
                    if _fc:
                        news_block["blocked"] = True
                    try:
                        import server_log as _sl
                        _sl.log("warn", "mt5_out",
                                f"فیلترِ اخبار موقتاً در دسترس نبود — {internal_symbol.upper()}",
                                f"دلیل={news_block.get('error')} · "
                                + ("معامله محتاطانه مسدود شد (fail-closed)" if _fc
                                   else "معامله بدونِ محافظتِ اخبار ادامه یافت (fail-open)"))
                    except Exception:  # noqa
                        pass
        if not dry_run and news_block.get("blocked"):
            ev = news_block.get("event", {}) or {}
            reason = (f"فیلتر اخبار: رویداد پرتأثیر «{ev.get('title','')}» ({ev.get('country','')}) "
                      f"نزدیک است؛ معامله مسدود شد.")
            append_log({"symbol": internal_symbol.upper(), "broker_symbol": bsym,
                        "direction": direction, "mode": tp_mode, "volume": total_vol,
                        "dry_run": False, "ok": False, "blocked": True,
                        "reason": reason, "risk_amount": round(risk_amount, 2)})
            return {"ok": False, "blocked": True, "error": reason,
                    "broker_symbol": bsym, "direction": direction, "news_block": news_block}

        # --- محافظ ریسک (فقط برای ارسال واقعی) ---
        guard = check_risk_guard(risk_amount=risk_amount, balance=balance)
        if not dry_run and not guard.get("ok"):
            append_log({"symbol": internal_symbol.upper(), "broker_symbol": bsym,
                        "direction": direction, "mode": tp_mode, "volume": total_vol,
                        "dry_run": False, "ok": False, "blocked": True,
                        "reason": guard.get("reason"), "risk_amount": round(risk_amount, 2)})
            return {"ok": False, "blocked": True, "error": guard.get("reason"),
                    "broker_symbol": bsym, "direction": direction, "risk_guard": guard}

        results = []
        pos_ticket = None
        for i, (vol, tp) in enumerate(legs):
            sl_i, tp_i = _apply_stops_level(info, price, sl, tp, is_buy)
            cmt = f"{cfg.get('comment','Agent')}-{direction}-" + ("FULL" if partial else f"TP{i+1}")
            req = {
                "action": action, "symbol": bsym, "volume": float(vol), "type": otype,
                "price": round(price, info.digits), "sl": sl_i, "tp": tp_i,
                "deviation": int(cfg.get("deviation", 20)),
                "magic": int(cfg.get("magic", 532025)),
                "comment": cmt,
                "type_time": mt5.ORDER_TIME_GTC, "type_filling": filling,
            }
            if dry_run:
                chk = mt5.order_check(req)
                results.append({
                    "leg": i + 1, "request": {k: v for k, v in req.items() if k not in ("type_time", "type_filling")},
                    "check_retcode": getattr(chk, "retcode", None),
                    "check_comment": getattr(chk, "comment", None),
                    "margin": getattr(chk, "margin", None),
                })
                continue
            r = mt5.order_send(req)
            # اصلاح (OPUS5-M5): DONE_PARTIAL (پرشدنِ جزئی) هم اجرا محسوب می‌شود.
            ok_leg = r is not None and r.retcode in (
                mt5.TRADE_RETCODE_DONE,
                getattr(mt5, "TRADE_RETCODE_DONE_PARTIAL", 10010))
            # اصلاح (MT5-003): order ticket لزوماً position ticket نیست (بروکرهای
            # netting/برخی سرورها شماره‌ی متفاوت می‌دهند)؛ پوزیشنِ واقعی استعلام می‌شود.
            _leg_pos = None
            if ok_leg:
                _ordt = getattr(r, "order", None)
                try:
                    _direct = mt5.positions_get(ticket=_ordt) if _ordt else None
                    if _direct:
                        _leg_pos = _direct[0].ticket
                    else:
                        _magic = int(cfg.get("magic", 532025))
                        _ptype = 0 if is_buy else 1
                        _cands = [p for p in (mt5.positions_get(symbol=bsym) or [])
                                  if getattr(p, "magic", None) == _magic
                                  and getattr(p, "type", None) == _ptype
                                  and getattr(p, "comment", "") == cmt]
                        _cands.sort(key=lambda p: getattr(p, "time_msc", getattr(p, "time", 0)),
                                    reverse=True)
                        if _cands:
                            _leg_pos = _cands[0].ticket
                except Exception:  # noqa
                    _leg_pos = None
            if _leg_pos:
                pos_ticket = _leg_pos
            results.append({
                "leg": i + 1, "ok": ok_leg,
                "retcode": getattr(r, "retcode", None), "comment": getattr(r, "comment", None),
                "hint": "" if ok_leg else retcode_hint(getattr(r, "retcode", None)),
                "order": getattr(r, "order", None), "deal": getattr(r, "deal", None),
                "position_ticket": _leg_pos,
                "volume": float(vol), "tp": tp_i, "sl": sl_i,
                "price": getattr(r, "price", price),
            })

        # اصلاح (MT5-004): موفقیتِ جزئی (TP1 انجام، TP2 رد) دیگر ok=True کلی نمی‌شود؛
        # caller برای retry امن به partial_failure نیاز دارد.
        partial_failure = False
        partial_ticket_unresolved = False
        if not dry_run:
            _oks = [x for x in results if x.get("ok")]
            _fails = [x for x in results if not x.get("ok")]
            partial_failure = bool(_oks and _fails)
            partial_ticket_unresolved = bool(partial and _oks and not pos_ticket)

        # ثبت برنامه‌ی بستن جزئی + روشن‌کردن موتور مدیریت
        if partial and not dry_run and pos_ticket:
            fracs = [float(x) for x in (cfg.get("partial_fractions") or [0.5, 0.3])]
            register_partial(pos_ticket, tps, fracs, total_vol, is_buy)
            start_manager()
        # اصلاح (OPUS5-M3): سفارشِ معلق (pending) پس از فعال‌شدن باید خودکار تحتِ
        # مدیریت (پارشیال/بریک‌ایون/تریلینگ) برود؛ قبلاً pos_ticket تهی می‌ماند و
        # هیچ‌کس پوزیشنِ فعال‌شده را مدیریت نمی‌کرد.
        if execution == "pending" and not dry_run:
            _fr = ([float(x) for x in (cfg.get("partial_fractions") or [0.5, 0.3])]
                   if partial else [])
            for x in results:
                if x.get("ok") and x.get("order"):
                    _watch_pending(x["order"], tps if partial else [], _fr,
                                   total_vol, is_buy,
                                   f"{cfg.get('comment', 'Agent')}-{direction}-"
                                   + ("FULL" if partial else f"TP{x.get('leg', 1)}"))
            start_manager()

        if dry_run:
            # اصلاح (OPUS5-M5): order_check در موفقیت retcode=0 می‌دهد (DONE=10009
            # مخصوصِ order_send است)؛ قبلاً پیش‌نمایش همیشه «ناموفق» گزارش می‌شد.
            _OKC = {0, getattr(mt5, "TRADE_RETCODE_DONE", 10009)}
            any_ok = bool(results) and all(
                x.get("check_retcode") in _OKC for x in results)
        else:
            any_ok = bool(results) and all(x.get("ok") for x in results)

        # لاگ معامله
        append_log({
            "symbol": internal_symbol.upper(), "broker_symbol": bsym,
            "direction": direction, "mode": tp_mode, "execution": execution,
            "volume": total_vol, "entry": entry, "sl": sl, "tps": tps,
            "dry_run": dry_run, "ok": any_ok,
            "partial_failure": partial_failure,
            "partial_ticket_unresolved": partial_ticket_unresolved,
            "risk_amount": round(risk_amount, 2),
            "balance": balance,
            "orders": [x.get("order") for x in results if x.get("order")],
            "retcodes": [x.get("retcode") for x in results],
        })

        # اصلاح (DISP-TRUTH-001/004): تیکتِ لگ‌های موفق + متنِ خطای خوانا برای caller
        _tickets = [x.get("position_ticket") or x.get("order")
                    for x in results if x.get("ok") and not dry_run]
        _err_txt = None
        if not dry_run:
            _bad = [x for x in results if x.get("ok") is False]
            if _bad:
                _b0 = _bad[0]
                _err_txt = (f"لگ {_b0.get('leg')}: retcode={_b0.get('retcode')}"
                            + (f" ({_b0.get('comment')})" if _b0.get("comment") else "")
                            + (f" — {_b0.get('hint')}" if _b0.get("hint") else ""))
        return {
            "ok": any_ok, "dry_run": dry_run,
            "error": _err_txt,
            "partial_downgraded": partial_downgraded,
            # اصلاح (OPUS5-M8): اگر به‌خاطرِ حجمِ کم، پله‌ها ادغام شده باشند اعلام شود
            "legs_dropped": max(0, (3 if tp_mode == "split" and len(tps) >= 3 else len(legs))
                                - len(legs)),
            "tickets": [t for t in _tickets if t],
            "broker_symbol": bsym, "internal": internal_symbol.upper(),
            "direction": direction, "execution": execution,
            "tp_mode": tp_mode, "partial": partial, "legs": results,
            "partial_failure": partial_failure,
            "partial_ticket_unresolved": partial_ticket_unresolved,
            "risk_amount": round(risk_amount, 2), "risk_guard": guard,
            "news_block": news_block, "market": market_state,
            "entry_ref": {"ask": tick.ask, "bid": tick.bid},
        }


# --------------------------------------------------------------------- پوزیشن‌ها
def positions(magic_only: bool = True) -> dict:
    if not MT5_AVAILABLE or not _ensure():
        return {"ok": False, "error": _err(), "positions": []}
    cfg = load_config()
    with _lock:
        try:
            ps = mt5.positions_get()
        except Exception as e:  # noqa
            return {"ok": False, "error": str(e), "positions": []}
    out = []
    for p in (ps or []):
        if magic_only and int(cfg.get("magic", 532025)) and p.magic != int(cfg.get("magic", 532025)):
            continue
        out.append({
            "ticket": p.ticket, "symbol": p.symbol,
            "type": "LONG" if p.type == 0 else "SHORT",
            "volume": p.volume, "price_open": p.price_open,
            "sl": p.sl, "tp": p.tp, "price_current": p.price_current,
            "profit": p.profit, "magic": p.magic, "comment": p.comment,
            "time": p.time,
        })
    return {"ok": True, "positions": out}


def close_position(ticket: int) -> dict:
    if not MT5_AVAILABLE or not _ensure():
        return {"ok": False, "error": _err()}
    with _lock:
        ps = mt5.positions_get(ticket=ticket)
        if not ps:
            return {"ok": False, "error": "پوزیشن پیدا نشد"}
        p = ps[0]
        info = mt5.symbol_info(p.symbol)
        tick = mt5.symbol_info_tick(p.symbol)
        is_buy = p.type == 0
        price = tick.bid if is_buy else tick.ask
        req = {
            "action": mt5.TRADE_ACTION_DEAL, "symbol": p.symbol,
            "volume": p.volume,
            "type": mt5.ORDER_TYPE_SELL if is_buy else mt5.ORDER_TYPE_BUY,
            "position": p.ticket, "price": round(price, info.digits),
            "deviation": int(load_config().get("deviation", 20)),
            "magic": p.magic, "comment": "close",
            "type_time": mt5.ORDER_TIME_GTC, "type_filling": _pick_filling(info),
        }
        r = mt5.order_send(req)
        ok = r is not None and r.retcode == mt5.TRADE_RETCODE_DONE
        return {"ok": ok, "retcode": getattr(r, "retcode", None),
                "comment": getattr(r, "comment", None)}


def close_all(magic_only: bool = True) -> dict:
    ps = positions(magic_only=magic_only)
    if not ps.get("ok"):
        return ps
    results = [{"ticket": p["ticket"], **close_position(p["ticket"])} for p in ps["positions"]]
    return {"ok": all(r.get("ok") for r in results) if results else True, "results": results}


def internal_for_broker(broker_symbol: str) -> str:
    """نگاشت معکوس: نمادِ کارگزار → نمادِ داخلی (BTCUSD → BTC)."""
    if not broker_symbol:
        return ""
    b = broker_symbol.upper()
    cfg = load_config()
    # ۱) نگاشت دستی کاربر
    for internal, mapped in (cfg.get("symbol_map") or {}).items():
        if mapped and mapped.upper() == b:
            return internal.upper()
    # ۲) تطبیقِ دقیق با نامزدهای پیش‌فرض (اولویت با تطبیق کامل)
    for internal, cands in DEFAULT_SYMBOL_CANDIDATES.items():
        for c in cands:
            if c.rstrip(".").upper() == b:
                return internal
    # ۳) تطبیقِ پیشوندی — فقط برای نامزدهای به‌قدر کافی بلند (≥۵ کاراکتر)
    #    تا از تطبیق‌های نادرستِ نامزدهای کوتاه مثل HG/CL/NDX جلوگیری شود.
    for internal, cands in DEFAULT_SYMBOL_CANDIDATES.items():
        for c in cands:
            cc = c.rstrip(".").upper()
            if len(cc) >= 5 and b.startswith(cc):
                return internal
    return ""


def close_for_news(currencies: list, scope: str = "matching") -> dict:
    """بستن پوزیشن‌ها پیش از اخبار.

    scope="all" → همه‌ی پوزیشن‌های ربات؛ "matching" → فقط آن‌هایی که ارزشان با رویداد یکی است.
    """
    import news  # داخلی برای پرهیز از وابستگی حلقوی هنگام import
    if not MT5_AVAILABLE or not _ensure():
        return {"ok": False, "error": _err(), "closed": []}
    ps = positions(magic_only=True)
    if not ps.get("ok"):
        return ps
    want = set(c.upper() for c in (currencies or []))
    closed = []
    for p in ps["positions"]:
        do_close = scope == "all"
        if not do_close:
            internal = internal_for_broker(p["symbol"])
            pos_ccy = set(news.currencies_for(internal)) if internal else set()
            # حدس کمکی: اگر کد ارز در نام نماد کارگزار باشد
            for cc in want:
                if cc in p["symbol"].upper():
                    pos_ccy.add(cc)
            do_close = bool(pos_ccy & want)
        if do_close:
            r = close_position(p["ticket"])
            closed.append({"ticket": p["ticket"], "symbol": p["symbol"], **r})
    return {"ok": all(c.get("ok") for c in closed) if closed else True, "closed": closed}


# ============================================================================
#   موتور مدیریت خودکار پوزیشن: Breakeven (سربه‌سر) + Trailing Stop (تریلینگ)
# ============================================================================
def modify_position(ticket: int, sl: float = None, tp: float = None) -> dict:
    """تغییر استاپ‌لاس/حد سودِ یک پوزیشن باز (TRADE_ACTION_SLTP)."""
    if not MT5_AVAILABLE or not _ensure():
        return {"ok": False, "error": _err()}
    with _lock:
        ps = mt5.positions_get(ticket=ticket)
        if not ps:
            return {"ok": False, "error": "پوزیشن پیدا نشد"}
        p = ps[0]
        info = mt5.symbol_info(p.symbol)
        digits = info.digits if info else 5
        req = {
            "action": mt5.TRADE_ACTION_SLTP,
            "symbol": p.symbol,
            "position": p.ticket,
            "sl": round(sl if sl is not None else p.sl, digits),
            "tp": round(tp if tp is not None else p.tp, digits),
            "magic": p.magic,
        }
        r = mt5.order_send(req)
        ok = r is not None and r.retcode == mt5.TRADE_RETCODE_DONE
        return {"ok": ok, "retcode": getattr(r, "retcode", None),
                "comment": getattr(r, "comment", None),
                "sl": req["sl"], "tp": req["tp"]}


def _better_sl(is_buy: bool, current_sl: float, candidate: float) -> bool:
    """آیا استاپِ پیشنهادی «بهتر» (در جهت سود) از استاپ فعلی است؟"""
    if candidate is None:
        return False
    if not current_sl:  # استاپ فعلی صفر/نامشخص
        return True
    return candidate > current_sl if is_buy else candidate < current_sl


def _partial_close(p, info, tick, volume: float) -> dict:
    """بستن بخشی از یک پوزیشن با حجم مشخص (سفارش DEAL در جهت مخالف)."""
    is_buy = p.type == 0
    price = tick.bid if is_buy else tick.ask
    vol = _norm_volume(info, volume)
    # نباید بیشتر از حجمِ پوزیشن باشد
    if vol > p.volume:
        vol = _norm_volume(info, p.volume)
    # اگر باقیمانده کمتر از حداقلِ لات شود، کارگزار پوزیشنِ خرد را نمی‌پذیرد → کل را ببند
    remaining = round(p.volume - vol, 8)
    if 0 < remaining < info.volume_min:
        vol = _norm_volume(info, p.volume)
    if vol < info.volume_min:
        return {"ok": False, "volume": vol,
                "error": "حجمِ بستنِ جزئی کمتر از حداقلِ مجاز است"}
    req = {
        "action": mt5.TRADE_ACTION_DEAL, "symbol": p.symbol,
        "volume": float(vol),
        "type": mt5.ORDER_TYPE_SELL if is_buy else mt5.ORDER_TYPE_BUY,
        "position": p.ticket, "price": round(price, info.digits),
        "deviation": int(load_config().get("deviation", 20)),
        "magic": p.magic, "comment": "partial-tp",
        "type_time": mt5.ORDER_TIME_GTC, "type_filling": _pick_filling(info),
    }
    r = mt5.order_send(req)
    ok = r is not None and r.retcode == mt5.TRADE_RETCODE_DONE
    return {"ok": ok, "volume": float(vol), "retcode": getattr(r, "retcode", None)}


def _manage_once() -> dict:
    """یک دور بررسی همه‌ی پوزیشن‌های این ربات و اعمال قوانین Partial/Breakeven/Trailing."""
    cfg = load_config()
    if not MT5_AVAILABLE or not _ensure():
        return {"ok": False, "error": _err(), "actions": []}
    actions = []
    with _lock:
        try:
            ps = mt5.positions_get()
        except Exception as e:  # noqa
            return {"ok": False, "error": str(e), "actions": []}
        magic = int(cfg.get("magic", 532025))
        live_tickets = set()
        for p in (ps or []):
            if magic and p.magic != magic:
                continue
            live_tickets.add(p.ticket)
            info = mt5.symbol_info(p.symbol)
            tick = mt5.symbol_info_tick(p.symbol)
            if info is None or tick is None:
                continue
            point = info.point or 0.0
            digits = info.digits
            is_buy = p.type == 0
            price = tick.bid if is_buy else tick.ask  # قیمت خروج جاری
            # اصلاح (MT5-009): حداقل فاصلهٔ مجاز استاپ از قیمت (trade_stops_level)
            # باید در بریک‌ایون/تریلینگ هم رعایت شود؛ وگرنه بروکرهای با stops_level
            # بزرگ هر چرخه را با 10016 رد می‌کنند (شکستِ خاموشِ بی‌پایان).
            min_stop = (getattr(info, "trade_stops_level", 0) or 0) * point

            # ثبت وضعیت اولیه‌ی پوزیشن (استاپ و ریسک اولیه)
            state = _pos_state.get(p.ticket)
            if state is None:
                init_risk = abs(p.price_open - p.sl) if p.sl else 0.0
                state = {"init_sl": p.sl, "risk": init_risk, "be_done": False,
                         "atr": (init_risk / 1.5) if init_risk > 0 else None}
                _pos_state[p.ticket] = state
            risk = state["risk"]

            # سود جاری بر حسب فاصله‌ی قیمت
            profit_dist = (price - p.price_open) if is_buy else (p.price_open - price)

            # ---- ۰) بستن جزئی خودکار در TP1/TP2 (حالت partial) ----
            pplan = _partial_plans.get(p.ticket)
            if pplan:
                for i, tp in enumerate(pplan["tps"][:len(pplan["fractions"])]):
                    if i in pplan["done"]:
                        continue
                    reached = (price >= tp) if is_buy else (price <= tp)
                    if not reached:
                        continue
                    vol_close = pplan["init_volume"] * float(pplan["fractions"][i])
                    if _norm_volume(info, vol_close) < info.volume_min:
                        pplan["done"].append(i)
                        continue
                    rc = _partial_close(p, info, tick, vol_close)
                    # اصلاح (MT5-006): پله فقط در صورتِ «موفقیت» انجام‌شده تلقی
                    # می‌شود؛ در شکست (requote/timeout) تا ۳ بار در چرخه‌های بعدی
                    # دوباره تلاش می‌شود و سپس با لاگِ هشدار کنار گذاشته می‌شود.
                    if rc.get("ok"):
                        pplan["done"].append(i)
                        actions.append({"ticket": p.ticket, "symbol": p.symbol,
                                        "type": f"partial-TP{i+1}",
                                        "volume": rc.get("volume")})
                        pr = mt5.positions_get(ticket=p.ticket)
                        if pr:
                            p = pr[0]  # تازه‌سازی حجم باقیمانده
                        else:
                            break
                    else:
                        fails = pplan.setdefault("fails", {})
                        fails[i] = fails.get(i, 0) + 1
                        if fails[i] >= 3:
                            pplan["done"].append(i)
                            try:
                                import server_log as _sl
                                _sl.log("warn", "mt5",
                                        f"بستنِ جزئی TP{i+1} پس از ۳ تلاشِ ناموفق رها شد "
                                        f"(تیکت {p.ticket})",
                                        str(rc.get("error") or rc.get("comment") or ""))
                            except Exception:  # noqa
                                pass

            # ---- ۱) Breakeven: بعد از رسیدن سود به breakeven_r × ریسک ----
            if cfg.get("breakeven_enabled", True) and not state["be_done"] and risk > 0:
                if profit_dist >= float(cfg.get("breakeven_r", 1.0)) * risk:
                    buf = float(cfg.get("breakeven_buffer_pts", 5)) * point
                    be_sl = p.price_open + buf if is_buy else p.price_open - buf
                    # اصلاح (MT5-009): اگر قیمت هنوز به‌اندازهٔ stops_level از be_sl
                    # دور نشده، در این چرخه تلاش نمی‌کنیم (چرخهٔ بعد دوباره بررسی می‌شود).
                    if min_stop > 0 and (
                            (is_buy and be_sl > price - min_stop)
                            or ((not is_buy) and be_sl < price + min_stop)):
                        be_sl = None
                    if be_sl is not None and _better_sl(is_buy, p.sl, be_sl):
                        r = modify_position(p.ticket, sl=round(be_sl, digits))
                        if r.get("ok"):
                            state["be_done"] = True
                            actions.append({"ticket": p.ticket, "symbol": p.symbol,
                                            "type": "breakeven", "sl": round(be_sl, digits)})
                            # تازه‌سازیِ sl؛ اگر پوزیشن همین لحظه بسته شده باشد،
                            # positions_get تهی است → از [0] با محافظت پرهیز می‌کنیم
                            # تا کلِ چرخهٔ مدیریت با IndexError متوقف نشود.
                            pr = mt5.positions_get(ticket=p.ticket)
                            if pr:
                                p = pr[0]
                            else:
                                continue  # پوزیشن بسته شد؛ به پوزیشنِ بعدی برو

            # ---- ۲) Trailing Stop ----
            if cfg.get("trailing_enabled", True):
                # فقط بعد از رسیدن سود به trailing_start_r × ریسک (اگر ریسک معلوم است)
                start_ok = True
                if risk > 0:
                    start_ok = profit_dist >= float(cfg.get("trailing_start_r", 1.0)) * risk
                if start_ok:
                    _tmode = cfg.get("trailing_mode", "points")
                    if _tmode == "percent":
                        dist = price * float(cfg.get("trailing_percent", 0.5)) / 100.0
                    elif _tmode == "atr" and state.get("atr"):
                        # اصلاح (OPUS5-M7): فاصلهٔ تریل بر اساس ATR نماد/تایم‌فریم —
                        # «۳۰۰ پوینتِ» ثابت برای BTC≈۳$ بود و با اولین نویز می‌بست.
                        dist = float(cfg.get("trailing_atr_mult", 2.0)) * float(state["atr"])
                    else:
                        dist = float(cfg.get("trailing_points", 300)) * point
                    # اصلاح (MT5-009): فاصلهٔ تریل نباید از حداقلِ مجاز بروکر کمتر باشد.
                    if min_stop > 0:
                        dist = max(dist, min_stop)
                    trail_sl = price - dist if is_buy else price + dist
                    trail_sl = round(trail_sl, digits)
                    if _better_sl(is_buy, p.sl, trail_sl):
                        r = modify_position(p.ticket, sl=trail_sl)
                        if r.get("ok"):
                            actions.append({"ticket": p.ticket, "symbol": p.symbol,
                                            "type": "trailing", "sl": trail_sl})

        # اصلاح (OPUS5-M3): سفارش‌های معلقِ فعال‌شده به منیجر وصل شوند
        try:
            _resolve_pending_fills()
        except Exception:  # noqa
            pass
        # اصلاح (OPUS5-M6): ماندگاریِ وضعیت پس از هر دورِ مدیریت
        _persist_state()
        # پاک‌سازی وضعیتِ پوزیشن‌های بسته‌شده
        for tk in list(_pos_state.keys()):
            if tk not in live_tickets:
                _pos_state.pop(tk, None)
        for tk in list(_partial_plans.keys()):
            if tk not in live_tickets:
                _partial_plans.pop(tk, None)

    _manager["last_run"] = time.time()
    _manager["last_error"] = None
    if actions:
        _manager["actions"] = (actions + _manager["actions"])[:50]
    return {"ok": True, "actions": actions}


def _manager_loop():
    stop = _manager["stop"]
    while not stop.is_set():
        try:
            _manage_once()
        except Exception as e:  # noqa
            _manager["last_error"] = str(e)
        interval = float(load_config().get("manage_interval", 5) or 5)
        stop.wait(max(2.0, interval))
    _manager["running"] = False


def start_manager() -> dict:
    """راه‌اندازی نخِ پس‌زمینه‌ی مدیریت پوزیشن (idempotent و thread-safe).

    اصلاح (MT5-006): check-and-start بدون لاک می‌توانست دو نخِ مدیرِ همزمان بسازد.
    """
    with _lock:
        return _start_manager_locked()


def _start_manager_locked() -> dict:
    if _manager["running"] and _manager["thread"] and _manager["thread"].is_alive():
        return manager_status()
    _manager["stop"] = threading.Event()
    _manager["running"] = True
    th = threading.Thread(target=_manager_loop, name="mt5-pos-manager", daemon=True)
    _manager["thread"] = th
    th.start()
    return manager_status()


def stop_manager() -> dict:
    if _manager["stop"]:
        _manager["stop"].set()
    _manager["running"] = False
    return manager_status()


def manager_status() -> dict:
    return {
        "running": bool(_manager["running"] and _manager["thread"]
                        and _manager["thread"].is_alive()),
        "last_run": _manager["last_run"],
        "last_error": _manager["last_error"],
        "recent_actions": _manager["actions"][:15],
        "tracked": len(_pos_state),
    }
