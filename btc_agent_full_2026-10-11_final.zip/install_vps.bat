@echo off
REM ============================================================================
REM  install_vps.bat  --  نصبِ پیش‌نیازها روی VPS ویندوز (یک‌بار اجرا)
REM  این اسکریپت پایتون را بررسی و همهٔ کتابخانه‌های لازم (شاملِ MetaTrader5)
REM  را نصب می‌کند. روی همان پوشهٔ برنامه اجرا کنید.
REM ============================================================================
setlocal
cd /d "%~dp0"

echo.
echo ============================================================
echo   نصبِ پیش‌نیازهای برنامهٔ تحلیل روی VPS ویندوز
echo ============================================================
echo.

REM --- بررسیِ وجودِ پایتون ---
where python >nul 2>nul
if errorlevel 1 (
    echo [X] پایتون پیدا نشد.
    echo     لطفاً Python 3.10+ را از https://www.python.org/downloads/windows/
    echo     نصب کنید و هنگام نصب گزینه "Add Python to PATH" را تیک بزنید.
    pause
    exit /b 1
)

echo [1/3] نسخهٔ پایتون:
python --version
echo.

echo [2/3] به‌روزرسانیِ pip ...
python -m pip install --upgrade pip

echo.
echo [3/3] نصبِ کتابخانه‌ها از requirements.txt (شاملِ MetaTrader5 روی ویندوز) ...
python -m pip install -r requirements.txt

echo.
echo ============================================================
echo   نصب کامل شد.
echo   گامِ بعد:
echo     1) متاتریدر ۵ را باز و وارد حسابِ خود شوید.
echo     2) در متاتریدر:  Tools ^> Options ^> Expert Advisors
echo        - تیکِ "Allow WebRequest for listed URL"
echo        - آدرس  http://127.0.0.1:8000  را اضافه کنید.
echo        - تیکِ "Allow Algo Trading" (دکمهٔ Algo Trading روشن باشد).
echo     3) برای اجرای برنامه:  run_vps.bat  را اجرا کنید.
echo ============================================================
pause
endlocal
