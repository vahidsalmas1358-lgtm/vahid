"""ذخیره و بازیابی تاریخچه سیگنال‌ها — پشتوانهٔ SQLite (WAL) + کشِ RAM در جلو.

معماریِ ترکیبی (بهترین حالت):
  • نوشتن → SQLite: درجِ O(1) و اتمیک (به‌جای بازنویسیِ کاملِ فایلِ JSON؛ ~۳۰۰× سریع‌تر).
  • خواندنِ داغ (تشخیصِ تغییرِ جهت در record) → کشِ RAM: بدونِ لمسِ دیسک (~۰٫۱µs).
  • رابطِ بیرونی (record/get_all/clear) دست‌نخورده است تا بقیهٔ برنامه تغییری نکند.
  • دادهٔ فایلِ قدیمیِ signals_history.json یک‌بار به‌صورتِ خودکار مهاجرت می‌شود.
"""
from __future__ import annotations
import os
import time
import threading

import db

HISTORY_PATH = os.path.join(os.path.dirname(__file__), "signals_history.json")

_lock = threading.RLock()
_last_dir: dict = {}     # key -> آخرین جهت (کشِ RAM برای حذفِ رکوردِ تکراری)
_ready = False


def _ensure_ready():
    """مهاجرتِ یک‌بارهٔ JSON → SQLite (تنبل‌ساز)."""
    global _ready
    if _ready:
        return
    with _lock:
        if _ready:
            return
        try:
            db.migrate_signals_from_json(HISTORY_PATH)
        except Exception:  # noqa
            pass
        _ready = True


def record(sig: dict):
    """یک سیگنال را ثبت می‌کند؛ فقط اگر جهت نسبت به آخرین رکورد همان نماد/تایم‌فریم
    تغییر کرده باشد (برای جلوگیری از انباشت رکوردهای تکراری)."""
    _ensure_ready()
    key = f"{sig['symbol']}:{sig['interval']}"
    with _lock:
        prev = _last_dir.get(key)
        if prev is None:                       # کولد: یک‌بار از دیسک بخوان
            prev = db.last_signal_direction(key)
        if prev is not None and prev == sig["direction"]:
            _last_dir[key] = prev
            return False                       # تغییری نکرده

        p = sig.get("plan", {})
        db.add_signal({
            "ts": int(time.time()),
            "key": key,
            "symbol": sig["symbol"],
            "pair": sig["pair"],
            "interval": sig["interval"],
            "direction": sig["direction"],
            "price": sig["price"],
            "score": sig["total_score"],
            "entry": p.get("entry"),
            "stop_loss": p.get("stop_loss"),
            "take_profits": [t["price"] for t in p.get("take_profits", [])],
            "generated_at": sig["generated_at"],
        })
        _last_dir[key] = sig["direction"]
        return True


def get_all(symbol=None, limit=100) -> list:
    _ensure_ready()
    return db.get_signals(symbol, limit)


def clear():
    with _lock:
        db.clear_signals()
        _last_dir.clear()
    return True
