# -*- coding: utf-8 -*-
"""آزمونِ عمیقِ مسیرهای واقعیِ متاتریدر (اجرا با کارگزارِ شبیه‌سازی‌شده).

این هارنس کدهای «فقط‌ویندوزیِ» mt5_bridge را که تا امروز هرگز اجرا نشده بودند، با
یک کارگزارِ مصنوعی واقعاً اجرا و ریاضیاتشان را راستی‌آزمایی می‌کند:
  • ارسالِ سفارش و تقسیمِ لات در حالت‌های split/single/none/partial
  • رعایتِ حداقل‌فاصلهٔ استاپ (trade_stops_level) و رقم اعشارِ هر نماد
  • بستنِ جزئیِ خودکار (Partial TP)
  • سربه‌سر (Breakeven / Risk-Free)
  • تریلینگ استاپ (Trailing) و عدم بازگشتِ استاپ به عقب
  • محاسبهٔ حجم بر پایهٔ ریسک (risk_pct)
روی نمادهایی با قیمت/اعشار/point/گامِ لاتِ کاملاً متفاوت (طلا، بیت‌کوین، EURUSD،
USDJPY، US500).
"""
import sys

import mock_mt5
import mt5_bridge as mb

PASS = 0
FAIL = 0


def check(name, cond, ctx=""):
    global PASS, FAIL
    if cond:
        PASS += 1
    else:
        FAIL += 1
        print(f"  \033[31mFAIL\033[0m  {name}")
        if ctx:
            print(f"        ↳ {ctx}")


def _ok(name):
    global PASS
    PASS += 1


# پروفایلِ نمادهای واقعیِ کارگزار (اعشار/point/گامِ لات/حداقل‌فاصلهٔ استاپِ متفاوت)
PROFILES = {
    # internal, broker, digits, point, vmin, vstep, stops_level, tick_value, tick_size, price
    "XAU": dict(broker="XAUUSD", digits=2, point=0.01, vmin=0.01, vstep=0.01,
                stops_level=0, tick_value=1.0, tick_size=0.01, price=2400.00),
    "BTC": dict(broker="BTCUSD", digits=2, point=0.01, vmin=0.01, vstep=0.01,
                stops_level=0, tick_value=0.01, tick_size=0.01, price=83000.00),
    "EURUSD": dict(broker="EURUSD", digits=5, point=0.00001, vmin=0.01, vstep=0.01,
                   stops_level=10, tick_value=1.0, tick_size=0.00001, price=1.08500),
    "USDJPY": dict(broker="USDJPY", digits=3, point=0.001, vmin=0.01, vstep=0.01,
                   stops_level=10, tick_value=0.67, tick_size=0.001, price=157.400),
    "SPX": dict(broker="US500", digits=1, point=0.1, vmin=0.1, vstep=0.1,
                stops_level=0, tick_value=0.1, tick_size=0.1, price=7660.0),
}


def make_broker():
    b = mock_mt5.Broker(balance=10000.0)
    for _, p in PROFILES.items():
        b.add_symbol(p["broker"], digits=p["digits"], point=p["point"],
                     volume_min=p["vmin"], volume_step=p["vstep"],
                     stops_level=p["stops_level"], tick_value=p["tick_value"],
                     tick_size=p["tick_size"], price=p["price"])
    return b


def install(b):
    # ثابت‌های MT5 را روی همان شیئی که به‌جای ماژولِ mt5 می‌نشیند سوار کن
    for k in dir(mock_mt5):
        if k.isupper():
            setattr(b, k, getattr(mock_mt5, k))
    mb.mt5 = b
    mb.MT5_AVAILABLE = True
    mb._conn.update(connected=True, error=None, since=1.0)
    mb._pos_state.clear()
    mb._partial_plans.clear()
    b.positions.clear()
    b.deals.clear()


def base_cfg(**over):
    cfg = {
        "magic": 777, "deviation": 20, "comment": "AgentTest",
        "default_volume": 0.10, "risk_mode": "fixed",
        "use_plan_sl": True, "use_plan_tp": True,
        "execution": "market", "tp_mode": "split",
        "market_hours_guard": False,      # در تست بستنِ بازار مانع نشود
        "max_open_positions": 0, "max_daily_trades": 0, "max_daily_risk_pct": 0,
        "breakeven_enabled": True, "breakeven_r": 1.0, "breakeven_buffer_pts": 5,
        "trailing_enabled": False, "trailing_mode": "points",
        "trailing_points": 300, "trailing_start_r": 1.0,
        "partial_fractions": [0.5, 0.3],
    }
    cfg.update(over)
    mb.save_config(cfg)
    return cfg


def make_plan(internal, direction):
    """نقشهٔ معاملهٔ واقع‌گرایانه با ریسک/هدفِ متناسب با اعشارِ نماد."""
    p = PROFILES[internal]
    price = p["price"]
    long = direction == "LONG"
    # فاصلهٔ ریسک ~0.5٪ قیمت تا از حداقل‌فاصلهٔ استاپ فراتر باشد
    risk_dist = max(price * 0.005, p["stops_level"] * p["point"] * 3)
    entry = price
    sl = entry - risk_dist if long else entry + risk_dist
    tps = [entry + risk_dist * m if long else entry - risk_dist * m for m in (1, 2, 3)]
    return {"entry": round(entry, p["digits"]), "stop_loss": round(sl, p["digits"]),
            "take_profits": [round(t, p["digits"]) for t in tps]}


# ============================================================= تست‌ها
def t_split_lot_and_rounding():
    print("\n[۱] تقسیمِ لات (split) + رقم اعشار + سمتِ SL/TP روی همهٔ نمادها")
    for internal, p in PROFILES.items():
        for direction in ("LONG", "SHORT"):
            b = make_broker(); install(b)
            base_cfg(tp_mode="split", default_volume=0.10)
            plan = make_plan(internal, direction)
            res = mb.send_order(internal, direction, plan, volume=0.10,
                                dry_run=False, skip_news_filter=True)
            ctx = {"internal": internal, "dir": direction, "res_ok": res.get("ok"),
                   "err": res.get("error")}
            check(f"{internal} {direction} split: ارسال موفق", res.get("ok"), ctx)
            pos = list(b.positions.values())
            # مجموعِ حجم پوزیشن‌ها == حجمِ درخواستی (بدونِ تورم)
            total = round(sum(x.volume for x in pos), 8)
            check(f"{internal} {direction} split: مجموعِ لات = 0.10 (بدونِ تورم)",
                  total == 0.10, {"total": total, "legs": [x.volume for x in pos]})
            # هر پوزیشن SL/TP در سمتِ درست و گِردشده به digits
            for x in pos:
                dig = p["digits"]
                sl_ok = (x.sl < x.price_open) if direction == "LONG" else (x.sl > x.price_open)
                tp_ok = (x.tp > x.price_open) if direction == "LONG" else (x.tp < x.price_open)
                check(f"{internal} {direction} split: SL سمتِ درست", sl_ok,
                      {"sl": x.sl, "open": x.price_open})
                check(f"{internal} {direction} split: TP سمتِ درست", tp_ok,
                      {"tp": x.tp, "open": x.price_open})
                check(f"{internal} {direction} split: SL با {dig} رقم اعشار",
                      round(x.sl, dig) == x.sl, {"sl": x.sl})
                check(f"{internal} {direction} split: TP با {dig} رقم اعشار",
                      round(x.tp, dig) == x.tp, {"tp": x.tp})
            # TPها متمایز و مرتب
            tps = [x.tp for x in pos]
            if len(tps) >= 2:
                check(f"{internal} {direction} split: TPهای پوزیشن‌ها متمایز",
                      len(set(tps)) == len(tps), {"tps": tps})


def t_stops_level():
    print("\n[۲] رعایتِ حداقل‌فاصلهٔ استاپِ کارگزار (trade_stops_level)")
    # EURUSD/USDJPY حداقل‌فاصله دارند؛ نقشه‌ای با SL/TP خیلی نزدیک می‌سازیم
    for internal in ("EURUSD", "USDJPY"):
        p = PROFILES[internal]
        for direction in ("LONG", "SHORT"):
            b = make_broker(); install(b)
            base_cfg(tp_mode="single")
            price = p["price"]; long = direction == "LONG"
            tiny = p["point"] * 2  # کمتر از حداقل‌فاصله (۱۰ point)
            entry = price
            sl = entry - tiny if long else entry + tiny
            tp = entry + tiny if long else entry - tiny
            plan = {"entry": entry, "stop_loss": round(sl, p["digits"]),
                    "take_profits": [round(tp, p["digits"])]}
            res = mb.send_order(internal, direction, plan, volume=0.10,
                                dry_run=False, skip_news_filter=True)
            check(f"{internal} {direction} stops-level: ارسال موفق", res.get("ok"), res.get("error"))
            pos = list(b.positions.values())
            min_dist = p["stops_level"] * p["point"]
            for x in pos:
                d_sl = abs(x.price_open - x.sl)
                d_tp = abs(x.tp - x.price_open)
                check(f"{internal} {direction}: فاصلهٔ SL ≥ حداقلِ مجاز",
                      d_sl >= min_dist - 1e-9, {"d_sl": d_sl, "min": min_dist})
                check(f"{internal} {direction}: فاصلهٔ TP ≥ حداقلِ مجاز",
                      d_tp >= min_dist - 1e-9, {"d_tp": d_tp, "min": min_dist})


def t_single_none():
    print("\n[۳] حالت‌های single و none")
    b = make_broker(); install(b)
    base_cfg(tp_mode="single")
    plan = make_plan("XAU", "LONG")
    mb.send_order("XAU", "LONG", plan, volume=0.10, dry_run=False, skip_news_filter=True)
    pos = list(b.positions.values())
    check("single: یک پوزیشن باز شد", len(pos) == 1, len(pos))
    check("single: TP = TP1", pos and pos[0].tp == plan["take_profits"][0],
          {"tp": pos[0].tp if pos else None, "tp1": plan["take_profits"][0]})

    b = make_broker(); install(b)
    base_cfg(tp_mode="none")
    mb.send_order("XAU", "LONG", plan, volume=0.10, dry_run=False, skip_news_filter=True)
    pos = list(b.positions.values())
    check("none: یک پوزیشن باز شد", len(pos) == 1, len(pos))
    check("none: بدونِ TP (tp=0)", pos and pos[0].tp == 0.0, {"tp": pos[0].tp if pos else None})


def t_partial_tp():
    print("\n[۴] بستنِ جزئیِ خودکار (Partial TP) + محاسبهٔ لاتِ باقیمانده")
    b = make_broker(); install(b)
    base_cfg(tp_mode="partial", default_volume=1.00, partial_fractions=[0.5, 0.3],
             breakeven_enabled=False, trailing_enabled=False)
    plan = make_plan("XAU", "LONG")
    mb.send_order("XAU", "LONG", plan, volume=1.00, dry_run=False, skip_news_filter=True)
    pos = list(b.positions.values())
    check("partial: یک پوزیشن با کل حجم باز شد", len(pos) == 1 and abs(pos[0].volume - 1.00) < 1e-9,
          {"n": len(pos), "vol": pos[0].volume if pos else None})
    check("partial: TP پوزیشن = TP3", pos and pos[0].tp == plan["take_profits"][2],
          {"tp": pos[0].tp if pos else None, "tp3": plan["take_profits"][2]})
    tk = pos[0].ticket
    tps = plan["take_profits"]

    # رسیدن قیمت به TP1 → بستنِ ۵۰٪
    b.set_price("XAUUSD", tps[0] + 0.1)
    mb._manage_once()
    v1 = b.positions[tk].volume
    check("partial: پس از TP1، ~۵۰٪ بسته شد (باقیمانده ≈ 0.50)", abs(v1 - 0.50) < 1e-9,
          {"remaining": v1})

    # رسیدن قیمت به TP2 → بستنِ ۳۰٪ دیگر (از حجمِ اولیه)
    b.set_price("XAUUSD", tps[1] + 0.1)
    mb._manage_once()
    v2 = b.positions[tk].volume
    check("partial: پس از TP2، ۳۰٪ دیگر بسته شد (باقیمانده ≈ 0.20)", abs(v2 - 0.20) < 1e-9,
          {"remaining": v2})
    # مجموعِ بسته‌شده نباید از حجمِ اولیه بیشتر باشد
    closed = sum(d.get("close_volume", 0) for d in b.deals)
    check("partial: مجموعِ بسته‌شده ≤ حجمِ اولیه", closed <= 1.00 + 1e-9, {"closed": closed})


def t_breakeven():
    print("\n[۵] سربه‌سر (Breakeven / Risk-Free) — سمت و بافرِ درست، بدونِ بازگشت")
    for internal in ("XAU", "EURUSD", "USDJPY"):
        p = PROFILES[internal]
        for direction in ("LONG", "SHORT"):
            b = make_broker(); install(b)
            base_cfg(tp_mode="single", breakeven_enabled=True, breakeven_r=1.0,
                     breakeven_buffer_pts=5, trailing_enabled=False)
            plan = make_plan(internal, direction)
            mb.send_order(internal, direction, plan, volume=0.10, dry_run=False, skip_news_filter=True)
            tk = list(b.positions.keys())[0]
            pos = b.positions[tk]
            risk = abs(pos.price_open - pos.sl)
            long = direction == "LONG"
            # قیمت را به‌اندازهٔ ۳R در جهتِ سود ببر تا حدِ سربه‌سر قطعاً برآورده شود
            # (سود بر پایهٔ قیمتِ خروج/bid محاسبه می‌شود که محافظه‌کارانه و درست است)
            target = pos.price_open + 3 * risk if long else pos.price_open - 3 * risk
            b.set_price(p["broker"], target)
            mb._manage_once()
            new_sl = b.positions[tk].sl
            # استاپِ سربه‌سر باید دقیقاً = قیمتِ ورود ± بافر باشد (مستقل از میزانِ حرکت)
            expected = round(pos.price_open + 5 * p["point"] if long
                             else pos.price_open - 5 * p["point"], p["digits"])
            check(f"{internal} {direction} BE: استاپ دقیقاً به سربه‌سر+بافر منتقل شد",
                  new_sl == expected, {"new_sl": new_sl, "expected": expected})
            # سمتِ درست: برای LONG استاپِ جدید ≥ ورود، برای SHORT ≤ ورود (قفلِ سود)
            check(f"{internal} {direction} BE: سمتِ درست (قفلِ سود)",
                  (new_sl >= pos.price_open) if long else (new_sl <= pos.price_open),
                  {"new_sl": new_sl, "open": pos.price_open})
            # اجرای دوباره نباید استاپ را به عقب برگرداند
            sl_before = b.positions[tk].sl
            mb._manage_once()
            check(f"{internal} {direction} BE: بدونِ بازگشتِ استاپ در اجرای دوباره",
                  b.positions[tk].sl == sl_before, {"sl": b.positions[tk].sl})


def t_trailing():
    print("\n[۶] تریلینگ استاپ — دنبال‌کردنِ سود و عدم بازگشت به عقب")
    for internal in ("XAU", "USDJPY"):
        p = PROFILES[internal]
        for direction in ("LONG", "SHORT"):
            b = make_broker(); install(b)
            base_cfg(tp_mode="single", breakeven_enabled=False,
                     trailing_enabled=True, trailing_mode="points",
                     trailing_points=200, trailing_start_r=1.0)
            plan = make_plan(internal, direction)
            mb.send_order(internal, direction, plan, volume=0.10, dry_run=False, skip_news_filter=True)
            tk = list(b.positions.keys())[0]
            pos = b.positions[tk]
            risk = abs(pos.price_open - pos.sl)
            long = direction == "LONG"
            dist = 200 * p["point"]
            # حرکتِ سودده فراتر از trailing_start (با حاشیهٔ کافی برای پوششِ اسپرد)
            step1 = pos.price_open + (2 * risk + dist) if long else pos.price_open - (2 * risk + dist)
            b.set_price(p["broker"], step1)
            mb._manage_once()
            sl1 = b.positions[tk].sl
            # انتظار بر پایهٔ قیمتِ واقعیِ خروج (bid برای لانگ، ask برای شورت)
            tk_now = b.symbol_info_tick(p["broker"])
            exit_px = tk_now.bid if long else tk_now.ask
            exp1 = round(exit_px - dist, p["digits"]) if long else round(exit_px + dist, p["digits"])
            check(f"{internal} {direction} trail: استاپ در فاصلهٔ درست دنبال شد",
                  sl1 == exp1, {"sl": sl1, "exp": exp1})
            # حرکتِ بیشتر → استاپ باید جلوتر برود
            step2 = step1 + dist if long else step1 - dist
            b.set_price(p["broker"], step2)
            mb._manage_once()
            sl2 = b.positions[tk].sl
            check(f"{internal} {direction} trail: استاپ جلوتر رفت (در جهتِ سود)",
                  (sl2 > sl1) if long else (sl2 < sl1), {"sl1": sl1, "sl2": sl2})
            # حرکتِ برگشتیِ کوچک → استاپ نباید عقب برود
            back = step2 - dist * 0.3 if long else step2 + dist * 0.3
            b.set_price(p["broker"], back)
            mb._manage_once()
            sl3 = b.positions[tk].sl
            check(f"{internal} {direction} trail: بدونِ بازگشتِ استاپ هنگام پول‌بک",
                  sl3 == sl2, {"sl2": sl2, "sl3": sl3})


def t_risk_pct_volume():
    print("\n[۷] محاسبهٔ حجم بر پایهٔ ریسک (risk_pct) روی نمادهای مختلف")
    for internal in ("XAU", "USDJPY", "SPX"):
        p = PROFILES[internal]
        b = make_broker(); install(b)
        base_cfg(tp_mode="single", risk_mode="risk_pct", risk_pct=1.0,
                 breakeven_enabled=False, trailing_enabled=False)
        plan = make_plan(internal, "LONG")
        res = mb.send_order(internal, "LONG", plan, volume=None,
                            dry_run=False, skip_news_filter=True)
        pos = list(b.positions.values())
        total = round(sum(x.volume for x in pos), 8)
        # محاسبهٔ موردِ انتظار: risk_cash / ((sl_dist/tick_size)*tick_value)
        sl_dist = abs(plan["entry"] - plan["stop_loss"])
        val_per_unit = (sl_dist / p["tick_size"]) * p["tick_value"]
        want_vol = 100.0 / val_per_unit  # balance 10000 * 1%
        # نرمال‌سازی به گامِ لات
        class _I:
            volume_min = p["vmin"]; volume_step = p["vstep"]; volume_max = 100.0
        want_norm = mb._norm_volume(_I(), want_vol)
        check(f"{internal} risk_pct: مجموعِ لات ≈ حجمِ محاسبه‌شده از ریسک",
              abs(total - want_norm) <= p["vstep"] + 1e-9,
              {"total": total, "want": want_norm, "raw": round(want_vol, 4)})
        # ریسکِ گزارش‌شده باید ~۱٪ موجودی (۱۰۰) باشد
        check(f"{internal} risk_pct: ریسکِ گزارش‌شده منطقی (>0)",
              res.get("risk_amount", 0) > 0, res.get("risk_amount"))


def t_no_position_leak():
    print("\n[۸] پاک‌سازیِ حالتِ پوزیشن پس از بسته‌شدن (نشتِ حافظه)")
    b = make_broker(); install(b)
    base_cfg(tp_mode="single", breakeven_enabled=True, trailing_enabled=True)
    plan = make_plan("XAU", "LONG")
    mb.send_order("XAU", "LONG", plan, volume=0.10, dry_run=False, skip_news_filter=True)
    mb._manage_once()
    check("state ثبت شد", len(mb._pos_state) >= 1, len(mb._pos_state))
    # بستنِ دستیِ همهٔ پوزیشن‌ها و اجرای مدیریت
    b.positions.clear()
    mb._manage_once()
    check("state پس از بسته‌شدن پاک شد (بدونِ نشت)", len(mb._pos_state) == 0, len(mb._pos_state))
    check("partial_plans پس از بسته‌شدن پاک شد", len(mb._partial_plans) == 0, len(mb._partial_plans))


def t_market_hours():
    print("\n[۹] ساعاتِ بازار — آخرِ هفته/جمعه (فارکس/فلز/شاخص) در برابرِ کریپتو ۲۴/۷")
    import market_hours as mh
    from datetime import datetime, timezone

    # زمان‌های نمونه (UTC): Mon=0..Sun=6
    fri_before = datetime(2026, 9, 25, 12, 0, tzinfo=timezone.utc)   # جمعه ظهر → باز
    fri_after = datetime(2026, 9, 25, 21, 30, tzinfo=timezone.utc)   # جمعه پس از ۲۱:۰۰ → بسته
    saturday = datetime(2026, 9, 26, 12, 0, tzinfo=timezone.utc)     # شنبه → بسته
    sun_before = datetime(2026, 9, 27, 10, 0, tzinfo=timezone.utc)   # یکشنبه قبل از ۲۱:۰۰ → بسته
    sun_after = datetime(2026, 9, 27, 22, 0, tzinfo=timezone.utc)    # یکشنبه پس از ۲۱:۰۰ → باز
    wednesday = datetime(2026, 9, 23, 12, 0, tzinfo=timezone.utc)    # وسطِ هفته → باز

    for internal in ("EURUSD", "XAU", "SPX"):
        check(f"{internal}: جمعه ظهر باز است", mh.is_open(internal, fri_before), internal)
        check(f"{internal}: جمعه پس از بسته‌شدن، بسته است", not mh.is_open(internal, fri_after), internal)
        check(f"{internal}: شنبه بسته است", not mh.is_open(internal, saturday), internal)
        check(f"{internal}: یکشنبه قبل از بازگشایی، بسته است", not mh.is_open(internal, sun_before), internal)
        check(f"{internal}: یکشنبه شب باز می‌شود", mh.is_open(internal, sun_after), internal)
        check(f"{internal}: وسطِ هفته باز است", mh.is_open(internal, wednesday), internal)

    # کریپتو همیشه باز (۲۴/۷) حتی شنبه/جمعه‌شب
    for internal in ("BTC", "ETH", "SOL"):
        check(f"{internal}: کریپتو شنبه هم باز است", mh.is_open(internal, saturday), internal)
        check(f"{internal}: کریپتو جمعه‌شب هم باز است", mh.is_open(internal, fri_after), internal)

    # پیامِ توضیحیِ آخرِ هفته درست تولید شود
    st = mh.status("EURUSD", saturday)
    check("status شنبه: open=False و دلیلِ فارسی دارد",
          st["open"] is False and "شنبه" in st["reason_fa"], st)
    st2 = mh.status("EURUSD", fri_after)
    check("status جمعهٔ پس از بسته‌شدن: زمانِ بازگشاییِ آینده مثبت است",
          st2["open"] is False and (st2["next_change_in_min"] or 0) > 0, st2)

    # --- مسیرِ واقعیِ ارسال باید روی بازارِ بسته، معاملهٔ واقعی را لغو کند ---
    # market_hours.status از زمانِ «اکنون» استفاده می‌کند؛ برای آزمونِ قطعی، آن را موقتاً
    # به یک تابعِ ثابتِ «بسته» مانکی‌پچ می‌کنیم.
    b = make_broker(); install(b)
    base_cfg(tp_mode="single", market_hours_guard=True)
    plan = make_plan("EURUSD", "LONG")
    orig_status = mb.market_hours.status
    try:
        mb.market_hours.status = lambda s, now=None: {
            "open": False, "asset_class": "forex", "always_open": False,
            "reason_fa": "بازار برای آخر هفته بسته است.", "reason_en": "closed"}
        res = mb.send_order("EURUSD", "LONG", plan, volume=0.10,
                            dry_run=False, skip_news_filter=True)
        check("ارسالِ واقعی روی بازارِ بسته لغو شد (blocked)",
              res.get("ok") is False and res.get("blocked") is True, res)
        check("هیچ پوزیشنی روی بازارِ بسته باز نشد", len(b.positions) == 0, len(b.positions))
        # اما در حالتِ dry-run (پیش‌نمایش) نباید مسدود شود
        res2 = mb.send_order("EURUSD", "LONG", plan, volume=0.10,
                             dry_run=True, skip_news_filter=True)
        check("پیش‌نمایش (dry-run) حتی روی بازارِ بسته کار می‌کند", res2.get("ok") is True, res2)
    finally:
        mb.market_hours.status = orig_status


def main():
    # اصلاح (TEST-CFG-001): این سوئیت کانفیگ واقعی را با base_cfg تغییر می‌دهد
    # (ازجمله trailing_enabled=False) و قبلاً بازنمی‌گرداند؛ در نتیجه پس از هر
    # اجرای ممیزی، تریلینگ/تنظیمات ربات بی‌صدا در حالت آزمایشی می‌ماند.
    import shutil, os
    _cfg = os.path.join(os.path.dirname(os.path.abspath(__file__)), "mt5_config.json")
    _bak = "/tmp/deep_audit_cfg.bak"
    _had = os.path.exists(_cfg)
    if _had:
        shutil.copy(_cfg, _bak)
    print("=" * 64)
    print(" آزمونِ عمیقِ مسیرهای واقعیِ متاتریدر (کارگزارِ شبیه‌سازی‌شده)")
    print("=" * 64)
    try:
        t_split_lot_and_rounding()
        t_stops_level()
        t_single_none()
        t_partial_tp()
        t_breakeven()
        t_trailing()
        t_risk_pct_volume()
        t_no_position_leak()
        t_market_hours()
    finally:
        if _had:
            shutil.copy(_bak, _cfg)
    print("\n" + "=" * 64)
    print(f"  نتیجه: {PASS} پاس · {FAIL} ناموفق")
    print("=" * 64)
    sys.exit(1 if FAIL else 0)


if __name__ == "__main__":
    main()
