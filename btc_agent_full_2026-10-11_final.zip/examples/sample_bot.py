# -*- coding: utf-8 -*-
"""نمونهٔ رباتِ پایتونیِ کاربر که مستقیم به متاتریدر سفارش می‌دهد."""
from __future__ import annotations
import time
import MetaTrader5 as mt5

DRY_RUN = True  # اصلاح (AUD-003): پیش‌فرضِ امن — تا وقتی آگاهانه False نشود، سفارشِ واقعی ارسال نمی‌شود

def my_signal():
    return "BUY"

def has_open_position(symbol: str) -> bool:
    """گاردِ پوزیشنِ باز (OP5-PY-16): جلوگیری از بازکردنِ پوزیشنِ تکراری."""
    positions = mt5.positions_get(symbol=symbol) or []
    return len(positions) > 0


def run():
    if not mt5.initialize():
        raise RuntimeError("اتصال به متاتریدر برقرار نشد")
    last_signal = None          # dedupe: تا وقتی سیگنال تغییر نکند ارسال نمی‌شود
    last_sent_at = 0.0
    while True:
        s = my_signal()
        now = time.monotonic()
        # OP5-PY-16: قبلاً هر ۶۰ ثانیه یک BUY تازه ارسال می‌شد (بدونِ dedupe/گاردِ
        # پوزیشن). اکنون: سیگنالِ None وضعیت را ریست می‌کند، فقط تغییرِ سیگنال
        # ارسال می‌شود و اگر پوزیشنِ بازی روی نماد باشد ارسال انجام نمی‌شود.
        if s not in ("BUY", "SELL", None):
            print("ignored invalid signal:", repr(s))
        elif s is None:
            last_signal = None
        elif s != last_signal and now - last_sent_at >= 60.0:
            if has_open_position("XAUUSD"):
                print("[guard] پوزیشنِ باز روی XAUUSD هست؛ سیگنال ارسال نشد.")
            else:
                req = {"action": mt5.TRADE_ACTION_DEAL, "symbol": "XAUUSD",
                       "volume": 0.1, "type": (mt5.ORDER_TYPE_BUY if s == "BUY"
                                               else mt5.ORDER_TYPE_SELL),
                       "price": (mt5.symbol_info_tick("XAUUSD").ask if s == "BUY"
                                 else mt5.symbol_info_tick("XAUUSD").bid)}
                if DRY_RUN:
                    print("[DRY-RUN] سفارش ارسال نشد:", req)
                else:
                    result = mt5.order_send(req)
                    print(result.retcode)
            last_signal = s
            last_sent_at = now
        time.sleep(60)

if __name__ == "__main__":
    run()
