//+------------------------------------------------------------------+
//|                                                    SampleEA.mq5  |
//+------------------------------------------------------------------+
#property copyright "User"
#property version   "1.10"
#property strict

// OP5-MQL-11: برای استفاده از SelectFilling/SendChecked/NormalizeVolumeDown
#include <RobotBridge.mqh>

input double InpLot = 0.10;
input bool   InpDemoSend = false; // اصلاح (AUD-002): پیش‌فرض امن — این فایل فقط «نمونهٔ آموزشیِ تزریق» است
datetime g_lastBar = 0;

int OnInit()
{
   Print("SampleEA started");
   return(INIT_SUCCEEDED);
}

void OnTick()
{
   // اصلاح (AUD-002) + OP5-MQL-11: قبلاً سفارش بدونِ type_filling/deviation/time/magic
   // و بدونِ نرمال‌سازیِ حجم ارسال می‌شد و نتیجهٔ bool هم بررسی نمی‌شد.
   datetime bar=iTime(_Symbol,PERIOD_CURRENT,0);
   if(!InpDemoSend || bar==g_lastBar) return;
   g_lastBar=bar;
   MqlTick q;
   if(!SymbolInfoTick(_Symbol,q)) return;
   double volume=NormalizeVolumeDown(_Symbol,InpLot);
   if(volume<=0.0) return;
   MqlTradeRequest req;
   MqlTradeResult res;
   ZeroMemory(req); ZeroMemory(res);
   req.action=TRADE_ACTION_DEAL;
   req.symbol=_Symbol;
   req.volume=volume;
   req.type=ORDER_TYPE_BUY;
   req.price=q.ask;
   req.type_time=ORDER_TIME_GTC;
   req.deviation=20;
   req.magic=10001;
   req.type_filling=SelectFilling(_Symbol);
   if(!SendChecked(req,res,1))
      PrintFormat("Order failed retcode=%u comment=%s err=%d",
                  res.retcode,res.comment,GetLastError());
   else
      PrintFormat("Order result retcode=%u order=%I64u deal=%I64u",
                  res.retcode,res.order,res.deal);
}
