# -*- coding: utf-8 -*-
"""آزمونِ فازیِ جامع (۲۰۰ معاملهٔ خرید/فروش با دادهٔ واقعی) روی همهٔ نمادها.

هدف: پیدا کردنِ ایراد/باگ/ناسازگاری/خطا در سراسرِ زنجیره با نمادهایی که
قیمت‌ها، اعشار و پسوندهای متفاوت دارند (طلا، بیت‌کوین، اتریوم، سولانا،
جفت‌ارزها، شاخص‌های سهام، ...) و تنظیماتِ تصادفیِ برنامه/ربات.

بخش‌ها:
  A) قراردادِ نقشهٔ معامله با دادهٔ واقعی (ورود + دقیقاً ۳ TP + ۱ SL) برای هر
     نماد × چند تایم‌فریم × هر دو جهت.
  B) نگاشتِ نماد↔پسوندِ کارگزار (بدونِ نگاشتِ نادرست).
  C) تقسیمِ حجم بینِ پله‌ها (بدونِ تورمِ حجم) روی گام/حداقلِ لاتِ متفاوت.
  D) ۲۰۰ سفارشِ تصادفیِ زنده روی /api/robot/order و /api/robot/test با
     تنظیماتِ رندومِ برنامه/ربات و نمادهای پسونددار.

خروجی: گزارشِ دسته‌بندی‌شده + فایلِ fuzz_findings.json برای تحلیل.
"""
import json
import random
import sys
import urllib.request

BASE = "http://127.0.0.1:8000"
_SEED = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].lstrip("-").isdigit() else 20260929
random.seed(_SEED)

# نمادهای دارای دادهٔ رایگانِ واقعی و کلاسِ دارایی (برای قیمت/اعشار/پسوندِ متفاوت)
DATA_SYMBOLS = {
    "BTC": ("crypto", ["BTCUSD", "BTCUSDT", "BTCUSD."]),
    "ETH": ("crypto", ["ETHUSD", "ETHUSDT"]),
    "SOL": ("crypto", ["SOLUSD", "SOLUSDT"]),
    "XRP": ("crypto", ["XRPUSD", "XRPUSDT"]),
    "DOGE": ("crypto", ["DOGEUSD", "DOGEUSDT"]),
    "BNB": ("crypto", ["BNBUSD", "BNBUSDT"]),
    "XAU": ("metal", ["XAUUSD", "GOLD", "XAUUSD."]),
    "XAG": ("metal", ["XAGUSD", "SILVER"]),
    "WTI": ("commodity", ["XTIUSD", "USOIL", "WTI"]),
    "NG": ("commodity", ["XNGUSD", "NATGAS"]),
    "HG": ("commodity", ["XCUUSD", "COPPER"]),
    "SPX": ("index", ["US500", "SPX500", "SP500"]),
    "NASDAQ": ("index", ["USTEC", "NAS100", "US100"]),
    "EURUSD": ("forex", ["EURUSD"]),
    "GBPUSD": ("forex", ["GBPUSD"]),
    "USDJPY": ("forex", ["USDJPY"]),
}
SUFFIXES = ["", "m", ".m", "micro", "pro", ".pro", "#", ".r", "c", ".cash", "-5", ".raw"]
TFS = ["5m", "15m", "1h", "4h"]

PASS = 0
FAIL = 0
FINDINGS = []      # لیستِ ایرادها برای تحلیل و رفع
WARN = []


def check(name, cond, ctx=""):
    global PASS, FAIL
    if cond:
        PASS += 1
    else:
        FAIL += 1
        FINDINGS.append({"check": name, "context": _short(ctx)})
        print(f"  \033[31mFAIL\033[0m  {name}")
        if ctx:
            print(f"        ↳ {_short(ctx)}")


def note(msg, ctx=""):
    WARN.append({"note": msg, "context": _short(ctx)})


def _short(x, n=400):
    try:
        s = x if isinstance(x, str) else json.dumps(x, ensure_ascii=False, default=str)
    except Exception:
        s = str(x)
    return s if len(s) <= n else s[:n] + "…"


# ----------------------------------------------------------------- HTTP helpers
def _post(path, payload, headers=None):
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(BASE + path, data=data, method="POST",
                                 headers={"Content-Type": "application/json",
                                          **(headers or {})})
    try:
        with urllib.request.urlopen(req, timeout=40) as r:
            return r.getcode(), json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", "ignore")
        try:
            return e.code, json.loads(body)
        except Exception:
            return e.code, {"_raw": body}
    except Exception as e:
        return -1, {"_exc": str(e)}


def _get(path):
    try:
        with urllib.request.urlopen(BASE + path, timeout=40) as r:
            return r.getcode(), json.loads(r.read().decode("utf-8"))
    except Exception as e:
        return -1, {"_exc": str(e)}


def set_dispatch(**kw):
    return _post("/api/dispatch/config", kw)


def set_robot(**kw):
    return _post("/api/robot/config", kw)


# ================================================================= PART A
def part_a_plan_contract():
    """قراردادِ نقشهٔ معامله با دادهٔ واقعی برای هر دو جهت و هر نماد/تایم‌فریم."""
    print("\n[A] قراردادِ نقشهٔ معامله با دادهٔ واقعی (ورود + دقیقاً ۳ TP + ۱ SL)")
    import engine
    tested = 0
    for symbol, (klass, _cands) in DATA_SYMBOLS.items():
        for tf in ("15m", "1h", "4h"):
            try:
                data = engine.build_signal(symbol, tf, with_ai=False)
            except Exception as e:
                check(f"ساختِ سیگنالِ {symbol}@{tf}", False, f"استثنا: {e}")
                continue
            price = data["price"]
            atr = data["atr"]
            dec = engine._dec(price)
            tech = data["technical"]
            check(f"{symbol}@{tf}: قیمتِ مثبت و معتبر", isinstance(price, (int, float)) and price > 0,
                  {"price": price})
            check(f"{symbol}@{tf}: ATR غیرمنفی", (atr or 0) >= 0, {"atr": atr})
            for direction in ("LONG", "SHORT"):
                plan = engine.build_trade_plan(
                    direction, price, atr, tech["supports"], tech["resistances"],
                    abs(data["total_score"]), dec, fib=tech.get("fibonacci"),
                    extra_sup=tech.get("conf_supports"), extra_res=tech.get("conf_resistances"))
                tested += 1
                ctx = {"symbol": symbol, "tf": tf, "dir": direction, "price": price,
                       "atr": atr, "dec": dec, "entry": plan.get("entry"),
                       "sl": plan.get("stop_loss"), "tps": [t["price"] for t in plan.get("take_profits", [])]}
                entry = plan.get("entry")
                sl = plan.get("stop_loss")
                tps = [t["price"] for t in plan.get("take_profits", [])]
                check(f"{symbol}@{tf} {direction}: ورود موجود", entry is not None, ctx)
                check(f"{symbol}@{tf} {direction}: استاپ موجود", sl is not None, ctx)
                check(f"{symbol}@{tf} {direction}: دقیقاً ۳ تیک‌پروفیت", len(tps) == 3, ctx)
                if len(tps) == 3 and entry is not None and sl is not None:
                    check(f"{symbol}@{tf} {direction}: هر ۳ تیک‌پروفیت متمایز", len(set(tps)) == 3, ctx)
                    check(f"{symbol}@{tf} {direction}: هیچ تیک‌پروفیتی روی نقطهٔ ورود نیست",
                          all(t != entry for t in tps), ctx)
                    if direction == "LONG":
                        check(f"{symbol}@{tf} LONG: استاپ زیرِ ورود", sl < entry, ctx)
                        check(f"{symbol}@{tf} LONG: تیک‌پروفیت‌ها بالای ورود و صعودی",
                              all(t > entry for t in tps) and tps == sorted(tps), ctx)
                    else:
                        check(f"{symbol}@{tf} SHORT: استاپ بالای ورود", sl > entry, ctx)
                        check(f"{symbol}@{tf} SHORT: تیک‌پروفیت‌ها زیرِ ورود و نزولی",
                              all(t < entry for t in tps) and tps == sorted(tps, reverse=True), ctx)
                    # اعشار: قیمت‌ها نباید دقتِ نامعقول داشته باشند (هم‌راستا با dec)
                    bad_dec = [t for t in tps + [entry, sl]
                               if round(float(t), dec) != float(t)]
                    check(f"{symbol}@{tf} {direction}: اعشارِ قیمت‌ها با dec={dec} سازگار است",
                          not bad_dec, {"bad": bad_dec, **ctx})
    print(f"    → {tested} نقشهٔ معامله با دادهٔ واقعی بررسی شد.")


# ================================================================= PART B
def part_b_symbol_resolution():
    print("\n[B] نگاشتِ نماد↔پسوندِ کارگزار (بدونِ نگاشتِ نادرست)")
    import mt5_bridge
    for internal, (klass, cands) in DATA_SYMBOLS.items():
        primary = cands[0]
        for suf in SUFFIXES:
            broker = primary + suf
            got = mt5_bridge.internal_for_broker(broker)
            # پسوندهای «.چیزی» و پسوندهای حرفی روی نامزدِ ≥۵ کاراکتری باید به همان داخلی نگاشت شوند
            check(f"نگاشتِ «{broker}» → {internal}", got == internal,
                  {"broker": broker, "expected": internal, "got": got})
    # نمادهای پشتیبانی‌نشده نباید به نمادِ اشتباه نگاشت شوند
    for bad in ["AUDUSD", "USDCHF", "USDCAD", "NZDUSD", "EURJPY", "GBPJPY", "AAPL",
                "TSLA", "AMZN", "PLATINUM", "ZZZZ"]:
        got = mt5_bridge.internal_for_broker(bad)
        check(f"نمادِ پشتیبانی‌نشده «{bad}» نگاشتِ نادرست ندارد", got == "",
              {"bad": bad, "got": got})


# ================================================================= PART C
def part_c_volume_split():
    print("\n[C] تقسیمِ حجم بینِ پله‌ها (بدونِ تورمِ حجم) روی گام/حداقلِ لاتِ متفاوت")
    import mt5_bridge

    class FakeInfo:
        def __init__(self, vmin, vstep, vmax=100.0):
            self.volume_min = vmin
            self.volume_step = vstep
            self.volume_max = vmax

    combos = [
        (0.01, 0.01), (0.1, 0.1), (0.01, 0.001), (1.0, 1.0),
        (0.1, 0.01), (0.5, 0.5), (0.02, 0.02),
    ]
    volumes = [0.01, 0.03, 0.05, 0.1, 0.25, 0.3, 1.0, 3.33, 0.007, 2.0]
    tps3 = [1, 2, 3]
    for (vmin, vstep) in combos:
        info = FakeInfo(vmin, vstep)
        for vol in volumes:
            for mode in ("split", "single", "none", "partial"):
                legs = mt5_bridge._legs(vol, tps3, mode, info)
                total_norm = mt5_bridge._norm_volume(info, vol)
                s = round(sum(v for v, _ in legs), 8)
                ctx = {"vmin": vmin, "vstep": vstep, "vol": vol, "mode": mode,
                       "legs": legs, "sum": s, "norm": total_norm}
                # مجموعِ لات‌ها نباید از حجمِ نرمال‌شده بیشتر شود (تورمِ حجم)
                check(f"حجم[min={vmin},step={vstep},vol={vol},{mode}]: مجموع ≤ نرمال‌شده + ۱ گام",
                      s <= total_norm + vstep + 1e-9, ctx)
                # هر پله باید ≥ حداقلِ لات باشد
                check(f"حجم[min={vmin},step={vstep},vol={vol},{mode}]: هر پله ≥ حداقلِ لات",
                      all(v >= vmin - 1e-9 for v, _ in legs), ctx)
                if mode == "single":
                    check(f"single[{vmin},{vstep},{vol}]: یک پله", len(legs) == 1, ctx)
                if mode == "none":
                    check(f"none[{vmin},{vstep},{vol}]: یک پله بدونِ TP",
                          len(legs) == 1 and legs[0][1] is None, ctx)


# ================================================================= PART D
def _rand_tps(price, direction, klass):
    """تولیدِ حد سودهای واقع‌گرایانه بر اساسِ قیمت و کلاسِ دارایی (اعشارِ متفاوت)."""
    if price is None:
        return []
    long = direction == "BUY"
    frac = {"crypto": 0.01, "metal": 0.005, "commodity": 0.01,
            "index": 0.004, "forex": 0.002}.get(klass, 0.01)
    style = random.choice(["three", "single", "none", "malformed"])
    if style == "none":
        return None
    if style == "malformed":
        return random.choice([["x"], [None], "not-a-list", [price, "y", price * 1.02]])
    step = price * frac
    if style == "single":
        return [round(price + step if long else price - step, 8)]
    return [round(price + step * m if long else price - step * m, 8) for m in (1, 2, 3)]


def part_d_live_fuzz(n=200):
    print(f"\n[D] {n} سفارشِ تصادفیِ زنده (خرید/فروش) با تنظیماتِ رندوم و نمادهای پسونددار")
    _, before = _get("/api/logs/stats") if False else (0, None)
    # شمارشِ خطاهای لاگ پیش از شروع
    err_before = _log_error_count()
    http_codes = {}
    forwarded_cnt = 0
    approved_cnt = 0
    blocked_cnt = 0
    rejected_cnt = 0
    invalid_cnt = 0
    price_cache = {}

    for i in range(n):
        internal = random.choice(list(DATA_SYMBOLS.keys()))
        klass, cands = DATA_SYMBOLS[internal]
        use_broker = random.random() < 0.6
        symbol = (random.choice(cands) + random.choice(SUFFIXES)) if use_broker else internal
        direction = random.choice(["BUY", "SELL"])
        tf = random.choice(TFS + [""])

        # قیمتِ مرجع (از کش یا یک بار واکشی برای تولیدِ SL/TP واقع‌گرایانه)
        if internal not in price_cache:
            _, sd = _get(f"/api/signal?symbol={internal}&tf=1h")
            price_cache[internal] = ((sd.get("data") or {}).get("price")) if isinstance(sd, dict) else None
        price = price_cache[internal]

        # حجم: شاملِ حالت‌های مرزی و نامعتبر
        vol_choice = random.random()
        if vol_choice < 0.1:
            volume = random.choice([0, -1, None, "abc"])   # نامعتبر → باید 400
        else:
            volume = random.choice([0.01, 0.02, 0.05, 0.1, 0.25, 0.3, 1.0, 0.007, 3.33, 2.0])

        # جهت: گاهی نامعتبر
        dir_field = direction
        if random.random() < 0.05:
            dir_field = random.choice(["HOLD", "", "CLOSE", "xyz"])

        long = direction == "BUY"
        entry = price
        sl = None
        if price:
            sl = round(price * (0.99 if long else 1.01), 8)
        tps = _rand_tps(price, direction, klass)

        payload = {"symbol": symbol, "direction": dir_field, "volume": volume,
                   "tf": tf, "robot_id": f"fuzz-{i}",
                   "platform": random.choice(["python", "mql5", "", "ea"])}
        if random.random() < 0.7 and entry is not None:
            payload["entry"] = entry
        if random.random() < 0.7 and sl is not None:
            payload["sl"] = sl
        if tps is not None:
            payload["tps"] = tps

        # گاهی نمادِ خالی برای آزمونِ اعتبارسنجی
        if random.random() < 0.03:
            payload["symbol"] = ""

        # --- تنظیماتِ رندومِ برنامه/ربات ---
        set_dispatch(
            news_filter_enabled=random.random() < 0.5,
            news_fail_closed=random.random() < 0.3,
            schedule_filter_enabled=random.random() < 0.3,
            schedule_fail_closed=random.random() < 0.3,
        )
        use_secret = random.random() < 0.12
        secret_val = "s3cr3t" if use_secret else ""
        set_robot(
            enabled=(random.random() < 0.92),
            filter_mode=random.choice(["internal", "ai", "both"]),
            require_direction_match=random.random() < 0.5,
            min_internal_score=random.choice([0, 5, 15, 30, 60]),
            min_ai_score=random.choice([0, 5, 15, 30]),
            auto_forward=random.random() < 0.85,
            respect_robot_volume=random.random() < 0.7,
            conflict_guard_enabled=random.random() < 0.6,
            dedupe_window_sec=random.choice([0, 0, 5, 30]),
            aggregate_window_sec=random.choice([0, 0, 1.0]),
            shared_secret=secret_val,
        )

        # هدرِ توکن: گاهی درست، گاهی غلط
        headers = {}
        if use_secret:
            headers["X-Robot-Secret"] = "s3cr3t" if random.random() < 0.5 else "WRONG"

        endpoint = random.choice(["/api/robot/order", "/api/robot/test"])
        is_test = endpoint.endswith("/test")
        code, body = _post(endpoint, payload, headers=headers)
        http_codes[code] = http_codes.get(code, 0) + 1

        it = f"#{i} {endpoint} sym={payload['symbol']!r} dir={dir_field!r} vol={volume!r}"

        # --- ناوردایی‌ها ---
        check(f"{it}: بدونِ خطای ۵xx/اتصال", code not in (-1,) and not (500 <= code < 600),
              {"code": code, "body": body, "payload": payload})
        check(f"{it}: پاسخِ JSON معتبر", isinstance(body, dict) and "_raw" not in body and "_exc" not in body,
              {"code": code, "body": body})

        if not isinstance(body, dict):
            continue

        # اعتبارسنجی: نماد/جهت/حجمِ نامعتبر → 400
        bad_input = (payload["symbol"] == "" or dir_field not in ("BUY", "SELL")
                     or (not isinstance(volume, (int, float)))
                     or (isinstance(volume, (int, float)) and volume <= 0))
        wrong_secret = use_secret and headers.get("X-Robot-Secret") == "WRONG"

        if wrong_secret:
            check(f"{it}: توکنِ غلط → 401", code == 401, {"code": code, "body": body})
            continue
        if bad_input:
            # ربات ممکن است غیرفعال باشد (200) — ولی اگر فعال است باید 400 بدهد
            check(f"{it}: ورودیِ نامعتبر → 400 یا ربات‌غیرفعال",
                  code == 400 or body.get("error"), {"code": code, "body": body})
            invalid_cnt += 1
            continue

        # ورودیِ سالم: باید 200 و ساختارِ استاندارد
        check(f"{it}: ورودیِ سالم → HTTP 200", code == 200, {"code": code, "body": body})
        if code == 200 and body.get("ok"):
            check(f"{it}: کلیدهای approved/forwarded موجود",
                  "approved" in body and "forwarded" in body, body)
            approved = body.get("approved")
            forwarded = body.get("forwarded")
            if forwarded:
                forwarded_cnt += 1
                check(f"{it}: forwarded ⇒ approved", approved is True, body)
                fr = body.get("forward") or {}
                check(f"{it}: forwarded ⇒ نتیجهٔ ارسال موجود", bool(fr), body)
                if is_test:
                    check(f"{it}: آزمایش ⇒ simulated=True (بدونِ معاملهٔ واقعی)",
                          body.get("simulated") is True, body)
                # جهتِ ارسال‌شده باید با درخواست یکی باشد
                fdir = (fr.get("direction") if isinstance(fr, dict) else None)
                want_internal = "LONG" if direction == "BUY" else "SHORT"
                if fdir:
                    check(f"{it}: جهتِ ارسال‌شده == درخواست", fdir == want_internal,
                          {"forward_dir": fdir, "want": want_internal, "body": body})
            elif approved:
                blocked_cnt += 1
            else:
                rejected_cnt += 1
            if approved:
                approved_cnt += 1

    err_after = _log_error_count()
    new_errs = err_after - err_before
    # خطاهای لاگ ممکن است ناشی از fail-open اخبار (warn) نباشند؛ فقط سطحِ error مهم است
    # اصلاح (FUZZ-FLAKY-001): هرسِ خودکارِ لاگِ سرور می‌تواند وسطِ اجرا شمارنده را
    # کاهش دهد (Δ منفی) — فقط «افزایش» یعنی خطای جدید.
    check(f"[D] بدونِ خطای غیرمنتظره در لاگِ سرور طیِ {n} معامله (Δerror={new_errs})",
          new_errs <= 0, _recent_errors())

    print(f"    → کدهای HTTP: {http_codes}")
    print(f"    → تأییدشده={approved_cnt} · ارسال‌شده(dry)={forwarded_cnt} · "
          f"تأیید‌ولی‌مسدود={blocked_cnt} · ردشده={rejected_cnt} · نامعتبر={invalid_cnt}")


def _log_error_count():
    code, body = _get("/api/logs?level=error&limit=2000")
    if code == 200 and isinstance(body, dict):
        d = body.get("data") or {}
        if isinstance(d.get("events"), list):
            return len(d["events"])
        if isinstance(d.get("stats"), dict):
            return d["stats"].get("error", 0)
    return 0


def _recent_errors():
    code, body = _get("/api/logs?level=error&limit=8")
    if code == 200 and isinstance(body, dict):
        return (body.get("data") or {}).get("events", body)
    return {"note": "لاگ در دسترس نیست"}


def restore_safe():
    set_dispatch(program_enabled=False, program_source="internal",
                 news_filter_enabled=True, news_fail_closed=False,
                 schedule_filter_enabled=True, schedule_fail_closed=False)
    set_robot(filter_mode="both", enabled=True, shared_secret="",
              require_direction_match=True, min_internal_score=15, min_ai_score=15,
              auto_forward=True, conflict_guard_enabled=True,
              respect_robot_volume=True, dedupe_window_sec=60.0,
              aggregate_window_sec=2.0)


def main():
    print("=" * 66)
    print(" آزمونِ فازیِ جامع — ۲۰۰ معاملهٔ خرید/فروش با دادهٔ واقعی")
    print("=" * 66)
    # سلامتِ سرور
    code, _ = _get("/api/symbols")
    if code != 200:
        print("سرور در دسترس نیست؛ ابتدا app.py را اجرا کنید.")
        sys.exit(2)
    part_a_plan_contract()
    part_b_symbol_resolution()
    part_c_volume_split()
    part_d_live_fuzz(200)
    restore_safe()

    print("\n" + "=" * 66)
    print(f"  نتیجه: {PASS} پاس · {FAIL} ناموفق · {len(WARN)} یادداشت")
    print("=" * 66)
    with open("fuzz_findings.json", "w", encoding="utf-8") as f:
        json.dump({"pass": PASS, "fail": FAIL, "findings": FINDINGS, "warn": WARN},
                  f, ensure_ascii=False, indent=2)
    print("  ایرادها در fuzz_findings.json ذخیره شد.")
    sys.exit(1 if FAIL else 0)


if __name__ == "__main__":
    main()
