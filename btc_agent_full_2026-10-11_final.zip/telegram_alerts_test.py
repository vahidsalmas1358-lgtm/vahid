# -*- coding: utf-8 -*-
"""تستِ عمیقِ «ارسالِ سیگنال به تلگرام» (و کانالِ ایمیل در حاشیه).

مسیرهای پوشش‌داده‌شده:
  ۱) واحدِ send_telegram: ساختِ URL/پارامترها، نبودِ توکن/چت، پاسخِ خطای API
     (توکنِ نامعتبر)، خطای شبکه.
  ۲) قالب‌بندیِ پیام (format_signal_text/html) با سیگنال‌های «واقعی» برای همهٔ
     نمادها در هر دو تایم‌فریم — بدونِ استثنا، با ورود/۳ حدِ سود/استاپ در
     جهت‌دارها و پیامِ انتظار در خنثی.
  ۳) endpoint دستی /api/alerts/send: بدونِ کانالِ فعال → 400؛ با تلگرامِ فعال →
     ارسالِ متنِ درست؛ شکستِ API → گزارشِ خطا.
  ۴) هشدارِ خودکارِ تغییرِ جهت در /api/signal (auto_alert): فقط هنگامِ «تغییرِ»
     جهت و نه در NEUTRAL/تکرار.
  ۵) امنیتِ تنظیمات: توکن در خروجیِ /api/alerts/config فاش نمی‌شود (ماسک).
  ۶) هشدارِ خبریِ news_alerts: متنِ خبر با تلگرامِ فعال ارسال می‌شود و در شکست،
     کلید نمی‌سوزد (تلاشِ مجدد).
"""
import os as _os_env; _os_env.environ.setdefault("BTC_AGENT_ALLOW_INSECURE_ROBOT", "1")  # محیط تست
import shutil
import time

import app
import alerts
import dispatch
import news_alerts

PASS = 0
FAIL = 0


def chk(name, cond, detail=""):
    global PASS, FAIL
    if cond:
        PASS += 1
    else:
        FAIL += 1
        print(f"   FAIL  {name} — {str(detail)[:220]}")


# محیط
for i, f in enumerate(("alerts_config.json", "dispatch_config.json")):
    try:
        shutil.copy(f, f"/tmp/tga_{i}.bak")
    except FileNotFoundError:
        pass

app.app.config["TESTING"] = True
client = app.app.test_client()

# ماکِ شبکهٔ تلگرام
CALLS = []


class _FakeResp:
    def __init__(self, j):
        self._j = j

    def json(self):
        return self._j


TG_RESPONSE = {"ok": True, "result": {"message_id": 1}}
TG_RAISE = None


def fake_post(url, timeout=None, data=None, **kw):
    CALLS.append({"url": url, "timeout": timeout, "data": dict(data or {})})
    if TG_RAISE:
        raise TG_RAISE
    return _FakeResp(TG_RESPONSE)


_real_post = alerts.requests.post
alerts.requests.post = fake_post

print("=" * 72)
print(" تستِ عمیقِ ارسالِ سیگنال به تلگرام")
print("=" * 72)

# ────────── ۱) واحدِ send_telegram ──────────
print("\n── ۱) تابعِ send_telegram ──")
alerts.save_config({"telegram": {"enabled": True, "bot_token": "", "chat_id": ""}})
r = alerts.send_telegram("سلام")
chk("بدونِ توکن/چت → خطای روشن و بدونِ تماسِ شبکه",
    r.get("ok") is False and "تنظیم نشده" in r.get("error", "") and not CALLS, r)

alerts.save_config({"telegram": {"enabled": True, "bot_token": "123:ABC", "chat_id": "777"}})
CALLS.clear()
r = alerts.send_telegram("پیام <b>تست</b>")
chk("ارسالِ موفق", r.get("ok") is True, r)
chk("URL درستِ Bot API", CALLS and CALLS[0]["url"] == "https://api.telegram.org/bot123:ABC/sendMessage",
    CALLS and CALLS[0]["url"])
chk("پارامترها: chat_id/text/parse_mode=HTML",
    CALLS and CALLS[0]["data"].get("chat_id") == "777"
    and CALLS[0]["data"].get("text") == "پیام <b>تست</b>"
    and CALLS[0]["data"].get("parse_mode") == "HTML", CALLS and CALLS[0]["data"])
chk("timeout تنظیم شده (هنگِ سرور ممنوع)", CALLS and (CALLS[0]["timeout"] or 0) > 0,
    CALLS and CALLS[0]["timeout"])

TG_RESPONSE = {"ok": False, "description": "Unauthorized"}
r = alerts.send_telegram("x")
chk("توکنِ نامعتبر (پاسخ ok:false) → خطا به کاربر برمی‌گردد",
    r.get("ok") is False and "Unauthorized" in r.get("error", ""), r)

TG_RESPONSE = {"ok": True}
TG_RAISE = ConnectionError("شبکه قطع است")
r = alerts.send_telegram("x")
chk("خطای شبکه → ok=False بدونِ کرش", r.get("ok") is False and "شبکه" in r.get("error", ""), r)
TG_RAISE = None

# ────────── ۲) قالب‌بندی با سیگنال‌های واقعی ──────────
print("\n── ۲) قالبِ پیام با سیگنال‌های واقعیِ همهٔ نمادها ──")
SYMS = ["BTC", "ETH", "SOL", "XAU", "XAG", "EURUSD", "GBPUSD", "USDJPY", "SPX", "NASDAQ"]
n_dir, n_neu = 0, 0
for sym in SYMS:
    for tf in ("15m", "1h"):
        try:
            with app.app.test_request_context():
                d, _i, _b = app._signal_for(sym, tf, with_ai=False)
        except Exception as e:  # noqa
            chk(f"{sym}/{tf}: دریافتِ سیگنال", False, e)
            continue
        try:
            txt = alerts.format_signal_text(d)
            html = alerts.format_signal_html(d)
        except Exception as e:  # noqa
            chk(f"{sym}/{tf}: قالب‌بندی بدونِ استثنا", False, repr(e))
            continue
        chk(f"{sym}/{tf}: سرصفحه شاملِ جفت‌ارز و تایم‌فریم",
            d["pair"] in txt and d["interval"] in txt, txt.splitlines()[0])
        if d["direction"] == "NEUTRAL":
            n_neu += 1
            chk(f"{sym}/{tf}: پیامِ خنثی «انتظار»", "خنثی" in txt and "منتظر" in txt, txt[-80:])
        else:
            n_dir += 1
            p = d["plan"]
            chk(f"{sym}/{tf}: ورود/۳TP/استاپ در متن",
                "ورود" in txt and txt.count("TP") >= 3 and "استاپ" in txt
                and str(p["take_profits"][0]["price"]) .rstrip("0").rstrip(".")[:6] in txt.replace(",", ""),
                txt)
            chk(f"{sym}/{tf}: HTML شاملِ ورود و استاپ", "ورود" in html and "استاپ" in html, html[:80])
print(f"   (جهت‌دار: {n_dir} · خنثی: {n_neu})")

# ────────── ۳) endpoint دستی /api/alerts/send ──────────
print("\n── ۳) /api/alerts/send ──")
alerts.save_config({"telegram": {"enabled": False}, "email": {"enabled": False},
                    "auto_alert": False})
r = client.post("/api/alerts/send", json={"symbol": "BTC", "tf": "15m"})
chk("هیچ کانالی فعال نیست → 400 با پیامِ روشن",
    r.status_code == 400 and "فعال نیست" in (r.get_json() or {}).get("error", ""),
    f"{r.status_code} {r.get_json()}")

alerts.save_config({"telegram": {"enabled": True, "bot_token": "123:ABC", "chat_id": "777"}})
CALLS.clear()
r = client.post("/api/alerts/send", json={"symbol": "ETH", "tf": "15m"})
d = r.get_json() or {}
chk("ارسالِ دستی موفق", r.status_code == 200 and d.get("ok") is True
    and (d.get("results") or {}).get("telegram", {}).get("ok") is True, d)
chk("متنِ ارسالی سیگنالِ همان نماد است",
    CALLS and "ETH" in CALLS[-1]["data"].get("text", ""), CALLS and CALLS[-1]["data"].get("text", "")[:60])

TG_RESPONSE = {"ok": False, "description": "chat not found"}
r = client.post("/api/alerts/send", json={"symbol": "BTC", "tf": "15m"})
d = r.get_json() or {}
chk("خطای تلگرام (chat not found) → ok=False و خطا در نتیجه",
    d.get("ok") is False and "chat not found" in str(d.get("results")), d)
TG_RESPONSE = {"ok": True}

# ────────── ۴) هشدارِ خودکارِ تغییرِ جهت ──────────
print("\n── ۴) auto_alert: فقط هنگامِ تغییرِ جهتِ غیرخنثی ──")
dispatch.save_config({"program_enabled": False})   # ارسالِ خودکار به MT5 قاطیِ تست نشود
alerts.save_config({"auto_alert": True,
                    "telegram": {"enabled": True, "bot_token": "123:ABC", "chat_id": "777"}})

BASE = {"pair": "ETH/USDT", "interval": "15m", "price": 2650.0, "total_score": 40.0,
        "generated_at": "2026-10-03 10:00 UTC", "symbol": "ETH",
        "internal_score": 40.0, "atr": 10.0, "confidence": 60.0,
        "technical": {"supports": [], "resistances": []},
        "plan": {"direction": "LONG", "entry": 2650.0, "stop_loss": 2640.0, "rr": 2.0,
                 "risk_per_unit": 10.0,
                 "take_profits": [{"price": 2660.0, "label": "TP1", "rr": 1.0, "close_pct": 40},
                                  {"price": 2670.0, "label": "TP2", "rr": 2.0, "close_pct": 30},
                                  {"price": 2680.0, "label": "TP3", "rr": 3.0, "close_pct": 30}]}}


def _fake_sig_factory(direction):
    d = dict(BASE)
    d["direction"] = direction
    d["plan"] = dict(BASE["plan"], direction=direction)
    return lambda *a, **k: (d, "ETH", None)


_real_sigfor = app._signal_for
app._last_dir.clear()
CALLS.clear()
app._signal_for = _fake_sig_factory("LONG")
client.get("/api/signal?symbol=ETH&tf=15m&ai=0")
chk("بارِ اول (سابقه‌ای نیست) → هشدار ارسال نمی‌شود", len(CALLS) == 0, len(CALLS))
client.get("/api/signal?symbol=ETH&tf=15m&ai=0")
chk("جهتِ تکراری → هشدار ارسال نمی‌شود", len(CALLS) == 0, len(CALLS))
app._signal_for = _fake_sig_factory("SHORT")
client.get("/api/signal?symbol=ETH&tf=15m&ai=0")
chk("تغییرِ جهت LONG→SHORT → دقیقاً یک هشدارِ تلگرام",
    len(CALLS) == 1 and "SHORT" in CALLS[0]["data"].get("text", ""), (len(CALLS), CALLS and CALLS[0]["data"].get("text", "")[:60]))
app._signal_for = _fake_sig_factory("NEUTRAL")
client.get("/api/signal?symbol=ETH&tf=15m&ai=0")
chk("تغییر به NEUTRAL → هشدار ارسال نمی‌شود", len(CALLS) == 1, len(CALLS))
app._signal_for = _real_sigfor

# ────────── ۵) امنیتِ تنظیمات ──────────
print("\n── ۵) ماسکِ توکن در تنظیماتِ عمومی ──")
r = client.get("/api/alerts/config")
raw = r.get_data(as_text=True)
d = (r.get_json() or {}).get("data") or {}
chk("توکن فاش نمی‌شود", "123:ABC" not in raw, raw[:120])
chk("پرچمِ bot_token_set=True", (d.get("telegram") or {}).get("bot_token_set") is True, d)

# ────────── ۶) هشدارِ خبریِ تلگرام (news_alerts) ──────────
print("\n── ۶) هشدارِ خبرِ مهمِ پیش‌رو ──")
import mt5_bridge as _mb
shutil.copy("mt5_config.json", "/tmp/tga_mt5.bak")
now = time.time()
fake_ev = {"title": "Non-Farm Payrolls", "country": "USD", "impact_rank": 3,
           "impact": "High", "ts": now + 10 * 60, "date": "2026-10-03T12:00:00+00:00"}
_real_fetch = news_alerts.news.fetch
news_alerts.news.fetch = lambda source=None, **k: {"ok": True, "events": [fake_ev]}
_mb.save_config({"news_alert_enabled": True, "news_alert_impact": "High",
                 "news_alert_before_min": 30, "news_autoclose_enabled": False})
news_alerts._alerted.clear()
CALLS.clear()
TG_RESPONSE = {"ok": False, "description": "boom"}   # اول شکست
news_alerts._run_once()
chk("خبر: تلاشِ ارسال انجام شد", len(CALLS) == 1, len(CALLS))
chk("خبر: پس از شکست، کلید نمی‌سوزد (NEWS-002)", not news_alerts._alerted, news_alerts._alerted)
TG_RESPONSE = {"ok": True}
news_alerts._run_once()
chk("خبر: تلاشِ مجدد موفق و متن شاملِ عنوانِ رویداد",
    len(CALLS) == 2 and "Non-Farm" in CALLS[-1]["data"].get("text", ""),
    (len(CALLS), CALLS and CALLS[-1]["data"].get("text", "")[:80]))
chk("خبر: پس از موفقیت، کلید ثبت شد (بدونِ اسپم)", len(news_alerts._alerted) == 1,
    news_alerts._alerted)
news_alerts._run_once()
chk("خبر: همان رویداد دوباره ارسال نمی‌شود", len(CALLS) == 2, len(CALLS))
news_alerts.news.fetch = _real_fetch
shutil.copy("/tmp/tga_mt5.bak", "mt5_config.json")

# بازگردانی
alerts.requests.post = _real_post
for i, f in enumerate(("alerts_config.json", "dispatch_config.json")):
    try:
        shutil.copy(f"/tmp/tga_{i}.bak", f)
    except FileNotFoundError:
        pass

print("\n" + "=" * 72)
print(f"  نتیجه: {PASS} پاس · {FAIL} ناموفق")
print("=" * 72)
raise SystemExit(1 if FAIL else 0)
