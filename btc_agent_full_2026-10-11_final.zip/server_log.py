"""لاگِ سمتِ سرور + پایشِ منابع (RAM/CPU).

یک بافرِ حلقوی (ring buffer) از رویدادهای سرور نگه می‌دارد و مصرفِ منابعِ
پردازه و سیستم را به‌دقت گزارش می‌کند. اگر psutil نصب باشد از آن استفاده می‌شود
(دقیق‌تر و چندسکویی)؛ در غیر این صورت روی لینوکس از /proc و در نهایت از
resource.getrusage به‌عنوان آخرین راهِ‌حل استفاده می‌کند.
"""
from __future__ import annotations

import os
import time
import threading
from collections import deque

# ── بافرِ لاگ ────────────────────────────────────────────────────────────────
_MAX = 400
_lock = threading.Lock()
_buf: deque = deque(maxlen=_MAX)
_seq = 0
_START = time.time()

_LEVELS = {"debug", "info", "success", "warn", "error"}


def log(level: str, cat: str, msg, detail: str = "") -> dict:
    """یک رویدادِ سرور را ثبت می‌کند و همان رکورد را برمی‌گرداند."""
    global _seq
    if level not in _LEVELS:
        level = "info"
    try:
        msg = str(msg) if msg is not None else ""
    except Exception:
        msg = ""
    try:
        if detail is None:
            detail = ""
        elif not isinstance(detail, str):
            detail = str(detail)
    except Exception:
        detail = ""
    with _lock:
        _seq += 1
        rec = {
            "id": _seq,
            "t": int(time.time() * 1000),
            "level": level,
            "cat": cat or "server",
            "msg": msg[:280],
            "detail": detail[:400],
        }
        _buf.append(rec)
    return rec


def get(since_id: int = 0, level: str = "", cat: str = "", limit: int = 1000) -> list:
    """رویدادهای بعد از since_id (اختیاری با فیلترِ سطح/دسته)."""
    with _lock:
        items = list(_buf)
    out = []
    for e in items:
        if since_id and e["id"] <= since_id:
            continue
        if level and e["level"] != level:
            continue
        if cat and e["cat"] != cat:
            continue
        out.append(e)
    if limit and len(out) > limit:
        out = out[-limit:]
    return out


def clear() -> None:
    with _lock:
        _buf.clear()
    log("info", "server", "لاگِ سرور پاک شد")


def purge_age(max_age_sec: float) -> int:
    """رویدادهای قدیمی‌تر از max_age_sec را حذف می‌کند و تعدادِ حذف‌شده را برمی‌گرداند."""
    if not max_age_sec or max_age_sec <= 0:
        return 0
    cutoff = int((time.time() - max_age_sec) * 1000)
    removed = 0
    with _lock:
        keep = [e for e in _buf if e["t"] >= cutoff]
        removed = len(_buf) - len(keep)
        if removed:
            _buf.clear()
            _buf.extend(keep)
    return removed


def stats() -> dict:
    with _lock:
        items = list(_buf)
    s = {"total": len(items), "debug": 0, "info": 0, "success": 0, "warn": 0, "error": 0}
    for e in items:
        if e["level"] in s:
            s[e["level"]] += 1
    return s


# ── پایشِ منابع ──────────────────────────────────────────────────────────────
_HAVE_PSUTIL = False
_PROC = None
try:  # مسیرِ ترجیحی: psutil (دقیق و چندسکویی)
    import psutil  # type: ignore

    _HAVE_PSUTIL = True
    _PROC = psutil.Process(os.getpid())
    try:
        _PROC.cpu_percent(None)      # مقداردهیِ اولیهٔ شمارندهٔ CPUِ پردازه
        psutil.cpu_percent(None)     # مقداردهیِ اولیهٔ شمارندهٔ CPUِ سیستم
    except Exception:
        pass
except Exception:
    _HAVE_PSUTIL = False


# --- fallback بدونِ psutil (لینوکس) ---
_CLK = 0
try:
    _CLK = os.sysconf("SC_CLK_TCK")  # tick در ثانیه
except Exception:
    _CLK = 100
_prev_proc_cpu = None   # (wall_time, utime+stime ticks)
_prev_sys_cpu = None     # (total, idle)


def _read_proc_rss_bytes() -> int:
    try:
        with open("/proc/self/statm") as f:
            pages = int(f.read().split()[1])
        return pages * os.sysconf("SC_PAGE_SIZE")
    except Exception:
        return 0


def _proc_cpu_percent_linux() -> float:
    global _prev_proc_cpu
    try:
        with open("/proc/self/stat") as f:
            parts = f.read().split()
        utime = int(parts[13]); stime = int(parts[14])
        ticks = utime + stime
        now = time.time()
        if _prev_proc_cpu is None:
            _prev_proc_cpu = (now, ticks)
            return 0.0
        dt = now - _prev_proc_cpu[0]
        dticks = ticks - _prev_proc_cpu[1]
        _prev_proc_cpu = (now, ticks)
        if dt <= 0:
            return 0.0
        return round((dticks / _CLK) / dt * 100.0, 1)
    except Exception:
        return 0.0


def _sys_mem_linux() -> tuple:
    """(total_bytes, available_bytes) از /proc/meminfo."""
    total = avail = 0
    try:
        with open("/proc/meminfo") as f:
            for line in f:
                if line.startswith("MemTotal:"):
                    total = int(line.split()[1]) * 1024
                elif line.startswith("MemAvailable:"):
                    avail = int(line.split()[1]) * 1024
                if total and avail:
                    break
    except Exception:
        pass
    return total, avail


def _sys_cpu_percent_linux() -> float:
    global _prev_sys_cpu
    try:
        with open("/proc/stat") as f:
            parts = f.readline().split()[1:]
        vals = [int(x) for x in parts]
        idle = vals[3] + (vals[4] if len(vals) > 4 else 0)
        total = sum(vals)
        if _prev_sys_cpu is None:
            _prev_sys_cpu = (total, idle)
            return 0.0
        dtotal = total - _prev_sys_cpu[0]
        didle = idle - _prev_sys_cpu[1]
        _prev_sys_cpu = (total, idle)
        if dtotal <= 0:
            return 0.0
        return round((1.0 - didle / dtotal) * 100.0, 1)
    except Exception:
        return 0.0


def resources() -> dict:
    """گزارشِ دقیقِ منابع؛ همهٔ حافظه‌ها بر حسبِ بایت، CPU بر حسبِ درصد."""
    out = {
        "ok": True,
        "backend": "psutil" if _HAVE_PSUTIL else "proc",
        "pid": os.getpid(),
        "uptime_sec": round(time.time() - _START, 1),
        "cpu_count": os.cpu_count() or 1,
    }
    if _HAVE_PSUTIL:
        try:
            with _PROC.oneshot():
                mem = _PROC.memory_info()
                out["proc_rss"] = int(getattr(mem, "rss", 0))
                out["proc_vms"] = int(getattr(mem, "vms", 0))
                out["proc_cpu"] = round(_PROC.cpu_percent(None), 1)
                try:
                    out["threads"] = _PROC.num_threads()
                except Exception:
                    out["threads"] = 0
                try:
                    out["proc_mem_pct"] = round(_PROC.memory_percent(), 1)
                except Exception:
                    out["proc_mem_pct"] = 0.0
            vm = psutil.virtual_memory()
            out["sys_mem_total"] = int(vm.total)
            out["sys_mem_used"] = int(vm.total - vm.available)
            out["sys_mem_pct"] = round(vm.percent, 1)
            out["sys_cpu"] = round(psutil.cpu_percent(None), 1)
            try:
                la = os.getloadavg()
                out["loadavg"] = [round(x, 2) for x in la]
            except Exception:
                pass
        except Exception as e:  # noqa
            out["ok"] = False
            out["error"] = str(e)[:200]
        return out
    # ── fallback: /proc ──
    rss = _read_proc_rss_bytes()
    out["proc_rss"] = rss
    out["proc_cpu"] = _proc_cpu_percent_linux()
    total, avail = _sys_mem_linux()
    out["sys_mem_total"] = total
    out["sys_mem_used"] = (total - avail) if total else 0
    out["sys_mem_pct"] = round((total - avail) / total * 100.0, 1) if total else 0.0
    out["proc_mem_pct"] = round(rss / total * 100.0, 1) if total else 0.0
    out["sys_cpu"] = _sys_cpu_percent_linux()
    try:
        out["threads"] = threading.active_count()
    except Exception:
        out["threads"] = 0
    try:
        out["loadavg"] = [round(x, 2) for x in os.getloadavg()]
    except Exception:
        pass
    if not total:
        # آخرین راهِ‌حل: max RSS از resource
        try:
            import resource
            ru = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
            # لینوکس KB، مک بایت
            out["proc_rss"] = out["proc_rss"] or (ru * 1024)
        except Exception:
            pass
    return out
