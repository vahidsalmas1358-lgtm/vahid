# -*- coding: utf-8 -*-
"""رگرسیونِ AI-NET-001 — «ارور 443 هنگام دریافت لیست مدل‌ها / اتصال به هوش مصنوعی».

ریشه: «443» کدِ خطای سرور نیست؛ پورتِ HTTPS در پیامِ خامِ requests است
(HTTPSConnectionPool(..., port=443)) یعنی اتصال از سیستمِ کاربر به سرویس‌دهنده
برقرار نشده (فیلترینگ/تحریم/نبودِ پروکسی). اصلاح: ترجمهٔ خطا به راهنمای روشن +
پشتیبانیِ پروکسی در همهٔ تماس‌های شبکه‌ایِ AI + فیلد پروکسی در UI.
"""
import os as _os_env; _os_env.environ.setdefault("BTC_AGENT_ALLOW_INSECURE_ROBOT", "1")  # محیط تست
import shutil

import requests

import app
import ai_bridge as ab

PASS = 0
FAIL = 0


def chk(name, cond, detail=""):
    global PASS, FAIL
    if cond:
        PASS += 1
    else:
        FAIL += 1
        print(f"   FAIL  {name} — {str(detail)[:220]}")


shutil.copy("ai_config.json", "/tmp/ainet.bak")
app.app.config["TESTING"] = True
client = app.app.test_client()

print("=" * 70)
print(" AI-NET-001: خطای «پورت 443» خوانا + پشتیبانی پروکسی")
print("=" * 70)

RAW443 = ("HTTPSConnectionPool(host='api.openai.com', port=443): Max retries exceeded "
          "with url: /v1/models (Caused by NewConnectionError('<urllib3.connection."
          "HTTPSConnection object>: Failed to establish a new connection: "
          "[Errno 101] Network is unreachable'))")

# ➊ ترجمهٔ خطاها
m = ab._net_err_fa(RAW443)
chk("پیام 443 → توضیحِ «کد خطای سرور نیست»", "کدِ خطای سرور» نیست" in m or "کدِ خطای سرور نیست" in m, m[:120])
chk("پیام 443 → راهنمای پروکسی", "پروکسی" in m, "")
chk("پیام 443 → پیشنهاد سرویس در دسترس/مدل محلی", "OpenRouter" in m and "Ollama" in m, "")
chk("جزئیات فنی حفظ می‌شود", "port=443" in m, "")
m = ab._net_err_fa("Missing dependencies for SOCKS support.")
chk("نبود PySocks → راهنمای نصب requests[socks]", "requests[socks]" in m, m[:80])
m = ab._net_err_fa("ProxyError: Cannot connect to proxy ...")
chk("خطای پروکسی → راهنمای بررسی پروکسی", "پروکسی" in m and "بررسی" in m, m[:80])
m = ab._net_err_fa("NameResolutionError: Failed to resolve 'api.example.com'")
chk("خطای DNS → راهنمای DNS", "DNS" in m, m[:80])
m = ab._net_err_fa("[401] Unauthorized")
chk("خطای غیرشبکه‌ای دست‌نخورده می‌ماند", m == "[401] Unauthorized", m)

# ➋ سیم‌کشی پروکسی: proxies باید به requests پاس شود
CAP = {}
_real_get = ab._session.get
_real_post = ab._session.post


def cap_get(url, **kw):
    CAP["get"] = kw
    raise requests.exceptions.ConnectionError(RAW443)


def cap_post(url, **kw):
    CAP["post"] = kw
    raise requests.exceptions.ConnectionError(RAW443)


ab._session.get = cap_get
ab._session.post = cap_post

ab.save_config({"proxy": "socks5h://127.0.0.1:1080", "base_url": "https://api.openai.com/v1",
                "model": "gpt-4o-mini"})
r = ab.list_models()
chk("list_models: پروکسی به requests پاس شد",
    CAP.get("get", {}).get("proxies") == {"http": "socks5h://127.0.0.1:1080",
                                          "https": "socks5h://127.0.0.1:1080"},
    CAP.get("get", {}).get("proxies"))
chk("list_models: خطای خوانا برمی‌گردد", r.get("ok") is False and "پروکسی" in r.get("error", ""),
    r.get("error", "")[:100])

r = ab.chat("سلام")
chk("chat: پروکسی پاس شد", CAP.get("post", {}).get("proxies", {}).get("https") ==
    "socks5h://127.0.0.1:1080", CAP.get("post", {}).get("proxies"))
chk("chat: خطای خوانا", r.get("ok") is False and "443" in r.get("error", ""), r.get("error", "")[:80])

CAP.clear()
evs = list(ab.chat_stream("سلام"))
chk("chat_stream: پروکسی پاس شد", CAP.get("post", {}).get("proxies", {}).get("https") ==
    "socks5h://127.0.0.1:1080", CAP.get("post", {}).get("proxies"))
chk("chat_stream: رویدادِ خطای خوانا", evs and "پروکسی" in (evs[-1].get("__error__") or ""),
    evs and str(evs[-1])[:100])

# بدونِ پروکسی → None (رفتارِ قبلی حفظ)
ab.save_config({"proxy": ""})
CAP.clear()
ab.list_models()
chk("بدونِ پروکسی → proxies=None", CAP.get("get", {}).get("proxies") is None,
    CAP.get("get", {}).get("proxies"))

ab._session.get = _real_get
ab._session.post = _real_post

# ➌ کانفیگ/API: ذخیره و نمایشِ پروکسی
r = client.post("/api/ai/config", json={"proxy": "http://127.0.0.1:8086"})
dj = (r.get_json() or {}).get("data") or {}
cfg1 = dj.get("config") or dj
chk("ذخیرهٔ پروکسی از API", r.status_code == 200 and cfg1.get("proxy") == "http://127.0.0.1:8086",
    cfg1.get("proxy"))
r = client.get("/api/ai/config")
dj = (r.get_json() or {}).get("data") or {}
cfg2 = dj.get("config") or dj
chk("public_config پروکسی را برمی‌گرداند", cfg2.get("proxy") == "http://127.0.0.1:8086",
    cfg2.get("proxy"))
chk("کلید API همچنان ماسک", "api_key" not in cfg2 and "api_key_set" in cfg2, list(cfg2)[:9])

# ➍ UI
ui = open("static/index.html", encoding="utf-8").read()
chk("UI: فیلد پروکسی", 'id="ai_proxy"' in ui, "")
chk("UI: راهنمای «port=443»", "port=443" in ui and "کدِ خطای سرور نیست" in ui, "")
chk("UI: aiCollect پروکسی را می‌فرستد", 'proxy:($("#ai_proxy")' in ui, "")

shutil.copy("/tmp/ainet.bak", "ai_config.json")
print("\n" + "=" * 70)
print(f"  نتیجه: {PASS} پاس · {FAIL} ناموفق")
print("=" * 70)
raise SystemExit(1 if FAIL else 0)
