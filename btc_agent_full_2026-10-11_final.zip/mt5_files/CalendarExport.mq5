//+------------------------------------------------------------------+
//|                                              CalendarExport.mq5   |
//|   سرویسِ صدور «تقویمِ اقتصادیِ خودِ متاتریدر ۵» به فایلِ JSON       |
//|                                                                  |
//|   چه می‌کند؟                                                       |
//|   توابعِ تقویمِ MQL5 (CalendarValueHistory/…) را می‌خواند و رویدادها |
//|   را در فایلِ  Common\Files\mt5_calendar.json  می‌ریزد تا برنامهٔ    |
//|   تحلیلِ پایتون آن را به‌عنوانِ «منبعِ اصلیِ اخبار» بخواند (به‌جای    |
//|   Forex Factory / TradingView).                                   |
//|                                                                  |
//|   نصب و اجرا:                                                      |
//|   ۱) این فایل را در MetaEditor باز کنید (منوی MT5 → IDE).          |
//|   ۲) F7 بزنید تا کامپایل شود (CalendarExport.ex5 ساخته می‌شود).    |
//|   ۳) در پنجرهٔ Navigator زیرِ «Services» روی CalendarExport         |
//|      راست‌کلیک → Add Service → OK. سرویس در پس‌زمینه اجرا می‌شود.   |
//|   ۴) همین بس! هر ۵ دقیقه فایلِ تقویم به‌روز می‌شود.                  |
//|                                                                  |
//|   نکته: توابعِ تقویم فقط با اتصالِ زندهٔ ترمینال کار می‌کنند و در    |
//|   Strategy Tester خروجی نمی‌دهند.                                  |
//+------------------------------------------------------------------+
#property service
#property copyright "MultiMarket Analysis Agent"
#property version   "1.20"

// ── ورودی‌ها (قابلِ تنظیم هنگامِ افزودنِ سرویس) ──
input int    RefreshMinutes = 5;      // فاصلهٔ به‌روزرسانی (دقیقه)
input int    DaysBack       = 7;      // چند روزِ گذشته
input int    DaysAhead      = 30;     // چند روزِ آینده
input string FileName       = "mt5_calendar.json"; // نامِ فایل در Common\Files
input string Countries      = "US,EU,GB,JP,AU,CA,CH,NZ,CN,DE,FR"; // کشورها (خالی = همه)

//+------------------------------------------------------------------+
//| نگاشتِ اهمیت → برچسب و رتبه (سازگار با برنامهٔ پایتون)             |
//+------------------------------------------------------------------+
void ImpactToText(ENUM_CALENDAR_EVENT_IMPORTANCE imp, string &label, int &rank)
{
   switch(imp)
   {
      case CALENDAR_IMPORTANCE_HIGH:     label="High";    rank=3; break;
      case CALENDAR_IMPORTANCE_MODERATE: label="Medium";  rank=2; break;
      case CALENDAR_IMPORTANCE_LOW:      label="Low";     rank=1; break;
      default:                           label="Holiday"; rank=0; break;
   }
}

//+------------------------------------------------------------------+
//| فرمت‌کردنِ مقدارِ عددیِ رویداد (با احترام به واحد/ضریب/اعشار)        |
//+------------------------------------------------------------------+
string FormatValue(double v, const MqlCalendarEvent &ev)
{
   if(!MathIsValidNumber(v))
      return "";
   // ضریب (هزار/میلیون/…)
   string suffix="";
   switch(ev.multiplier)
   {
      case CALENDAR_MULTIPLIER_THOUSANDS: suffix="K"; break;
      case CALENDAR_MULTIPLIER_MILLIONS:  suffix="M"; break;
      case CALENDAR_MULTIPLIER_BILLIONS:  suffix="B"; break;
      case CALENDAR_MULTIPLIER_TRILLIONS: suffix="T"; break;
      default: suffix=""; break;
   }
   string s=DoubleToString(v, ev.digits);
   s=s+suffix;
   // واحد (درصد و…)
   if(ev.unit==CALENDAR_UNIT_PERCENT) s=s+"%";
   return s;
}

//+------------------------------------------------------------------+
//| فرارِ کاراکترهای ویژه برای رشتهٔ JSON                              |
//+------------------------------------------------------------------+
string JsonEscape(string s)
{
   string out="";
   int n=StringLen(s);
   for(int i=0;i<n;i++)
   {
      ushort c=StringGetCharacter(s,i);
      if(c=='"')       out+="\\\"";
      else if(c=='\\') out+="\\\\";
      else if(c=='\n') out+="\\n";
      else if(c=='\r') out+="\\r";
      else if(c=='\t') out+="\\t";
      else             out+=ShortToString(c);
   }
   return out;
}

//+------------------------------------------------------------------+
//| کمکی‌های امن (OP5-MQL-18) — عددِ محدود و فرارِ سخت‌گیرانهٔ JSON      |
//+------------------------------------------------------------------+
bool IsFiniteNumber(const double v)
{
   return(MathIsValidNumber(v) && v!=DBL_MAX && v!=-DBL_MAX);
}

string JsonEscapeStrict(const string s)
{
   string out="";
   for(int i=0;i<StringLen(s);i++)
   {
      ushort c=StringGetCharacter(s,i);
      if(c=='\\') out+="\\\\";
      else if(c=='"') out+="\\\"";
      else if(c=='\b') out+="\\b";
      else if(c=='\f') out+="\\f";
      else if(c=='\n') out+="\\n";
      else if(c=='\r') out+="\\r";
      else if(c=='\t') out+="\\t";
      else if(c<0x20) out+=StringFormat("\\u%04X",(int)c);
      else out+=ShortToString(c);
   }
   return out;
}

//+------------------------------------------------------------------+
//| تجزیهٔ لیستِ کشورها با trim و حذفِ تکراری‌ها (OP5-MQL-23)           |
//+------------------------------------------------------------------+
int ParseCountries(const string csv,string &out[])
{
   ArrayResize(out,0);
   if(csv==NULL || csv=="") return 0;
   string raw[];
   int n=StringSplit(csv,',',raw);
   int count=0;
   for(int i=0;i<n;i++)
   {
      string c=raw[i]; StringTrimLeft(c); StringTrimRight(c);
      StringToUpper(c);
      if(c=="") continue;
      bool seen=false;
      for(int j=0;j<count;j++) if(out[j]==c) { seen=true; break; }
      if(!seen) { ArrayResize(out,count+1); out[count++]=c; }
   }
   return count;
}

//+------------------------------------------------------------------+
//| پنجرهٔ زمانی + offset (OP5-MQL-21) — fail-closed اگر ساعت نامعتبر  |
//+------------------------------------------------------------------+
bool GetCalendarWindow(datetime &from,datetime &to,long &offset)
{
   datetime server=TimeTradeServer();
   datetime gmt=TimeGMT();
   if(server<=0 || gmt<=0) return false;
   from=server-(datetime)MathMax(0,DaysBack)*86400;
   to=server+(datetime)MathMax(0,DaysAhead)*86400;
   offset=(long)gmt-(long)server;
   return to>from;
}

//+------------------------------------------------------------------+
//| نوشتنِ اتمیک (نوشتن در .tmp و rename) — OP5-MQL-22                |
//+------------------------------------------------------------------+
bool WriteCalendarAtomic(const string file_name,const string json)
{
   string tmp=file_name+".tmp";
   ResetLastError();
   int h=FileOpen(tmp,FILE_WRITE|FILE_TXT|FILE_ANSI|FILE_COMMON,'\t',CP_UTF8);
   if(h==INVALID_HANDLE)
   {
      PrintFormat("Calendar temp open failed: %s err=%d",tmp,GetLastError());
      return false;
   }
   bool ok=(FileWriteString(h,json)==StringLen(json));
   FileFlush(h);
   FileClose(h);
   if(!ok) { FileDelete(tmp,FILE_COMMON); return false; }
   if(FileIsExist(file_name,FILE_COMMON)) FileDelete(file_name,FILE_COMMON);
   if(!FileMove(tmp,FILE_COMMON,file_name,FILE_COMMON))
   {
      PrintFormat("Calendar atomic move failed err=%d",GetLastError());
      FileDelete(tmp,FILE_COMMON);
      return false;
   }
   return true;
}

string SafeBaseName(const string name)
{
   // فقط basename مجاز است (بدونِ مسیر) — OP5-MQL-22
   int cut=0;
   for(int i=0;i<StringLen(name);i++)
   {
      ushort c=StringGetCharacter(name,i);
      if(c=='/' || c=='\\') cut=i+1;
   }
   return StringSubstr(name,cut);
}

bool ValidateInputs()
{
   if(SafeBaseName(FileName)=="" || StringFind(FileName,"..")>=0) return false;
   if(RefreshMinutes<1) return false;
   if(DaysBack<0 || DaysAhead<0) return false;
   return true;
}

//+------------------------------------------------------------------+
//| ساخت و نوشتنِ فایلِ تقویم                                          |
//+------------------------------------------------------------------+
bool BuildAndWrite()
{
   // OP5-MQL-21: پنجرهٔ زمانی و offset فقط با ساعتِ معتبر (fail-closed).
   // اگر ساعت/اتصال در دسترس نباشد، فایلِ قبلی دست‌نخورده می‌ماند.
   datetime from=0, to=0;
   long     gmt_offset=0;
   if(!GetCalendarWindow(from,to,gmt_offset))
   {
      Print("CalendarExport: server/GMT clock unavailable — export skipped (previous file kept).");
      return false;
   }

   // کشورهای موردنظر (trim + حذفِ تکراری — OP5-MQL-23)
   string cc[];
   int ccn = ParseCountries(Countries, cc);

   string body = "";
   int total = 0;
   // OP5-MQL-23: چاپِ هر رویداد فقط یک‌بار (کلید = event_id + زمان)
   string seen_keys[];

   // اگر لیستِ کشور تهی بود، یک بار با فیلترِ NULL همهٔ رویدادها را می‌گیریم
   int passes = (ccn > 0) ? ccn : 1;

   for(int p=0; p<passes; p++)
   {
      string country_code = (ccn > 0) ? cc[p] : NULL;
      MqlCalendarValue values[];
      int got = CalendarValueHistory(values, from, to, country_code, NULL);
      if(got <= 0)
         continue;

      for(int i=0; i<got; i++)
      {
         MqlCalendarEvent ev;
         if(!CalendarEventById(values[i].event_id, ev))
            continue;
         MqlCalendarCountry cn;
         CalendarCountryById(ev.country_id, cn);

         string label; int rank;
         ImpactToText(ev.importance, label, rank);

         long utc_ts = (long)values[i].time + gmt_offset;

         string key=IntegerToString((long)values[i].event_id)+"@"+IntegerToString((long)values[i].time);
         bool dup=false;
         for(int k=0;k<ArraySize(seen_keys);k++) if(seen_keys[k]==key){ dup=true; break; }
         if(dup) continue;
         int sn=ArraySize(seen_keys);
         ArrayResize(seen_keys,sn+1); seen_keys[sn]=key;

         string fc = FormatValue(values[i].GetForecastValue(), ev);
         string pv = FormatValue(values[i].GetPreviousValue(), ev);
         string ac = FormatValue(values[i].GetActualValue(),   ev);

         if(total > 0) body += ",";
         body += "\n  {";
         body += "\"title\":\""    + JsonEscapeStrict(ev.name)     + "\",";
         body += "\"currency\":\"" + JsonEscapeStrict(cn.currency) + "\",";
         body += "\"country\":\""  + JsonEscapeStrict(cn.code)     + "\",";
         body += "\"impact\":\""   + JsonEscapeStrict(label)       + "\",";
         body += "\"impact_rank\":"+ IntegerToString(rank)         + ",";
         body += "\"forecast\":\"" + JsonEscapeStrict(fc)          + "\",";
         body += "\"previous\":\"" + JsonEscapeStrict(pv)          + "\",";
         body += "\"actual\":\""   + JsonEscapeStrict(ac)          + "\",";
         body += "\"ts\":"         + IntegerToString(utc_ts);
         body += "}";
         total++;
      }
   }

   long now_utc = (long)TimeGMT();
   string json = "{\n";
   json += "\"generated_ts\":" + IntegerToString(now_utc) + ",\n";
   json += "\"source\":\"MetaTrader5\",\n";
   json += "\"count\":" + IntegerToString(total) + ",\n";
   json += "\"events\":[" + body + "\n]\n}\n";

   // OP5-MQL-22: نوشتنِ اتمیک — خوانندهٔ پایتون هرگز فایلِ نیمه‌نوشته نمی‌بیند.
   // FILE_COMMON → پوشهٔ مشترکِ همهٔ ترمینال‌ها؛ CP_UTF8 → خروجی حتماً UTF-8 باشد.
   string fname=SafeBaseName(FileName);
   if(!WriteCalendarAtomic(fname,json))
   {
      PrintFormat("CalendarExport: نوشتنِ فایل ناموفق بود (%s) — فایلِ قبلی حفظ شد.", fname);
      return false;
   }
   PrintFormat("CalendarExport: %d رویداد در %s نوشته شد.", total, fname);
   return true;
}

//+------------------------------------------------------------------+
//| نقطهٔ ورودِ سرویس                                                  |
//+------------------------------------------------------------------+
void OnStart()
{
   if(!ValidateInputs())
   {
      Print("CalendarExport: ورودی‌های نامعتبر (نامِ فایل/بازه). سرویس متوقف شد.");
      return;
   }
   int wait_ms = MathMax(1, RefreshMinutes) * 60 * 1000;
   // چند تلاشِ اولیه چون پس از استارتِ ترمینال، تقویم بلافاصله آماده نیست
   while(!IsStopped())
   {
      bool ok = BuildAndWrite();
      if(!ok)
      {
         // اگر داده هنوز آماده نبود، کمی صبر و دوباره
         for(int s=0; s<30 && !IsStopped(); s++) Sleep(1000);
      }
      // خوابِ اصلی تا دورِ بعد (با احترام به توقفِ سرویس)
      int slept = 0;
      while(slept < wait_ms && !IsStopped())
      {
         Sleep(1000);
         slept += 1000;
      }
   }
}
//+------------------------------------------------------------------+
