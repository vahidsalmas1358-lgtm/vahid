# -*- coding: utf-8 -*-
"""ممیزی جامع: ۱۰۰ معاملهٔ خرید/فروش روی نمادهای «تصادفی» با دادهٔ واقعی +
بررسی و دیباگِ عمیقِ همهٔ تب‌ها و منوهای برنامه.

فاز ۱ — همهٔ ۱۸ تب/منو از مسیرِ APIهای پشتیبانشان روی سرورِ زنده (ساختار + صحت).
فاز ۲ — ۱۰۰ معاملهٔ تصادفی (نماد/تایم‌فریم/جهت/حجم/حالتِ TP/اجرا/حالتِ ریسک تصادفی)
         با نقشه‌های «واقعی» از سرورِ زنده روی بروکرِ شبیه‌سازی‌شده، با چک‌های کامل:
         لگ‌بندی، جمعِ حجم، سمت/گِردشدنِ SL/TP، stops_level، فرمولِ لاتِ ریسکی،
         سفارش‌های معلق، و منیجر (پارشیال+بریک‌ایون) روی نمونه‌ها.
فاز ۳ — مسیرهای ارسالِ زنده (dry_run دستی + سفارشِ ربات) با صداقتِ simulated.

Seed تصادفی چاپ می‌شود تا هر اجرا قابلِ بازتولید باشد.
"""
import os as _os_env; _os_env.environ.setdefault("BTC_AGENT_ALLOW_INSECURE_ROBOT", "1")  # محیط تست
import json
import random
import shutil
import time

import requests

BASE = "http://localhost:8000"
SEED = int(time.time()) % 100000
random.seed(SEED)
PASS = 0
FAIL = 0
FAILURES = []


def chk(name, cond, detail=""):
    global PASS, FAIL
    if cond:
        PASS += 1
    else:
        FAIL += 1
        FAILURES.append({"name": name, "detail": str(detail)[:250]})
        print(f"   FAIL  {name} — {str(detail)[:160]}")


def get(path, **params):
    r = requests.get(BASE + path, params=params, timeout=180)
    try:
        return r.status_code, r.json()
    except Exception:
        return r.status_code, {"_raw": r.text[:200]}


def post(path, body):
    r = requests.post(BASE + path, json=body, timeout=180)
    try:
        return r.status_code, r.json()
    except Exception:
        return r.status_code, {"_raw": r.text[:200]}


def okd(d):
    return (d or {}).get("data") or {}


print("=" * 74)
print(f" ممیزی جامع برنامه — ۱۰۰ معاملهٔ تصادفی با دادهٔ واقعی · seed={SEED}")
print("=" * 74)

# ═══════════════ فاز ۱: همهٔ تب‌ها و منوها ═══════════════
print("\n── فاز ۱: بررسی همهٔ تب‌ها/منوها از مسیر API ──")

st, _ = get("/")
chk("صفحهٔ اصلی (قالب داشبورد) 200", st == 200, st)

st, d = get("/api/symbols")
syms = (d or {}).get("data") or []
chk("منوی نماد: /api/symbols", st == 200 and len(syms) >= 10, len(syms))

# تب ۱/۲ — داشبورد داخلی + داشبورد AI
st, d = get("/api/signal", symbol="BTC", tf="15m", ai=0)
sig = okd(d)
chk("تب داشبورد: سیگنال BTC سالم", st == 200 and sig.get("price", 0) > 0, st)
st, d = get("/api/signal", symbol="ETH", tf="1h", ai=1)
sig2 = okd(d)
chk("تب داشبورد AI: ai=1 بدون کرش (ai.used گزارش می‌شود)",
    st == 200 and isinstance(sig2.get("ai"), dict) and "used" in sig2["ai"], str(sig2.get("ai"))[:80])

# تب ۳ — چند تایم‌فریم
st, d = get("/api/mtf", symbol="BTC")
chk("تب چندتایم‌فریم: /api/mtf", st == 200 and (d or {}).get("ok", True), st)

# تب ۴ — اسکنر
st, d = get("/api/scan", tf="15m")
sd = okd(d)
chk("تب اسکنر: پویش بدون خطا", st == 200 and (sd.get("count") or 0) >= 5 and not sd.get("errors"),
    f"count={sd.get('count')} errors={sd.get('errors')}")

# تب ۵ — مقایسه
st, d = get("/api/compare", symbols="BTC,ETH,XAU")
chk("تب مقایسه: /api/compare", st == 200 and (d or {}).get("ok", True), st)

# تب ۶ — بک‌تست
st, d = get("/api/backtest", symbol="BTC", tf="1h", bars=300, threshold=20, sl=1.5, tp=3.0)
bt = okd(d)
chk("تب بک‌تست: اجرا و آمار", st == 200 and (d or {}).get("ok") and "trades" in json.dumps(bt)[:4000],
    str(d)[:120])

# تب ۷ — بهینه‌سازی
st, d = get("/api/optimize", symbol="BTC", tf="1h", bars=300, metric="net_r", short=1)
op = okd(d)
chk("تب بهینه‌سازی: بهترین ترکیب برمی‌گردد", st == 200 and (d or {}).get("ok") and op.get("best"),
    str(d)[:120])

# تب ۸ — تاریخچه
st, d = get("/api/history")
_h = (d or {}).get("data")
chk("تب تاریخچه: خواندن (لیست)", st == 200 and isinstance(_h, (list, dict)), type(_h).__name__)

# تب ۹ — تحلیل عملکرد
st, d = get("/api/analytics")
chk("تب تحلیل عملکرد: /api/analytics", st == 200 and (d or {}).get("ok", True), st)

# تب ۱۰ — هشدارها
st, d = get("/api/alerts/config")
ac = okd(d)
chk("تب هشدارها: تنظیمات + ماسکِ توکن",
    st == 200 and "telegram" in ac
    and '"bot_token":' not in json.dumps(ac)
    and "bot_token_set" in json.dumps(ac), list(ac))

# تب ۱۱ — اخبار
st, d = get("/api/news")
chk("تب اخبار: /api/news", st == 200, st)
st, d = get("/api/news/scheduler")
chk("تب اخبار: زمان‌بند", st == 200, st)
st, d = get("/api/news/check", symbol="XAU")
chk("تب اخبار: news/check", st == 200, st)

# تب ۱۲ — متاتریدر ۵
for p, nm in (("/api/mt5/status", "status"), ("/api/mt5/config", "config"),
              ("/api/mt5/marketwatch", "marketwatch"), ("/api/mt5/positions", "positions"),
              ("/api/mt5/log", "log"), ("/api/mt5/data/list", "data/list")):
    st, d = get(p)
    chk(f"تب متاتریدر: {nm}", st == 200, f"{p} → {st}")
st, d = get("/api/mt5/manager")
chk("تب متاتریدر: وضعیت منیجر", st == 200, st)
st, d = get("/api/mt5/resolve", symbol="BTC")
chk("تب متاتریدر: resolve (بدون MT5 خطای روشن)", st == 200, st)

# تب ۱۳ — روش ارسال سیگنال
st, d = get("/api/dispatch/config")
chk("تب روش ارسال: تنظیمات", st == 200 and "program_source" in json.dumps(okd(d)), st)
st, d = get("/api/dispatch/live", tf="15m")
chk("تب روش ارسال: نمای زنده", st == 200 and (d or {}).get("ok", True), st)

# تب ۱۴ — هوش مصنوعی
st, d = get("/api/ai/config")
chk("تب هوش مصنوعی: تنظیمات", st == 200, st)
st, d = get("/api/ai/logs")
chk("تب هوش مصنوعی: لاگ", st == 200, st)

# تب ۱۵ — سیگنال‌های ورودی ربات‌ها
st, d = get("/api/robot/config")
rc = okd(d)
chk("تب ربات‌ها: config+stats (آمار جدا از آزمایشی)",
    st == 200 and "stats" in rc and "tests" in (rc.get("stats") or {}), list(rc.get("stats") or {}))
st, d = get("/api/robot/log")
chk("تب ربات‌ها: گزارش", st == 200, st)

# تب ۱۶ — تزریق کد
st, d = post("/api/inject", {"filename": "bot.py",
                             "content": "import time\nwhile True:\n    time.sleep(1)\n"})
chk("تب تزریق: فایل پایتونی تزریق می‌شود",
    st == 200 and (d or {}).get("ok") and (d or {}).get("patched"), str(d)[:120])
st, d = post("/api/inject", {"filename": "x.txt", "content": "hi"})
chk("تب تزریق: پسوند نامعتبر رد می‌شود", st == 400, st)

# تب ۱۷ — ساعات کار سرور
st, d = get("/api/server/time")
sv = okd(d)
chk("تب ساعات سرور: server/time", st == 200 and "server" in sv and "program_active" in sv,
    list(sv)[:6])
st, d = get("/api/schedule/config")
chk("تب ساعات سرور: schedule/config", st == 200, st)

# تب ۱۸ — لاگ رویدادها + منوی وضعیت
st, d = get("/api/logs")
chk("تب لاگ: /api/logs", st == 200, st)
st, d = get("/api/system/stats")
chk("منوی وضعیت: system/stats", st == 200, st)

# ═══════════════ فاز ۲: ۱۰۰ معاملهٔ تصادفی با دادهٔ واقعی ═══════════════
print("\n── فاز ۲: ۱۰۰ معاملهٔ تصادفی (بروکر شبیه‌سازی‌شده + نقشه‌های واقعی) ──")
import engine  # noqa: E402
import mock_mt5  # noqa: E402
import mt5_bridge as mb  # noqa: E402
import market_hours as mh  # noqa: E402

for i, f in enumerate(("mt5_config.json", "dispatch_config.json", "robot_config.json")):
    shutil.copy(f, f"/tmp/full100_{i}.bak")

PROFILES = {
    "BTC":    ("BITCOIN",     2, 0.01,    0.01, 0.01, 30, 1.0,   0.01),
    "ETH":    ("ETHUSD.z",    2, 0.01,    0.10, 0.10, 20, 1.0,   0.01),
    "SOL":    ("SOLUSD",      3, 0.001,   0.01, 0.01, 20, 1.0,   0.001),
    "XAU":    ("XAUUSD.m",    2, 0.01,    0.01, 0.01, 30, 1.0,   0.01),
    "XAG":    ("XAGUSD.r",    3, 0.001,   0.01, 0.01, 30, 5.0,   0.001),
    "EURUSD": ("EURUSD.r",    5, 0.00001, 0.01, 0.01, 10, 1.0,   0.00001),
    "GBPUSD": ("GBPUSDmicro", 5, 0.00001, 0.01, 0.01, 10, 1.0,   0.00001),
    "USDJPY": ("USDJPY.pro",  3, 0.001,   0.01, 0.01, 10, 0.65,  0.001),
    "SPX":    ("US500",       1, 0.1,     0.10, 0.10, 50, 1.0,   0.1),
    "NASDAQ": ("USTEC",       1, 0.1,     0.10, 0.10, 50, 1.0,   0.1),
}
TFS = ["15m", "1h"]

# دادهٔ واقعی: یک بار برای هر (نماد،تایم‌فریم) از سرورِ زنده
REAL = {}
for sym in PROFILES:
    for tf in TFS:
        st, d = get("/api/signal", symbol=sym, tf=tf, ai=0)
        data = okd(d)
        if st == 200 and data.get("price"):
            REAL[(sym, tf)] = data
chk("دادهٔ واقعی برای همهٔ ۲۰ ترکیب نماد/تایم‌فریم", len(REAL) == 20, len(REAL))


def plan_for(data, direction):
    if data.get("direction") == direction and (data.get("plan") or {}).get("take_profits"):
        return data["plan"]
    tech = data["technical"]
    return engine.build_trade_plan(
        direction, data["price"], data["atr"], tech["supports"], tech["resistances"],
        abs(data.get("total_score") or 20), engine._dec(data["price"]),
        fib=tech.get("fibonacci"), extra_sup=tech.get("conf_supports"),
        extra_res=tech.get("conf_resistances"))


# بروکرِ شبیه‌سازی‌شده
BAL = 500_000.0
b = mock_mt5.Broker(balance=BAL)
for sym, (bsym, dgt, pt, vmin, vstep, stops, tv, ts) in PROFILES.items():
    px = REAL[(sym, "15m")]["price"] if (sym, "15m") in REAL else 100.0
    b.add_symbol(bsym, digits=dgt, point=pt, volume_min=vmin, volume_step=vstep,
                 volume_max=10000.0, stops_level=stops, tick_value=tv, tick_size=ts,
                 price=round(px, dgt))
for k in dir(mock_mt5):
    if k.isupper():
        setattr(b, k, getattr(mock_mt5, k))
mb.mt5 = b
mb.MT5_AVAILABLE = True
mb._conn.update(connected=True, error=None, since=1.0)
_real_mh = mh.status
mh.status = lambda s, now=None: {"open": True, "state": "open", "reason": ""}

mb.save_config({"market_hours_guard": False, "news_filter_enabled": False,
                "max_daily_trades": 0, "max_daily_risk_pct": 0, "allowed_symbols": [],
                "manage_positions": False, "magic": 532025, "comment": "Rnd100",
                "partial_fractions": [0.5, 0.3], "breakeven_enabled": True,
                "breakeven_r": 1.0, "breakeven_buffer_pts": 5,
                "trailing_enabled": True, "trailing_points": 300, "trailing_start_r": 1.0,
                "risk_pct": 0.5,
                "symbol_map": {k: v[0] for k, v in PROFILES.items()}})

executed = 0
for n in range(1, 101):
    sym = random.choice(list(PROFILES))
    tf = random.choice(TFS)
    data = REAL[(sym, tf)]
    bsym, dgt, pt, vmin, vstep, stops, tv, ts = PROFILES[sym]
    info = b.symbol_info(bsym)
    direction = random.choice(["LONG", "SHORT"])
    plan = plan_for(data, direction)
    tp_mode = random.choice(["split", "single", "none", "partial"])
    execution = "pending" if random.random() < 0.15 else "market"
    risk_mode = "risk_pct" if random.random() < 0.25 else "fixed"
    vol = random.choice([vmin, vmin * 3, round(vmin * 10, 2), 0.5, 1.0])
    vol = max(vol, vmin)
    mb.save_config({"tp_mode": tp_mode, "execution": execution, "risk_mode": risk_mode})
    b.set_price(bsym, round(float(plan["entry"]), dgt))
    pend0, pos0 = len(b.pending), len(b.positions)
    res = mb.send_order(sym, direction, plan, volume=(None if risk_mode == "risk_pct" else vol))
    tag = f"#{n} {bsym} {direction} {tp_mode}/{execution}/{risk_mode}"
    if not res.get("ok"):
        chk(f"{tag}: ارسال موفق", False, res.get("error"))
        continue
    executed += 1
    legs = res.get("legs") or []
    tot = sum(float(l.get("volume") or 0) for l in legs)
    if tp_mode == "split":
        splittable = mb._floor_step(tot / 3.0, vstep) >= vmin
        chk(f"{tag}: تعداد لگ (split)", len(legs) == (3 if splittable else len(legs))
            and (splittable is False or len(legs) == 3) and 1 <= len(legs) <= 3,
            f"legs={len(legs)} tot={tot}")
    else:
        chk(f"{tag}: تعداد لگ", len(legs) == 1, len(legs))
    nexp = len(legs)
    chk(f"{tag}: هم‌ترازی حجم با گام", abs(tot / vstep - round(tot / vstep)) < 1e-6, tot)
    if risk_mode == "risk_pct":
        sl_dist = abs(float(plan["entry"]) - float(plan["stop_loss"]))
        want = (BAL * 0.5 / 100.0) / ((sl_dist / ts) * tv)
        want_n = mb._norm_volume(info, want)
        chk(f"{tag}: لات ریسکی ≈ فرمول", abs(tot - want_n) <= vstep + 1e-9,
            f"tot={tot} want={want_n}")
    else:
        chk(f"{tag}: حجم = درخواستی", abs(tot - mb._norm_volume(info, vol)) <= 1e-9,
            f"{tot} vs {vol}")
    if execution == "pending":
        chk(f"{tag}: در صفِ معلق (نه پوزیشن)", len(b.pending) == pend0 + nexp
            and len(b.positions) == pos0, f"pend+{len(b.pending)-pend0} pos+{len(b.positions)-pos0}")
        for o in list(b.pending.values())[-nexp:]:
            chk(f"{tag}: قیمتِ معلق=ورود و گِرد", abs(o.price_open - round(float(plan['entry']), dgt)) < 1e-9,
                o.price_open)
        b.pending.clear()
    else:
        newps = [p for p in b.positions.values()][pos0:]
        for p in newps:
            okside = (p.sl < p.price_open and (p.tp == 0 or p.tp > p.price_open)) if direction == "LONG" \
                else (p.sl > p.price_open and (p.tp == 0 or p.tp < p.price_open))
            chk(f"{tag}: سمتِ SL/TP", okside, f"sl={p.sl} tp={p.tp} open={p.price_open}")
            chk(f"{tag}: گِردِ اعشار", abs(p.sl - round(p.sl, dgt)) < 1e-12
                and abs(p.tp - round(p.tp, dgt)) < 1e-12, f"{p.sl}/{p.tp}")
        # هر دهمی: منیجر (پارشیال + بریک‌ایون) روی پوزیشنِ partial
        if tp_mode == "partial" and n % 2 == 0 and newps:
            mb.stop_manager()
            time.sleep(0.05)
            p = newps[-1]
            v0 = float(p.volume)   # قبل از manage — شیء پوزیشن in-place تغییر می‌کند
            tps = [t["price"] if isinstance(t, dict) else t for t in plan["take_profits"]]
            half = (b.symbols[bsym].get("spread_points", 10) * info.point) / 2.0
            move = (tps[0] + half + 2 * pt) if direction == "LONG" else (tps[0] - half - 2 * pt)
            b.set_price(bsym, round(move, dgt))
            mb._manage_once()
            pr = b.positions.get(p.ticket)
            if pr:
                v_exp = mb._norm_volume(info, v0 - mb._floor_step(v0 * 0.5, info.volume_step))
                chk(f"{tag}: پارشیال TP1 نصف", abs(pr.volume - v_exp) <= vstep + 1e-9,
                    f"{v0}→{pr.volume}")
                be_ok = (pr.sl >= pr.price_open) if direction == "LONG" else                         (pr.sl <= pr.price_open) if pr.sl else False
                prof = (tick_b := b.symbol_info_tick(bsym)) and (
                    (tick_b.bid - pr.price_open) if direction == "LONG" else (pr.price_open - tick_b.ask))
                risk0 = abs(pr.price_open - (plan["stop_loss"]))
                if prof is not None and prof >= risk0 - 1e-12:
                    chk(f"{tag}: بریک‌ایون پس از 1R", be_ok, f"sl={pr.sl} open={pr.price_open}")
        # پاک‌سازی برای معاملهٔ بعد
        for tk in [p.ticket for p in newps]:
            b.positions.pop(tk, None)
            mb._pos_state.pop(tk, None)
            mb._partial_plans.pop(tk, None)

chk("هر ۱۰۰ معامله اجرا شد", executed == 100, executed)
mb.stop_manager()
mh.status = _real_mh

# ═══════════════ فاز ۳: مسیرهای ارسالِ زنده ═══════════════
print("\n── فاز ۳: ارسالِ زنده (پیش‌نمایش دستی + سفارش ربات) ──")
for _ in range(3):
    sym = random.choice(list(PROFILES))
    dirx = random.choice(["LONG", "SHORT"])
    st, d = post("/api/mt5/send", {"symbol": sym, "tf": "15m", "dry_run": True,
                                   "volume": 0.2, "direction": dirx})
    res = okd(d)
    pl = res.get("planned") or {}
    chk(f"زنده send {sym}/{dirx}: planned با ۳TP", st == 200 and res.get("ok")
        and len(pl.get("tps") or []) == 3, str(d)[:100])

st, d = post("/api/robot/order", {"symbol": "BTCUSD", "direction": "SELL", "volume": 0.01,
                                  "robot_id": f"rnd100-{SEED}"})
chk("ربات زنده: پاسخ ۲۰۰ و ساختار صادقانه", st == 200 and (d or {}).get("ok") is True
    and ((not (d or {}).get("forwarded")) or (d or {}).get("simulated") is True), str(d)[:120])

# تاریخچه بعد از این‌همه سیگنال باید خوانا بماند
st, d = get("/api/history")
chk("تاریخچه پس از کارزار سالم", st == 200, st)

# بازگردانی کانفیگ‌ها
for i, f in enumerate(("mt5_config.json", "dispatch_config.json", "robot_config.json")):
    shutil.copy(f"/tmp/full100_{i}.bak", f)

print("\n" + "=" * 74)
print(f"  معاملات اجراشده: {executed}/100 · نتیجه: {PASS} پاس · {FAIL} ناموفق · seed={SEED}")
print("=" * 74)
if FAILURES:
    with open("app_full_100_failures.json", "w", encoding="utf-8") as f:
        json.dump({"seed": SEED, "failures": FAILURES}, f, ensure_ascii=False, indent=1)
    print("  جزئیات: app_full_100_failures.json")
raise SystemExit(1 if FAIL else 0)
