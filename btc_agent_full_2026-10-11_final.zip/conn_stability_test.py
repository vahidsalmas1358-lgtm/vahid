# -*- coding: utf-8 -*-
"""رگرسیونِ CONN-FLAP-001/002 — «پشتِ‌سرِهم پیامِ "اتصال دوباره برقرار شد" می‌آید».

ریشه‌ها: (۱) هر خطای گذرای هر درخواستِ کُند در UI فوراً «آفلاین» اعلام می‌کرد و
چکِ بعدی toast وصل‌شدن می‌داد؛ (۲) در پلِ متاتریدر، یک شکستِ لحظه‌ایِ account_info
بازاتصالِ کامل و قطع/وصلِ نمایشی می‌ساخت.
"""
import mock_mt5
import mt5_bridge as mb

PASS = 0
FAIL = 0


def chk(name, cond, detail=""):
    global PASS, FAIL
    if cond:
        PASS += 1
    else:
        FAIL += 1
        print(f"   FAIL  {name} — {str(detail)[:180]}")


print("=" * 70)
print(" پایداریِ اتصال: هیسترزیس UI + تلاشِ مجددِ MT5")
print("=" * 70)

# ── بک‌اند: CONN-FLAP-002
b = mock_mt5.Broker(balance=1000)
for k in dir(mock_mt5):
    if k.isupper():
        setattr(b, k, getattr(mock_mt5, k))
mb.mt5 = b
mb.MT5_AVAILABLE = True
mb._conn.update(connected=True, error=None, since=1.0)
calls = {"n": 0, "connect": 0}
_acc = b.account_info
def flaky():
    calls["n"] += 1
    return None if calls["n"] == 1 else _acc()
b.account_info = flaky
_rc = mb.connect
mb.connect = lambda *a, **k: (calls.__setitem__("connect", calls["connect"] + 1) or {"connected": True})
chk("خطای گذرای MT5 → بدونِ بازاتصال (فلپ نمی‌کند)", mb._ensure() and calls["connect"] == 0, calls)
b.account_info = lambda: None
mb._ensure()
chk("قطعیِ واقعی → بازاتصال انجام می‌شود", calls["connect"] == 1, calls)
mb.connect = _rc
b.account_info = _acc

# ── UI: CONN-FLAP-001 (چکِ ایستا)
ui = open("static/index.html", encoding="utf-8").read()
chk("آفلاین فقط پس از ۲ شکستِ پیاپیِ سلامت", "_connFails>=2" in ui.replace(" ", ""), "")
chk("toast فقط برای قطعیِ ≥۸ثانیه و حداکثر دقیقه‌ای یک‌بار",
    ">=8000" in ui and ">60000" in ui and "_connToastAt" in ui, "")
chk("خطای گذرای درخواست‌ها → connSuspect (نه اعلامِ آفلاین)",
    "connSuspect" in ui and 'typeof connSuspect==="function"' in ui
    and 'typeof setConn==="function") setConn(false)' not in ui, "")
chk("سرور چندنخی است (threaded=True)",
    "threaded=True" in open("app.py", encoding="utf-8").read(), "")

print("\n" + "=" * 70)
print(f"  نتیجه: {PASS} پاس · {FAIL} ناموفق")
print("=" * 70)
raise SystemExit(1 if FAIL else 0)
