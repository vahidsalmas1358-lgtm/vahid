"""ارسال هشدار سیگنال از طریق تلگرام و ایمیل (SMTP).

تنظیمات (توکن‌ها/رمزها) توسط کاربر از داشبورد وارد و در فایل alerts_config.json
ذخیره می‌شوند. هیچ کلید پیش‌فرضی وجود ندارد.
"""
from __future__ import annotations
import os
import json
import smtplib
import ssl
import threading   # OP5-CORE-14: قفلِ سراسریِ کانفیگ (RLock) نیاز به threading دارد
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

import requests

import jsonutil   # OP5-CORE-10: نوشتنِ اتمیکِ تنظیمات

_lock = threading.RLock()
CONFIG_PATH = os.path.join(os.path.dirname(__file__), "alerts_config.json")


def load_config() -> dict:
    if os.path.exists(CONFIG_PATH):
        try:
            with open(CONFIG_PATH, encoding="utf-8") as f:
                value = json.load(f)
            # اصلاح (ALERTS-001): JSONِ معتبر ولی غیرdict (مثل [] یا رشته) نباید
            # public_config/endpoint تنظیمات را با 500 بشکند.
            if isinstance(value, dict):
                return value
        except Exception:  # noqa
            pass
    return {"telegram": {"enabled": False, "bot_token": "", "chat_id": ""},
            "email": {"enabled": False, "smtp_host": "", "smtp_port": 587,
                      "username": "", "password": "", "to_addr": ""},
            "auto_alert": False}


def _as_bool(v, default=False):
    """تبدیلِ امنِ ورودی به بولی: رشته‌های «false/0/no/off» خاموش تلقی می‌شوند.

    بدونِ این، ذخیرهٔ رشته‌ای مثل "false" (truthy در پایتون) آلارم را به‌اشتباه
    روشن می‌کرد.
    """
    if isinstance(v, bool):
        return v
    if isinstance(v, (int, float)):
        return bool(v)
    if isinstance(v, str):
        return v.strip().lower() in ("1", "true", "yes", "on")
    return default


def _as_int(v, default):
    try:
        return int(float(v))
    except (TypeError, ValueError):
        return default


_ALLOWED_TOP = ("telegram", "email", "auto_alert")
_ALLOWED_TG = ("enabled", "bot_token", "chat_id")
_ALLOWED_EM = ("enabled", "smtp_host", "smtp_port", "username", "password", "to_addr")


def _sanitize(cfg: dict) -> dict:
    """نوعِ فیلدهای شناخته‌شده را قهری می‌کند تا ورودیِ خراب ذخیره نشود."""
    out = {k: v for k, v in cfg.items() if k in _ALLOWED_TOP}
    if isinstance(out.get("telegram"), dict):
        out["telegram"] = {k: v for k, v in out["telegram"].items() if k in _ALLOWED_TG}
    if isinstance(out.get("email"), dict):
        out["email"] = {k: v for k, v in out["email"].items() if k in _ALLOWED_EM}
    if "auto_alert" in out:
        out["auto_alert"] = _as_bool(out["auto_alert"])
    tg = out.get("telegram")
    if isinstance(tg, dict):
        if "enabled" in tg:
            tg["enabled"] = _as_bool(tg["enabled"])
        if "chat_id" in tg:
            tg["chat_id"] = str(tg["chat_id"] or "").strip()
        if "bot_token" in tg:
            tg["bot_token"] = str(tg["bot_token"] or "").strip()
    elif tg is not None:
        out.pop("telegram", None)     # تلگرامِ غیر-dict → نادیده
    em = out.get("email")
    if isinstance(em, dict):
        if "enabled" in em:
            em["enabled"] = _as_bool(em["enabled"])
        if "smtp_port" in em:
            p = _as_int(em["smtp_port"], 587)
            em["smtp_port"] = p if 1 <= p <= 65535 else 587
        for k in ("smtp_host", "username", "password", "to_addr"):
            if k in em:
                em[k] = str(em[k] or "").strip()
    elif em is not None:
        out.pop("email", None)        # ایمیلِ غیر-dict → نادیده
    return out


def save_config(cfg: dict) -> dict:
    current = load_config()
    cfg = _sanitize(cfg if isinstance(cfg, dict) else {})
    # ادغام عمیق ساده
    for k, v in cfg.items():
        if isinstance(v, dict) and isinstance(current.get(k), dict):
            current[k].update(v)
        else:
            current[k] = v
    # پاک‌سازیِ کلیدهای ناشناخته‌ای که قبلاً واردِ فایل شده‌اند
    for k in [k for k in current if k not in _ALLOWED_TOP]:
        current.pop(k, None)
    # OP5-CORE-10: نوشتنِ اتمیک تا فایلِ تنظیماتِ اعلان‌ها نیمه‌نوشته نشود
    with _lock:
        jsonutil.atomic_write_json(CONFIG_PATH, current)
    return current


def public_config() -> dict:
    """نسخه امن تنظیمات برای نمایش در فرانت (بدون رمز/توکن کامل)."""
    c = load_config()
    tg = c.get("telegram", {})
    em = c.get("email", {})
    def mask(s):
        return ("•" * 6 + s[-4:]) if s and len(s) > 4 else ("" if not s else "••••")
    return {
        "telegram": {"enabled": tg.get("enabled", False),
                     "chat_id": tg.get("chat_id", ""),
                     "bot_token_set": bool(tg.get("bot_token"))},
        "email": {"enabled": em.get("enabled", False),
                  "smtp_host": em.get("smtp_host", ""),
                  "smtp_port": em.get("smtp_port", 587),
                  "username": em.get("username", ""),
                  "to_addr": em.get("to_addr", ""),
                  "password_set": bool(em.get("password"))},
        "auto_alert": c.get("auto_alert", False),
    }


def send_telegram(text: str) -> dict:
    c = load_config().get("telegram", {})
    token, chat_id = c.get("bot_token"), c.get("chat_id")
    if not token or not chat_id:
        return {"ok": False, "error": "توکن یا chat_id تلگرام تنظیم نشده است"}
    try:
        url = f"https://api.telegram.org/bot{token}/sendMessage"
        r = requests.post(url, timeout=12, data={
            "chat_id": chat_id, "text": text, "parse_mode": "HTML"})
        j = r.json()
        if not j.get("ok"):
            return {"ok": False, "error": j.get("description", "خطای تلگرام")}
        return {"ok": True}
    except Exception as e:  # noqa
        return {"ok": False, "error": str(e)}


def send_email(subject: str, body_html: str) -> dict:
    c = load_config().get("email", {})
    host = c.get("smtp_host")
    port = int(c.get("smtp_port") or 587)
    user = c.get("username")
    pwd = c.get("password")
    to_addr = c.get("to_addr") or user
    if not host or not user or not pwd:
        return {"ok": False, "error": "تنظیمات SMTP کامل نیست"}
    try:
        msg = MIMEMultipart("alternative")
        msg["Subject"] = subject
        msg["From"] = user
        msg["To"] = to_addr
        msg.attach(MIMEText(body_html, "html", "utf-8"))
        context = ssl.create_default_context()
        if port == 465:
            with smtplib.SMTP_SSL(host, port, timeout=15, context=context) as s:
                s.login(user, pwd)
                s.sendmail(user, [to_addr], msg.as_string())
        else:
            with smtplib.SMTP(host, port, timeout=15) as s:
                s.starttls(context=context)
                s.login(user, pwd)
                s.sendmail(user, [to_addr], msg.as_string())
        return {"ok": True}
    except Exception as e:  # noqa
        return {"ok": False, "error": str(e)}


def format_signal_text(sig: dict) -> str:
    """متن ساده برای تلگرام."""
    p = sig["plan"]
    dir_emoji = {"LONG": "🟢 خرید (LONG)", "SHORT": "🔴 فروش (SHORT)",
                 "NEUTRAL": "🟡 خنثی / انتظار"}[sig["direction"]]
    lines = [
        f"<b>سیگنال {sig['pair']} — {sig['interval']}</b>",
        f"قیمت: ${sig['price']:,}",
        f"جهت: {dir_emoji}  (امتیاز {sig['total_score']})",
    ]
    if sig["direction"] != "NEUTRAL":
        lines.append(f"🎯 ورود: ${p['entry']:,}")
        for tp in p["take_profits"]:
            lines.append(f"✅ {tp['label']}: ${tp['price']:,}  (R:R {tp['rr']}, بستن {tp['close_pct']}٪)")
        lines.append(f"🛑 استاپ‌لاس: ${p['stop_loss']:,}")
    else:
        lines.append("در محدوده خنثی؛ منتظر تایید روند بمانید.")
    lines.append(f"\n⏱ {sig['generated_at']}")
    return "\n".join(lines)


def format_signal_html(sig: dict) -> str:
    p = sig["plan"]
    color = {"LONG": "#16c784", "SHORT": "#ea3943", "NEUTRAL": "#f0a92b"}[sig["direction"]]
    label = {"LONG": "خرید (LONG)", "SHORT": "فروش (SHORT)", "NEUTRAL": "خنثی"}[sig["direction"]]
    rows = ""
    if sig["direction"] != "NEUTRAL":
        rows += f"<tr><td>ورود</td><td><b>${p['entry']:,}</b></td></tr>"
        for tp in p["take_profits"]:
            rows += (f"<tr><td>{tp['label']} (بستن {tp['close_pct']}٪)</td>"
                     f"<td style='color:#16c784'><b>${tp['price']:,}</b> — R:R {tp['rr']}</td></tr>")
        rows += f"<tr><td>استاپ‌لاس</td><td style='color:#ea3943'><b>${p['stop_loss']:,}</b></td></tr>"
    return f"""
    <div dir="rtl" style="font-family:Tahoma,sans-serif;background:#0d1420;color:#e6edf7;
         padding:20px;border-radius:12px;max-width:460px">
      <h2 style="margin:0 0 6px">سیگنال {sig['pair']} · {sig['interval']}</h2>
      <p style="color:#8095b0;margin:0 0 12px">قیمت فعلی: ${sig['price']:,} · امتیاز کل: {sig['total_score']}</p>
      <div style="display:inline-block;padding:8px 20px;border-radius:30px;background:{color}22;
           color:{color};font-weight:bold;font-size:18px;margin-bottom:12px">{label}</div>
      <table style="width:100%;border-collapse:collapse;font-size:14px">{rows}</table>
      <p style="font-size:11px;color:#8095b0;margin-top:14px">{sig['generated_at']} — ابزار تحلیلی، توصیه مالی نیست.</p>
    </div>"""
