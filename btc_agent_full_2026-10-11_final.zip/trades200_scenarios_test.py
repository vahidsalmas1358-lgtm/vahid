# -*- coding: utf-8 -*-
"""کارزارِ ۲۰۰ معاملهٔ خرید/فروش با دادهٔ واقعی روی ۱۰ نماد با قیمت/اعشارِ متفاوت.

پوشش: محاسباتِ لات/SL/TP در LONG و SHORT، تقسیمِ لات بین ۳ حد سود، گِردکردنِ
اعشار برای نمادهای ۱٫۲٫۳٫۵ رقمی، حالت‌های tp_mode (split/single/none/partial)،
اجرای market/pending، لاتِ ریسکی (risk_pct) در برابرِ فرمولِ دستی، بریک‌ایون +
بافر، تریلینگ‌استاپ (یکنواختی و فاصله)، پارشیال‌تیک‌پرافیت (کسرها و حجمِ
باقیمانده)، ریسک‌فری، گیتِ ساعاتِ بازار (جمعه/شنبه/یکشنبه) با ساعتِ شبیه‌سازی‌شده.

دادهٔ واقعی: قیمت/ATR/نقشهٔ معامله از سرورِ زنده (منابعِ آزادِ واقعی) گرفته می‌شود؛
بروکرِ مصنوعی (mock_mt5) با همان قیمت‌های واقعی و پروفایل‌های واقع‌گرایانهٔ هر نماد
(digits/point/step/tick) مقداردهی می‌شود.
"""
import json

import sys
import urllib.request
from datetime import datetime, timezone

sys.path.insert(0, ".")
import mock_mt5
import mt5_bridge as mb
import market_hours as mh
import engine

BASE = "http://127.0.0.1:8000"
PASS = FAIL = 0
FAILS = []


def chk(name, cond, detail=""):
    global PASS, FAIL
    if cond:
        PASS += 1
    else:
        FAIL += 1
        FAILS.append(f"{name} — {detail}")
        print(f"   FAIL  {name} — {detail}")


# ─────────────────────── پروفایل‌های واقع‌گرایانهٔ بروکر ───────────────────────
# (نمادِ داخلی، نامِ کارگزار با پسوندهای متنوع، digits، point، vmin، vstep،
#  stops_level، tick_value، tick_size)
PROFILES = [
    ("XAU",    "XAUUSD.m",    2, 0.01,    0.01, 0.01, 30, 1.0,   0.01),
    ("XAG",    "XAGUSD.r",    3, 0.001,   0.01, 0.01, 20, 0.5,   0.001),
    ("BTC",    "BITCOIN",     2, 0.01,    0.01, 0.01, 0,  0.01,  0.01),
    ("ETH",    "ETHUSD.z",    2, 0.01,    0.01, 0.01, 0,  0.01,  0.01),
    ("SOL",    "SOLUSD",      3, 0.001,   0.01, 0.01, 0,  0.001, 0.001),
    ("EURUSD", "EURUSD.r",    5, 0.00001, 0.01, 0.01, 20, 1.0,   0.00001),
    ("GBPUSD", "GBPUSDmicro", 5, 0.00001, 0.01, 0.01, 20, 1.0,   0.00001),
    ("USDJPY", "USDJPY.pro",  3, 0.001,   0.01, 0.01, 20, 0.65,  0.001),
    ("SPX",    "US500",       1, 0.1,     0.1,  0.1,  0,  0.1,   0.1),
    ("NASDAQ", "USTEC",       1, 0.1,     0.1,  0.1,  0,  0.1,   0.1),
]
TFS = ["15m", "1h"]


def fetch_real(symbol, tf):
    """سیگنالِ واقعی (قیمت/نقشه/تکنیکال) از سرورِ زنده — منابعِ آزادِ واقعی."""
    u = f"{BASE}/api/signal?symbol={symbol}&tf={tf}&ai=0"
    r = urllib.request.urlopen(u, timeout=120)
    j = json.loads(r.read())
    assert j.get("ok"), f"سیگنال {symbol} {tf} ناموفق: {j.get('error')}"
    return j["data"]


def plan_for(data, direction):
    """نقشهٔ واقعی برای جهتِ خواسته‌شده (در صورتِ نیاز بازسازی با همان کدِ برنامه)."""
    if direction == data["direction"]:
        return data["plan"]
    tech = data["technical"]
    return engine.build_trade_plan(
        direction, data["price"], data["atr"],
        tech["supports"], tech["resistances"],
        abs(data["total_score"]), engine._dec(data["price"]),
        fib=tech.get("fibonacci"),
        extra_sup=tech.get("conf_supports"), extra_res=tech.get("conf_resistances"))


# ─────────────────────── نصبِ بروکرِ مصنوعی با قیمت‌های واقعی ───────────────────────
print("=" * 72)
print(" کارزارِ ۲۰۰ معامله — دادهٔ واقعی، ۱۰ نماد، سناریوهای متنوع")
print("=" * 72)

REAL = {}
for internal, bsym, dg, pt, vmin, vstep, stl, tval, tsz in PROFILES:
    REAL[internal] = {tf: fetch_real(internal, tf) for tf in TFS}
    print(f"   دادهٔ واقعی {internal:7s} → قیمت {REAL[internal]['1h']['price']}")

b = mock_mt5.Broker(balance=1_000_000.0)
for internal, bsym, dg, pt, vmin, vstep, stl, tval, tsz in PROFILES:
    b.add_symbol(bsym, digits=dg, point=pt, volume_min=vmin, volume_step=vstep,
                 stops_level=stl, tick_value=tval, tick_size=tsz,
                 price=float(REAL[internal]["1h"]["price"]))
for k in dir(mock_mt5):
    if k.isupper():
        setattr(b, k, getattr(mock_mt5, k))
mb.mt5 = b
mb.MT5_AVAILABLE = True
mb._conn.update(connected=True, error=None, since=1.0)

# ساعتِ شبیه‌سازی‌شده برای گیتِ بازار (دوشنبه = بازارِ سنتی باز)
SIM = {"now": datetime(2026, 10, 5, 10, 0, tzinfo=timezone.utc)}
_real_status = mh.status
mh.status = lambda s, now=None: _real_status(s, now or SIM["now"])

import shutil
shutil.copy("mt5_config.json", "/tmp/mt5cfg_campaign.bak")

BASE_CFG = {"risk_mode": "fixed", "default_volume": 0.1, "tp_mode": "split",
            "execution": "market", "use_plan_sl": True, "use_plan_tp": True,
            "market_hours_guard": True, "manage_positions": False,
            "max_daily_trades": 0, "max_daily_risk_pct": 0,
            "breakeven_enabled": True, "breakeven_r": 1.0, "breakeven_buffer_pts": 5,
            "trailing_enabled": True, "trailing_mode": "points",
            "trailing_points": 300, "trailing_start_r": 1.0,
            "partial_fractions": [0.5, 0.3], "allowed_symbols": []}
mb.save_config(BASE_CFG)


def dec_of(step):
    s = f"{step:.8f}".rstrip("0")
    return len(s.split(".")[1]) if "." in s else 0


def positions():
    return list(b.positions.values())


KEPT = set()


def clear_positions():
    """همهٔ پوزیشن‌ها به‌جز تیکت‌های نگه‌داشته برای فازِ منیجر پاک می‌شوند."""
    for t in list(b.positions):
        if t not in KEPT:
            b.positions.pop(t, None)
            mb._pos_state.pop(t, None)
            mb._partial_plans.pop(t, None)


# ─────────────────────── فاز ۱: ۲۰۰ معامله ───────────────────────
print("\n── فاز ۱: ۲۰۰ معاملهٔ خرید/فروش (ماتریسِ سناریوها) ──")
trade_no = 0
kept_for_manager = []   # (ticket، نماد داخلی، bsym، جهت، plan، info)
executed = 0

for round_i in range(20):                      # ۲۰ دور × ۱۰ نماد = ۲۰۰
    for pi, (internal, bsym, dg, pt, vmin, vstep, stl, tval, tsz) in enumerate(PROFILES):
        trade_no += 1
        tf = TFS[trade_no % len(TFS)]
        data = REAL[internal][tf]
        # جهت: نیمی سیگنالِ واقعی، نیمی اجباری برعکس → پوششِ LONG و SHORT
        sig_dir = data["direction"] if data["direction"] in ("LONG", "SHORT") else "LONG"
        direction = sig_dir if trade_no % 2 == 0 else ("SHORT" if sig_dir == "LONG" else "LONG")
        plan = plan_for(data, direction)
        # سناریوی حالت‌ها
        tp_mode = ["split", "split", "single", "none", "partial"][trade_no % 5]
        execution = "pending" if trade_no % 10 == 7 else "market"
        volume = [0.05, 0.1, 0.25, 0.33, 1.0][trade_no % 5]
        if vstep >= 0.1:
            volume = max(volume, 0.3)
        risk_mode = "risk_pct" if trade_no % 4 == 3 else "fixed"
        mb.save_config({"risk_mode": risk_mode, "tp_mode": tp_mode,
                        "execution": execution, "risk_pct": 0.5})
        b.set_price(bsym, float(data["price"]))

        _before = set(b.positions)
        res = mb.send_order(bsym, direction, plan,
                            volume=(None if risk_mode == "risk_pct" else volume),
                            dry_run=False, skip_news_filter=True)
        tag = f"#{trade_no:03d} {bsym} {direction} {tp_mode}/{execution}/{risk_mode}"
        chk(f"{tag}: ok", res.get("ok"), str(res.get("error"))[:90])
        if not res.get("ok"):
            clear_positions()
            continue
        executed += 1
        legs = res.get("legs") or []
        dec = dec_of(vstep)

        if execution == "market":
            ps = [p for t, p in b.positions.items() if t not in _before]
            # ۱) مجموعِ حجمِ پوزیشن‌ها = حجمِ کل گزارش‌شده
            tot_pos = round(sum(p.volume for p in ps), dec)
            tot_res = round(sum(l["volume"] for l in legs), dec)
            chk(f"{tag}: مجموع لات پوزیشن‌ها=گزارش", tot_pos == tot_res,
                f"{tot_pos} vs {tot_res}")
            for p in ps:
                # ۲) تراز با step و حداقل
                ratio = p.volume / vstep
                chk(f"{tag}: لات تراز با گام", abs(ratio - round(ratio)) < 1e-6, str(p.volume))
                chk(f"{tag}: لات ≥ حداقل", p.volume >= vmin - 1e-12, str(p.volume))
                # ۳) سمتِ SL/TP
                if p.sl:
                    chk(f"{tag}: سمت SL", (p.sl < p.price_open) if direction == "LONG"
                        else (p.sl > p.price_open), f"sl={p.sl} open={p.price_open}")
                    # ۴) گِردِ اعشارِ نماد
                    chk(f"{tag}: اعشار SL", abs(p.sl - round(p.sl, dg)) < 1e-9, str(p.sl))
                    # ۵) حداقل فاصلهٔ استاپ
                    if stl:
                        chk(f"{tag}: فاصله SL ≥ stops_level",
                            abs(p.price_open - p.sl) >= stl * pt - 1e-9,
                            f"dist={abs(p.price_open-p.sl)}")
                if p.tp:
                    chk(f"{tag}: سمت TP", (p.tp > p.price_open) if direction == "LONG"
                        else (p.tp < p.price_open), f"tp={p.tp} open={p.price_open}")
                    chk(f"{tag}: اعشار TP", abs(p.tp - round(p.tp, dg)) < 1e-9, str(p.tp))
            # ۶) تعداد لِگ‌ها با tp_mode سازگار
            if tp_mode == "split":
                n_tp = len([t for t in (plan.get("take_profits") or [])][:3])
                chk(f"{tag}: تعداد پله ≤ TPها", 1 <= len(legs) <= max(1, n_tp), str(len(legs)))
            elif tp_mode in ("single", "none", "partial"):
                chk(f"{tag}: تک‌پوزیشن", len(legs) == 1, str(len(legs)))
            # ۷) لاتِ ریسکی مطابقِ فرمول
            if risk_mode == "risk_pct":
                entry = plan.get("entry") or float(data["price"])
                sl = plan.get("stop_loss")
                if sl:
                    risk_cash = 1_000_000.0 * 0.5 / 100.0
                    vexp = risk_cash / ((abs(entry - sl) / tsz) * tval)
                    vexp_n = mb._norm_volume(b.symbol_info(bsym), vexp)
                    chk(f"{tag}: لات ریسکی=فرمول", abs(tot_res - vexp_n) <= vstep + 1e-9,
                        f"got={tot_res} expected≈{vexp_n}")
            # ۸) ریسکِ گزارش‌شده سازگار با SL
            ra = res.get("risk_amount")
            chk(f"{tag}: risk_amount>0", (ra or 0) > 0 or not plan.get("stop_loss"), str(ra))
        else:   # pending
            chk(f"{tag}: pending ثبت شد (نه پوزیشنِ فوری)",
                len(b.pending) >= 1 and not [t for t in b.positions if t not in _before],
                f"pending={len(b.pending)} pos={len(b.positions)}")
            entry_p = plan.get("entry")
            ref = float(data["price"])
            for o in b.pending.values():
                if direction == "LONG":
                    want = mock_mt5.ORDER_TYPE_BUY_LIMIT if entry_p < ref else mock_mt5.ORDER_TYPE_BUY_STOP
                else:
                    want = mock_mt5.ORDER_TYPE_SELL_LIMIT if entry_p > ref else mock_mt5.ORDER_TYPE_SELL_STOP
                chk(f"{tag}: نوع سفارش معلق درست", o.type == want,
                    f"type={o.type} want={want} entry={entry_p} ref={ref}")
                chk(f"{tag}: قیمت معلق=ورود نقشه", abs(o.price_open - entry_p) < 1e-9,
                    f"{o.price_open} vs {entry_p}")
            b.pending.clear()

        # نگه‌داشتنِ چند پوزیشنِ partial برای فازِ منیجر
        if (tp_mode == "partial" and execution == "market" and res.get("ok")
                and len(kept_for_manager) < 12
                and bsym not in {k[2] for k in kept_for_manager}):
            new_ps = [p for t, p in b.positions.items() if t not in _before]
            if new_ps:
                KEPT.add(new_ps[-1].ticket)
                kept_for_manager.append((new_ps[-1].ticket, internal, bsym, direction,
                                         plan, b.symbol_info(bsym)))
        clear_positions()

print(f"   اجراشده: {executed}/{trade_no} معامله")

# ─────────────────────── فاز ۲: بریک‌ایون/تریلینگ/پارشیال/ریسک‌فری ───────────────────────
print("\n── فاز ۲: منیجر (پارشیال + بریک‌ایون + تریلینگ + ریسک‌فری) روی پوزیشن‌های واقعی ──")
mb.stop_manager()          # دترمینیسم: فقط فراخوانی‌های صریحِ _manage_once
mb.save_config({"manage_positions": True})
for ticket, internal, bsym, direction, plan, info in kept_for_manager:
    if ticket not in b.positions:
        continue
    p = b.positions[ticket]
    dgts = info.digits
    is_buy = (direction == "LONG")
    entry, sl0 = p.price_open, p.sl
    risk = abs(entry - sl0) if sl0 else 0.0
    tps = [t["price"] if isinstance(t, dict) else t for t in (plan.get("take_profits") or [])][:3]
    tag = f"mgr {bsym} {direction}"
    if not (risk > 0 and tps):
        continue
    chk(f"mgr {bsym} {direction}: پلنِ پارشیال برای تیکت ثبت است",
        ticket in mb._partial_plans, f"ticket={ticket} plans={list(mb._partial_plans)}")
    v0 = p.volume

    # ➊ حرکت به TP1 (≥1R) → پارشیال TP1 + بریک‌ایون
    # نکتهٔ اسپرد: قیمتِ خروجِ منیجر برای LONG=bid و برای SHORT=ask است و
    # ماکت bid/ask را به‌اندازهٔ نصفِ اسپرد از قیمتِ میانی دور می‌کند؛ پس
    # باید mid را به‌اندازهٔ half+۲pt از TP فراتر ببریم تا سمتِ خروج برسد.
    half = (b.symbols[bsym].get("spread_points", 10) * info.point) / 2.0
    tp1 = tps[0]
    move = tp1 + ((half + info.point * 2) if is_buy else -(half + info.point * 2))
    b.set_price(bsym, move)
    mb._manage_once()
    pr = b.positions.get(ticket)
    chk(f"{tag}: پس از TP1 پوزیشن باز است", pr is not None, "بسته شد؟")
    if pr is None:
        continue
    vstep = info.volume_step
    dec = dec_of(vstep)
    v_exp = mb._norm_volume(info, v0 - mb._norm_volume(info, v0 * 0.5))
    chk(f"{tag}: پارشیال TP1 نیمِ حجم", abs(pr.volume - v_exp) <= vstep + 1e-9,
        f"v0={v0} → {pr.volume} (انتظار≈{v_exp})")
    buf = 5 * info.point
    # profit واقعی از دیدِ منیجر: fill (entry واقعی پوزیشن) تا قیمتِ سمتِ خروج
    exit1 = (move - half) if is_buy else (move + half)
    prof1 = (exit1 - entry) if is_buy else (entry - exit1)
    if prof1 >= risk - 1e-9:   # آستانهٔ breakeven_r=1.0 قطعاً رد شده
        be_ok = (pr.sl >= entry) if is_buy else (pr.sl <= entry)
        chk(f"{tag}: بریک‌ایون (ریسک‌فری)", be_ok, f"sl={pr.sl} entry={entry}")
        chk(f"{tag}: بافر بریک‌ایون درست", abs(abs(pr.sl - entry) - buf) < info.point * 3 + 1e-9
            or ((pr.sl - entry) if is_buy else (entry - pr.sl)) > buf - 1e-9,
            f"sl={pr.sl} entry={entry} buf={buf}")
    chk(f"{tag}: اعشار SL منیجر", abs(pr.sl - round(pr.sl, dgts)) < 1e-9, str(pr.sl))
    sl_after_be = pr.sl

    # ➋ حرکتِ بیشتر → تریلینگ جلو برود (یکنواخت)
    far = move + (risk * 2 if is_buy else -risk * 2)
    b.set_price(bsym, far)
    mb._manage_once()
    pr2 = b.positions.get(ticket)
    if pr2 is not None:
        trailed = (pr2.sl > sl_after_be) if is_buy else (pr2.sl < sl_after_be)
        chk(f"{tag}: تریلینگ جلو رفت", trailed, f"{sl_after_be} → {pr2.sl}")
        rf = (pr2.sl >= entry) if is_buy else (pr2.sl <= entry)
        chk(f"{tag}: ریسک‌فری پس از ۲R (BE یا تریل از ورود گذشته)", rf,
            f"sl={pr2.sl} entry={entry}")
        dist = 300 * info.point
        exit_px = (far - half) if is_buy else (far + half)   # bid برای LONG / ask برای SHORT
        gap = (exit_px - pr2.sl) if is_buy else (pr2.sl - exit_px)
        chk(f"{tag}: فاصلهٔ تریل ≈ تنظیم", abs(gap - dist) < max(dist * 0.01, info.point * 3),
            f"gap={gap} dist={dist}")
        sl_trail = pr2.sl
        # ➌ برگشتِ قیمت → SL عقب نرود (یکنواختی)
        back = far - (risk if is_buy else -risk)
        b.set_price(bsym, back)
        mb._manage_once()
        pr3 = b.positions.get(ticket)
        if pr3 is not None:
            chk(f"{tag}: SL در برگشت عقب نرفت",
                (pr3.sl >= sl_trail - 1e-12) if is_buy else (pr3.sl <= sl_trail + 1e-12),
                f"{sl_trail} → {pr3.sl}")
KEPT.clear()
clear_positions()
mb.save_config({"manage_positions": False})

# ─────────────────────── فاز ۳: ساعاتِ بازار / آخر هفته / جمعه / سشن‌ها ───────────────────────
print("\n── فاز ۳: گیتِ ساعاتِ بازار با ساعتِ شبیه‌سازی‌شدهٔ بروکر ──")
WEEK = {
    "دوشنبه ۱۰:۰۰":        (datetime(2026, 10, 5, 10, 0, tzinfo=timezone.utc), True),
    "جمعه ۲۰:۵۹ (قبل بستن)": (datetime(2026, 10, 2, 20, 59, tzinfo=timezone.utc), True),
    "جمعه ۲۱:۰۱ (بسته)":    (datetime(2026, 10, 2, 21, 1, tzinfo=timezone.utc), False),
    "شنبه ۱۲:۰۰ (تعطیل)":   (datetime(2026, 10, 3, 12, 0, tzinfo=timezone.utc), False),
    "یکشنبه ۲۰:۳۰ (قبل باز)": (datetime(2026, 10, 4, 20, 30, tzinfo=timezone.utc), False),
    "یکشنبه ۲۱:۳۰ (بازشده)": (datetime(2026, 10, 4, 21, 30, tzinfo=timezone.utc), True),
}
trad = [("XAU", "XAUUSD.m"), ("EURUSD", "EURUSD.r"), ("SPX", "US500")]
for label, (t, open_exp) in WEEK.items():
    SIM["now"] = t
    for internal, bsym in trad:
        st = mh.status(bsym)
        chk(f"ساعات {bsym} {label}", st["open"] == open_exp,
            f"open={st['open']} انتظار={open_exp}")
        # ارسالِ واقعی هم باید همین را رعایت کند
        data = REAL[internal]["1h"]
        b.set_price(bsym, float(data["price"]))
        res = mb.send_order(bsym, "LONG", plan_for(data, "LONG"),
                            volume=0.3 if bsym == "US500" else 0.05,
                            dry_run=False, skip_news_filter=True)
        if open_exp:
            chk(f"ارسال {bsym} {label} مجاز", res.get("ok"), str(res.get("error"))[:80])
        else:
            chk(f"ارسال {bsym} {label} مسدود", res.get("blocked") is True and not res.get("ok"),
                str(res)[:80])
        clear_positions()
    # کریپتو همیشه باز
    st = mh.status("BITCOIN")
    chk(f"ساعات BITCOIN {label} (۲۴/۷)", st["open"] is True, str(st["open"]))
SIM["now"] = datetime(2026, 10, 5, 10, 0, tzinfo=timezone.utc)

# ─────────────────────── فاز ۴: ریاضیِ نقشه‌های واقعی (۳TP، ترتیب، سمت‌ها) ───────────────────────
print("\n── فاز ۴: صحتِ ریاضیِ نقشه‌های واقعی برای هر ۱۰ نماد × ۲ تایم‌فریم × ۲ جهت ──")
for internal, bsym, dg, pt, vmin, vstep, stl, tval, tsz in PROFILES:
    for tf in TFS:
        data = REAL[internal][tf]
        for direction in ("LONG", "SHORT"):
            plan = plan_for(data, direction)
            tag = f"plan {internal} {tf} {direction}"
            tps = [t["price"] if isinstance(t, dict) else t
                   for t in (plan.get("take_profits") or [])]
            entry = plan.get("entry")
            sl = plan.get("stop_loss")
            chk(f"{tag}: دقیقاً ۳ حد سود", len(tps) == 3, str(len(tps)))
            if entry and sl:
                chk(f"{tag}: سمت SL", (sl < entry) if direction == "LONG" else (sl > entry),
                    f"entry={entry} sl={sl}")
            if entry and len(tps) == 3:
                if direction == "LONG":
                    chk(f"{tag}: ترتیب TPها صعودی", tps[0] < tps[1] < tps[2], str(tps))
                    chk(f"{tag}: TPها بالای ورود", all(t > entry for t in tps), str(tps))
                else:
                    chk(f"{tag}: ترتیب TPها نزولی", tps[0] > tps[1] > tps[2], str(tps))
                    chk(f"{tag}: TPها زیر ورود", all(t < entry for t in tps), str(tps))
            if entry and sl and tps:
                rr1 = abs(tps[0] - entry) / max(abs(entry - sl), 1e-12)
                chk(f"{tag}: R:R منطقی (۰٫۳ تا ۲۰)", 0.3 <= rr1 <= 20, f"RR1={rr1:.2f}")

# ─────────────────────── جمع‌بندی ───────────────────────
mh.status = _real_status
shutil.copy("/tmp/mt5cfg_campaign.bak", "mt5_config.json")
print("\n" + "=" * 72)
print(f"  معاملاتِ اجراشده: {executed} · نتیجه: {PASS} پاس · {FAIL} ناموفق")
print("=" * 72)
if FAILS:
    with open("trades200_scenarios_failures.json", "w", encoding="utf-8") as f:
        json.dump(FAILS, f, ensure_ascii=False, indent=1)
    print("  جزئیاتِ خطاها: trades200_scenarios_failures.json")
sys.exit(1 if FAIL else 0)
