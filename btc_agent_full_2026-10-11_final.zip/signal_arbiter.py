"""داوریِ سیگنال‌های همزمان/متضاد برای هر نماد (ضدِّ تکرار و ضدِّ تضاد).

سناریوهایی که این ماژول پوشش می‌دهد:

۱) پردازشِ همزمانِ چند سیگنال: برای هر نماد یک «داوری» انجام می‌شود که رقابتِ نخ‌ها
   (thread ها) را ایمن می‌کند؛ پس چند سیگنالِ همزمان بی‌خطر پردازش می‌شوند.

۲) چند سیگنالِ هم‌جهت (مثلاً دو «خرید») برای یک نماد: فقط «یکی» (بهترین) ارسال می‌شود؛
   از ارسالِ تکراری جلوگیری می‌شود.

۳) چند سیگنالِ متضاد (خرید و فروش) برای یک نماد: «بهترین/قوی‌ترین» انتخاب و ارسال می‌شود
   و از ارسالِ همزمانِ خرید و فروش جلوگیری می‌شود.

روش: هر سیگنال در یک «پنجرهٔ کوتاهِ جمع‌آوری» (aggregation window) وارد یک دستهٔ (batch)
همان نماد می‌شود و منتظر می‌ماند؛ در پایانِ پنجره، نامزدِ با بالاترین امتیاز برنده می‌شود و
بقیه رد می‌شوند (هم‌جهت → «تکراری»، مخالف → «متضاد»). یک «حافظهٔ اخیر» هم نگه داشته می‌شود
تا سیگنال‌هایی که کمی دیرتر (بیرون از پنجره) می‌رسند نیز رد شوند.
"""
from __future__ import annotations
import threading
import time
import itertools

_glock = threading.RLock()          # قفلِ سراسری برای دفترداریِ دسته‌ها و حافظه
_counter = itertools.count(1)
_batches: dict = {}                 # symbol -> _Batch (دستهٔ فعالِ فعلی)
_recent: dict = {}                  # symbol -> {"direction","ts","score"}
_sym_locks: dict = {}               # symbol -> RLock (سریال‌سازیِ ارسال برای هر نماد)


class _Batch:
    __slots__ = ("symbol", "window", "deadline", "candidates",
                 "decided", "winner_id", "cv")

    def __init__(self, symbol: str, window: float):
        self.symbol = symbol
        self.window = float(window)
        self.deadline = time.time() + float(window)
        self.candidates = []          # [{id, direction, score, meta}]
        self.decided = False
        self.winner_id = None
        self.cv = threading.Condition(_glock)


def _decide(b: _Batch) -> None:
    """برندهٔ دسته را انتخاب می‌کند: بالاترین امتیاز؛ در تساوی، زودترین (کوچک‌ترین id)."""
    if b.decided:
        return
    if b.candidates:
        winner = max(b.candidates, key=lambda c: (c["score"], -c["id"]))
        b.winner_id = winner["id"]
    else:
        b.winner_id = None
    b.decided = True
    b.cv.notify_all()


def submit(symbol: str, direction: str, score: float,
           window: float = 2.0, meta: dict = None) -> dict:
    """یک نامزد را وارد داوری می‌کند و تا مشخص‌شدنِ برنده منتظر می‌ماند.

    خروجی: {win, kind: "win"|"duplicate"|"conflict", winner:{direction,score},
             n: تعدادِ نامزدها, my_score, winner_score}
    """

    # OP5-ARB-13: score/window باید عددِ متناهی باشند؛ NaN مقدارِ truthy است و
    # قبلاً می‌توانست به‌عنوانِ برندهٔ رقابت انتخاب شود (سرایتِ NaN در رقابتِ چندنخی).
    import math as _math
    if direction not in ("LONG", "SHORT"):
        raise ValueError("invalid direction")
    try:
        score = float(score)
        window = float(window)
    except (TypeError, ValueError):
        raise ValueError("score/window must be numeric")
    if not _math.isfinite(score):
        raise ValueError("score must be finite")
    if not _math.isfinite(window) or window < 0:
        raise ValueError("window must be finite and non-negative")
    symbol = (symbol or "").upper()
    cid = next(_counter)
    cand = {"id": cid, "direction": direction,
            "score": float(score or 0.0), "meta": meta or {}}

    with _glock:
        b = _batches.get(symbol)
        now = time.time()
        if b is None or b.decided or now >= b.deadline:
            b = _Batch(symbol, window)
            _batches[symbol] = b
        b.candidates.append(cand)
        cv = b.cv

        # انتظار تا تصمیم‌گیری یا پایانِ پنجره
        while not b.decided:
            remaining = b.deadline - time.time()
            if remaining <= 0:
                _decide(b)
                break
            cv.wait(timeout=remaining)

        winner = next((c for c in b.candidates if c["id"] == b.winner_id), None)
        n = len(b.candidates)
        # اجازهٔ ساختِ دستهٔ تازه برای سیگنال‌های بعدی
        if _batches.get(symbol) is b:
            _batches.pop(symbol, None)

    win = (winner is not None and winner["id"] == cid)
    if win:
        kind = "win"
    elif winner is not None and winner["direction"] == direction:
        kind = "duplicate"
    else:
        kind = "conflict"
    return {"win": win, "kind": kind, "n": n, "my_score": cand["score"],
            "winner_direction": (winner or {}).get("direction"),
            "winner_score": (winner or {}).get("score")}


def symbol_lock(symbol: str) -> threading.RLock:
    """قفلِ اختصاصیِ هر نماد برای سریال‌سازیِ بخشِ «بازبینی → ارسال → ثبت»."""
    symbol = (symbol or "").upper()
    with _glock:
        lk = _sym_locks.get(symbol)
        if lk is None:
            lk = threading.RLock()
            _sym_locks[symbol] = lk
        return lk


def note_forward(symbol: str, direction: str, score: float = 0.0) -> None:
    """ثبتِ آخرین ارسالِ موفق برای یک نماد (برای ردِّ سیگنال‌های اخیرِ بعدی)."""
    with _glock:
        _recent[(symbol or "").upper()] = {
            "direction": direction, "ts": time.time(), "score": float(score or 0.0)}


def recent(symbol: str, ttl: float) -> dict:
    """اگر در بازهٔ ttl ثانیهٔ اخیر برای این نماد ارسالی داشته‌ایم، آن را برمی‌گرداند."""
    with _glock:
        r = _recent.get((symbol or "").upper())
        if r and (time.time() - r["ts"]) <= float(ttl):
            return dict(r)
    return None


def clear_recent(symbol: str = None) -> None:
    """پاک‌کردنِ حافظهٔ اخیر (کلِ آن یا فقط یک نماد)."""
    with _glock:
        if symbol is None:
            _recent.clear()
        else:
            _recent.pop((symbol or "").upper(), None)


def reset() -> None:
    """بازنشانیِ کاملِ وضعیت (برای تست)."""
    with _glock:
        _batches.clear()
        _recent.clear()
        _sym_locks.clear()
