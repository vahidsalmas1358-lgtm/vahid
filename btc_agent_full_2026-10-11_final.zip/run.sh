#!/usr/bin/env bash
# ============================================================================
#  run.sh  --  راه‌اندازِ دائمیِ داشبورد تحلیل روی لینوکس / macOS
#  کارهایی که خودکار انجام می‌دهد:
#    ۱) پیدا کردنِ Python 3
#    ۲) ساختِ محیطِ مجازی (.venv) — فقط بارِ اول
#    ۳) نصبِ کتابخانه‌ها از requirements.txt — فقط وقتی لازم باشد
#    ۴) اجرای سرور روی پورتِ 8000 و راه‌اندازیِ مجدد در صورتِ قطع‌شدن
#  توقف: کلیدِ Ctrl+C
#  تغییرِ پورت:  PORT=9000 ./run.sh
# ============================================================================
set -u
cd "$(dirname "$0")"

PORT="${PORT:-8000}"

echo "============================================================"
echo "   داشبورد تحلیل  --  راه‌اندازِ لینوکس / macOS"
echo "============================================================"

# --- ۱) پیدا کردنِ پایتون ---
PY="$(command -v python3 || command -v python || true)"
if [ -z "$PY" ]; then
  echo "[X] Python 3 پیدا نشد. لطفاً پایتون ۳٫۱۰ به‌بالا را نصب کنید:"
  echo "    Ubuntu/Debian:  sudo apt install python3 python3-venv python3-pip"
  echo "    macOS (brew) :  brew install python"
  exit 1
fi
echo "[1/4] پایتون: $("$PY" --version 2>&1)"

# --- ۲) ساختِ venv (فقط بارِ اول) ---
if [ ! -x ".venv/bin/python" ]; then
  echo "[2/4] ساختِ محیطِ مجازی (.venv) ..."
  if ! "$PY" -m venv .venv; then
    echo "[X] ساختِ venv ناموفق بود. روی اوبونتو/دبیان این را نصب کنید:  sudo apt install python3-venv"
    exit 1
  fi
else
  echo "[2/4] محیطِ مجازی از قبل موجود است."
fi
VENV_PY=".venv/bin/python"

# --- ۳) نصبِ کتابخانه‌ها (فقط وقتی flask نصب نباشد) ---
if ! "$VENV_PY" -c "import flask" >/dev/null 2>&1; then
  echo "[3/4] نصبِ کتابخانه‌ها ... (فقط بارِ اول کمی طول می‌کشد)"
  "$VENV_PY" -m pip install --upgrade pip
  if ! "$VENV_PY" -m pip install -r requirements.txt; then
    echo "[X] نصبِ کتابخانه‌ها ناموفق بود."
    exit 1
  fi
else
  echo "[3/4] کتابخانه‌ها از قبل نصب‌اند."
fi

# --- بازکردنِ مرورگر (در صورتِ امکان، بدونِ ایجادِ خطا) ---
URL="http://127.0.0.1:${PORT}"
( command -v xdg-open >/dev/null 2>&1 && xdg-open "$URL" >/dev/null 2>&1 ) \
  || ( command -v open >/dev/null 2>&1 && open "$URL" >/dev/null 2>&1 ) || true

echo "[4/4] اجرای سرور ..."
echo "------------------------------------------------------------"
echo "   داشبورد:  $URL"
echo "   توقف   :  Ctrl+C"
echo "------------------------------------------------------------"

# --- حلقهٔ اجرا با راه‌اندازیِ مجدد؛ Ctrl+C کاملاً خارج می‌شود ---
trap 'echo; echo "خروج. خدانگهدار."; exit 0' INT TERM
while true; do
  PORT="$PORT" "$VENV_PY" app.py || true
  echo
  echo "سرور متوقف شد؛ راه‌اندازیِ مجدد تا ۳ ثانیهٔ دیگر ... (برای خروج Ctrl+C)"
  sleep 3
done
