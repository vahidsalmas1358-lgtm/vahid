# -*- coding: utf-8 -*-
"""رگرسیونِ PROG-GUARD-001 — «معاملاتِ موافقِ تکراری و معاملاتِ مخالفِ همزمان باز می‌شوند».

ریشه‌ها:
  • مسیرِ خودکارِ برنامه فقط حافظهٔ درون‌پردازه‌ایِ «آخرین جهت» (کلید نماد:tf) را
    داشت: تغییرِ تایم‌فریم/نامِ نماد/ری‌استارت → هم‌جهتِ تکراری؛ چرخشِ جهتِ
    سیگنال → معاملهٔ مخالف کنارِ پوزیشنِ باز (هجِ ناخواسته).
  • مسیرِ دستی/خودکارِ UI (/api/mt5/send) فقط هم‌جهت را می‌بست، نه مخالف را.

پس از اصلاح: هر دو مسیر پیش از ارسال، «پوزیشن‌های بازِ واقعی» را چک می‌کنند.
"""
import os as _os_env; _os_env.environ.setdefault("BTC_AGENT_ALLOW_INSECURE_ROBOT", "1")  # محیط تست
import shutil

import app
import dispatch
import mock_mt5
import mt5_bridge as mb
import market_hours as mh

PASS = 0
FAIL = 0


def chk(name, cond, detail=""):
    global PASS, FAIL
    if cond:
        PASS += 1
    else:
        FAIL += 1
        print(f"   FAIL  {name} — {str(detail)[:220]}")


for i, f in enumerate(("mt5_config.json", "dispatch_config.json")):
    shutil.copy(f, f"/tmp/pc_{i}.bak")
app.app.config["TESTING"] = True
client = app.app.test_client()
_mh = mh.status
mh.status = lambda s, now=None: {"open": True, "state": "open", "reason": ""}

b = mock_mt5.Broker(balance=100000)
b.add_symbol("ETHUSD.z", digits=2, point=0.01, volume_min=0.01, volume_step=0.01,
             stops_level=10, tick_value=1.0, tick_size=0.01, price=2650.0)
for k in dir(mock_mt5):
    if k.isupper():
        setattr(b, k, getattr(mock_mt5, k))
mb.mt5 = b
mb.MT5_AVAILABLE = True
mb._conn.update(connected=True, error=None, since=1.0)
mb.save_config({"market_hours_guard": False, "news_filter_enabled": False,
                "max_daily_trades": 0, "max_daily_risk_pct": 0, "allowed_symbols": [],
                "manage_positions": False, "risk_mode": "fixed", "tp_mode": "single",
                "execution": "market", "default_volume": 0.1, "magic": 532025,
                "symbol_map": {"ETH": "ETHUSD.z"}})
dispatch.save_config({"program_enabled": True, "program_source": "internal",
                      "program_min_internal": 15, "news_filter_enabled": False,
                      "schedule_filter_enabled": False,
                      "program_block_duplicate_open": True,
                      "program_block_opposite_open": True})


def DATA(direction, score):
    e = 2650.0
    sl = e - 14 if direction == "LONG" else e + 14
    sgn = 1 if direction == "LONG" else -1
    return {"symbol": "ETH", "pair": "ETH/USDT", "interval": "15m", "price": e,
            "generated_at": "x", "direction": direction, "internal_score": score,
            "total_score": score, "confidence": 60.0, "atr": 10.0,
            "technical": {"supports": [], "resistances": []},
            "plan": {"direction": direction, "entry": e, "stop_loss": sl,
                     "take_profits": [{"price": e + sgn * 10}, {"price": e + sgn * 20},
                                      {"price": e + sgn * 32}]}}


def pos_dirs():
    return sorted(("LONG" if p.type == 0 else "SHORT") for p in b.positions.values())


print("=" * 72)
print(" گاردِ پوزیشن: نه تکراریِ هم‌جهت، نه خرید/فروشِ همزمان")
print("=" * 72)

# ─── ۱) مسیرِ خودکار: ارسالِ اول
app._last_dispatch_dir.clear()
app._program_auto_dispatch(DATA("LONG", 40), "ETH", "15m", broker="ETHUSD.z")
chk("خودکار: معاملهٔ اول باز شد", pos_dirs() == ["LONG"], pos_dirs())

# ─── ۲) هم‌جهتِ تکراری با «کلیدِ متفاوت» (تایم‌فریمِ دیگر + ری‌استارتِ شبیه‌سازی‌شده)
app._last_dispatch_dir.clear()          # شبیه‌سازیِ ری‌استارتِ برنامه
app._program_auto_dispatch(DATA("LONG", 45), "ETH", "5m", broker="ETHUSD.z")
chk("خودکار: هم‌جهتِ تکراری (tf دیگر/ری‌استارت) باز نشد", pos_dirs() == ["LONG"], pos_dirs())
app._program_auto_dispatch(DATA("LONG", 45), "ETH", "15m", broker="ETHUSD.z")
chk("خودکار: هم‌جهتِ تکراری (همان tf) باز نشد", pos_dirs() == ["LONG"], pos_dirs())

# ─── ۳) دستورالعملِ کاربر (REVERSE-001، پیش‌فرض): سیگنالِ مخالف → بستنِ قبلی + بازکردنِ معکوس
app._last_dispatch_dir.clear()
app._program_auto_dispatch(DATA("SHORT", -45), "ETH", "15m", broker="ETHUSD.z")
chk("reverse: پوزیشنِ LONG بسته و SHORT باز شد (هیچ هجی نه)", pos_dirs() == ["SHORT"], pos_dirs())
import server_log as _sl
_revlogs = [x for x in _sl.get(limit=100) if "بستنِ پوزیشن(های) مخالف" in (x.get("msg") or "")]
chk("reverse: بستنِ مخالف در لاگ ثبت شد", len(_revlogs) >= 1, len(_revlogs))

# ─── ۴) حالتِ close: فقط بستن، بدونِ معاملهٔ جدید
dispatch.save_config({"program_opposite_action": "close"})
app._last_dispatch_dir.clear()
app._program_auto_dispatch(DATA("LONG", 45), "ETH", "15m", broker="ETHUSD.z")
chk("close: پوزیشنِ SHORT بسته شد و معاملهٔ جدیدی باز نشد", pos_dirs() == [], pos_dirs())

# ─── ۴ب) حالتِ block: نگه‌داشتنِ پوزیشن و ردِ سیگنالِ مخالف
dispatch.save_config({"program_opposite_action": "block"})
app._last_dispatch_dir.clear()
app._program_auto_dispatch(DATA("LONG", 45), "ETH", "15m", broker="ETHUSD.z")  # باز می‌شود (خالی بود)
chk("block: معاملهٔ اول باز شد", pos_dirs() == ["LONG"], pos_dirs())
app._last_dispatch_dir.clear()
app._program_auto_dispatch(DATA("SHORT", -45), "ETH", "15m", broker="ETHUSD.z")
chk("block: پوزیشن نگه داشته شد و سیگنالِ مخالف رد شد", pos_dirs() == ["LONG"], pos_dirs())
dispatch.save_config({"program_opposite_action": "reverse"})
b.positions.clear(); mb._pos_state.clear(); mb._partial_plans.clear()
app._last_dispatch_dir.clear()
app._program_auto_dispatch(DATA("SHORT", -45), "ETH", "15m", broker="ETHUSD.z")
chk("پس از پاک‌سازی: جهتِ جدید آزاد", pos_dirs() == ["SHORT"], pos_dirs())

# ─── ۵) خاموش‌کردنِ گاردها (انتخابِ کاربر) → رفتارِ قبلی
dispatch.save_config({"program_block_duplicate_open": False,
                      "program_block_opposite_open": False})
app._last_dispatch_dir.clear()
app._program_auto_dispatch(DATA("LONG", 40), "ETH", "15m", broker="ETHUSD.z")
chk("گاردها خاموش → هج/تکرار به انتخابِ کاربر ممکن است", sorted(pos_dirs()) == ["LONG", "SHORT"],
    pos_dirs())
dispatch.save_config({"program_block_duplicate_open": True,
                      "program_block_opposite_open": True})
b.positions.clear()

# ─── ۶) مسیرِ دستی/خودکارِ UI (/api/mt5/send)
_real_sig = app._signal_for
app._signal_for = lambda s, tf, with_ai=False, **k: (DATA("LONG", 40), "ETH", None)
r = client.post("/api/mt5/send", json={"symbol": "ETH", "tf": "15m", "direction": "LONG"})
chk("دستی: معاملهٔ اول باز شد", r.status_code == 200 and pos_dirs() == ["LONG"],
    (r.status_code, pos_dirs()))
r = client.post("/api/mt5/send", json={"symbol": "ETH", "tf": "15m", "direction": "SHORT"})
d = r.get_json() or {}
chk("دستی: معاملهٔ مخالف → 409 با پیامِ هج", r.status_code == 409 and d.get("opposite") is True
    and "همزمان" in (d.get("error") or ""), (r.status_code, str(d)[:100]))
chk("دستی: هجی باز نشد", pos_dirs() == ["LONG"], pos_dirs())
r = client.post("/api/mt5/send", json={"symbol": "ETH", "tf": "15m", "direction": "SHORT",
                                       "allow_opposite": True})
chk("دستی: هجِ عمدی با allow_opposite ممکن است", r.status_code == 200
    and sorted(pos_dirs()) == ["LONG", "SHORT"], (r.status_code, pos_dirs()))
app._signal_for = _real_sig

# ─── ۷) UI و لاگ
ui = open("static/index.html", encoding="utf-8").read()
chk("UI: سوئیچ‌های گارد در تبِ روش ارسال", 'id="dp_blockdup"' in ui and 'id="dp_blockopp"' in ui, "")
chk("UI: ذخیرهٔ کلیدهای گارد", "program_block_duplicate_open" in ui
    and "program_block_opposite_open" in ui, "")
chk("UI: منوی رفتارِ سیگنالِ مخالف (reverse/close/block)",
    'id="dp_oppact"' in ui and "بازکردنِ معاملهٔ معکوس" in ui, "")
import server_log
logs = [x for x in server_log.get(limit=300) if "گاردِ پوزیشن" in (x.get("msg") or "")]
chk("لاگ: علتِ مسدودی ثبت شده (بدونِ اسپم)", 1 <= len(logs) <= 6, len(logs))

mh.status = _mh
b.positions.clear()
for i, f in enumerate(("mt5_config.json", "dispatch_config.json")):
    shutil.copy(f"/tmp/pc_{i}.bak", f)
print("\n" + "=" * 72)
print(f"  نتیجه: {PASS} پاس · {FAIL} ناموفق")
print("=" * 72)
raise SystemExit(1 if FAIL else 0)
