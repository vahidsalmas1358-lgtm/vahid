"""زمان‌بندِ پس‌زمینه برای اخبار: اعلان پیش از رویدادهای پرتأثیر + بستن خودکار پوزیشن‌ها.

هر ۶۰ ثانیه تقویم را بررسی می‌کند و:
  ۱) اگر «اعلان اخبار» روشن باشد، برای رویدادهای پرتأثیرِ نزدیک (تا news_alert_before_min دقیقه)
     یک پیام تلگرام/ایمیل می‌فرستد (هر رویداد فقط یک بار).
  ۲) اگر «بستن خودکار پیش از اخبار» روشن باشد، تا news_close_before_min دقیقه مانده به رویداد،
     پوزیشن‌های مرتبط (یا همه) را می‌بندد (هر رویداد فقط یک بار).

تنظیمات از mt5_config خوانده می‌شوند (کلیدهای news_alert_* و news_close_*).
"""
from __future__ import annotations

import time
import threading

import news
import alerts
import dispatch
import mt5_bridge

IMPACT_RANK = {"holiday": 0, "low": 1, "medium": 2, "high": 3}
MAJORS = ["USD", "EUR", "GBP", "JPY"]

_state = {"thread": None, "stop": None, "running": False,
          "last_run": None, "last_error": None, "actions": []}
_alerted: set = set()   # کلید رویدادهایی که اعلان‌شان رفته
_closed: set = set()    # کلید رویدادهایی که بستن‌شان انجام شده


def _key(e) -> str:
    return f"{e.get('title','')}|{e.get('country','')}|{e.get('ts')}"


def _prune_seen(now: float) -> None:
    """هرسِ کلیدهای رویدادهای گذشته (جلوگیری از رشدِ بی‌پایانِ حافظه در اجرای طولانی).

    کلیدها به شکلِ "title|country|ts" هستند؛ رویدادهایی که بیش از یک روز از
    زمان‌شان گذشته دیگر هرگز دوباره بررسی نمی‌شوند، پس نگه‌داشتن‌شان لازم نیست.
    """
    cutoff = now - 86400
    for seen in (_alerted, _closed):
        stale = set()
        for k in seen:
            try:
                ts = float(k.rsplit("|", 1)[1])
            except Exception:  # noqa
                continue
            if ts < cutoff:
                stale.add(k)
        seen -= stale


def _fmt_event(e, mins) -> str:
    return (f"{e.get('impact','')} — {e.get('country','')} — {e.get('title','')}\n"
            f"⏱ حدود {int(mins)} دقیقه دیگر\n"
            f"پیش‌بینی: {e.get('forecast') or '—'} | قبلی: {e.get('previous') or '—'}")


def _record(kind, e, extra=None):
    _state["actions"] = ([{"ts": time.time(), "kind": kind,
                           "title": e.get("title"), "country": e.get("country"),
                           "extra": extra}] + _state["actions"])[:50]


def _run_once():
    cfg = mt5_bridge.load_config()
    alert_on = cfg.get("news_alert_enabled")
    close_on = cfg.get("news_autoclose_enabled")
    if not alert_on and not close_on:
        return
    # منبعِ تقویم را از تنظیماتِ مرکزی (تبِ «روشِ ارسالِ سیگنال») بخوان تا
    # هشدار/بستنِ خودکار با همان تقویمی کار کند که فیلترِ اخبار استفاده می‌کند.
    try:
        _src = dispatch.load_config().get("news_source", "both")
    except Exception:  # noqa
        _src = "both"
    res = news.fetch(source=_src)
    if not res.get("ok"):
        _state["last_error"] = res.get("error")
        return
    now = time.time()
    _prune_seen(now)

    # --- اعلان پیش از رویداد ---
    if alert_on:
        rank = IMPACT_RANK.get(str(cfg.get("news_alert_impact", "High")).lower(), 3)
        before = float(cfg.get("news_alert_before_min", 30)) * 60
        ccy = set(c.upper() for c in (cfg.get("news_alert_currencies") or MAJORS))
        for e in res["events"]:
            if e["impact_rank"] < rank or e["country"] not in ccy:
                continue
            dt = e["ts"] - now
            if 0 < dt <= before and _key(e) not in _alerted:
                mins = dt / 60
                text = "📰 هشدار خبر مهم پیش‌رو\n\n" + _fmt_event(e, mins)
                sent = {}
                acfg = alerts.load_config()
                if acfg.get("telegram", {}).get("enabled"):
                    sent["telegram"] = alerts.send_telegram(text)
                if acfg.get("email", {}).get("enabled"):
                    sent["email"] = alerts.send_email(
                        f"هشدار خبر: {e.get('country')} {e.get('title')}",
                        "<pre>" + text + "</pre>")
                # اصلاح (NEWS-002): اگر هیچ کانالی تحویل موفق نداشت، کلید ثبت نشود
                # تا در چرخهٔ بعدی دوباره تلاش شود (قبلاً اعلانِ شکست‌خورده می‌سوخت).
                delivered = any(bool((v or {}).get("ok")) for v in sent.values())
                if delivered or not sent:
                    _alerted.add(_key(e))
                _record("alert", e, {"mins": round(mins), "sent": list(sent.keys()),
                                     "delivered": delivered})

    # --- بستن خودکار پیش از رویداد ---
    if close_on:
        rank = IMPACT_RANK.get(str(cfg.get("news_close_impact", "High")).lower(), 3)
        before = float(cfg.get("news_close_before_min", 15)) * 60
        scope = cfg.get("news_close_scope", "matching")
        for e in res["events"]:
            if e["impact_rank"] < rank:
                continue
            dt = e["ts"] - now
            if 0 < dt <= before and _key(e) not in _closed:
                try:
                    r = mt5_bridge.close_for_news([e["country"]], scope=scope)
                    n = len(r.get("closed", []))
                    # اصلاح (NEWS-001): کلید فقط پس از بستنِ موفق ثبت می‌شود تا در
                    # صورت timeout/خطا، چرخهٔ بعدی دوباره تلاش کند.
                    if r.get("ok"):
                        _closed.add(_key(e))
                    _record("autoclose", e, {"closed": n, "ok": r.get("ok")})
                    # در صورت بستن، به کاربر هم اطلاع بده
                    if n:
                        acfg = alerts.load_config()
                        msg = (f"🛑 بستن خودکار پیش از خبر «{e.get('title')}» ({e.get('country')}) — "
                               f"{n} پوزیشن بسته شد.")
                        if acfg.get("telegram", {}).get("enabled"):
                            alerts.send_telegram(msg)
                except Exception as ex:  # noqa
                    _state["last_error"] = str(ex)


def _loop():
    stop = _state["stop"]
    while not stop.is_set():
        try:
            _run_once()
            _state["last_run"] = time.time()
        except Exception as ex:  # noqa
            _state["last_error"] = str(ex)
        stop.wait(60)
    _state["running"] = False


_start_lock = threading.RLock()   # OP5-CORE-16: check-then-start اتمیک


def start():
    # دو فراخوانِ همزمان (یا اجرای WSGI) قبلاً می‌توانستند دو thread بسازند.
    with _start_lock:
        if _state["running"] and _state["thread"] and _state["thread"].is_alive():
            return status()
        _state["stop"] = threading.Event()
        _state["running"] = True
        th = threading.Thread(target=_loop, name="news-scheduler", daemon=True)
        _state["thread"] = th
        th.start()
    return status()


def stop():
    if _state["stop"]:
        _state["stop"].set()
    _state["running"] = False
    return status()


def status() -> dict:
    return {
        "running": bool(_state["running"] and _state["thread"]
                        and _state["thread"].is_alive()),
        "last_run": _state["last_run"],
        "last_error": _state["last_error"],
        "recent_actions": _state["actions"][:15],
        "alerted": len(_alerted),
    }
