# -*- coding: utf-8 -*-
"""رگرسیونِ AI-CTX-001 — «مدل می‌گفت به اینترنت دسترسی ندارم».

ریشه: پرسشِ آزادِ کاربر (/api/ai/ask و ask_stream) خام به مدل می‌رفت؛ مدلِ زبانی
اینترنت ندارد و حق داشت بگوید «دسترسی ندارم». اکنون برنامه دادهٔ زندهٔ بازار
(قیمت/اندیکاتورها/سطوح/نقشه/فاندامنتال/سنتیمنت/وضعیت بازار) را خودش داخل پیام
می‌گذارد + دستورِ صریح که «به اینترنت نیاز نداری و نگو دسترسی ندارم».

این تست با مدلِ ماک، دقیقاً متنِ رسیده به مدل را می‌سنجد.
"""
import os as _os_env; _os_env.environ.setdefault("BTC_AGENT_ALLOW_INSECURE_ROBOT", "1")  # محیط تست
import app
import ai_bridge

PASS = 0
FAIL = 0


def chk(name, cond, detail=""):
    global PASS, FAIL
    if cond:
        PASS += 1
    else:
        FAIL += 1
        print(f"   FAIL  {name} — {str(detail)[:220]}")


app.app.config["TESTING"] = True
client = app.app.test_client()

# سیگنالِ ساختگیِ کامل به‌جای واکشیِ شبکه (قالبِ واقعیِ data)
DATA = {
    "symbol": "ETH", "pair": "ETH/USDT", "interval": "15m", "price": 2654.32,
    "generated_at": "2026-10-04 10:00 UTC", "data_source": "OKX",
    "direction": "SHORT", "internal_score": -41.0, "total_score": -41.0,
    "confidence": 63.0, "atr": 11.5,
    "market": {"open": True, "asset_class": "crypto", "reason_fa": "بازار کریپتو ۲۴/۷"},
    "technical": {"score": -38.0, "rsi": 36.2, "trend": "down", "atr": 11.5,
                  "supports": [2640.0, 2611.0], "resistances": [2667.0, 2690.0],
                  "signals": [{"name": "RSI (14)", "value": "36.2", "dir": -1}]},
    "fundamental": {"score": -10.0, "available": True, "market_cap": 200e9,
                    "signals": [{"name": "تغییر ۲۴ ساعته", "value": "-1.2%", "dir": -1}]},
    "sentiment": {"score": -20.0, "title": "شاخص ترس و طمع", "value": 71,
                  "classification": "Greed", "kind": "fng"},
    "plan": {"direction": "SHORT", "entry": 2654.0, "stop_loss": 2668.5, "rr": 2.4,
             "note": "پلن تستی",
             "take_profits": [{"price": 2640.0}, {"price": 2628.0}, {"price": 2612.0}]},
}
_real_sig = app._signal_for
app._signal_for = lambda sym, tf, with_ai=False: (DATA, "ETH", None)

CAPTURED = {}
_real_chat = ai_bridge.chat
_real_stream = ai_bridge.chat_stream


def fake_chat(prompt, **kw):
    CAPTURED["prompt"] = prompt
    return {"ok": True, "content": "تحلیل انجام شد.", "model": "mock"}


def fake_stream(prompt, **kw):
    CAPTURED["sprompt"] = prompt
    yield {"delta": "تحلیل "}
    yield {"delta": "شد.", "done": True}


ai_bridge.chat = fake_chat
ai_bridge.chat_stream = fake_stream

print("=" * 70)
print(" AI-CTX-001: مدل بدونِ اینترنت باید دادهٔ زنده را از خودِ برنامه بگیرد")
print("=" * 70)

# ➊ ask با پیوست (پیش‌فرض)
r = client.post("/api/ai/ask", json={"prompt": "بازار را تحلیل کن",
                                     "symbol": "ETH", "tf": "15m"})
d = r.get_json() or {}
p = CAPTURED.get("prompt", "")
chk("پاسخ ۲۰۰ و ok", r.status_code == 200 and d.get("ok") is True, r.status_code)
chk("دادهٔ زنده داخل پیام است (قیمت)", "2654.32" in p, p[:80])
chk("نقشهٔ معامله داخل پیام است (SL)", "2668.5" in p, "")
chk("اندیکاتور داخل پیام است (RSI)", "RSI (14)" in p and "36.2" in p, "")
chk("سنتیمنت داخل پیام است", "ترس و طمع" in p, "")
chk("دستورِ «به اینترنت نیاز نداری» در پیام", "به اینترنت" in p and "نیاز نداری" in p, "")
chk("منعِ گفتنِ «دسترسی ندارم»", "دسترسی ندارم" in p, "")
chk("پرسشِ کاربر انتهای پیام", p.rstrip().endswith("بازار را تحلیل کن"), p[-50:])
chk("متادیتای پیوست در پاسخ", (d.get("data") or {}).get("market_attached") is True
    and (d.get("data") or {}).get("market_symbol") == "ETH", d.get("data", {}).get("market_attached"))

# ➋ ask بدونِ پیوست (کاربر خاموش کرده)
CAPTURED.clear()
r = client.post("/api/ai/ask", json={"prompt": "سلام", "attach_market": False})
p = CAPTURED.get("prompt", "")
chk("attach_market=false → پرسشِ خام", p == "سلام", p[:60])
chk("متادیتا: market_attached=false",
    ((r.get_json() or {}).get("data") or {}).get("market_attached") is False, "")

# ➌ ask_stream با پیوست + رویدادِ meta در جریان
CAPTURED.clear()
r = client.post("/api/ai/ask_stream", json={"prompt": "روند چیست؟",
                                            "symbol": "ETH", "tf": "15m"})
body = r.get_data(as_text=True)
sp = CAPTURED.get("sprompt", "")
chk("stream: پاسخ ۲۰۰ و SSE", r.status_code == 200 and "data:" in body, r.status_code)
chk("stream: دادهٔ زنده در پیامِ مدل", "2654.32" in sp and "نیاز نداری" in sp, sp[:80])
chk("stream: رویدادِ meta با market_attached", '"market_attached": true' in body
    or '"market_attached":true' in body, body[:120])
chk("stream: پرسشِ کاربر انتهای پیام", sp.rstrip().endswith("روند چیست؟"), sp[-40:])

# ➍ خطای واکشی سیگنال → بدونِ پیوست ولی بدونِ شکستِ درخواست
app._signal_for = lambda *a, **k: (_ for _ in ()).throw(RuntimeError("قطع داده"))
CAPTURED.clear()
r = client.post("/api/ai/ask", json={"prompt": "تحلیل کن"})
d = r.get_json() or {}
chk("قطعِ منبعِ داده → درخواست نمی‌شکند و خام می‌رود",
    r.status_code == 200 and CAPTURED.get("prompt") == "تحلیل کن"
    and (d.get("data") or {}).get("market_attached") is False, str(d)[:100])

# ➎ سقفِ طول همچنان روی «پرسشِ کاربر» است نه مجموع
app._signal_for = lambda sym, tf, with_ai=False: (DATA, "ETH", None)
r = client.post("/api/ai/ask", json={"prompt": "x" * 11999})
chk("پرسشِ ۱۱۹۹۹ نویسه‌ای + پیوست پذیرفته می‌شود", r.status_code == 200, r.status_code)
r = client.post("/api/ai/ask", json={"prompt": "x" * 12001})
chk("پرسشِ >۱۲۰۰۰ نویسه رد می‌شود (413)", r.status_code == 413, r.status_code)

# ➏ تب UI: چک‌باکس و ارسالِ نماد/تایم‌فریم
ui = open("static/index.html", encoding="utf-8").read()
chk("UI: چک‌باکس ai_ctx موجود و پیش‌فرض روشن", 'id="ai_ctx" checked' in ui, "")
chk("UI: بدنهٔ stream شامل symbol/tf/attach_market",
    "attach_market:attach" in ui and "symbol:currentSym,tf:currentTF" in ui, "")

ai_bridge.chat = _real_chat
ai_bridge.chat_stream = _real_stream
app._signal_for = _real_sig

print("\n" + "=" * 70)
print(f"  نتیجه: {PASS} پاس · {FAIL} ناموفق")
print("=" * 70)
raise SystemExit(1 if FAIL else 0)
