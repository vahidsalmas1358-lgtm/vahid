@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
cd /d "%~dp0"

REM ============================================================================
REM  run.bat  --  راه‌اندازِ دائمیِ داشبورد تحلیل روی ویندوز (و VPS ویندوز)
REM  خودکار: پیدا کردنِ پایتون -> ساختِ .venv -> نصبِ کتابخانه‌ها -> اجرا با ری‌استارت
REM  توقف: پنجره را ببندید یا Ctrl+C بزنید.
REM  تغییرِ پورت:  set PORT=9000  و سپس run.bat
REM ============================================================================

if "%PORT%"=="" set "PORT=8000"

echo ============================================================
echo    داشبورد تحلیل  --  راه‌اندازِ ویندوز
echo ============================================================

REM --- پیدا کردنِ پایتون (اول py -3 سپس python) ---
set "PYLAUNCH="
py -3 --version >nul 2>nul && set "PYLAUNCH=py -3"
if not defined PYLAUNCH (
  python --version >nul 2>nul && set "PYLAUNCH=python"
)
if not defined PYLAUNCH (
  echo [X] پایتون پیدا نشد.
  echo     لطفاً Python 3.10 یا بالاتر را از این آدرس نصب کنید:
  echo         https://www.python.org/downloads/windows/
  echo     و هنگام نصب حتماً گزینه  "Add Python to PATH"  را تیک بزنید.
  pause
  exit /b 1
)
echo [1/4] پایتون یافت شد: %PYLAUNCH%

REM --- ساختِ محیطِ مجازی فقط بارِ اول ---
if not exist ".venv\Scripts\python.exe" (
  echo [2/4] ساختِ محیطِ مجازی .venv ...
  %PYLAUNCH% -m venv .venv
  if errorlevel 1 (
    echo [X] ساختِ محیطِ مجازی ناموفق بود.
    pause
    exit /b 1
  )
) else (
  echo [2/4] محیطِ مجازی از قبل موجود است.
)
set "VENV_PY=.venv\Scripts\python.exe"

REM --- نصبِ کتابخانه‌ها فقط وقتی flask نصب نباشد ---
"%VENV_PY%" -c "import flask" >nul 2>nul
if errorlevel 1 (
  echo [3/4] نصبِ کتابخانه‌ها ... (فقط بارِ اول کمی طول می‌کشد)
  "%VENV_PY%" -m pip install --upgrade pip
  "%VENV_PY%" -m pip install -r requirements.txt
  if errorlevel 1 (
    echo [X] نصبِ کتابخانه‌ها ناموفق بود. اتصالِ اینترنت را بررسی کنید.
    pause
    exit /b 1
  )
) else (
  echo [3/4] کتابخانه‌ها از قبل نصب‌اند.
)

echo [4/4] اجرای سرور ...
echo ------------------------------------------------------------
echo    داشبورد:  http://127.0.0.1:%PORT%
echo    توقف   :  Ctrl+C  یا بستنِ این پنجره
echo ------------------------------------------------------------
start "" http://127.0.0.1:%PORT%

:loop
"%VENV_PY%" app.py
echo.
echo سرور متوقف شد؛ راه‌اندازیِ مجدد تا ۳ ثانیهٔ دیگر ... (برای خروج Ctrl+C)
timeout /t 3 /nobreak >nul
goto loop

endlocal
