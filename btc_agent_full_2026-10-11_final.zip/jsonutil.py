"""کمکی‌های مشترک (OP5-CORE): نوشتنِ اتمیکِ JSON + ابزارهای عددیِ ایمن.

نوشتنِ مستقیم با open(path, "w") فایل را truncate می‌کند؛ اگر فرایند وسطِ نوشتن
متوقف شود، فایلِ تنظیمات ناقص می‌ماند و ماژول بعدی آن را با پیش‌فرض جایگزین
می‌کند (از دست رفتنِ تنظیماتِ معاملاتی). این ماژول نوشتن را با temp + fsync +
os.replace (اتمیک در POSIX/ویندوز) انجام می‌دهد.
"""
from __future__ import annotations

import json
import math
import os
import tempfile


def atomic_write_json(path: str, value, indent: int = 2) -> None:
    """JSON را به‌صورت اتمیک در path می‌نویسد (temp file + fsync + os.replace)."""
    directory = os.path.dirname(path) or "."
    fd, tmp = tempfile.mkstemp(prefix=".config-", suffix=".tmp", dir=directory)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(value, f, ensure_ascii=False, indent=indent)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
    finally:
        try:
            os.unlink(tmp)
        except FileNotFoundError:
            pass


def as_bool(v, default: bool = False) -> bool:
    """تبدیلِ ایمنِ مقدار به bool؛ رشته‌های \"false\"/\"0\"/\"off\" دیگر True نمی‌شوند."""
    if v is None:
        return bool(default)
    if isinstance(v, str):
        return v.strip().lower() not in ("", "0", "false", "no", "off", "none")
    return bool(v)


def finite_number(v, default=None):
    """عددِ متناهی یا default (bool و NaN/inf رد می‌شوند)."""
    if isinstance(v, bool) or v is None:
        return default
    try:
        f = float(v)
    except (TypeError, ValueError):
        return default
    return f if math.isfinite(f) else default


def is_finite(v) -> bool:
    return finite_number(v, None) is not None
