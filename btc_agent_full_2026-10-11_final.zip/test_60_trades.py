"""آزمونِ جامعِ صحتِ برنامه با ۶۰ معاملهٔ واقعی (خرید/فروش) روی نمادهای متنوع.

هدف: با دادهٔ واقعیِ بازار و کدِ واقعیِ برنامه (نه داده‌ی ساختگی)، درستیِ این بخش‌ها آزموده شود:
  ۱) ساختِ نقشهٔ معامله  (engine.build_trade_plan): ترتیبِ ورود/استاپ/سه TP، RR، دقتِ اعشار.
  ۲) مدیریتِ دقتِ اعشار روی نمادهایی با مقیاسِ قیمتِ کاملاً متفاوت (۰٫۰۹ تا ۸۴۰۰۰).
  ۳) موتورِ ارزیابیِ عملکرد (analytics.evaluate) روی مسیرِ قیمتِ واقعیِ پس از ورود.
  ۴) لایهٔ ذخیره‌سازی (SQLite): درج/بازخوانیِ صحیحِ ۶۰ رکورد.
  ۵) تجمیعِ تحلیلِ عملکرد (analytics.analyze): برابریِ آمارِ کل با جمعِ تک‌تکِ معاملات.

روشِ راستی‌آزمایی: هر معامله با یک ارزیابِ «مستقل» (پیاده‌سازیِ جداگانه در همین فایل)
دوباره ارزیابی می‌شود و باید مو‌به‌مو با خروجیِ موتورِ برنامه یکی باشد.
"""
from __future__ import annotations
import time
import engine
import analytics
import data_sources as ds
import db
import symbols as sym

# نمادها با مقیاسِ قیمت و اعشارِ متفاوت (۶ معامله برای هرکدام → ۶۰ معامله)
SYMBOLS = ["BTC", "ETH", "SOL", "XRP", "DOGE", "XAU", "XAG", "WTI", "EURUSD", "USDJPY"]
PER = 6
TF = "1h"
EPS = 1e-9


# ----------------------------------------------------------- ارزیابِ مستقل (برای راستی‌آزمایی)
def indep_eval(direction, entry, sl, tps, forward):
    tps = [float(t) for t in tps if t is not None]
    long = direction == "LONG"
    risk = (entry - sl) if long else (sl - entry)
    if risk <= 0 or not tps:
        return {"status": "skip"}
    n = len(tps)
    Rs = [((tp - entry) / risk) if long else ((entry - tp) / risk) for tp in tps]
    # همان مدلِ وزنیِ بستنِ analytics: ۴۰/۳۵/۲۵ (نرمال‌شده اگر تعدادِ TP≠۳)
    _base = [0.40, 0.35, 0.25][:n] or [1.0]
    _s = sum(_base) or 1.0
    fracs = [w / _s for w in _base]
    def realized(reached):
        return sum(Rs[k] * fracs[k] for k in range(reached))
    reached, be, bars = 0, False, 0
    for (t, o, h, l, c) in forward:
        bars += 1
        cur = reached
        while cur < n and ((h >= tps[cur]) if long else (l <= tps[cur])):
            cur += 1
        stop = entry if be else sl
        stopped = (l <= stop) if long else (h >= stop)
        if not be:
            if stopped:
                return {"status": "loss", "outcome": "SL", "reached": 0, "R": -1.0,
                        "fully_closed": True, "bars_held": bars}
            if cur >= 1:
                reached, be = cur, True
                if reached >= n:
                    return {"status": "win", "outcome": f"TP{reached}", "reached": reached,
                            "R": realized(reached), "fully_closed": True, "bars_held": bars}
        else:
            if cur > reached:
                reached = cur
                if reached >= n:
                    return {"status": "win", "outcome": f"TP{reached}", "reached": reached,
                            "R": realized(reached), "fully_closed": True, "bars_held": bars}
            if stopped:
                return {"status": "win", "outcome": f"TP{reached}", "reached": reached,
                        "R": realized(reached), "fully_closed": True, "bars_held": bars}
    if reached == 0:
        return {"status": "pending", "outcome": "OPEN", "reached": 0, "R": None,
                "fully_closed": False, "bars_held": bars}
    return {"status": "win", "outcome": f"TP{reached}", "reached": reached,
            "R": realized(reached), "fully_closed": False, "bars_held": bars}


def decimals_of(x):
    s = repr(float(x))
    if "e" in s or "E" in s:
        return 99
    return len(s.split(".")[1].rstrip("0")) if "." in s else 0


def main():
    checks = {"plan_order": [], "decimals": [], "rr": [], "eval_match": []}
    fails = []
    trades = []
    n_trade = 0

    for si, symbol in enumerate(SYMBOLS):
        try:
            df = ds.get_history(symbol, TF)
        except Exception as e:  # noqa
            fails.append(f"{symbol}: get_history failed: {e}")
            continue
        L = len(df)
        if L < 320:
            fails.append(f"{symbol}: too few bars ({L})")
            continue
        exp_dec = engine._dec(float(df["close"].iloc[-1]))
        rows = list(zip(df["time"].tolist(), df["open"].tolist(), df["high"].tolist(),
                        df["low"].tolist(), df["close"].tolist()))

        lo, hi = 220, L - 60
        idxs = [int(lo + (hi - lo) * k / (PER - 1)) for k in range(PER)]
        for j, i in enumerate(idxs):
            n_trade += 1
            direction = "LONG" if (n_trade % 2 == 1) else "SHORT"   # ترکیبِ خرید/فروش
            sub = df.iloc[:i + 1]
            tech = engine.analyze_technical(sub)
            price = tech["price"]; atr = tech["atr"]; dec = engine._dec(price)
            plan = engine.build_trade_plan(
                direction, price, atr, tech["supports"], tech["resistances"],
                strength=45, dec=dec, fib=tech.get("fibonacci"),
                extra_sup=tech.get("conf_supports"), extra_res=tech.get("conf_resistances"))
            entry = plan["entry"]; slv = plan["stop_loss"]
            tps = [t["price"] for t in plan["take_profits"]]
            rrs = [t["rr"] for t in plan["take_profits"]]

            # (۱) ترتیبِ نقشه
            if direction == "LONG":
                order_ok = slv < entry < tps[0] < tps[1] < tps[2]
            else:
                order_ok = tps[2] < tps[1] < tps[0] < entry < slv
            checks["plan_order"].append(order_ok)
            if not order_ok:
                fails.append(f"{symbol} #{j} {direction}: ORDER e={entry} sl={slv} tps={tps}")

            # (۲) دقتِ اعشار — پویا و درست برای مقیاسِ قیمتِ همان معامله
            # قاعدهٔ مرجع (مستقل از کدِ برنامه) برای راستی‌آزمایی:
            def rule_dec(p):
                p = abs(p)
                return 2 if p >= 100 else 4 if p >= 1 else 5 if p >= 0.01 else 8
            exp = rule_dec(price)
            dec_vals_ok = all(decimals_of(v) <= dec for v in [entry, slv] + tps)
            dec_ok = dec_vals_ok and dec == exp
            checks["decimals"].append(dec_ok)
            if not dec_ok:
                fails.append(f"{symbol} #{j}: DECIMALS price={price} dec={dec} exp={exp} vals={[entry, slv]+tps}")

            # (۳) RR صعودی و مثبت
            rr_ok = all(r is not None and r > 0 for r in rrs) and rrs[0] <= rrs[1] <= rrs[2]
            checks["rr"].append(rr_ok)
            if not rr_ok:
                fails.append(f"{symbol} #{j}: RR {rrs}")

            # (۴) ارزیابیِ موتور در برابرِ ارزیابِ مستقل روی کندلِ واقعیِ بعدی
            forward = rows[i + 1:]
            r_eng = analytics.evaluate(direction, entry, slv, tps, forward)
            r_ind = indep_eval(direction, entry, slv, tps, forward)
            match = (r_eng.get("status") == r_ind.get("status")
                     and r_eng.get("outcome") == r_ind.get("outcome")
                     and r_eng.get("reached") == r_ind.get("reached")
                     and ((r_eng.get("R") is None and r_ind.get("R") is None)
                          or (r_eng.get("R") is not None and r_ind.get("R") is not None
                              and abs(r_eng["R"] - r_ind["R"]) < EPS)))
            checks["eval_match"].append(match)
            if not match:
                fails.append(f"{symbol} #{j}: EVAL mismatch eng={r_eng} ind={r_ind}")

            ts = int(df["time"].iloc[i] / 1000)
            cfg = sym.get(symbol)
            trades.append({
                "ts": ts, "key": f"{symbol}:{TF}", "symbol": symbol, "pair": cfg["pair"],
                "interval": TF, "direction": direction, "price": price,
                "score": (tech["score"] if direction == "LONG" else -abs(tech["score"])),
                "entry": entry, "stop_loss": slv, "take_profits": tps,
                "generated_at": time.strftime("%Y-%m-%d %H:%M UTC", time.gmtime(ts)),
                "_eval": r_eng, "_dec": dec, "_exp_dec": exp_dec,
            })

    # (۵) ذخیره‌سازی: پاک‌سازی و درجِ ۶۰ معامله، سپس بازخوانی
    db.clear_signals()
    for tr in trades:
        db.add_signal(tr)
    n_db = db.count_signals()
    read_back = db.get_signals(limit=100)
    store_ok = (n_db == len(trades) == 60)
    # صحتِ round-trip: مقایسهٔ چند فیلد
    rt_ok = True
    by_key = {}
    for r in read_back:
        by_key.setdefault((r["symbol"], r["direction"]), []).append(r)
    # تطبیق مجموعِ TPها
    sum_tps_in = sum(len(t["take_profits"]) for t in trades)
    sum_tps_out = sum(len(r["take_profits"]) for r in read_back)
    rt_ok = (sum_tps_in == sum_tps_out)

    # (۶) تجمیعِ analytics.analyze در برابرِ جمعِ مستقلِ همین ۶۰
    rep = analytics.analyze()
    s = rep["summary"]
    my_wins = sum(1 for t in trades if t["_eval"]["status"] == "win")
    my_loss = sum(1 for t in trades if t["_eval"]["status"] == "loss")
    my_pend = sum(1 for t in trades if t["_eval"]["status"] == "pending")
    my_R = round(sum(t["_eval"]["R"] for t in trades if t["_eval"]["R"] is not None), 2)
    agg_ok = (s["n_total"] == 60 and s["n_wins"] == my_wins
              and s["n_losses"] == my_loss and s["n_pending"] == my_pend
              and abs((s["total_R"] or 0) - my_R) < 0.02)

    # ---------------------------------------------------------- گزارش
    def rate(key):
        arr = checks[key]
        return sum(arr), len(arr)

    print("=" * 64)
    print("گزارشِ آزمونِ ۶۰ معاملهٔ واقعی")
    print("=" * 64)
    scales = {}
    for t in trades:
        e = scales.setdefault(t["symbol"], {"pmin": t["price"], "pmax": t["price"], "decs": set()})
        e["pmin"] = min(e["pmin"], t["price"]); e["pmax"] = max(e["pmax"], t["price"])
        e["decs"].add(t["_dec"])
    print("\nنمادها و مقیاسِ قیمت و اعشارِ (پویا) استفاده‌شده:")
    for symn in SYMBOLS:
        if symn in scales:
            e = scales[symn]
            decs = "،".join(str(d) for d in sorted(e["decs"]))
            print(f"  {symn:7s} price {e['pmin']:.6g} … {e['pmax']:.6g}   decimals={decs}")
    print(f"\nتعدادِ کلِ معاملات: {len(trades)}  (خرید/فروش متناوب)")
    print("\n— نتایجِ صحت‌سنجی —")
    for key, fa in [("plan_order", "ترتیبِ ورود/استاپ/TP"),
                    ("decimals", "دقتِ اعشار"),
                    ("rr", "RR مثبت و صعودی"),
                    ("eval_match", "تطابقِ موتورِ ارزیابی با ارزیابِ مستقل")]:
        ok, tot = rate(key)
        print(f"  {fa:42s} {ok}/{tot}  {'✅' if ok == tot else '❌'}")
    print(f"  {'ذخیره‌سازی (۶۰ درج/بازخوانی)':42s} {'✅' if store_ok and rt_ok else '❌'}"
          f"  (db={n_db}, tps_in={sum_tps_in}, tps_out={sum_tps_out})")
    print(f"  {'تجمیعِ analytics == جمعِ مستقل':42s} {'✅' if agg_ok else '❌'}")

    print("\n— خلاصهٔ عملکردِ ۶۰ معامله (از analytics.analyze) —")
    print(f"  برد={s['n_wins']}  باخت={s['n_losses']}  در جریان={s['n_pending']}"
          f"  | win-rate(تعیین‌شده‌ها)={s['win_rate']}%")
    print(f"  مجموع R={s['total_R']}  میانگین R={s['avg_R']}  profit factor={s['profit_factor']}")
    print(f"  نرخِ TP1/TP2/TP3 = {s['tp1_rate']}% / {s['tp2_rate']}% / {s['tp3_rate']}%")
    print(f"  (راستی‌آزماییِ مستقل: برد={my_wins} باخت={my_loss} درجریان={my_pend} مجموعR={my_R})")

    print("\n— تفکیک بر اساسِ جهت —")
    for a in rep["by_direction"]:
        print(f"  {a['key']:6s} n={a['n_total']:2d} win={a['win_rate']} ΣR={a['total_R']} pend={a['n_pending']}")
    print("\n— تفکیک بر اساسِ نماد —")
    for a in rep["by_symbol"]:
        print(f"  {a['key']:7s} n={a['n_total']:2d} win={a['win_rate']} ΣR={a['total_R']} pend={a['n_pending']}")

    print("\n— نمونه معاملات (۱۲ ردیفِ اول) —")
    print(f"  {'symbol':7s} {'dir':5s} {'entry':>12s} {'SL':>12s} {'TP1':>12s} {'res':>6s} {'R':>7s}")
    for t in trades[:12]:
        e = t["_eval"]
        rr = f"{e['R']:.2f}" if e["R"] is not None else "—"
        print(f"  {t['symbol']:7s} {t['direction']:5s} {t['entry']:>12.6g} {t['stop_loss']:>12.6g}"
              f" {t['take_profits'][0]:>12.6g} {e['outcome']:>6s} {rr:>7s}")

    all_ok = (all(all(checks[k]) for k in checks) and store_ok and rt_ok and agg_ok and not fails)
    print("\n" + "=" * 64)
    print(f"نتیجهٔ کلی: {'✅ همهٔ آزمون‌ها موفق' if all_ok else '❌ برخی آزمون‌ها ناموفق'}")
    if fails:
        print(f"\nخطاها ({len(fails)}):")
        for f in fails[:20]:
            print("  -", f)
    print("=" * 64)
    return 0 if all_ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
