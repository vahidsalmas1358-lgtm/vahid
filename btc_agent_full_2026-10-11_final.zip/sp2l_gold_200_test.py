# -*- coding: utf-8 -*-
"""۲۰۰ معاملهٔ بازسازی‌شدهٔ رباتِ SP2L_Advanced روی طلا (XAUUSD).

روش بازسازی:
  • دادهٔ واقعیِ کندلِ طلا از منابعِ خودِ برنامه (Yahoo GC=F) در ۵ تایم‌فریم.
  • در هر نقطهٔ ورود، منطقِ روندیِ SP2L بازسازی می‌شود: EMA20/EMA50 → جهت،
    ATR14 → حدِ ضرر (×1.2) و تک‌حدِ سود (×1.8) — دقیقاً مثلِ payloadِ واقعیِ ربات
    (تک‌TP، حجم 0.01، magic=8).
  • هر سفارش از مسیرِ واقعیِ پلِ ربات (POST /api/robot/test) عبور می‌کند تا
    نرمال‌سازی/تأیید هم آزموده شود.
  • سرنوشتِ معامله روی کندل‌های بعدیِ همان دادهٔ واقعی بازسازی می‌شود:
    برخورد با TP → برد، برخورد با SL → باخت؛ اگر هر دو در یک کندل باشند،
    محافظه‌کارانه «باخت» ثبت می‌شود؛ اگر تا ۴۰ کندل هیچ‌کدام نخورد،
    با قیمتِ پایانیِ کندلِ چهلم بسته می‌شود (timeout).
  • PnL دلاری با حجمِ واقعیِ ربات (0.01 لات = ۱ اونس → ۱$ به ازای هر ۱$ حرکت).
"""
import json
import sys
import urllib.request

sys.path.insert(0, ".")
import data_sources as ds  # noqa: E402

BASE = "http://127.0.0.1:8000"
HORIZON = 40          # حداکثر کندلِ انتظار برای TP/SL
SL_ATR, TP_ATR = 1.2, 1.8
OZ = 1.0              # 0.01 لات طلا = ۱ اونس
PLAN = [("15m", 60), ("30m", 40), ("1h", 40), ("2h", 30), ("4h", 30)]  # = ۲۰۰


def http(method, path, body=None, timeout=60):
    req = urllib.request.Request(BASE + path, method=method)
    data = None
    if body is not None:
        data = json.dumps(body).encode()
        req.add_header("Content-Type", "application/json")
    with urllib.request.urlopen(req, data=data, timeout=timeout) as r:
        return json.loads(r.read().decode())


def sp2l_payload(direction, entry, sl, tp):
    """عینِ payloadِ واقعیِ SP2L_Advanced_Bot (تک‌TP، پایتون، magic=8)."""
    return {"symbol": "XAUUSD", "direction": direction, "volume": 0.01,
            "entry": round(entry, 2), "sl": round(sl, 2), "tp": round(tp, 2),
            "magic": 8, "robot_id": "SP2L_Advanced",
            "comment": "SP2L Advanced Trader", "platform": "python"}


def ema(vals, n):
    k = 2.0 / (n + 1)
    out, e = [], None
    for v in vals:
        e = v if e is None else v * k + e * (1 - k)
        out.append(e)
    return out


def atr14(h, l, c):
    trs, out, prev = [], [], None
    for i in range(len(c)):
        tr = h[i] - l[i] if i == 0 else max(h[i] - l[i],
                                            abs(h[i] - c[i - 1]),
                                            abs(l[i] - c[i - 1]))
        trs.append(tr)
        if len(trs) < 14:
            out.append(sum(trs) / len(trs))
        else:
            prev = sum(trs[:14]) / 14 if prev is None else (prev * 13 + tr) / 14
            out.append(prev)
    return out


def simulate(tf, count, trades):
    df = ds.get_candles("XAU", tf, 300)
    src = df.attrs.get("source", "?")
    _ = df["open"].tolist()
    h = df["high"].tolist()
    l = df["low"].tolist()
    c = df["close"].tolist()
    ts = df["time"].tolist()
    n = len(c)
    e20, e50, a14 = ema(c, 20), ema(c, 50), atr14(h, l, c)
    first, last = 60, n - HORIZON - 1
    if last <= first:
        raise SystemExit(f"دادهٔ کافی برای {tf} نیست ({n} کندل)")
    step = max(1, (last - first) // count)
    made = 0
    i = first
    while made < count and i <= last:
        atr = a14[i]
        if atr <= 0:
            i += 1
            continue
        direction = "BUY" if e20[i] > e50[i] else "SELL"
        entry = c[i]
        sgn = 1 if direction == "BUY" else -1
        sl = entry - sgn * SL_ATR * atr
        tp = entry + sgn * TP_ATR * atr
        # عبور از پلِ واقعیِ ربات
        r = http("POST", "/api/robot/test", sp2l_payload(direction, entry, sl, tp))
        approved = bool(r.get("approved", r.get("ok")))
        order = r.get("order", {})
        # بازسازیِ سرنوشت روی کندل‌های واقعیِ بعدی
        outcome, exit_px, bars = "timeout", c[min(i + HORIZON, n - 1)], HORIZON
        for j in range(i + 1, min(i + HORIZON, n - 1) + 1):
            hit_tp = (h[j] >= tp) if sgn > 0 else (l[j] <= tp)
            hit_sl = (l[j] <= sl) if sgn > 0 else (h[j] >= sl)
            if hit_tp and hit_sl:
                outcome, exit_px, bars = "both→loss", sl, j - i
                break
            if hit_sl:
                outcome, exit_px, bars = "loss", sl, j - i
                break
            if hit_tp:
                outcome, exit_px, bars = "win", tp, j - i
                break
        pnl = (exit_px - entry) * sgn * OZ
        risk = abs(entry - sl) * OZ
        trades.append({
            "tf": tf, "i": i, "t": int(ts[i]), "dir": direction,
            "entry": entry, "sl": sl, "tp": tp, "atr": atr,
            "outcome": outcome, "exit": exit_px, "bars": bars,
            "pnl": round(pnl, 2), "r": round(pnl / risk, 3) if risk else 0.0,
            "approved": approved,
            "norm_ok": (order.get("symbol") == "XAUUSD"
                        and order.get("tps") == [round(tp, 2)]),
            "src": src,
        })
        made += 1
        i += step
    return made, src


def main():
    # پیکربندیِ فعلیِ پل را نگه می‌داریم و در پایان برمی‌گردانیم
    cfg0 = http("GET", "/api/robot/config").get("data", {})
    http("POST", "/api/robot/config", {
        "enabled": True, "filter_mode": "internal",
        "require_direction_match": False, "min_internal_score": 0,
        "min_ai_score": 0, "auto_forward": True,
        "respect_robot_volume": True, "conflict_guard_enabled": False,
        "shared_secret": "", "default_tf": "5m"})
    trades = []
    srcs = {}
    try:
        for tf, cnt in PLAN:
            made, src = simulate(tf, cnt, trades)
            srcs[tf] = src
            print(f"  {tf}: {made} معامله بازسازی شد (منبع: {src})")
    finally:
        keep = {k: cfg0[k] for k in cfg0 if not isinstance(cfg0[k], (dict, list))}
        if keep:
            http("POST", "/api/robot/config", keep)

    with open("sp2l_gold_200_trades.json", "w", encoding="utf-8") as f:
        json.dump({"trades": trades, "sources": srcs}, f, ensure_ascii=False)

    wins = [t for t in trades if t["outcome"] == "win"]
    losses = [t for t in trades if t["outcome"] in ("loss", "both→loss")]
    tmo = [t for t in trades if t["outcome"] == "timeout"]
    decided = len(wins) + len(losses)
    wr = 100.0 * len(wins) / decided if decided else 0.0
    wr_all = 100.0 * len([t for t in trades if t["pnl"] > 0]) / len(trades)
    print(f"\nمعاملات: {len(trades)} | برد: {len(wins)} | باخت: {len(losses)} "
          f"| timeout: {len(tmo)} | وین‌ریت (قطعی‌ها): {wr:.1f}٪ "
          f"| وین‌ریت (همه با PnL>0): {wr_all:.1f}٪")
    approved = sum(1 for t in trades if t["approved"])
    norm_ok = sum(1 for t in trades if t["norm_ok"])
    print(f"تأیید پل: {approved}/{len(trades)} | نرمال‌سازی صحیح: {norm_ok}/{len(trades)}")


if __name__ == "__main__":
    main()
