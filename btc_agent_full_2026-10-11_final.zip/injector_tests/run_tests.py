# -*- coding: utf-8 -*-
"""هارنسِ تستِ جامعِ bridge_injector روی چند فایلِ پایتون و MQL5."""
import os
import re
import sys
import glob
import py_compile
import importlib

# اصلاح (TEST-006): مسیرها نسبت به خودِ فایل تعیین می‌شوند تا هارنس در هر checkout کار کند.
from pathlib import Path
_ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(_ROOT.parent))
import bridge_injector
importlib.reload(bridge_injector)

PY_DIR = str(_ROOT / "py")
MQ_DIR = str(_ROOT / "mql5")
OUT_DIR = str(_ROOT / "out")
os.makedirs(OUT_DIR, exist_ok=True)

URL = "http://127.0.0.1:8000"
SECRET = ""

PASS, FAIL = 0, 0
FAILURES = []


def chk(name, cond, detail=""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"   PASS  {name}")
    else:
        FAIL += 1
        FAILURES.append(f"{name} :: {detail}")
        print(f"   FAIL  {name}  <<< {detail}")


def balanced(text, op, cl):
    depth = 0
    for ch in text:
        if ch == op:
            depth += 1
        elif ch == cl:
            depth -= 1
            if depth < 0:
                return False
    return depth == 0


def _strip_mql_noncode(src):
    """حذفِ کامنت‌ها و رشته‌ها برای تحلیلِ ساختاریِ MQL5."""
    out = []
    i, n = 0, len(src)
    while i < n:
        two = src[i:i + 2]
        c = src[i]
        if two == "//":
            while i < n and src[i] != "\n":
                i += 1
        elif two == "/*":
            end = src.find("*/", i + 2)
            i = (end + 2) if end != -1 else n
        elif c in "\"'":
            i += 1
            while i < n:
                if src[i] == "\\":
                    i += 2
                    continue
                if src[i] == c:
                    i += 1
                    break
                i += 1
        else:
            out.append(c)
            i += 1
    return "".join(out)


def mql_lint(out, is_include):
    """تحلیل‌گرِ ایستایِ MQL5 — کلاس‌های رایجِ خطای کامپایل را برمی‌گرداند."""
    problems = []
    code = _strip_mql_noncode(out)
    # توازنِ نشانه‌ها (روی کد، بدونِ کامنت/رشته)
    if not balanced(code, "{", "}"):
        problems.append("آکولادهای نامتوازن {}")
    if not balanced(code, "(", ")"):
        problems.append("پرانتزهای نامتوازن ()")
    if not balanced(code, "[", "]"):
        problems.append("براکت‌های نامتوازن []")
    # OnInit تکراری
    ninit = len(re.findall(r'\bint\s+OnInit\s*\(', code))
    if ninit > 1:
        problems.append(f"OnInit تکراری ({ninit} بار)")
    if is_include and ninit >= 1:
        problems.append("فایلِ include نباید OnInit داشته باشد")
    # ورودی‌های تکراری
    for inp in ("InpBridgeURL", "InpSecret", "InpTimeoutMs"):
        c = len(re.findall(r'\binput\b[^\n;]*\b%s\b' % inp, code))
        if c > 1:
            problems.append(f"ورودیِ تکراری: {inp} ({c} بار)")
    # include تکراری
    ninc = out.count("#include <RobotBridge.mqh>")
    if ninc > 1:
        problems.append(f"#include تکراری ({ninc} بار)")
    # شیءِ bridge باید دقیقاً یک بار و در دامنهٔ سراسری باشد
    m = list(re.finditer(r'\bCRobotBridge\s+bridge\s*;', code))
    if len(m) != 1:
        problems.append(f"CRobotBridge bridge; باید ۱ بار باشد (شد {len(m)})")
    elif code[:m[0].start()].count("{") != code[:m[0].start()].count("}"):
        problems.append("CRobotBridge bridge; در دامنهٔ سراسری نیست")
    # include باید پیش از اولین استفاده از CRobotBridge باشد
    if "#include <RobotBridge.mqh>" in out and "CRobotBridge" in out:
        if out.index("#include <RobotBridge.mqh>") > out.index("CRobotBridge"):
            problems.append("#include بعد از استفاده از CRobotBridge آمده")
    # bridge.Init باید داخلِ یک تابع باشد (نه دامنهٔ سراسری)
    mi = re.search(r'bridge\.Init\s*\(', code)
    if mi and code[:mi.start()].count("{") <= code[:mi.start()].count("}"):
        problems.append("bridge.Init(...) بیرونِ بدنهٔ تابع است")
    # OrderSendBridge باید حداقل دو آرگومان داشته باشد
    for mm in re.finditer(r'bridge\.OrderSendBridge\s*\(([^)]*)\)', code):
        if mm.group(1).count(",") < 1:
            problems.append("OrderSendBridge با آرگومانِ ناکافی")
            break
    return problems


# ─────────────────────────── PYTHON ───────────────────────────
print("\n" + "=" * 70)
print("PYTHON FILES")
print("=" * 70)
for path in sorted(glob.glob(f"{PY_DIR}/*.py")):
    name = os.path.basename(path)
    print(f"\n▶ {name}")
    src = open(path, encoding="utf-8", newline="").read()
    out, report, lang = bridge_injector.patch_source(name, src, URL, SECRET)
    outp = os.path.join(OUT_DIR, name.replace(".py", ".bridge.py"))
    open(outp, "w", encoding="utf-8").write(out)

    chk(f"{name}: lang=python", lang == "python", lang)
    chk(f"{name}: marker present", bridge_injector.MARKER in out)
    chk(f"{name}: RobotBridge import added",
        "from robot_client_example import RobotBridge" in out)
    chk(f"{name}: bridge object created", "bridge = RobotBridge(" in out)
    # compile
    try:
        py_compile.compile(outp, doraise=True)
        chk(f"{name}: py_compile OK", True)
    except py_compile.PyCompileError as e:
        chk(f"{name}: py_compile OK", False, str(e))
    # idempotency: patching the output again must NOT change it
    out2, rep2, _ = bridge_injector.patch_source(name, out, URL, SECRET)
    chk(f"{name}: idempotent (2nd pass no change)", out2 == out,
        "second injection changed the file")

    # per-file behavioural checks
    if name == "p1_basic_order_send.py":
        chk(f"{name}: mt5.order_send → bridge.order_send",
            "bridge.order_send(" in out and "mt5.order_send(" not in out)
    if name == "p2_alias_multi.py":
        chk(f"{name}: alias mt.order_send converted (2x)",
            out.count("bridge.order_send(") == 2 and "mt.order_send(" not in out)
    if name == "p3_from_import.py":
        chk(f"{name}: bare order_send( converted",
            "bridge.order_send(" in out)
    if name == "p4_meta_run.py":
        chk(f"{name}: Meta.run auto-wired to bridge.send",
            "_bridge_res = bridge.send(" in out)
        chk(f"{name}: original Meta.run commented out",
            "# Meta.run(" in out.replace(" ", "") or "#Meta.run(" in out.replace(" ", ""))
        chk(f"{name}: direction mapped from buy/sell",
            '("BUY" if buy else "SELL")' in out)
    if name == "p5_no_exec.py":
        chk(f"{name}: no-exec → TODO guidance present",
            "TODO" in out)
    if name == "p6_class_method.py":
        chk(f"{name}: order_send in method converted",
            "return bridge.order_send(req)" in out)
        chk(f"{name}: docstring mention NOT altered",
            "mentions mt5.order_send(x)" in out)
        chk(f"{name}: comment mention NOT altered",
            "comment mentioning mt5.order_send(req)" in out)
    if name == "p7_meta_run_nested.py":
        chk(f"{name}: nested Meta.run auto-wired",
            "_bridge_res = bridge.send(" in out)
        chk(f"{name}: custom var names mapped (want_buy)",
            '("BUY" if want_buy else "SELL")' in out)
    if name == "p8_fullmodule.py":
        chk(f"{name}: full-module MetaTrader5.order_send converted",
            "bridge.order_send(" in out and "MetaTrader5.order_send(" not in out)
    if name == "p9_tabs.py":
        chk(f"{name}: tab-indented order_send converted",
            "bridge.order_send(" in out and "mt5.order_send(" not in out)
        chk(f"{name}: tab indentation preserved (no tabs→spaces mangling)",
            "\t" in out)
    if name == "p11_advanced_layers.py":
        chk(f"{name}: assign-style Meta.run wired (res = _bridge_res)",
            "res = _bridge_res" in out)
        chk(f"{name}: kwargs layer place_order wired",
            "ok = _bridge_res" in out and "ex.place_order(symbol=" not in out.split("نسخهٔ اصلی")[0])
        chk(f"{name}: direction from kwarg passed through",
            'direction="BUY"' in out)
        chk(f"{name}: buy() name → direction BUY",
            out.count("_bridge_res = bridge.send(") >= 3)
        chk(f"{name}: if-condition call NOT silently changed",
            "if ex.open_trade(pair=sym" in out)
        chk(f"{name}: hint for in-condition call",
            any("شرط" in r for r in report))
        chk(f"{name}: callback ref untouched + warned",
            "runner(mt5.order_send)" in out and any("callback" in r or "ارجاع" in r for r in report))
    if name == "p12_wildcard_async.py":
        chk(f"{name}: bare order_send from import * bridged",
            "r = bridge.order_send(req)" in out)
        chk(f"{name}: awaited sell() wired",
            "_bridge_res = bridge.send(" in out and "await broker.sell(" not in out.split("نسخهٔ اصلی")[0])
        chk(f"{name}: async-origin note injected at call site",
            "async بود" in out)
    if name == "p13_future_paren.py":
        # OP5-INJ-05: بلوک تزریق باید بعد از from __future__ چندخطی (پرانتزی) بیاید
        chk(f"{name}: block inserted AFTER multi-line __future__ import",
            out.index(bridge_injector.MARKER) > out.index("division)"))
        chk(f"{name}: future import intact",
            "from __future__ import (annotations," in out)
        chk(f"{name}: order_send bridged", "bridge.order_send(" in out)
    if name == "p10_bom.py":
        chk(f"{name}: BOM preserved at file start (position 0)",
            out[:1] == "\ufeff")
        chk(f"{name}: exactly one BOM (not duplicated/misplaced)",
            out.count("\ufeff") == 1)
    for r in report:
        print(f"       · {r}")


# ─────────────────────────── MQL5 ───────────────────────────
print("\n" + "=" * 70)
print("MQL5 FILES")
print("=" * 70)
for path in sorted(glob.glob(f"{MQ_DIR}/*.mq5") + glob.glob(f"{MQ_DIR}/*.mqh")):
    name = os.path.basename(path)
    print(f"\n▶ {name}")
    src = open(path, encoding="utf-8", newline="").read()
    out, report, lang = bridge_injector.patch_source(name, src, URL, SECRET)
    ext = os.path.splitext(name)[1]
    outp = os.path.join(OUT_DIR, name.replace(ext, f".bridge{ext}"))
    open(outp, "w", encoding="utf-8").write(out)

    chk(f"{name}: lang=mql5", lang == "mql5", lang)
    chk(f"{name}: marker present", bridge_injector.MARKER in out)
    chk(f"{name}: #include <RobotBridge.mqh>", "#include <RobotBridge.mqh>" in out)
    chk(f"{name}: global CRobotBridge bridge;",
        "CRobotBridge bridge;" in out)
    chk(f"{name}: bridge.Init(...) present", "bridge.Init(" in out)
    is_inc = ext == ".mqh"
    lint = mql_lint(out, is_inc)
    chk(f"{name}: deep MQL5 lint clean", not lint, "; ".join(lint))
    # idempotency
    out2, _, _ = bridge_injector.patch_source(name, out, URL, SECRET)
    chk(f"{name}: idempotent (2nd pass no change)", out2 == out,
        "second injection changed the file")

    if name == "m1_ordersend_allman.mq5":
        chk(f"{name}: OrderSend → bridge.OrderSendBridge",
            "bridge.OrderSendBridge(" in out and "if(!OrderSend(" not in out)
        chk(f"{name}: bridge.Init inside existing OnInit",
            "int OnInit()" in out and "bridge.Init(" in out)
    if name == "m2_ctrade.mq5":
        chk(f"{name}: CTrade auto-wired (BridgeCTOrder present)",
            "BridgeCTOrder(" in out and "bool BridgeCTOrder(" in out)
        chk(f"{name}: trade.Buy/Sell replaced",
            "trade.Buy(" not in _strip_mql_noncode(out)
            and "trade.Sell(" not in _strip_mql_noncode(out))
        # OP5-INJ-06: قیمتِ صریحِ فراخوانی دیگر حذف نمی‌شود و به‌عنوانِ entry منتقل می‌شود.
        chk(f"{name}: Buy mapped (dir/vol/sl/tp, explicit price → entry)",
            'BridgeCTOrder(_Symbol, "BUY", InpLot, ask - 1.0, ask + 2.0, ask)' in out)
        chk(f"{name}: helper after bridge decl (declaration-before-use)",
            out.index("CRobotBridge bridge;") < out.index("bool BridgeCTOrder("))
        chk(f"{name}: CTrade report line present",
            any("CTrade" in r for r in report))
    if name == "m3_include_no_oninit.mqh":
        chk(f"{name}: OrderSend converted in include",
            "bridge.OrderSendBridge(" in out)
        chk(f"{name}: NO OnInit added to include (avoids dup)",
            "int OnInit()" not in out)
        chk(f"{name}: BridgeInit() helper added instead",
            "void BridgeInit(" in out)
        chk(f"{name}: NO input added to include (avoids dup)",
            "input string InpBridgeURL" not in out)
        chk(f"{name}: injected block INSIDE include guard",
            ("#define" in out and out.index("#define") < out.index(bridge_injector.MARKER)))
    if name == "m4_no_property_knr.mq5":
        chk(f"{name}: OrderSend converted (K&R)",
            "bridge.OrderSendBridge(" in out)
        chk(f"{name}: include placed at top (no #property)",
            out.index("#include <RobotBridge.mqh>") < out.index("int OnInit"))
    if name == "m5_full_ea.mq5":
        chk(f"{name}: both OrderSend calls converted (2x)",
            out.count("bridge.OrderSendBridge(") == 2)
        chk(f"{name}: exactly one OnInit (no duplicate)",
            len(re.findall(r'\bint\s+OnInit\s*\(', _strip_mql_noncode(out))) == 1)
        chk(f"{name}: existing inputs preserved (InpLot)",
            "input double InpLot" in out)
        chk(f"{name}: string 'OrderSend(req,res)' in Print untouched",
            "OrderSend(req,res) is documented here" in out)
    if name == "m6_has_include.mq5":
        chk(f"{name}: no duplicate #include",
            out.count("#include <RobotBridge.mqh>") == 1)
        chk(f"{name}: OrderSend converted",
            "bridge.OrderSendBridge(" in out)
    if name == "m7_partial_inputs.mq5":
        chk(f"{name}: no duplicate InpBridgeURL",
            len(re.findall(r'\binput\b[^\n;]*InpBridgeURL', _strip_mql_noncode(out))) == 1)
        chk(f"{name}: no duplicate CRobotBridge bridge;",
            len(re.findall(r'\bCRobotBridge\s+bridge\s*;', _strip_mql_noncode(out))) == 1)
        chk(f"{name}: no duplicate #include",
            out.count("#include <RobotBridge.mqh>") == 1)
        chk(f"{name}: OrderSend converted",
            "bridge.OrderSendBridge(" in out)
    if name == "m8_no_oninit_no_send.mq5":
        chk(f"{name}: OnInit created (was missing)",
            len(re.findall(r'\bint\s+OnInit\s*\(', _strip_mql_noncode(out))) == 1)
        chk(f"{name}: infra added (bridge + include)",
            "CRobotBridge bridge;" in out and "#include <RobotBridge.mqh>" in out)
    if name == "m9_crlf_void.mq5":
        chk(f"{name}: OrderSend converted (CRLF + void)",
            "bridge.OrderSendBridge(" in out)
        chk(f"{name}: bridge.Init inside OnInit(void)",
            "bridge.Init(" in out)
        chk(f"{name}: CRLF line endings preserved (all \\n are \\r\\n)",
            "\r\n" in out and out.count("\n") == out.count("\r\n"))
    if name == "m10_mql4style.mq5":
        chk(f"{name}: OrderSend converted (MQL4-style call)",
            "bridge.OrderSendBridge(" in out)
        chk(f"{name}: exactly one OnInit",
            len(re.findall(r'\bint\s+OnInit\s*\(', _strip_mql_noncode(out))) == 1)
    if name == "m11_trade_backslash.mq5":
        chk(f"{name}: CTrade auto-wired with comment arg",
            'BridgeCTOrder(_Symbol, "BUY", Lots, 0, 0, 0, "entry")' in out)
        chk(f"{name}: pre-existing backslash include preserved",
            "#include <Trade" + chr(92) + "Trade.mqh>" in out)
        chk(f"{name}: RobotBridge include added alongside",
            "#include <RobotBridge.mqh>" in out)
    if name == "m12_ctrade_advanced.mq5":
        code12 = _strip_mql_noncode(out)
        chk(f"{name}: pointer CTrade market call wired",
            "m_trade.PositionOpen(" not in code12)
        chk(f"{name}: PositionOpen var-type → runtime ternary dir (explicit price kept)",
            'BridgeCTOrder("XAUUSD", ((ot)==ORDER_TYPE_BUY?"BUY":"SELL"), InpLot, 1900.0, 2100.0, 0, "sig-42")' in out)
        chk(f"{name}: if-condition structure preserved",
            'if(BridgeCTOrder("XAUUSD"' in out)
        # OP5-INJ-06: پندینگ‌ها هرگز خودکار تبدیل نمی‌شوند (پل نوع/انقضا ندارد).
        chk(f"{name}: BuyStop pending left untouched (not silently converted)",
            "m_trade.BuyStop(" in code12)
        chk(f"{name}: SellLimit pending left untouched",
            "m_trade.SellLimit(" in code12)
        chk(f"{name}: pending warning in report",
            any("پندینگ" in r for r in report))
        chk(f"{name}: string mention untouched",
            'm_trade.Buy(0.1) is documented here' in out)
        chk(f"{name}: helper defined exactly once",
            out.count("bool BridgeCTOrder(") == 1)
    if name == "m13_ordersend_async.mq5":
        code13 = _strip_mql_noncode(out)
        # OP5-INJ-06: OrderSendAsync دست‌نخورده می‌ماند (پل APIِ همگام دارد) + هشدار.
        chk(f"{name}: OrderSendAsync left intact (not silently made sync)",
            "OrderSendAsync(req, res)" in code13)
        chk(f"{name}: plain OrderSend still bridged",
            "bridge.OrderSendBridge(req, res)" in out)
        chk(f"{name}: user wrapper decl preserved (not self-rewritten)",
            "bool OrderSendAsync(MqlTradeRequest &r, MqlTradeResult &s)" in out)
        chk(f"{name}: async warning in report",
            any("OrderSendAsync" in r for r in report))
        chk(f"{name}: async sync-note in report",
            any("sync" in r or "همگام" in r for r in report))
    for r in report:
        print(f"       · {r}")


# ─────────────────── BROKEN INPUT SAFETY (INJ-SYNTAX-001/002) ───────────────────
print("\n" + "=" * 70)
print("BROKEN INPUT SAFETY")
print("=" * 70)

_o, _r, _ = bridge_injector.patch_source("b.py", "def broken(:\n    pass\n", URL, "")
chk("broken py: unchanged", _o == "def broken(:\n    pass\n")
chk("broken py: syntax-error report (line no)", ("خطای نحوی" in _r[0]) and ("خط 1" in _r[0]))
_src = "\ufeffdef broken(:\r\n    pass\r\n"
_o, _r, _ = bridge_injector.patch_source("b.py", _src, URL, "")
chk("broken py: BOM+CRLF byte-identical", _o == _src)
_o, _r, _ = bridge_injector.patch_source("b.mq5", "int OnInit(){ return 0; \nvoid f(){ OrderSend(a,b); }\n", URL, "")
chk("unbalanced mq5: warning present", any("متوازن نیستند" in x for x in _r))
chk("unbalanced mq5: still injected", "bridge.OrderSendBridge(a,b)" in _o.replace("\r\n", "\n"))
_o, _r, _ = bridge_injector.patch_source("b.mq5", 'int OnInit(){ Print("{{{"); return 0; }\nvoid f(){ OrderSend(a,b); }\n', URL, "")
chk("braces in string: no false warning", not any("متوازن" in x for x in _r))


# ─────────────────── COMMENT / STRING SAFETY (no false replace) ───────────────────
print("\n" + "=" * 70)
print("MQL STRING LITERAL SAFETY (OP5-INJ-05)")
print("=" * 70)
chk("plain url literal", bridge_injector._mql_string_literal("http://127.0.0.1:8000")
    == '"http://127.0.0.1:8000"')
evil = 'http://x/"quoted"\nnewline\\slash'
lit = bridge_injector._mql_string_literal(evil)
chk("quote/backslash/newline escaped (no raw quote inside)",
    lit.startswith('"') and lit.endswith('"') and '\\"' in lit
    and '\\n' in lit and '\\\\' in lit and '\n' not in lit)
chk("secret CR/LF rejected by validator",
    (lambda: (bridge_injector._validate_base_url("http://127.0.0.1:8000", "a\rb")
              and False))() if False else True)
try:
    bridge_injector._validate_base_url("http://127.0.0.1:8000", "a\r\nb")
    chk("secret CR/LF rejected by validator", False)
except ValueError:
    chk("secret CR/LF rejected by validator", True)
try:
    bridge_injector._validate_base_url("ftp://example.com", "")
    chk("non-http(s) url rejected", False)
except ValueError:
    chk("non-http(s) url rejected", True)

print("\n" + "=" * 70)
print("COMMENT / STRING SAFETY")
print("=" * 70)

py_cs = ('import MetaTrader5 as mt5\n'
         '# note: mt5.order_send(x) in a comment must NOT change\n'
         'msg = "call mt5.order_send(x) from docs"\n'
         'r = mt5.order_send(req)\n')
o, _, _ = bridge_injector.patch_source("cs.py", py_cs, URL, SECRET)
chk("py: comment order_send NOT replaced",
    "# note: mt5.order_send(x)" in o, "comment was altered")
chk("py: string order_send NOT replaced",
    '"call mt5.order_send(x) from docs"' in o, "string was altered")
chk("py: real order_send IS replaced",
    "r = bridge.order_send(req)" in o, "real call not replaced")

mq_cs = ('#property strict\n'
         '// call OrderSend(a,b) in comment must NOT change\n'
         'int OnInit(){ Print("use OrderSend(x,y)"); return 0; }\n'
         'void OnTick(){ OrderSend(req,res); }\n')
om, _, _ = bridge_injector.patch_source("cs.mq5", mq_cs, URL, SECRET)
chk("mq: comment OrderSend NOT replaced",
    "// call OrderSend(a,b)" in om, "comment was altered")
chk("mq: string OrderSend NOT replaced",
    'Print("use OrderSend(x,y)")' in om, "string was altered")
chk("mq: real OrderSend IS replaced",
    "bridge.OrderSendBridge(req,res)" in om, "real call not replaced")

print("\n" + "=" * 70)
print(f"RESULT: {PASS} passed, {FAIL} failed")
if FAILURES:
    print("\nFAILURES:")
    for f in FAILURES:
        print("  -", f)
print("=" * 70)
sys.exit(1 if FAIL else 0)
