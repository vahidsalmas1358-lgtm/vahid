#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Class-based bot. NOTE: this docstring mentions mt5.order_send(x) on purpose
to make sure the injector does NOT touch text inside strings/docstrings."""
# --- BRIDGE-INJECTED: اتصالِ خودکار به «برنامهٔ تحلیل» (توسطِ bridge_injector) ---
from robot_client_example import RobotBridge
bridge = RobotBridge('http://127.0.0.1:8000', secret='')
# --- پایانِ BRIDGE-INJECTED ---

import MetaTrader5 as mt5


class Trader:
    """A trader that calls mt5.order_send inside a method."""

    def __init__(self, symbol):
        self.symbol = symbol

    def open(self, lot, sl, tp):
        # comment mentioning mt5.order_send(req) should stay intact
        req = {
            "action": mt5.TRADE_ACTION_DEAL,
            "symbol": self.symbol,
            "volume": lot,
            "type": mt5.ORDER_TYPE_BUY,
            "sl": sl,
            "tp": tp,
        }
        return bridge.order_send(req)


if __name__ == "__main__":
    mt5.initialize()
    Trader("XAUUSD").open(0.1, 3300, 3350)
