#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""A bot that uses a custom alias and sends several orders."""
from __future__ import annotations
# --- BRIDGE-INJECTED: اتصالِ خودکار به «برنامهٔ تحلیل» (توسطِ bridge_injector) ---
from robot_client_example import RobotBridge
bridge = RobotBridge('http://127.0.0.1:8000', secret='')
# --- پایانِ BRIDGE-INJECTED ---


import MetaTrader5 as mt
import time


def buy(sym):
    req = {"symbol": sym, "type": mt.ORDER_TYPE_BUY, "volume": 0.2}
    return bridge.order_send(req)


def sell(sym):
    req = {"symbol": sym, "type": mt.ORDER_TYPE_SELL, "volume": 0.2}
    r = bridge.order_send(req)
    return r


if __name__ == "__main__":
    mt.initialize()
    buy("XAUUSD")
    time.sleep(1)
    sell("XAUUSD")
