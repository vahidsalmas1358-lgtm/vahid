# --- BRIDGE-INJECTED: اتصالِ خودکار به «برنامهٔ تحلیل» (توسطِ bridge_injector) ---
from robot_client_example import RobotBridge
bridge = RobotBridge('http://127.0.0.1:8000', secret='')
# --- پایانِ BRIDGE-INJECTED ---

import MetaTrader5 as mt5

mt5.initialize()

def open_trade(symbol, lot, sl, tp):
    request = {
        "action": mt5.TRADE_ACTION_DEAL,
        "symbol": symbol,
        "volume": lot,
        "type": mt5.ORDER_TYPE_BUY,
        "price": mt5.symbol_info_tick(symbol).ask,
        "sl": sl,
        "tp": tp,
        "magic": 234000,
        "comment": "basic",
    }
    result = bridge.order_send(request)
    if result.retcode == mt5.TRADE_RETCODE_DONE:
        print("done")
    return result

open_trade("EURUSD", 0.1, 1.09, 1.11)
