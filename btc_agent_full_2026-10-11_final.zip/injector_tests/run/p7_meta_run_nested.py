#!/usr/bin/env python
"""Meta.run nested deep inside conditionals, with a trailing comment."""
# --- BRIDGE-INJECTED: اتصالِ خودکار به «برنامهٔ تحلیل» (توسطِ bridge_injector) ---
from robot_client_example import RobotBridge
bridge = RobotBridge('http://127.0.0.1:8000', secret='')
# --- پایانِ BRIDGE-INJECTED ---

import MetaTrader5 as mt5
import Meta

SYMBOL = "EURUSD"
LOT = 0.05
MAGIC = 777


def loop_once(want_buy, want_sell, sl, tp):
    if want_buy or want_sell:
        if sl > 0:
            # --- BRIDGE-INJECTED: «Meta.run» خودکار به bridge.send وصل شد ---
            _bridge_res = bridge.send(
                symbol=SYMBOL,
                direction=("BUY" if want_buy else "SELL"),
                volume=LOT,
                sl=sl,
                tp=tp,
                magic=MAGIC,
            )
            if _bridge_res.forwarded:
                print("Bridge: به متاتریدر ارسال شد ✅ -", _bridge_res.comment)
            elif _bridge_res.approved:
                print("Bridge: تایید شد ولی ارسال نشد -", _bridge_res.comment)
            else:
                print("Bridge: رد شد ⛔ -", _bridge_res.comment)
            # --- نسخهٔ اصلیِ اجرای مستقیم (غیرفعال‌شده؛ برای بازگشت از کامنت خارج کنید): ---
            #             Meta.run(SYMBOL, want_buy, want_sell, LOT, tp, sl, MAGIC, stopLossPure=True)  # execute
            # --- پایانِ BRIDGE-INJECTED ---
    return True


mt5.initialize()
loop_once(True, False, 1.05, 1.09)
