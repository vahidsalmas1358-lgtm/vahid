# -*- coding: utf-8 -*-
"""رباتِ پیشرفته: لایهٔ اجرای سفارشیِ خودش را دارد (نه mt5.order_send مستقیم)."""
# --- BRIDGE-INJECTED: اتصالِ خودکار به «برنامهٔ تحلیل» (توسطِ bridge_injector) ---
from robot_client_example import RobotBridge
bridge = RobotBridge('http://127.0.0.1:8000', secret='')
# --- پایانِ BRIDGE-INJECTED ---

import MetaTrader5 as mt5
import Meta  # noqa: F401  (استابِ لایهٔ اجرا در تستِ runtime)


class Executor:
    def place_order(self, **kw):
        ...

    def buy(self, **kw):
        ...

    def open_trade(self, **kw):
        ...


ex = Executor()


def strategy(sym, lots, sl, tp):
    # نتیجه در متغیر نگه داشته می‌شود (Assign) — باید سیم‌کشی شود
    # --- BRIDGE-INJECTED: «Meta.run» خودکار به bridge.send وصل شد ---
    _bridge_res = bridge.send(
        symbol=sym,
        direction=("BUY" if True else "SELL"),
        volume=lots,
        sl=sl,
        tp=tp,
        magic=777,
    )
    res = _bridge_res  # BRIDGE-INJECTED: نتیجهٔ پل (BridgeResult: ok/retcode/comment/forwarded)
    if _bridge_res.forwarded:
        print("Bridge: به متاتریدر ارسال شد ✅ -", _bridge_res.comment)
    elif _bridge_res.approved:
        print("Bridge: تایید شد ولی ارسال نشد -", _bridge_res.comment)
    else:
        print("Bridge: رد شد ⛔ -", _bridge_res.comment)
    # --- نسخهٔ اصلیِ اجرای مستقیم (غیرفعال‌شده؛ برای بازگشت از کامنت خارج کنید): ---
    #     res = Meta.run(sym, True, False, lots, tp, sl, 777)
    # --- پایانِ BRIDGE-INJECTED ---
    # لایهٔ اجرای سفارشی با کیورد-آرگومان‌های متعارف — باید سیم‌کشی شود
    # --- BRIDGE-INJECTED: «ex.place_order» خودکار به bridge.send وصل شد ---
    _bridge_res = bridge.send(
        symbol=sym,
        direction="BUY",
        volume=lots,
        sl=sl,
        tp=tp,
        magic=9,
    )
    ok = _bridge_res  # BRIDGE-INJECTED: نتیجهٔ پل (BridgeResult: ok/retcode/comment/forwarded)
    if _bridge_res.forwarded:
        print("Bridge: به متاتریدر ارسال شد ✅ -", _bridge_res.comment)
    elif _bridge_res.approved:
        print("Bridge: تایید شد ولی ارسال نشد -", _bridge_res.comment)
    else:
        print("Bridge: رد شد ⛔ -", _bridge_res.comment)
    # --- نسخهٔ اصلیِ اجرای مستقیم (غیرفعال‌شده؛ برای بازگشت از کامنت خارج کنید): ---
    #     ok = ex.place_order(symbol=sym, side="BUY", lot=lots, stop_loss=sl, take_profit=tp, magic=9)
    # --- پایانِ BRIDGE-INJECTED ---
    # جهت از نامِ تابع (buy) — باید سیم‌کشی شود
    # --- BRIDGE-INJECTED: «ex.buy» خودکار به bridge.send وصل شد ---
    _bridge_res = bridge.send(
        symbol=sym,
        direction="BUY",
        volume=0.2,
    )
    if _bridge_res.forwarded:
        print("Bridge: به متاتریدر ارسال شد ✅ -", _bridge_res.comment)
    elif _bridge_res.approved:
        print("Bridge: تایید شد ولی ارسال نشد -", _bridge_res.comment)
    else:
        print("Bridge: رد شد ⛔ -", _bridge_res.comment)
    # --- نسخهٔ اصلیِ اجرای مستقیم (غیرفعال‌شده؛ برای بازگشت از کامنت خارج کنید): ---
    #     ex.buy(symbol=sym, qty=0.2)
    # --- پایانِ BRIDGE-INJECTED ---
    # داخلِ شرط — خودکار قابل‌تبدیل نیست؛ باید «راهنما» بدهد نه تغییرِ خاموش
    if ex.open_trade(pair=sym, direction="SELL", size=lots):
        pass
    # ارجاع به order_send به‌عنوان callback — باید هشدار بدهد و دست نزند
    runner(mt5.order_send)
    return res, ok


def runner(fn):
    # فقط ارجاع را نگه می‌دارد؛ عمداً صدا نمی‌زند
    return fn


if __name__ == "__main__":
    strategy("BTC", 0.10, 95.0, 110.0)
    print("done p11")
