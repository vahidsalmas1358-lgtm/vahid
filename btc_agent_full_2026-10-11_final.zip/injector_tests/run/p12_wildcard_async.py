# -*- coding: utf-8 -*-
"""رباتِ پیشرفته: import ستاره‌ای + متدِ async برای اجرا."""
# --- BRIDGE-INJECTED: اتصالِ خودکار به «برنامهٔ تحلیل» (توسطِ bridge_injector) ---
from robot_client_example import RobotBridge
bridge = RobotBridge('http://127.0.0.1:8000', secret='')
# --- پایانِ BRIDGE-INJECTED ---

from MetaTrader5 import *


class Broker:
    async def sell(self, **kw):
        ...


broker = Broker()


def run_sync(req):
    # order_send برهنه از import * — باید پل شود
    r = bridge.order_send(req)
    return r


async def run_async(sym, lots):
    # فراخوانیِ await شده — باید سیم‌کشی شود (با یادآوریِ sync بودنِ پل)
    # --- BRIDGE-INJECTED: «broker.sell» خودکار به bridge.send وصل شد ---
    # توجه: فراخوانیِ اصلی async بود؛ bridge.send همگام (sync) است.
    _bridge_res = bridge.send(
        symbol=sym,
        direction="SELL",
        volume=lots,
        sl=1.0,
        tp=2.0,
    )
    if _bridge_res.forwarded:
        print("Bridge: به متاتریدر ارسال شد ✅ -", _bridge_res.comment)
    elif _bridge_res.approved:
        print("Bridge: تایید شد ولی ارسال نشد -", _bridge_res.comment)
    else:
        print("Bridge: رد شد ⛔ -", _bridge_res.comment)
    # --- نسخهٔ اصلیِ اجرای مستقیم (غیرفعال‌شده؛ برای بازگشت از کامنت خارج کنید): ---
    #     await broker.sell(symbol=sym, lot=lots, stop=1.0, target=2.0)
    # --- پایانِ BRIDGE-INJECTED ---


if __name__ == "__main__":
    import asyncio
    run_sync({"action": 1, "symbol": "BTC", "volume": 0.1, "type": 0})
    asyncio.run(run_async("BTC", 0.1))
    print("done p12")
