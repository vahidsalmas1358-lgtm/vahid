#!/usr/bin/env python
# --- BRIDGE-INJECTED: اتصالِ خودکار به «برنامهٔ تحلیل» (توسطِ bridge_injector) ---
from robot_client_example import RobotBridge
bridge = RobotBridge('http://127.0.0.1:8000', secret='')
# --- پایانِ BRIDGE-INJECTED ---

__author__ = "Tester"
import MetaTrader5 as mt5
import Meta

SYMBOL = "XAUUSD"
LOT = 0.01
MAGIC = 55

mt5.initialize()

while True:
    buy = True
    sell = False
    sl = 3300.0
    tp = 3350.0
    if buy or sell:
        # --- BRIDGE-INJECTED: «Meta.run» خودکار به bridge.send وصل شد ---
        _bridge_res = bridge.send(
            symbol=SYMBOL,
            direction=("BUY" if buy else "SELL"),
            volume=LOT,
            sl=sl,
            tp=tp,
            magic=MAGIC,
        )
        if _bridge_res.forwarded:
            print("Bridge: به متاتریدر ارسال شد ✅ -", _bridge_res.comment)
        elif _bridge_res.approved:
            print("Bridge: تایید شد ولی ارسال نشد -", _bridge_res.comment)
        else:
            print("Bridge: رد شد ⛔ -", _bridge_res.comment)
        # --- نسخهٔ اصلیِ اجرای مستقیم (غیرفعال‌شده؛ برای بازگشت از کامنت خارج کنید): ---
        #         Meta.run(
        #             SYMBOL,
        #             buy,
        #             sell,
        #             LOT,
        #             tp,
        #             sl,
        #             MAGIC,
        #             stopLossPure=True
        #         )
        # --- پایانِ BRIDGE-INJECTED ---
    break
