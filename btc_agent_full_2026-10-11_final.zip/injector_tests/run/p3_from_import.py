"""Uses `from MetaTrader5 import ...` so order_send is called bare."""
# --- BRIDGE-INJECTED: اتصالِ خودکار به «برنامهٔ تحلیل» (توسطِ bridge_injector) ---
from robot_client_example import RobotBridge
bridge = RobotBridge('http://127.0.0.1:8000', secret='')
# --- پایانِ BRIDGE-INJECTED ---

from MetaTrader5 import initialize, order_send, ORDER_TYPE_BUY, TRADE_ACTION_DEAL

initialize()

req = {
    "action": TRADE_ACTION_DEAL,
    "symbol": "GBPUSD",
    "volume": 0.05,
    "type": ORDER_TYPE_BUY,
    "sl": 1.25,
    "tp": 1.28,
}
res = bridge.order_send(req)
print(res)
