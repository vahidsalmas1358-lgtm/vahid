# -*- coding: utf-8 -*-
"""رباتِ پیشرفته: import ستاره‌ای + متدِ async برای اجرا."""
from MetaTrader5 import *


class Broker:
    async def sell(self, **kw):
        ...


broker = Broker()


def run_sync(req):
    # order_send برهنه از import * — باید پل شود
    r = order_send(req)
    return r


async def run_async(sym, lots):
    # فراخوانیِ await شده — باید سیم‌کشی شود (با یادآوریِ sync بودنِ پل)
    await broker.sell(symbol=sym, lot=lots, stop=1.0, target=2.0)


if __name__ == "__main__":
    import asyncio
    run_sync({"action": 1, "symbol": "BTC", "volume": 0.1, "type": 0})
    asyncio.run(run_async("BTC", 0.1))
    print("done p12")
