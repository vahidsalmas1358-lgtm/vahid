#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""A bot that uses a custom alias and sends several orders."""
from __future__ import annotations

import MetaTrader5 as mt
import time


def buy(sym):
    req = {"symbol": sym, "type": mt.ORDER_TYPE_BUY, "volume": 0.2}
    return mt.order_send(req)


def sell(sym):
    req = {"symbol": sym, "type": mt.ORDER_TYPE_SELL, "volume": 0.2}
    r = mt.order_send(req)
    return r


if __name__ == "__main__":
    mt.initialize()
    buy("XAUUSD")
    time.sleep(1)
    sell("XAUUSD")
