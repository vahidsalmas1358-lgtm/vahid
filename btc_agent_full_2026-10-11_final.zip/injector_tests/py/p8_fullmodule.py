# ربات با نامِ کاملِ ماژول (بدونِ alias) — MetaTrader5.order_send
import MetaTrader5
import MetaTrader5 as mt5  # نامِ مستعار هم هست

def go(sig):
    req = {"action": mt5.TRADE_ACTION_DEAL, "symbol": "EURUSD",
           "type": mt5.ORDER_TYPE_BUY, "volume": 0.1}
    r = MetaTrader5.order_send(req)   # فراخوانی با نامِ کاملِ ماژول
    return r
