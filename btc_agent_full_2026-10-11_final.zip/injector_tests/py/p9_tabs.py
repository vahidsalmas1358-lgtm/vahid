# ربات با تورفتگیِ tab (نه space)
import MetaTrader5 as mt5
def handler(setup):
	if setup:
		request = {"action": mt5.TRADE_ACTION_DEAL, "symbol": "BTCUSD", "type": mt5.ORDER_TYPE_SELL, "volume": 0.2}
		res = mt5.order_send(request)
		return res
