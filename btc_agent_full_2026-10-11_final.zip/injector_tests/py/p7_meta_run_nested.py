#!/usr/bin/env python
"""Meta.run nested deep inside conditionals, with a trailing comment."""
import MetaTrader5 as mt5
import Meta

SYMBOL = "EURUSD"
LOT = 0.05
MAGIC = 777


def loop_once(want_buy, want_sell, sl, tp):
    if want_buy or want_sell:
        if sl > 0:
            Meta.run(SYMBOL, want_buy, want_sell, LOT, tp, sl, MAGIC, stopLossPure=True)  # execute
    return True


mt5.initialize()
loop_once(True, False, 1.05, 1.09)
