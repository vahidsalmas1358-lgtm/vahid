#!/usr/bin/env python
__author__ = "Tester"
import MetaTrader5 as mt5
import Meta

SYMBOL = "XAUUSD"
LOT = 0.01
MAGIC = 55

mt5.initialize()

while True:
    buy = True
    sell = False
    sl = 3300.0
    tp = 3350.0
    if buy or sell:
        Meta.run(
            SYMBOL,
            buy,
            sell,
            LOT,
            tp,
            sl,
            MAGIC,
            stopLossPure=True
        )
    break
