from __future__ import (annotations,
                        division)
import MetaTrader5 as mt5


def place():
    req = {"action": mt5.TRADE_ACTION_DEAL, "symbol": "XAUUSD",
           "type": mt5.ORDER_TYPE_BUY, "volume": 0.01}
    return mt5.order_send(req)
