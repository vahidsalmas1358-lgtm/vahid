"""Uses `from MetaTrader5 import ...` so order_send is called bare."""
from MetaTrader5 import initialize, order_send, ORDER_TYPE_BUY, TRADE_ACTION_DEAL

initialize()

req = {
    "action": TRADE_ACTION_DEAL,
    "symbol": "GBPUSD",
    "volume": 0.05,
    "type": ORDER_TYPE_BUY,
    "sl": 1.25,
    "tp": 1.28,
}
res = order_send(req)
print(res)
