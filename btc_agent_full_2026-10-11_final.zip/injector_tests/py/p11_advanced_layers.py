# -*- coding: utf-8 -*-
"""رباتِ پیشرفته: لایهٔ اجرای سفارشیِ خودش را دارد (نه mt5.order_send مستقیم)."""
import MetaTrader5 as mt5
import Meta  # noqa: F401  (استابِ لایهٔ اجرا در تستِ runtime)


class Executor:
    def place_order(self, **kw):
        ...

    def buy(self, **kw):
        ...

    def open_trade(self, **kw):
        ...


ex = Executor()


def strategy(sym, lots, sl, tp):
    # نتیجه در متغیر نگه داشته می‌شود (Assign) — باید سیم‌کشی شود
    res = Meta.run(sym, True, False, lots, tp, sl, 777)
    # لایهٔ اجرای سفارشی با کیورد-آرگومان‌های متعارف — باید سیم‌کشی شود
    ok = ex.place_order(symbol=sym, side="BUY", lot=lots, stop_loss=sl, take_profit=tp, magic=9)
    # جهت از نامِ تابع (buy) — باید سیم‌کشی شود
    ex.buy(symbol=sym, qty=0.2)
    # داخلِ شرط — خودکار قابل‌تبدیل نیست؛ باید «راهنما» بدهد نه تغییرِ خاموش
    if ex.open_trade(pair=sym, direction="SELL", size=lots):
        pass
    # ارجاع به order_send به‌عنوان callback — باید هشدار بدهد و دست نزند
    runner(mt5.order_send)
    return res, ok


def runner(fn):
    # فقط ارجاع را نگه می‌دارد؛ عمداً صدا نمی‌زند
    return fn


if __name__ == "__main__":
    strategy("BTC", 0.10, 95.0, 110.0)
    print("done p11")
