﻿# -*- coding: utf-8 -*-
import MetaTrader5 as mt5
def t(s):
    req={"action":mt5.TRADE_ACTION_DEAL,"symbol":"XAUUSD","type":mt5.ORDER_TYPE_BUY,"volume":0.01}
    return mt5.order_send(req)
