def init(*a, **k): pass
class _C:
    def __getattr__(self, n): return ""
Fore = _C(); Style = _C(); Back = _C()
