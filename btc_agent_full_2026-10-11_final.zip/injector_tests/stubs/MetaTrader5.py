# استابِ MetaTrader5 برای تستِ اجرای واقعیِ ربات‌های تزریق‌شده روی لینوکس
TRADE_ACTION_DEAL = 1
ORDER_TYPE_BUY = 0
ORDER_TYPE_SELL = 1
TRADE_RETCODE_DONE = 10009
TIMEFRAME_H1 = 16385
TIMEFRAME_M1 = 1
def initialize(*a, **k): return True
def shutdown(*a, **k): return True
def last_error(*a, **k): return (0, "ok")
def symbol_select(*a, **k): return True
def account_info(*a, **k): return None
class _Tick:  ask = 1.2345; bid = 1.2340
def symbol_info_tick(*a, **k): return _Tick()
class _SInfo: point = 0.01; digits = 2
def symbol_info(*a, **k): return _SInfo()
def copy_rates_from_pos(*a, **k):
    import numpy as np
    return np.array([(0, 1.0, 1.0, 1.0, 1.0)],
                    dtype=[("time","i8"),("open","f8"),("high","f8"),("low","f8"),("close","f8")])
def order_send(*a, **k):
    raise AssertionError("mt5.order_send نباید بعد از تزریق صدا زده شود (باید bridge.order_send جایگزین شده باشد)")
def positions_get(*a, **k): return ()
def orders_get(*a, **k): return ()
