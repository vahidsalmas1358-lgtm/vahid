#property strict
input double InpLot=0.1;

int OnInit(void)
  {
   return(INIT_SUCCEEDED);
  }

void OnTick()
  {
   MqlTradeRequest req; MqlTradeResult res;
   ZeroMemory(req);
   req.action=TRADE_ACTION_DEAL; req.symbol=_Symbol; req.volume=InpLot; req.type=ORDER_TYPE_SELL;
   if(!OrderSend(req,res)) Print("fail");
  }
