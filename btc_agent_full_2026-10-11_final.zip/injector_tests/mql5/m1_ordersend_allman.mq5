//+------------------------------------------------------------------+
//|                                            m1_ordersend_allman.mq5 |
//+------------------------------------------------------------------+
#property copyright "Tester"
#property version   "1.00"
#property strict

input double InpLot = 0.10;
input int    InpMagic = 12345;

int OnInit()
  {
   Print("EA started");
   return(INIT_SUCCEEDED);
  }

void OnDeinit(const int reason)
  {
  }

void OnTick()
  {
   MqlTradeRequest request;
   MqlTradeResult  result;
   ZeroMemory(request);
   request.action = TRADE_ACTION_DEAL;
   request.symbol = _Symbol;
   request.volume = InpLot;
   request.type   = ORDER_TYPE_BUY;
   request.price  = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
   request.magic  = InpMagic;
   if(!OrderSend(request, result))
      Print("OrderSend failed: ", result.retcode);
  }
