//+------------------------------------------------------------------+
//|                                          m3_include_no_oninit.mqh |
//|  A helper include with an order-sending function but NO OnInit.   |
//+------------------------------------------------------------------+
#ifndef __M3_HELPER_MQH__
#define __M3_HELPER_MQH__

bool SendMarketBuy(const string symbol, const double volume)
  {
   MqlTradeRequest request;
   MqlTradeResult  result;
   ZeroMemory(request);
   request.action = TRADE_ACTION_DEAL;
   request.symbol = symbol;
   request.volume = volume;
   request.type   = ORDER_TYPE_BUY;
   request.price  = SymbolInfoDouble(symbol, SYMBOL_ASK);
   return OrderSend(request, result);
  }

#endif
