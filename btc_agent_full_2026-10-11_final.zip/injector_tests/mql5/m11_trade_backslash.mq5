#property strict
#include <Trade\Trade.mqh>

CTrade trade;
input double Lots = 0.5;

int OnInit()
  {
   trade.SetExpertMagicNumber(8);
   return(INIT_SUCCEEDED);
  }

void OnTick()
  {
   if(PositionsTotal() == 0)
      trade.Buy(Lots, _Symbol, 0, 0, 0, "entry");
  }
