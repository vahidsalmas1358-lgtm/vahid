#property version "1.00"
#include <RobotBridge.mqh>

input string InpBridgeURL = "http://127.0.0.1:8000";
input string InpSecret    = "";
input int    InpTimeoutMs = 10000;
input double InpLot = 0.10;

CRobotBridge bridge;

int OnInit()
  {
   bridge.Init(InpBridgeURL, InpSecret, InpTimeoutMs);
   return(INIT_SUCCEEDED);
  }

void OnTick()
  {
   MqlTradeRequest req; MqlTradeResult res;
   ZeroMemory(req);
   req.action=TRADE_ACTION_DEAL; req.symbol=_Symbol; req.volume=InpLot; req.type=ORDER_TYPE_BUY;
   OrderSend(req,res);
  }
