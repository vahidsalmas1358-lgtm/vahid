// EA with no #property lines and K&R brace style OnInit
input double InpLot = 0.20;

int OnInit(){
   Print("no-property EA");
   return(INIT_SUCCEEDED);
}

void OnTick(){
   MqlTradeRequest req;
   MqlTradeResult  res;
   ZeroMemory(req);
   req.action = TRADE_ACTION_DEAL;
   req.symbol = _Symbol;
   req.volume = InpLot;
   req.type   = ORDER_TYPE_SELL;
   OrderSend(req, res);
}
