//+------------------------------------------------------------------+
//|                                                     m5_full_ea.mq5 |
//|                        A realistic EA with several order sends.    |
//+------------------------------------------------------------------+
#property copyright "Tester"
#property link      "https://example.com"
#property version   "1.10"
#property strict

input double InpLot     = 0.10;   // volume
input int    InpMagic   = 424242; // magic
input int    InpSlPips  = 200;    // stop pips

int    g_ticks = 0;

int OnInit()
  {
   Print("m5_full_ea init, note: OrderSend(req,res) is documented here");
   return(INIT_SUCCEEDED);
  }

void OnDeinit(const int reason)
  {
   Print("bye");
  }

bool DoBuy()
  {
   MqlTradeRequest request;
   MqlTradeResult  result;
   ZeroMemory(request);
   request.action = TRADE_ACTION_DEAL;
   request.symbol = _Symbol;
   request.volume = InpLot;
   request.type   = ORDER_TYPE_BUY;
   request.price  = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
   request.magic  = InpMagic;
   return OrderSend(request, result);
  }

bool DoSell()
  {
   MqlTradeRequest request;
   MqlTradeResult  result;
   ZeroMemory(request);
   request.action = TRADE_ACTION_DEAL;
   request.symbol = _Symbol;
   request.volume = InpLot;
   request.type   = ORDER_TYPE_SELL;
   request.price  = SymbolInfoDouble(_Symbol, SYMBOL_BID);
   request.magic  = InpMagic;
   return OrderSend(request, result);
  }

void OnTick()
  {
   g_ticks++;
   if(g_ticks % 2 == 0)
      DoBuy();
   else
      DoSell();
  }
