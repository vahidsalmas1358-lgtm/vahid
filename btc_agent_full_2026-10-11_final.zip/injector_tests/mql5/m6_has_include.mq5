//+------------------------------------------------------------------+
//|                                                  m6_has_include.mq5 |
//|   EA that ALREADY includes RobotBridge.mqh (partial integration).  |
//+------------------------------------------------------------------+
#property version "1.00"
#include <RobotBridge.mqh>

input double InpLot = 0.10;

int OnInit()
  {
   return(INIT_SUCCEEDED);
  }

void OnTick()
  {
   MqlTradeRequest req;
   MqlTradeResult  res;
   ZeroMemory(req);
   req.action = TRADE_ACTION_DEAL;
   req.symbol = _Symbol;
   req.volume = InpLot;
   req.type   = ORDER_TYPE_BUY;
   OrderSend(req, res);
  }
