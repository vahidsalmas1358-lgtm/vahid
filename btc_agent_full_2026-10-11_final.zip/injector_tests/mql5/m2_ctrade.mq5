//+------------------------------------------------------------------+
//|                                                      m2_ctrade.mq5 |
//+------------------------------------------------------------------+
#property copyright "Tester"
#property version   "1.00"
#include <Trade\Trade.mqh>

CTrade trade;
input double InpLot = 0.10;

int OnInit()
  {
   trade.SetExpertMagicNumber(9999);
   return(INIT_SUCCEEDED);
  }

void OnTick()
  {
   double ask = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
   double bid = SymbolInfoDouble(_Symbol, SYMBOL_BID);
   if(ask > 0)
      trade.Buy(InpLot, _Symbol, ask, ask - 1.0, ask + 2.0);
   else
      trade.Sell(InpLot, _Symbol, bid, bid + 1.0, bid - 2.0);
  }
