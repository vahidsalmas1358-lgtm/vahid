//+------------------------------------------------------------------+
//| m13_ordersend_async.mq5 — OrderSendAsync + wrapperِ هم‌نام          |
//+------------------------------------------------------------------+
#property strict

input double InpLot = 0.10;

// wrapperِ کاربر با همان نام — نباید خودش بازنویسی شود (گاردِ declaration)
bool OrderSendAsync(MqlTradeRequest &r, MqlTradeResult &s)
{
   return(false);
}

int OnInit()
{
   return(INIT_SUCCEEDED);
}

void OnTick()
{
   MqlTradeRequest req;
   MqlTradeResult  res;
   ZeroMemory(req);
   req.action = TRADE_ACTION_DEAL;
   req.symbol = _Symbol;
   req.volume = InpLot;
   if(!OrderSendAsync(req, res))
      Print("async failed");
   OrderSend(req, res);
}
