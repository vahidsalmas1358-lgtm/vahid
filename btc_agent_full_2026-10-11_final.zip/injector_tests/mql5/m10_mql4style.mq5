#property copyright "test"
#property version   "1.00"

input double Lots = 0.1;
input int    StopLoss = 300;

int OnInit()
  {
   return(INIT_SUCCEEDED);
  }

void OnTick()
  {
   double ask = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
   int ticket = OrderSend(_Symbol, OP_BUY, Lots, ask, 3, 0, 0, "my ea", 8, 0, clrGreen);
   if(ticket < 0)
      Print("OrderSend failed");
  }
