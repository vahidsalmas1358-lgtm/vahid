#property indicator_chart_window
#property version "1.00"

int OnCalculate(const int rates_total, const int prev_calculated,
                const int begin, const double &price[])
  {
   return(rates_total);
  }
