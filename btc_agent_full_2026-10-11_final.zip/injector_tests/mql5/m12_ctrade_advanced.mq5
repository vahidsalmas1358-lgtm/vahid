//+------------------------------------------------------------------+
//| m12_ctrade_advanced.mq5 — رباتِ پیشرفته با CTradeِ پوینتری،        |
//| PositionOpen با نوعِ متغیر، سفارش‌های پندینگ و فراخوانی داخلِ شرط  |
//+------------------------------------------------------------------+
#property strict
#include <Trade\Trade.mqh>

CTrade *m_trade;
input double InpLot = 0.20;

int OnInit()
{
   m_trade = new CTrade;
   m_trade.SetExpertMagicNumber(777);
   return(INIT_SUCCEEDED);
}

void OnTick()
{
   ENUM_ORDER_TYPE ot = (iClose(_Symbol, PERIOD_M15, 1) > iOpen(_Symbol, PERIOD_M15, 1))
                        ? ORDER_TYPE_BUY : ORDER_TYPE_SELL;
   // فراخوانی داخلِ شرط — ساختارِ if باید حفظ شود
   if(m_trade.PositionOpen("XAUUSD", ot, InpLot, 0, 1900.0, 2100.0, "sig-42"))
      Print("opened");
   // پندینگ با آرگومان‌های کامل (type_time/expiration باید نادیده گرفته شوند)
   m_trade.BuyStop(0.1, 2450.5, NULL, 2440.0, 2470.0, ORDER_TIME_GTC, 0, "brk");
   // پندینگِ حداقلی
   m_trade.SellLimit(0.3, 2500.0);
   // این یکی فقط متن است و نباید عوض شود: "m_trade.Buy(0.1)"
   Print("docs: m_trade.Buy(0.1) is documented here");
}
