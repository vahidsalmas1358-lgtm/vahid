# -*- coding: utf-8 -*-
"""تستِ «اجرای واقعیِ» ربات‌های تزریق‌شدهٔ پایتون.

py_compile فقط نحو را چک می‌کند؛ این اسکریپت فایلِ تزریق‌شده را واقعاً اجرا می‌کند
(با استاب‌های MetaTrader5/Meta/colorama و اتصال به داشبوردِ زندهٔ localhost:8000) تا
ثابت شود در «روندِ کار/اجرا» خطایی رخ نمی‌دهد و پُل واقعاً فعال می‌شود.
"""
import os
import sys
import subprocess
import importlib

# اصلاح (TEST-007): مسیرها نسبت به خودِ فایل تعیین می‌شوند تا هارنس قابل‌حمل باشد.
from pathlib import Path
_ROOT = Path(__file__).resolve().parent
BASE = str(_ROOT.parent)
sys.path.insert(0, BASE)
import bridge_injector
importlib.reload(bridge_injector)

STUBS = str(_ROOT / "stubs")
PY_DIR = str(_ROOT / "py")
RUN_DIR = str(_ROOT / "run")
os.makedirs(RUN_DIR, exist_ok=True)

# فایل‌هایی که تا پایان اجرا می‌شوند (بدونِ حلقهٔ بی‌نهایتِ بلاک‌کننده)
TARGETS = ["p1_basic_order_send.py", "p2_alias_multi.py", "p3_from_import.py",
           "p4_meta_run.py", "p6_class_method.py", "p7_meta_run_nested.py",
           "p11_advanced_layers.py", "p12_wildcard_async.py"]

env = dict(os.environ)
env["PYTHONPATH"] = STUBS + ":" + BASE   # استاب‌ها + robot_client_example واقعی

PASS = FAIL = 0
for name in TARGETS:
    src = open(f"{PY_DIR}/{name}", encoding="utf-8").read()
    out, _, _ = bridge_injector.patch_source(name, src, "http://127.0.0.1:8000", "")
    outp = f"{RUN_DIR}/{name}"
    open(outp, "w", encoding="utf-8").write(out)
    try:
        r = subprocess.run([sys.executable, outp], env=env, cwd=RUN_DIR,
                           capture_output=True, text=True, timeout=40)
        ok = (r.returncode == 0) and ("Traceback" not in r.stderr)
        bridge_fired = ("Bridge:" in r.stdout) or ("order_send" not in r.stderr)
    except subprocess.TimeoutExpired:
        ok, bridge_fired, r = False, False, None
    status = "PASS" if ok else "FAIL"
    if ok:
        PASS += 1
    else:
        FAIL += 1
    print(f"\n▶ {name}: RUNTIME {status} (exit={getattr(r,'returncode','?')})")
    if r is not None:
        tail_out = "\n".join([l for l in r.stdout.splitlines()
                              if "Bridge:" in l or "done" in l or "STUB" in l][:4])
        if tail_out:
            print("   stdout:", tail_out.replace("\n", " | "))
        if not ok and r.stderr:
            print("   STDERR:", r.stderr.strip().splitlines()[-3:])

print("\n" + "=" * 60)
print(f"RUNTIME RESULT: {PASS} passed, {FAIL} failed")
print("=" * 60)
sys.exit(1 if FAIL else 0)
